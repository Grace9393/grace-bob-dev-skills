Propose a change to the Service Manual - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Propose a change to the Service Manual
======================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [How we prioritise changes](#how-we-prioritise-changes)
2. [Your identity](#your-identity)
3. [Contact us](#contact-us)
4. [How we handle your data](#how-we-handle-your-data)

This form is for government staff to propose a change or addition to the [Service Manual](http://www.gov.uk/service-manual).

How we prioritise changes
-------------------------

We consider Service Manual changes against these criteria:

* how well it reflects good practice
* how time consuming it is to work on
* any risks involved
* the impact of the change

To help us make changes, we may ask you to provide evidence that the change:

* is needed
* has consensus
* is deliverable

Your identity
-------------

We ask for your contact details which must include:

* a government or public sector email address
* your job title
* details of the change you are proposing

We’ll verify that you’re government staff and reply to you.

Please give us as much information on the form as possible.

[Propose a change](https://submit.forms.service.gov.uk/form/2765/propose-a-change-to-the-service-manual)

Contact us
----------

### Email

Email us at: [service-manual@digital.cabinet-office.gov.uk](mailto:service-manual@digital.cabinet-office.gov.uk)

### Slack

Message us on the #servicemanual channel on the [cross-government Slack workspace](https://ukgovernmentdigital.slack.com/archives/C062HDSJU).

How we handle your data
-----------------------

Please refer to our [privacy notice](https://docs.google.com/document/d/1qgq94Kk4_Ab19VDzMkq50CsGMPciJ0bQZ_zh2ubC9zk/edit) for more information.

Updates to this page
--------------------

Published 22 May 2024

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---