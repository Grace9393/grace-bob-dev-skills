2. Solve a whole problem for users - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service Standard](service-manual_service-standard.md)

Service Standard

2. Solve a whole problem for users
==================================

Work towards creating a service that solves a whole problem for users, working with other teams and organisations where necessary.

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Why it's important](#why-its-important)
2. [What it means](#what-it-means)
3. [Related guidance](#related-guidance)
4. [Related blog posts](#related-blog-posts)
5. [Service standard points](#service-standard-points)

Why it’s important
------------------

Services that do not work well with other related services make it hard for users to do what they need to. For example, working out which of several similar schemes they’re eligible for or choosing the right form to fill in out of several near-identical options.

However we should be careful not to build big, complicated services that are not intuitive to use because they try to do too much.

And it does not mean trying to fix everything at once. Making incremental and frequent improvements benefits users.

Just make sure the increments are working towards bringing related content and services together into a journey that makes sense to users, irrespective of which department or team they ‘belong’ to. Because users should not have to understand how government works in order to use public services.

What it means
-------------

Service teams should:

* understand any genuine constraints that affect the service - for example, legislative constraints - and work with policy professionals to solve any problems those constraints are causing
* make sure services are scoped according to how users think and what they need to do - not too narrow or too broad
* be able to explain how the service the team is working on will join up with other things into a journey that solves a whole problem for users
* take responsibility for agreeing how this user journey will work with organisations responsible for different parts of it - for example, with the GDS content team to join up GOV.UK content with the service you’re working on
* consider alternatives to creating a service - for example publishing website content, running a campaign, partnering with a non-government organisation or making data or an Application Programming Interface (API) available to third parties
* work in the open so that people inside and outside the organisation know what the service team is doing - increasing the potential for collaboration and reducing duplication of effort (for example by publishing business cases, mission statements, research findings, user experience maps, maps of existing services and product roadmaps showing plans to develop new features)
* work towards minimising the number of times users have to provide the same information to government (while respecting users’ privacy), for example by using a single sign-on
* work with other teams and organisations where that’s necessary to solve a whole problem for users

Related guidance
----------------

[Scoping your service](https://www.gov.uk/service-manual/design/scoping-your-service)

[Developing a roadmap](https://www.gov.uk/service-manual/agile-delivery/developing-a-roadmap)

[Working across organisational boundaries](https://www.gov.uk/service-manual/agile-delivery/working-across-organisational-boundaries)

Related blog posts
------------------

[How service teams are solving a whole problem for users](https://services.blog.gov.uk/2022/03/16/how-service-teams-are-solving-a-whole-problem-for-users/)

Service standard points
-----------------------

[1. Understand users and their needs](https://www.gov.uk/service-manual/service-standard/point-1-understand-user-needs)

[2. Solve a whole problem for users](https://www.gov.uk/service-manual/service-standard/point-2-solve-a-whole-problem)

[3. Provide a joined up experience across all channels](https://www.gov.uk/service-manual/service-standard/point-3-join-up-across-channels)

[4. Make the service simple to use](https://www.gov.uk/service-manual/service-standard/point-4-make-the-service-simple-to-use)

[5. Make sure everyone can use the service](https://www.gov.uk/service-manual/service-standard/point-5-make-sure-everyone-can-use-the-service)

[6. Have a multidisciplinary team](https://www.gov.uk/service-manual/service-standard/point-6-have-a-multidisciplinary-team)

[7. Use agile ways of working](https://www.gov.uk/service-manual/service-standard/point-7-use-agile-ways-of-working)

[8. Iterate and improve frequently](https://www.gov.uk/service-manual/service-standard/point-8-iterate-and-improve-frequently)

[9. Create a secure service which protects users’ privacy](https://www.gov.uk/service-manual/service-standard/point-9-create-a-secure-service)

[10. Define what success looks like and publish performance data](https://www.gov.uk/service-manual/service-standard/point-10-define-success-publish-performance-data)

[11. Choose the right tools and technology](https://www.gov.uk/service-manual/service-standard/point-11-choose-the-right-tools-and-technology)

[12. Make new source code open](https://www.gov.uk/service-manual/service-standard/point-12-make-new-source-code-open)

[13. Use and contribute to open standards, common components and patterns](https://www.gov.uk/service-manual/service-standard/point-13-use-common-standards-components-patterns)

[14. Operate a reliable service](https://www.gov.uk/service-manual/service-standard/point-14-operate-a-reliable-service)

Updates to this page
--------------------

Published 8 May 2019

Last updated 30 May 2022
[+ show all updates](#full-history)

1. 30 May 2022

   Added links to related guidance and other standard points. There is no change to the content of the standard point itself.
2. 2 December 2021

   A number of minor changes to make the point easier to understand. There is no substantial change to what teams need to do.
3. 8 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---