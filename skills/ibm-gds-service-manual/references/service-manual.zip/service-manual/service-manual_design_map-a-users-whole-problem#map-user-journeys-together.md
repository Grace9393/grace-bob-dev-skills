Map and understand a user's whole problem - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Map and understand a user's whole problem
=========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Work out who else is involved in delivering a user journey](#work-out-who-else-is-involved-in-delivering-a-user-journey)
2. [Map user journeys together](#map-user-journeys-together)
3. [Work out what you need to change](#work-out-what-you-need-to-change)
4. [Put something in place to make sure those bigger changes get made](#put-something-in-place-to-make-sure-those-bigger-changes-get-made)

It’s important for teams to make sure the thing they’re building forms a coherent part of a user’s wider journey.

This is because what they’re working on is probably part of a bigger task that users are trying to complete. For instance, booking a theory test is just one part of learning to drive a car.

For users to complete complicated tasks like these successfully, all the different parts of the journey need to join up coherently. If they don’t, the user will get stuck and their journey breaks down.

To build things that join up coherently, teams need to understand what the user’s wider journey looks like. It’s probably not reasonable to expect individual delivery teams to build a detailed understanding of that themselves.

They can [scope their transactions in an intuitive way](service-manual_design_scoping-your-service.md), but they won’t have the time or resources to research and map the user’s whole journey in detail.

That’s an issue, because this work is very valuable. It can help you spot problems with the wider journey and make sure it’s user-centred from start to finish.

It also makes it easier for delivery teams to learn about what their users are trying to do, and to understand the journey they need to join up with.

So it might make sense to do this work at programme or organisation level instead. You could start by working out what your most important user journeys are and mapping them out in detail, one by one.

What you discover can help you prioritise what delivery teams should work on next.

It’s useful to do some work to [understand which services your organisation is responsible for](service-manual_design_create-a-list-of-services.md) before you start mapping anything. That can help you identify which user journey to work on first.

Work out who else is involved in delivering a user journey
----------------------------------------------------------

Complicated user journeys often cut across organisational boundaries. For instance, to become a childminder, you need to deal with Ofsted, HM Revenue and Customs (HMRC) and the Disclosure and Barring Service (DBS).

For journeys like this to join up in a way that makes sense, you’ll almost certainly need to collaborate with people in other organisations.

So start by working out who else you need to be talking to. A lo-fi way of doing this is to look at GOV.UK to see which organisations are publishing content on relevant subjects.

You could also do a more formal [stakeholder analysis exercise](https://www.smartsheet.com/what-stakeholder-analysis-and-mapping-and-how-do-you-do-it-effectively), which means working out things like who:

* needs to be most closely involved in the work
* might be hardest to engage with
* has information that will be valuable

It’s useful to get in touch with any relevant stakeholders before you move on to the next activity. That’s because the next step in the process involves mapping, which helps you understand how the journey is currently being delivered and the sorts of improvements you could make.

There’s guidance to help you [collaborate across organisational boundaries](service-manual_design_working-across-organisational-boundaries.md).

Map user journeys together
--------------------------

You want everyone involved in delivering the user journey to have the same understanding of what needs fixing. Collaborating on journey mapping is the easiest way to make this happen.

At this point, it’s worth considering whether it’s a good idea to [set up a service community](service-manual_design_service-communities.md). These are networks of people with different skills who work across organisations to deliver services that work well for users.

### Work out how the service looks from government’s perspective

When thinking about a user’s experience of a journey and what you might do to address any issues they face, it’s useful to understand how the journey is currently being delivered. This includes understanding any:

* online and offline touchpoints
* backend processes, and who’s involved in them
* evidence users have to provide to get through the journey

It’s good to present this information as a diagram, sometimes known as a [‘service landscape’](https://www.nngroup.com/articles/service-blueprints-definition/).

### Understand the journey from the user’s point of view

As well as building your service landscape, you should look at the journey from a user’s perspective.

Start by talking to your users to [learn more about the steps they have to take and the transactions involved](https://www.gov.uk/service-manual/user-research/contextual-research-and-observation).

What you learn should help you [put together an experience map](https://www.gov.uk/service-manual/user-research/creating-an-experience-map). The map should show which bits of the journey users are struggling with and the areas you might want to focus on improving.

Work out what you need to change
--------------------------------

Your service landscape and experience map should help you spot things that aren’t working as well as they could. These could be things like:

* dead ends in the user journey
* users not understanding whether they should use a particular transaction, or which one of several similar looking transactions they should use
* confusing or duplicative content
* online and offline elements of the transaction not joining up in an intuitive way

You’ll be able to fix some of these issues relatively easily, while others will take a bit more time and work.

### Identify the quicker wins

Start by fixing the stuff that’s cheaper and quicker to fix, so that you improve some things for users straight away. Once you’ve made the quicker fixes, you can start planning how to address the more difficult things.

Content changes tend to be cheap to make and deliver value to users quickly. So you could start by [improving your content](https://medium.com/@stephen.gill/practical-transformation-start-by-making-things-a-bit-less-rubbish-e89986adbeb1) or introducing something like [step-by-step navigation](https://design-system.service.gov.uk/patterns/step-by-step-navigation/) if you’re working on a linear journey.

### Show what bigger improvements might look like

As well as quick fixes, you’ll probably spot opportunities to make bigger improvements, or redesign elements of the user journey.

For example, you might see in research that users are confused because something they think of as a single task is spread across several transactions - and that it’d be more user-centred to bring them together into one transaction.

Or you might see that the journey’s breaking down when the user moves between channels and that slightly tweaking a letter makes it easier for the user to continue their journey online.

You can build an improved journey map that includes improvements like these and shows what the ideal user journey would look like.

It doesn’t need to be polished: it just needs to show how the journey might look if it was designed around what makes sense to users, rather than what makes sense to government.

Put something in place to make sure those bigger changes get made
-----------------------------------------------------------------

There’s no point spending time working out how an improved end-to-end user journey might look if those changes won’t ever get made.

One way to make sure problems get addressed is to turn your cross-organisational project team into something more formal and sustainable.

One way of doing this might be to join or start a service community.

The communities model can help you explain to stakeholders why the work you’re planning is important and address common collaboration challenges like governance. You can read more about [how to run a service community](service-manual_design_working-across-organisational-boundaries.md).

Your map showing what an improved version of the journey might look like could form the basis of a backlog for the community to work on.

Updates to this page
--------------------

Published 1 May 2019

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---