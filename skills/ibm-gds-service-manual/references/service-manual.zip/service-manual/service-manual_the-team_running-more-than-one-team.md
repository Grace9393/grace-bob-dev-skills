Running more than one service team - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

Running more than one service team
==================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Managing multiple teams](#managing-multiple-teams)
2. [Get your teams sitting together](#get-your-teams-sitting-together)
3. [Encourage cross-team standups](#encourage-cross-team-standups)
4. [Examples and case studies](#examples-and-case-studies)
5. [Related guides](#related-guides)

As soon as you have more than one team working on a service, you need to make sure they’re able to coordinate their plans, communicate progress and collaborate effectively using [agile methods](service-manual_agile-delivery_agile-methodologies.md).

This can mean a small increase in the amount of work, but do not lose sight of the aim to have self-organising, self-managing teams.

Managing multiple teams
-----------------------

Having more than one team does not mean you need more governance. Make sure you continue to follow the [governance principles for agile service delivery](service-manual_agile-delivery_governance-principles-for-agile-service-delivery.md) to keep it to a minimum.

As someone in a leadership or management role, you need to:

* make sure everyone understands the service vision and goals, especially new starters
* have teams plan together and think about what they’ll individually be responsible for
* look at splitting work by theme, product or features to minimise dependencies between teams
* think about whether it makes sense to share specialist people across teams, for example technical architects and people working in security, policy or finance

Delivery teams work best when they can control how they work. When you have multiple teams, it’s important that you do not force them to work in exactly the same way as each other.

Get your teams sitting together
-------------------------------

It’s better for multiple teams to be sitting in the same location, just as a single team benefits from this. When your teams do not sit together:

* there are communication difficulties
* there’s less informal communication and learning
* it’s harder to establish a shared culture

You can split teams across different shared locations if you cannot find a suitable space for all members, or people live and work in different parts of the country.

You can also use the following tools to help teams that do not have a shared space to communicate effectively and stay in touch at all times:

* video communication
* social media (including Slack, Hipchat, Yammer etc)
* regular face-to-face meetings

Encourage cross-team standups
-----------------------------

You can get team representatives together in regular cross-team [standups](service-manual_agile-delivery_agile-tools-techniques#daily-standup.md) (sometimes called a ‘standup of standups’). It’s helpful for delivery managers to attend these so they can:

* report on their team’s progress
* raise concerns about blockers
* find out about opportunities to help other teams
* learn from other delivery managers’ experiences

Cross-team standups should take place in front of a [shared team wall](service-manual_agile-delivery_team-wall.md), which is useful for making blockers and achievements visible. Walls also give people a sense of shared ownership and encourage them to discuss different aspects of your service.

Examples and case studies
-------------------------

You may find the following useful:

* [scaling for agile: a GDS blog post](https://gds.blog.gov.uk/2012/10/26/what-weve-learnt-about-scaling-agile/)
* [making clear goals for complex agile programmes: a GOV.UK Verify blog post](https://identityassurance.blog.gov.uk/2016/03/11/goals-cycles-and-people-running-an-agile-complex-programme-in-government/)

Related guides
--------------

You may also find these guides useful:

* [Recruit your team](service-manual_the-team_recruit-your-team.md)
* [Change the size of a service team](service-manual_the-team_change-size-of-service-team.md)

Updates to this page
--------------------

Published 3 March 2016

Last updated 24 March 2016
[+ show all updates](#full-history)

1. 24 March 2016

   Added agile working examples and case studies.
2. 6 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---