Encouraging people to use your service online - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Accessibility and assisted digital](service-manual_helping-people-to-use-your-service.md)

Accessibility and assisted digital

Encouraging people to use your service online
=============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Assisted digital and digital take-up community](service-manual_communities_assisted-digital-and-digital-take-up-community.md)

Contents
--------

1. [Find out why people don’t use your service online](#find-out-why-people-dont-use-your-service-online)
2. [Changing the way people access your service](#changing-the-way-people-access-your-service)
3. [Related guides](#related-guides)

The proportion of users choosing the digital service is known as the service’s ‘digital take up’. You must [measure your digital take up](service-manual_measuring-success_measuring-digital-take-up.md) and try to increase it.

Increasing digital take-up doesn’t mean expecting all your users to use the service online independently. You should provide [assisted digital support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md) for users who can’t or won’t use your service online, and include assisted digital users in your digital take up figures.

Don’t push users online by concealing offline contact details or limiting access to offline support. If a large number of users are choosing offline routes, you need to find out why and take informed action to change how they access your service.

Find out why people don’t use your service online
-------------------------------------------------

You should [do research with users who aren’t using your digital service](https://www.gov.uk/service-manual/user-research/understanding-users-who-dont-use-digital-services), to understand:

* their user journey - how they interact with your service, online or otherwise
* why they prefer to complete their task using non-digital methods

Use your findings to increase digital take-up or to improve offline channels if there’s a good reason people are using them.

Do research on users who:

* currently use your service or might use it in future
* need assisted digital support
* are currently choosing offline channels
* have stopped using your service because it’s online only

In your research, investigate whether any of your users:

* aren’t aware they can complete a task online
* don’t want to complete certain tasks online
* find online parts of your service too difficult to use
* don’t know how to get assisted digital support
* can’t access the internet
* don’t think online parts of your service are safe or will handle their data securely

Changing the way people access your service
-------------------------------------------

You should:

* promote the online service to users
* train assisted digital staff to improve users’ digital skills, confidence and trust
* encourage people to use more cost effective offline channels

### Promote your online service to users

Tell users that they can access your service online in ways that encourage them to use it, and in places where they’ll hear about it.

For example, you could:

* advertise (online and offline)
* promote the online service and assisted digital support options in the same places as the non-digital alternative - this reassures users that there is help for them if they need it
* prompt action, for example by signposting to a memorable URL that goes straight to the service
* communicate the benefits of using your service online - for example if it’s cheaper or quicker to use

Your research may show that users have particular concerns about doing things online. You should seek to directly address these concerns. For example, you can:

* design online parts of your service to be as trustworthy and reassuring as possible
* be clear about how you’re dealing with users’ security

### Train staff to improve users’ digital skills, confidence and trust

You should train support staff to use your online service so that they can:

* understand the potential benefits of using the service online
* encourage users to access the service online
* offer support if users need it

You should:

* make sure support staff are using the same version of the online service as users
* explain to staff the advantages of using the service online
* show staff how users use the service online, including how they get assisted digital support
* consider whether an increase in people using the service online could change how support staff need to do their job, and explain any changes

### Encourage people to use more cost effective offline channels

As well as helping users get online you should also try moving demand from more expensive offline channels to cheaper ones, as long as they’re still capable of meeting your users’ needs effectively. For example, you might promote your phone-based assisted digital service to users currently seeking face to face help.

Related guides
--------------

You may also find these guides useful:

* [Assisted digital support: an introduction](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)
* [Designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md)
* [How your assisted digital support will be assessed](service-manual_helping-people-to-use-your-service_how-your-assisted-digital-support-will-be-assessed.md)
* [Understanding users who don’t use digital services](service-manual_user-research_understanding-users-who-dont-use-digital-services.md)
* [Make your service accessible](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Making your service more inclusive](service-manual_design_making-your-service-more-inclusive.md)

Updates to this page
--------------------

Published 8 April 2016

Last updated 30 August 2018
[+ show all updates](#full-history)

1. 30 August 2018

   Made clear you should include your service's assisted digital users in your digital take up figures.
2. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---