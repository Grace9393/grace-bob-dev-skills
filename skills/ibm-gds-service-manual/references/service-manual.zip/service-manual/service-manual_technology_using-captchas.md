Using CAPTCHAs - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Using CAPTCHAs
==============

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (frontend development)](service-manual_communities_technology-community-frontend-development.md)

Contents
--------

1. [Why CAPTCHAs are problematic](#why-captchas-are-problematic)
2. [Alternatives to CAPTCHAs](#alternatives-to-captchas)
3. [Related guides](#related-guides)

[CAPTCHAs](https://en.wikipedia.org/wiki/CAPTCHA) are used to try and distinguish between humans and bots (automated software). They do this by having users perform a task to prove they’re human - for example, decipher and enter jumbled up text before submitting a form.

There are security, privacy, usability and accessibility issues associated with CAPTCHAs. You must not use them unless you both:

* limit their use to cases where you detect suspicious activity (for example, you detect bot-like behaviour and need to test whether the user is human)
* have evidence to show that alternative solutions will not work for your service

Why CAPTCHAs are problematic
----------------------------

CAPTCHAs will make your service more difficult for some people to use, including [disabled people](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction#think-about-accessibility-from-the-start.md).

Third-party CAPTCHA services could also introduce additional risks, including:

* security issues - if your provider’s security is compromised, your service and its users may also be affected
* privacy concerns - for example, third-party services might set cookies, collect analytics and track users across multiple sites
* performance issues - if you rely on a supplier, it means you’ll be affected by any performance problems or outages they experience

Your service could still be at risk, even with a CAPTCHA in place. Advances in computer imaging and the use of CAPTCHA farms means some bots will still be able to access your service.

Alternatives to CAPTCHAs
------------------------

Many of the risks that CAPTCHAs are aimed at reducing can be addressed in other ways including:

* [rate and connection limiting](https://en.wikipedia.org/wiki/Rate_limiting)
* [using honey pots](https://en.wikipedia.org/wiki/Honeypot_(computing))
* [transaction monitoring](https://www.gov.uk/service-manual/technology/monitoring-the-status-of-your-service)

You can discuss alternatives to CAPTCHAs with the [frontend community](https://www.gov.uk/service-manual/communities/technology-community-frontend-development).

Related guides
--------------

You may also find the following guides useful:

* [Protecting your service against fraud](service-manual_technology_protecting-your-service-against-fraud.md)
* [Working with cookies and similar technologies](service-manual_technology_working-with-cookies-and-similar-technologies.md)

Updates to this page
--------------------

Published 13 March 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---