Create accounts – GOV.UK Design System






[Skip to main content](#main-content)


[GOV.UK


Design System](/)

Search Design system
[Sitemap](/sitemap/)

Menu

* [Get started 
  + [Get started overview](/get-started/)
  + ### Setup guides

    - [Prototyping](/get-started/prototyping/)
    - [Production](/get-started/production/)
  + ### How to guides

    - [Making labels and legends headings](/get-started/labels-legends-headings/)
    - [Extending and modifying components in production](/get-started/extending-and-modifying-components/)
    - [Understanding focus state styles](/get-started/focus-states/)
    - [Updating your service to use the new type scale](/get-started/new-type-scale/)](/get-started/)
* [Styles 
  + [Styles overview](/styles/)
  + ### Page structure

    - [Page template](/styles/page-template/)
    - [Layout](/styles/layout/)
    - [Spacing](/styles/spacing/)
    - [Section break](/styles/section-break/)
  + ### Typography

    - [Typeface](/styles/typeface/)
    - [Type scale](/styles/type-scale/)
    - [Headings](/styles/headings/)
    - [Paragraphs](/styles/paragraphs/)
    - [Links](/styles/links/)
    - [Lists](/styles/lists/)
    - [Font override classes](/styles/font-override-classes/)
  + ### Visual elements

    - [Colour](/styles/colour/)
    - [Images](/styles/images/)](/styles/)
* [Components 
  + [Components overview](/components/)
  + - [Accordion](/components/accordion/)
    - [Back link](/components/back-link/)
    - [Breadcrumbs](/components/breadcrumbs/)
    - [Button](/components/button/)
    - [Character count](/components/character-count/)
    - [Checkboxes](/components/checkboxes/)
    - [Cookie banner](/components/cookie-banner/)
    - [Date input](/components/date-input/)
    - [Details](/components/details/)
    - [Error message](/components/error-message/)
    - [Error summary](/components/error-summary/)
    - [Exit this page](/components/exit-this-page/)
    - [Fieldset](/components/fieldset/)
    - [File upload](/components/file-upload/)
    - [GOV.UK footer](/components/footer/)
    - [GOV.UK header](/components/header/)
    - [Inset text](/components/inset-text/)
    - [Notification banner](/components/notification-banner/)
    - [Pagination](/components/pagination/)
    - [Panel](/components/panel/)
    - [Password input](/components/password-input/)
    - [Phase banner](/components/phase-banner/)
    - [Radios](/components/radios/)
    - [Select](/components/select/)
    - [Service navigation](/components/service-navigation/)
    - [Skip link](/components/skip-link/)
    - [Summary list](/components/summary-list/)
    - [Table](/components/table/)
    - [Tabs](/components/tabs/)
    - [Tag](/components/tag/)
    - [Task list](/components/task-list/)
    - [Text input](/components/text-input/)
    - [Textarea](/components/textarea/)
    - [Warning text](/components/warning-text/)](/components/)
* [**Patterns 
  + [Patterns overview](/patterns/)
  + ### Ask users for…

    - [Addresses](/patterns/addresses/)
    - [Bank details](/patterns/bank-details/)
    - [Dates](/patterns/dates/)
    - [Email addresses](/patterns/email-addresses/)
    - [Equality information](/patterns/equality-information/)
    - [Names](/patterns/names/)
    - [National Insurance numbers](/patterns/national-insurance-numbers/)
    - [Passwords](/patterns/passwords/)
    - [Payment card details](/patterns/payment-card-details/)
    - [Phone numbers](/patterns/phone-numbers/)
  + ### Help users to…

    - [Check a service is suitable](/patterns/check-a-service-is-suitable/)
    - [Check answers](/patterns/check-answers/)
    - [Complete multiple tasks](/patterns/complete-multiple-tasks/)
    - [Confirm a phone number](/patterns/confirm-a-phone-number/)
    - [Confirm an email address](/patterns/confirm-an-email-address/)
    - [Contact a department or service team](/patterns/contact-a-department-or-service-team/)
    - [Create a username](/patterns/create-a-username/)
    - [Create accounts](/patterns/create-accounts/)
    - [Exit a page quickly](/patterns/exit-a-page-quickly/)
    - [Navigate a service](/patterns/navigate-a-service/)
    - [Start using a service](/patterns/start-using-a-service/)
    - [Recover from validation errors](/patterns/validation/)
  + ### Pages

    - [Confirmation pages](/patterns/confirmation-pages/)
    - [Cookies page](/patterns/cookies-page/)
    - [Page not found pages](/patterns/page-not-found-pages/)
    - [There is a problem with the service pages](/patterns/problem-with-the-service-pages/)
    - [Question pages](/patterns/question-pages/)
    - [Service unavailable pages](/patterns/service-unavailable-pages/)
    - [Step by step navigation](/patterns/step-by-step-navigation/)**](/patterns/)
* [Community 
  + [Community overview](/community/)
  + ### What we’re working on

    - [Upcoming components and patterns](/community/upcoming-components-patterns/)
    - [Roadmap](/community/roadmap/)
  + ### Ways to get involved

    - [Share findings about your users](/community/share-research-findings/)
    - [Propose a component or pattern](/community/propose-a-component-or-pattern/)
    - [Develop a component or pattern](/community/develop-a-component-or-pattern/)
    - [Propose a content change using GitHub](/community/propose-a-content-change-using-github/)
  + ### How we work

    - [Community principles](/community/community-principles/)
    - [Contribution criteria](/community/contribution-criteria/)
    - [Design System working group](/community/design-system-working-group/)
    - [Blog posts, videos and podcasts](/community/blogs-talks-podcasts/)
  + ### Resources

    - [Resources and tools](/community/resources-and-tools/)
  + ### Events and workshops

    - [Design System Day Events](/community/design-system-day/)
    - [Design System Day 2022](/community/design-system-day-2022/)
    - [Design System Day 2023](/community/design-system-day-2023/)
    - [Design System Day 2024](/community/design-system-day-2024/)
    - [Code of Conduct](/community/code-of-conduct/)](/community/)
* [Accessibility 
  + [Accessibility overview](/accessibility/)
  + - [Accessibility strategy](/accessibility/accessibility-strategy/)](/accessibility/)

Pages in this section
---------------------

### Ask users for…

* [Addresses](/patterns/addresses/)
* [Bank details](/patterns/bank-details/)
* [Dates](/patterns/dates/)
* [Email addresses](/patterns/email-addresses/)
* [Equality information](/patterns/equality-information/)
* [Names](/patterns/names/)
* [National Insurance numbers](/patterns/national-insurance-numbers/)
* [Passwords](/patterns/passwords/)
* [Payment card details](/patterns/payment-card-details/)
* [Phone numbers](/patterns/phone-numbers/)

### Help users to…

* [Check a service is suitable](/patterns/check-a-service-is-suitable/)
* [Check answers](/patterns/check-answers/)
* [Complete multiple tasks](/patterns/complete-multiple-tasks/)
* [Confirm a phone number](/patterns/confirm-a-phone-number/)
* [Confirm an email address](/patterns/confirm-an-email-address/)
* [Contact a department or service team](/patterns/contact-a-department-or-service-team/)
* [Create a username](/patterns/create-a-username/)
* [Create accounts](/patterns/create-accounts/)
* [Exit a page quickly](/patterns/exit-a-page-quickly/)
* [Navigate a service](/patterns/navigate-a-service/)
* [Start using a service](/patterns/start-using-a-service/)
* [Recover from validation errors](/patterns/validation/)

### Pages

* [Confirmation pages](/patterns/confirmation-pages/)
* [Cookies page](/patterns/cookies-page/)
* [Page not found pages](/patterns/page-not-found-pages/)
* [There is a problem with the service pages](/patterns/problem-with-the-service-pages/)
* [Question pages](/patterns/question-pages/)
* [Service unavailable pages](/patterns/service-unavailable-pages/)
* [Step by step navigation](/patterns/step-by-step-navigation/)

1. [Home](/)
2. [Patterns](/patterns)


Help users to
Create accounts
=============================

When to use this pattern
------------------------

Provide user accounts if your users will need to regularly access or update their data in your service.

When not to use this pattern
----------------------------

Do not create user accounts if you can provide a usable service without them.

This is because user accounts are:

* a barrier for many users and make it more likely they will drop out
* difficult to build and maintain

If you want to let users check the status of a one-off transaction, give them a unique reference number they can use along with their name or email address.

Unique references are hard to remember so you should send them in an email or text message to the user.

How it works
------------

If a user needs an account as part of your service:

* let them use as much of your service as possible before they need to create an account
* use clear and consistent language
* create a simple user journey
* make the sign-up process clear

### Use clear and consistent language

For consistency with other GOV.UK services, use the phrase ‘Create an account’ instead of ‘Register’, ‘Sign up’ or something else.

Use labels like ‘Create a username’ and ‘Create a password’ rather than ‘Username’ and ‘Password’. This helps users to understand that they’re not being asked to enter an existing username or password.

### Create a simple user journey

Make it clear what you need users to do when they create an account.

Show a clear difference between creating an account and signing in. Presenting the options side by side is not enough because users might miss one of them or not understand the difference.

### Make the sign-up process clear

If a user fails to create an account they might not be able to use your service at all.

Make sure the account creation screen is solely about that task. Do not add any distracting content or links.

Make sure users do not need to enter the same information more than once when creating an account.

### Avoid using security measures such as CAPTCHAs

CAPTCHAs and similar tests require users to recognise words or pictures.

These are tests of cognitive function, which might be difficult for some users. Users can also struggle to recognise specific words or pictures due to differences in culture and locale.

See more about [using CAPTCHAs and why they’re problematic](https://www.gov.uk/service-manual/technology/using-captchas) in the Service Manual. [WCAG lists some other security measures](https://www.w3.org/WAI/WCAG22/Understanding/accessible-authentication-minimum#object-recognition) you can implement to prevent misuse and automated abuse in your service.

### Never use National Insurance numbers to verify a user’s identity

If you currently use National Insurance numbers to verify identity, find out how to [protect your service against fraud](https://www.gov.uk/service-manual/technology/protecting-your-service-against-fraud).

Help improve this pattern
-------------------------

To help make sure that this page is useful, relevant and up to date, you can:

* take part in the
  [‘Create accounts’ discussion on GitHub](https://github.com/alphagov/govuk-design-system-backlog/issues/41)
  and share your research
* [propose a change on GitHub](https://github.com/alphagov/govuk-design-system/edit/main/src/patterns/create-accounts/index.md)
  – read more about
  [how to propose changes in GitHub](/community/propose-a-content-change-using-github/)

Need help?
----------

If you’ve got a question about the GOV.UK Design System, [contact the team](/get-in-touch/).

[Back to top](#top)