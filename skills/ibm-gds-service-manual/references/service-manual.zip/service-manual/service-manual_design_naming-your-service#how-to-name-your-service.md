Naming your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Naming your service
===================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [When to name your service](#when-to-name-your-service)
2. [How to name your service](#how-to-name-your-service)
3. [Examples of service names](#examples-of-service-names)
4. [Check how the name is performing](#check-how-the-name-is-performing)

The name you choose for your service is important to its success.

Picking the right name means that users can:

* find your service more easily when they search online
* understand what your service does and easily decide whether to use it

When to name your service
-------------------------

You should try to name your service by the end of the discovery phase. By this stage you should have:

* defined the problem you’re trying to solve
* learned more about the context of the task your users are trying to do

How to name your service
------------------------

Good service names:

* use the words users use
* are based on analytics and user research
* describe a task, not a technology
* do not need to change when policy or technology changes
* [are verbs, not nouns](https://designnotes.blog.gov.uk/2015/06/22/good-services-are-verbs-2/)
* do not include government department or agency names
* are not brand-driven or focused on marketing

### Problems with naming your service

If you’re having problems naming your service, it might be because you have not scoped your service correctly. In this case, you should review your [user needs](service-manual_user-research_start-by-learning-user-needs.md) and carry out [user research](service-manual_user-research.md) on the task that users are trying to do.

You might want to expand or reduce the scope of your service if it covers several related services (for example, if it’s a tax or grant service).

Examples of service names
-------------------------

You can use these service names as good examples:

* Register to vote
* Get help with court fees
* Renew your passport
* Find an apprenticeship

### The register to vote service

Before the register to vote service was created, it was known internally as Individual Electoral Registration System.

### The get help with court fees service

The get help with court fees service was originally called fee remission.

After doing research with users and court staff, the service team found the name was confusing people. This made the service harder for users to understand and more expensive to deliver.

Check how the name is performing
--------------------------------

You should check how your service’s name performs both before and after going live.

### Use research and testing

You should use research and testing to check that the name of your service allows users to quickly recognise what it does.

You can use [tree testing](https://en.wikipedia.org/wiki/Tree_testing) to see if users can:

* navigate from a home page to your service
* distinguish your service from other related services

### Review search terms

Check search data to find out what terms users search for that relate to your service.

You can also ask the [user research community](https://www.gov.uk/service-manual/communities/user-research-community) for help. They may be able to share research which helps you categorise your service and use the right words to name it.

### Using metrics

You can review metrics to get an idea of how a service name is performing. For example, you can check:

* page views from organic search
* click-through rate to a ‘start’ button
* external search volumes for the old and new name
* reduced number of on-page searches about the service
* number of users calling to ask ‘How do I… ?’

Updates to this page
--------------------

Published 18 October 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---