Find agile training, learning and support - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

Find agile training, learning and support
=========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Civil Service Learning](#civil-service-learning)
2. [Agile training for delivery managers and scrum masters](#agile-training-for-delivery-managers-and-scrum-masters)
3. [Agile training for other team roles and stakeholders](#agile-training-for-other-team-roles-and-stakeholders)
4. [Agile coaching](#agile-coaching)
5. [Learn from other teams](#learn-from-other-teams)
6. [Bring knowledge into your team](#bring-knowledge-into-your-team)
7. [Find support and share ideas](#find-support-and-share-ideas)
8. [How to start out](#how-to-start-out)

Training and coaching will give you the basics of some [agile delivery techniques](service-manual_agile-delivery_agile-tools-techniques.md), but the real learning comes from putting it into practice.

It’s also important that your team and organisation’s culture is set up to support learning and experimenting.

Civil Service Learning
----------------------

If you’re a civil servant, you can also find agile and digital training courses through [Civil Service Learning](https://learn.civilservice.gov.uk/).

Agile training for delivery managers and scrum masters
------------------------------------------------------

There are many different approaches to agile delivery management, so it’s good to learn a number of tools and techniques. You should also strengthen your understanding with independent learning and doing.

You should consider your own learning needs before booking a course, but it’s helpful to learn about:

* specific frameworks and methods: start with lightweight frameworks and methodologies such as Scrum, Kanban and extreme programming
* more specific practices such as agile user stories, agile estimating, agile planning and managing teams
* softer skills, such as workshop facilitation, coaching and motivating teams

Agile training for other team roles and stakeholders
----------------------------------------------------

If you need to find out more about agile and how it relates to your role, book a course that gives you an introduction to agile and covers its benefits. Make sure that it’s a course that covers more than one method or framework.

Agile coaching
--------------

Part of a delivery manager or scrum master’s role is to be an agile coach, training the team, organisation and stakeholders in the benefits of agile working.

### Book agile coach training

If you’re a civil servant, find and book an agile course through [Civil Service Learning](https://learn.civilservice.gov.uk/).

### Hire an agile coach

Sometimes it can be helpful to bring in an agile coach, especially in an organisation new to agile, where an agile coach can:

* train teams and organisations in agile working
* help organisational change
* help stakeholder engagement

You can [use the Digital Marketplace to buy a service or find a skill](https://www.digitalmarketplace.service.gov.uk/).

Learn from other teams
----------------------

You can learn a lot by watching other people practising agile techniques in your organisation or in other government organisations.

Ask an agile team if you can sit in on their planning, review and retrospective meetings.

There are [communities of practice](service-manual_communities.md) for all agile disciplines where you can find teams and people.

Bring knowledge into your team
------------------------------

It’s important to bring knowledge into your team, especially from external contractors, for example by:

* shadowing
* pairing
* mentoring

When you hire contractors and suppliers, you should make sure they’re prepared to do this.

### Shadowing

Try to spend some time working with people who use agile. This will give you a better understanding of how they solve problems and use agile methods.

You could invite speakers to share their experiences with you and your team and discuss your ideas with them.

### Pairing

Pairing comes from the term ‘pair programming’ in [extreme programming](https://en.wikipedia.org/wiki/Extreme_programming), but is just as relevant for all types of work and job role.

During this practice 2 people will sit together to work on the same thing at the same time. One person is writing the code or doing the task, and the other is observing and giving input. The benefits of working in this way are:

* better quality of work
* better communication among team members
* you learn hands-on how something is built and why decisions were made

Pairing can rapidly increase individual and team learning.

### Mentoring

This works by pairing a new or less experienced team member (mentee) with someone with more or different experience (mentor). There is an ongoing relationship where the mentor:

* regularly meets with the mentee
* is freely available for advice and coaching
* allows the mentee to shadow and attend networking opportunities

Find support and share ideas
----------------------------

A fundamental principle of agile is finding things out for yourself and sharing knowledge.

Part of this is by asking questions and visiting other teams. But you can also gain more knowledge through learning by:

* joining cross-government digital communities
* attending events and networking
* reading widely (including blogs)
* coaching others and sharing your knowledge

### Networking and events

Networking is a useful way of learning. You can [find local meetups and events](http://www.meetup.com/) close to you or you can start your own.

### Blogs

There are many blogs and blog posts about agile and lean techniques, for example:

* [the Mountain Goat Software blog](https://www.mountaingoatsoftware.com/blog)
* [Explaining the role of a delivery manager](https://emilywebber.co.uk/what-is-an-agile-delivery-manager/) by Emily Webber
* [Relationship between a product manager and a delivery manager](https://medium.com/@abisola/relationship-between-a-product-manager-and-a-delivery-manager-9e5138b587b6) by Abisola Fatokun
* [It takes two - a post about the the split of responsibilities between product and delivery managers](https://digitalbydefault.com/2020/05/06/it-takes-two/) by Matt Jukes
* [The Delivery Manager’s Learning List](https://digitalpeople.blog.gov.uk/2020/05/15/how-i-co-created-the-delivery-managers-learning-list/) by Myles Jarvis collects together many more recommended blogs, articles and learning resources.

Digital teams in government also publish blogs that can give you real examples of a particular agile team or challenge, for example:

* [Ministry of Justice’s MOJ Digital](https://mojdigital.blog.gov.uk/)
* [Home Office Digital](https://hodigital.blog.gov.uk/)
* [Department of Work and Pensions’ Digital DWP](https://digitaldwp.blog.gov.uk/)

[Find more GOV.UK blogs](https://www.blog.gov.uk/)

How to start out
----------------

The phrase ‘fail fast’ is often used in an agile context, especially when building software.

While failure can be seen as a negative thing, the point is that you’re detecting problems as early as possible.

Take a project that you’re working on and start to apply agile techniques to it, then improve on them as you go.

Updates to this page
--------------------

Published 22 February 2016

Last updated 27 April 2021
[+ show all updates](#full-history)

1. 27 April 2021

   Added links to GDS Academy courses, updated links to Civil Service Learning, updated example blogs and blog posts.
2. 7 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---