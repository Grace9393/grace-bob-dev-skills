Technology community (technical architecture) - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Technology community (technical architecture)
=============================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Join the community](#join-the-community)
3. [Resources](#resources)
4. [Technical architecture in the Service Manual](#technical-architecture-in-the-service-manual)

The cross-government technical architecture community exists to:

* share knowledge and information about technical architecture for government services
* discuss and challenge the way technical architecture works for government services
* bring together people from across government with an interest in technical architecture

Who the community is for
------------------------

You might be interested in this community if you’re involved in any aspect of technical architecture, for example:

* choosing technology (eg languages, frameworks or software) for a service
* giving technology advice and being the technical voice in conversations about service design
* making a service secure
* testing the security and performance of a service

You do not need to be a technical architect to join.

Join the community
------------------

### Online

Join the [UK government Slack](https://ukgovernmentdigital.slack.com/), which has several technology-related channels (you can create a Slack account using your government email address).

### Training and events

The community holds regular:

* cross-government architecture lunches
* cross-government architecture drinks

These alternate on a monthly basis.

You can find information about meetups in the technical architects Google group.

Resources
---------

The [technology in government blog](https://technology.blog.gov.uk/) documents how technologists across government are building, assembling and running digital and technology projects.

Technical architecture in the Service Manual
--------------------------------------------

These guides show what we currently believe to be best practice for technical architecture in government:

* [Choosing your technology: an introduction](service-manual_technology_choosing-technology-an-introduction.md)
* [Making source code open and reusable](service-manual_technology_making-source-code-open-and-reusable.md)
* [Using HTTPS](service-manual_technology_using-https.md)
* [Exploratory testing](service-manual_technology_exploratory-testing.md)
* [Quality assurance: testing your service regularly](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* [Test your service’s performance](service-manual_technology_test-your-services-performance.md)
* [Moving away from legacy systems](service-manual_technology_moving-away-from-legacy-systems.md)
* [Working with open standards](service-manual_technology_working-with-open-standards.md)
* [Protecting your service against fraud](service-manual_technology_protecting-your-service-against-fraud.md)
* [How to email your users](service-manual_technology_how-to-email-your-users.md)
* [Working with cookies and similar technologies](service-manual_technology_working-with-cookies-and-similar-technologies.md)
* [Securing your information](service-manual_technology_securing-your-information.md)
* [Securing your cloud environment](service-manual_technology_securing-your-cloud-environment.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Updates to this page
--------------------

Published 23 May 2016

Last updated 1 June 2018
[+ show all updates](#full-history)

1. 1 June 2018

   Removed link to technical architects Google group, which no longer exists.
2. 5 August 2016

   Added guide to 'Moving away from legacy systems'.
3. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---