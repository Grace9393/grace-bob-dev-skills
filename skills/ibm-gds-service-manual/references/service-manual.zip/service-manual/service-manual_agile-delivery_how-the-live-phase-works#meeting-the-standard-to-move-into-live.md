How the live phase works - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

How the live phase works
========================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Running your service during live](#running-your-service-during-live)
2. [Meeting the standard to move into live](#meeting-the-standard-to-move-into-live)
3. [Other things to consider before you move into live](#other-things-to-consider-before-you-move-into-live)
4. [When you need to retire your service](#when-you-need-to-retire-your-service)
5. [Related guides](#related-guides)

The live phase is about supporting the service in a sustainable way, and continuing to iterate and make improvements. You’ll also:

* continue to address any constraints you identified at beta
* continue to develop the service and work with other organisations providing services that are part of the same journey, so that you’re iterating towards solving a whole problem for users
* transition or integrate any existing transactions that meet a similar need to yours - making sure that what you end up with has a [scope that makes sense to users](https://www.gov.uk/service-manual/design/scoping-your-service)

You’ll have your live assessment at the end of the public beta phase. Spend public beta preparing for live.

You can [download a poster that explains what the live phase is for](https://github.com/eliothill/service-design-posters).

Running your service during live
--------------------------------

You’ll need to work out [how to run your service sustainably](https://www.gov.uk/service-manual/agile-delivery/running-your-service-in-a-sustainable-way) during live. This does not necessarily mean having an agile team on the service 100% of the time. Spend time during public beta working out what level of continuous improvement it makes sense to support, and [who you’ll need on the team](https://www.gov.uk/service-manual/the-team/set-up-a-service-team).

As in beta, improvements you make during live should be:

* based on [user research](https://www.gov.uk/service-manual/user-research/user-research-in-live)
* tested to make sure they work with different [browsers and devices](service-manual_technology_designing-for-different-browsers-and-devices.md)
* [tested for accessibility](https://www.gov.uk/service-manual/technology/testing-for-accessibility)
* [quality assured](service-manual_technology_quality-assurance-testing-your-service-regularly.md)

You should also make sure you are clear on the effects that changes will have on offline channels, or any related services - and make sure none of your changes will have a negative impact.

You’ll also need to spend time during public beta [reviewing the performance metrics you set](https://www.gov.uk/service-manual/measuring-success) to check the data you’re collecting will tell you whether your service is performing as it should.

Meeting the standard to move into live
--------------------------------------

Before the service moves into the live phase, you’ll need to show that you’ve used the beta phase to build a service that meets the needs you identified at discovery and alpha, testing and iterating based on what you learn.

### Solving a whole problem for users

Once you’re in live, you’ll need to continue to develop your service so it forms an intuitive part of the user’s wider journey.

This means continuing to work with teams responsible for related services, and continuing to address any constraints affecting how you can iterate the service.

During public beta, start putting a [roadmap](https://www.mindtheproduct.com/2018/09/product-roadmaps-in-five-easy-pieces/) together for this work. Items in your roadmap should be ambitious, at the level of things like:

* continuing to make sure that [transactions are scoped in a way that makes sense to users](https://www.gov.uk/service-manual/design/scoping-your-service)
* starting a service community (or joining an existing one) to support others working in your problem space
* continuing to address any constraints you identified at beta (for example, with [legacy technology](https://www.gov.uk/service-manual/technology/moving-away-from-legacy-systems))

### Providing a joined up experience across channels

Before you move into live, you’ll need to make sure the people who support your users understand the online part of the service.

This might involve things like updating call centre scripts, providing training or finding a way for operations staff to walk through or familiarise themselves with the service.

Other things to consider before you move into live
--------------------------------------------------

Before the service goes live, you’ll also need to make sure:

* you’re [securing the service’s information](service-manual_technology_securing-your-information.md)
* you’ve got appropriate metrics in place to [measure the success of the service](service-manual_measuring-success.md), based on what you’ve learned during beta
* the service meets [accessibility requirements](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* you’re able to [maintain uptime and availability](service-manual_technology_uptime-and-availability-keeping-your-service-online.md) and [monitor the status of the service](service-manual_technology_monitoring-the-status-of-your-service.md)
* you’re able to continue with [vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* you’re able to continue [testing service performance](service-manual_technology_test-your-services-performance.md)
* you’re able to maintain [quality assurance](https://www.gov.uk/service-manual/technology/quality-assurance-testing-your-service-regularly)
* you have addressed, or have plans to address, any [pain points that might lead to people being excluded](service-manual_design_making-your-service-more-inclusive.md)

If you’ve created any new design patterns - or learned anything useful about an existing design pattern - you should share what you’ve learned through the [GOV.UK Design System](https://design-system.service.gov.uk/).

When you need to retire your service
------------------------------------

You need to [retire your service](https://www.gov.uk/service-manual/agile-delivery/retiring-your-service) if you find out users do not need it anymore - or that so few users need it that it’s not cost effective to keep running it in its current form.

Related guides
--------------

You may find these guides useful:

* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [How the alpha phase works](service-manual_agile-delivery_how-the-alpha-phase-works.md)
* [How the beta phase works](service-manual_agile-delivery_how-the-beta-phase-works.md)
* [Retiring your service](service-manual_agile-delivery_retiring-your-service.md)

Updates to this page
--------------------

Published 4 August 2016

Last updated 8 May 2019
[+ show all updates](#full-history)

1. 8 May 2019

   Updated to match the requirements outlined in the new standard.
2. 3 October 2017

   Added guidance on how to meet government accessibility requirements in live.
3. 3 April 2017

   Added the need to continue doing user research in live.
4. 4 August 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---