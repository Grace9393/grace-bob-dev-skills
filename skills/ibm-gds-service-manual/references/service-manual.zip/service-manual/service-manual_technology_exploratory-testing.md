Exploratory testing - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Exploratory testing
===================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (backend development)](service-manual_communities_technology-community-backend-development.md)

Contents
--------

1. [The value of exploratory testing](#the-value-of-exploratory-testing)
2. [Who does exploratory testing](#who-does-exploratory-testing)
3. [When to do exploratory testing](#when-to-do-exploratory-testing)
4. [How to do exploratory testing](#how-to-do-exploratory-testing)
5. [Reporting an exploratory test](#reporting-an-exploratory-test)
6. [Tools for exploratory testing](#tools-for-exploratory-testing)
7. [Related guides](#related-guides)

The goal of exploratory testing is to explore a system as a user would, without a script to test a predetermined outcome.

The tester is not looking into anything specific. Instead they use their knowledge, experience and intuition to check a system - possibly finding new defects as they go.

The value of exploratory testing
--------------------------------

Exploratory testing:

* detects subtle or complex bugs in a system (that are not detected in targeted testing)
* provides user-oriented feedback to the team

Exploratory testing aims to find new and undiscovered problems. It contrasts with other more prescribed methods of testing, such as test automation, which aims to show scripted tests can complete successfully without defects.

Done well, exploratory testing will help you write new automated tests to ensure that problems aren’t repeated.

Who does exploratory testing
----------------------------

Exploratory testing is ideally performed by experienced testers (eg quality assurance testers) as they tend to have:

* analytical skills
* an ability to behave like users
* a knack for finding defects

Providing they have the necessary testing skills, other people that might be good at running exploratory tests include:

* business analysts
* product managers
* subject matter experts

These people tend to know what a system should be able to do, and are therefore well suited to testing it.

When to do exploratory testing
------------------------------

Exploratory testing works best on a system that has enough functionality for you to interact with it in a meaningful way. This could be before you release your first minimum viable product in beta or before you release a major new feature in your service.

How to do exploratory testing
-----------------------------

Exploratory testing may sound ad hoc, but it is a disciplined approach and requires specific techniques. You should:

* state a goal for each testing session
* document all your queries and observations during the testing session - capture the evidence as notes, screenshots and log files so that the testing can replicated or investigated further
* note down ideas for further testing

An exploratory test that discovers a bug can be developed into a test scenario and automated.

To achieve best results during exploratory testing, apply the techniques of:

* test charters
* mind maps
* timeboxing

### Test charters

Test charters give exploratory testing sessions a mission without being prescriptive. A charter won’t detail which problems you’re looking for, but it can outline:

* which parts of the system you’ll be looking at (also known as your mission scope)
* your testing goals (eg making sure a system is secure enough for people to use)
* who is testing the system
* when and where the testing is taking place
* the test environment (eg the software you’ll use to do your tests)
* any test data you’re using (eg a mock username or password)

### Mind maps

Some testers use mind maps to document exploratory testing.

Mind mapping is a visual thinking tool that involves organising information in a diagram, instead of writing it in sentences.

Mind maps suit exploratory testing because they’re quick and easy to record and don’t follow a linear approach.

### Timeboxing

Timeboxing your session (or setting a time limit) can help you focus on specific goals rather than drift into unfocused exploration.

Setting a limit can be useful because exploratory testing is unscripted and unpredictable, following an ‘inspect and adapt’ model (where the next test you do is based on the previous test results).

Read more about these techniques in [Session-based test management](http://www.satisfice.com/sbtm) by Jonathan Bach.

Reporting an exploratory test
-----------------------------

Depending on what you’re testing and who you need to share the results with, you might want to document:

* a charter
* the features you’ve tested
* notes on how you conducted the testing
* notes on any bugs you found
* a list of issues (questions and concerns about the product or project that arose during testing)
* extra materials you used to support testing

You can also report how much of the exploratory testing session you spent on each different activity, including:

* creating and executing tests
* investigating and reporting bugs
* setting up the session

Tools for exploratory testing
-----------------------------

There are many different tools you can use for exploratory testing, eg fully automated video capture and logging tools, planning tools, or walls full of process diagrams and feature descriptions.

However the only tools you really need are a pen and some paper. Other tools are nice to have but don’t put off your testing if you don’t have access to them.

Related guides
--------------

You may also find these guides useful:

* [Quality assurance: testing your service regularly](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [Test your service’s performance](service-manual_technology_test-your-services-performance.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* [Testing for accessibility](service-manual_technology_testing-for-accessibility.md)

Updates to this page
--------------------

Published 23 May 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---