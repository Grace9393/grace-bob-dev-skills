Using in-depth interviews - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Using in-depth interviews
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to use in-depth interviews](#when-to-use-in-depth-interviews)
2. [Steps to follow](#steps-to-follow)
3. [Examples and case studies](#examples-and-case-studies)
4. [Related guides](#related-guides)

In-depth interviews help you learn more about different types of users, their circumstances, how they use a service and what they need from it to get the right outcome for them.

When to use in-depth interviews
-------------------------------

In-depth interviews are helpful when you want to:

* learn more about your users and relevant aspects of their lives and work
* get a deeper understanding of any problems that users tell you about

You can combine in-depth interviews with [moderated usability testing](service-manual_user-research_using-moderated-usability-testing.md) by talking to participants before asking them to try out a prototype or service.

Steps to follow
---------------

Plan your in-depth interviews carefully so you get results that can help improve your service.

### Plan the sessions

You normally do in-depth interviews with one user at a time. You can also speak to people in pairs or small groups if they use a service together (for example, family members who help each other or members of a team who work together on tasks).

Interviews can take between 30 minutes and 2 hours, depending on the complexity of the subject and number of questions you have. Longer interviews will give you more detail but make it harder to recruit participants.

When planning your sessions, you’ll need to:

* [choose a location for your research](service-manual_user-research_choose-a-location-for-user-research.md) - interviews can take place almost anywhere, including a user’s home or workplace, at a neutral place like a research studio, café or public library, or remotely by phone or video call
* [recruit research participants](service-manual_user-research_find-user-research-participants.md) - these should be current or likely users of the service you’re researching
* make sure the venue is accessible to the people you want to see
* arrange for interpreters or assistants to help participants that need them
* decide if and how you want to [record the sessions](service-manual_user-research_taking-notes-and-recording-user-research-sessions.md)
* invite observers and [arrange a note-taker for each session](service-manual_user-research_taking-notes-and-recording-user-research-sessions.md)

### Design the interview

To create a structure that works well:

* review the research questions you’re trying to answer
* think about any processes or technology you want to see
* write a list of the topics you want to cover
* order the topics to create a logical flow

For each topic:

* write starter questions to introduce the topic
* add possible follow-up questions you might ask to learn more
* test your questions and structure by interviewing a colleague - revise any questions that aren’t clear and re-order your topics if the interview doesn’t flow well

Once you’re happy, create a ‘discussion guide’. This should include:

* your introduction script - this tells the participant who you are, explains the research and reminds them about things like recording
* the interview topics, including starter and follow-up questions
  instructions for any activities
* a planning checklist to make sure you’ll have everything you need on the day

You can use your discussion guide to:

* stay on track during interviews
* make sure interviewers cover the same topics so participants have a consistent experience
* review interview sessions with your team
* maintain a record of what you do in this round of research

### Do the interview

Once you’ve started the session and the participant is settled:

* get the participant’s [informed consent](service-manual_user-research_getting-users-consent-for-research.md)
* run through your introduction script
* start with a few general questions to help the participant relax - for example, ask them about their journey or to tell you about their job
* take time to adjust to their conversation pace and style

Think about your discussion guide and get participants talking with open, neutral questions like:

* how do you…?
* what are the different ways you…?
* what do you think about…?

Encourage them to give more detail with simple follow-up questions like:

* you said… when/why/who was that?
* can you tell me more about…?
* in what way…?

During the interview:

* focus on stories and real examples - avoid generalities and talking about how things ‘should’ happen
* make sure you really listen - show the participant you’re interested in what they’re saying
* make sure you understand what the participant has said - ask follow-up questions if you’re not sure
* don’t change the flow of the interview abruptly - if a participant goes off topic, wait for a natural break and gently bring them back to what you want to talk about
* try to stay quiet - the more you talk, the less your participant will talk
* don’t stick to your discussion guide rigidly - let the conversation develop naturally and be prepared to dig into any new and interesting issues that come up

### After the interview

Reserve some time at the end of the session to:

* ask follow-up questions about anything the participant said that you didn’t clearly understand
* check if the participant has any final thoughts about the things you’ve discussed

Once you’ve finished:

* thank the participant for their time and what they’ve helped you learn
* explain what will happen with your research
* ask the participant what they thought of the session, so you can improve next time

If you’ve finished for the day:

* make sure any personal data you’ve collected (on paper or in recordings) is stored securely
* pack away your equipment (use your planning checklist)

Examples and case studies
-------------------------

Learn more about in-depth interviewing by finding out:

* [how a GOV.UK team designed a ‘research cycle’ to support their evolving research need](https://userresearch.blog.gov.uk/2016/10/20/practice-makes-perfect-evolving-our-user-research-for-gov-uk/)
* [how a team researching webchat for GOV.UK based their discussion guides on earlier research with specific user groups](https://userresearch.blog.gov.uk/2016/12/20/researching-with-webchat-advisers-and-managers/)

Related guides
--------------

You may also find these guides useful:

* [Write a recruitment brief](service-manual_user-research_write-a-recruitment-brief.md)
* [Analysing a user research session](service-manual_user-research_analyse-a-research-session.md)
* [Doing user research remotely by phone or video call](https://www.gov.uk/service-manual/user-research/remote-user-research-phone-video-call)
* [Sharing user research findings](service-manual_user-research_sharing-user-research-findings.md)

Updates to this page
--------------------

Published 21 February 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---