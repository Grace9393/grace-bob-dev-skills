Making prototypes - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Making prototypes
=================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [When to use prototypes](#when-to-use-prototypes)
2. [Types of prototype](#types-of-prototype)
3. [Using code prototypes](#using-code-prototypes)
4. [Sharing code prototypes](#sharing-code-prototypes)
5. [Testing your prototypes](#testing-your-prototypes)
6. [Further reading](#further-reading)

You must make prototypes of your service to explore, share and test different designs before you commit to building anything.

You can quickly make and test multiple prototypes and discard the ones that do not test well.

Making prototypes is important because it:

* improves the usability of your service
* helps you to make sure you’re building the right service for your users
* helps your whole team to get a shared understanding about the future of your service
* allows your team to explore design ideas much faster and at lower risk than using your production code

When to use prototypes
----------------------

You must use prototypes in the alpha phase of your service to explore and test different approaches to the design of the service.

Continue to use prototypes in the beta and live stages of your service to explore potential new features or improvements.

Types of prototype
------------------

![ ](https://assets.publishing.service.gov.uk/media/57ed2df640f0b606dc000012/bettersketching-920x640.jpg)

Prototypes can vary in style from a quick pen and paper sketch to a code prototype that works like a fully interactive website.

You should use the prototype that best meets your needs at the time.

[Sketches](https://designnotes.blog.gov.uk/2014/05/22/gov-uk-sketching-templates/) are useful for exploring and discussing basic ideas with colleagues.

Code prototypes are better for user research because they’re more realistic.

Using code prototypes
---------------------

Prototypes built in code can look and behave like the live GOV.UK site and are the best approach if you want to test realistic interactions that a user has with your service.

The advantages of prototypes built in code are that:

* they look and behave almost exactly like the real thing, on mobile as well as desktop - this means users you test with are less distracted
* you’re always aware of the constraints of designing for the web
* it’s easier for the whole team to have a shared understanding of design ideas

The code in a prototype does not need to meet the same standards as production code. For example, it does not need to be secure or to perform well with large volumes of traffic. When you do move into production you need to make sure any code you use is good quality so you may not be able to use the same code. Do not just copy prototype code into production.

The point is to test ideas as quickly as possible. If an idea tests well, you may want to work with a developer to make your code a bit clearer so that it’s easier for others to work with.

### Using the GOV.UK Prototype Kit

The [GOV.UK Prototype Kit](https://govuk-prototype-kit.herokuapp.com/docs) lets you build realistic prototypes of your service that look and behave like GOV.UK.

It comes with [detailed installation instructions](https://govuk-prototype-kit.herokuapp.com/docs/install) and some example pages to get you started.

To use it you’ll need some basic knowledge of HTML, for example what tags and attributes are and how to copy and paste code.

Alternatively, you can work with developers on your team to create prototypes together.

Sharing code prototypes
-----------------------

### Publishing on the web

You can share code prototypes by publishing them on the web.

The GOV.UK Prototype Kit includes instructions for [publishing prototypes](https://govuk-prototype-kit.herokuapp.com/docs/publishing-on-heroku) using a service called Heroku.

When you’ve uploaded your prototype, you can easily share it with others. You must protect access to your prototype with a password so that members of the public do not find it and mistake it for a real service.

You must not use the GOV.UK Prototype Kit to make live services. It’s designed for prototyping and does not have the security or performance features needed for a live service.

### Using code collaboration software

Multiple people can collaborate on the same prototype using software called Git. The GOV.UK Prototype Kit has guidance on [how to set up Git for your prototypes](https://govuk-prototype-kit.herokuapp.com/docs/setting-up-git).

Testing your prototypes
-----------------------

Read these user research guides to find out more about how to test your prototypes:

* [How user research improves service design](service-manual_user-research_how-user-research-improves-service-design.md)
* [Start by learning user needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Plan user research for your service](service-manual_user-research_plan-user-research-for-your-service.md)
* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)

Further reading
---------------

Read these blog posts to find out more about prototyping:

* [How designers prototype at GDS](https://designnotes.blog.gov.uk/2014/10/13/how-designers-prototype-at-gds/)
* [GOV.UK sketching templates](https://designnotes.blog.gov.uk/2014/05/22/gov-uk-sketching-templates/)
* [Prototyping tips](https://designnotes.blog.gov.uk/2015/03/19/prototyping-tips/)

Updates to this page
--------------------

Published 18 October 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---