Accessibility community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Accessibility community
=======================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [Accessibility in the Service Manual](#accessibility-in-the-service-manual)
5. [Other communities](#other-communities)

The accessibility community is a group where you can:

* ask questions about accessibility, develop your knowledge, and get or give advice and support
* stay updated on the accessibility work that different departments are involved in
* meet people across government with an interest in improving accessibility
* share good practice ideas and examples

The community also helps to raise awareness of accessibility concerns or issues, which can then be addressed in blog posts, new guidance or training.

Who the community is for
------------------------

You might be interested in this community if your work involves:

* writing content or code
* designing the user experience
* doing user research
* managing a product or service

You can also join if you want to learn more about accessibility, or if you do not want to tackle accessibility issues on your own.

You do not have to be in an accessibility-related role to join, but you must be working in or with government. Most people in the group are not accessibility specialists.

Get involved
------------

### Online

If you’re interested in discussing accessibility issues, you can:

* join the accessibility community discussion group - to get access, contact [join-accessibility-community@digital.cabinet-office.gov.uk](mailto:join-accessibility-community@digital.cabinet-office.gov.uk) using your government email address
* join the [cross-government accessibility Slack channel](https://ukgovernmentdigital.slack.com/messages/accessibility/) to ask a short question that needs a quick response - you can create a Slack account using your government email address
* write something for the [accessibility in government blog](https://accessibility.blog.gov.uk/)

### Events

The community runs [cross-government accessibility meetups](https://accessibility.blog.gov.uk/2016/12/20/what-we-talked-about-at-the-cross-government-accessibility-meetup/) every year. These are announced on the accessibility community discussion group.

Community resources
-------------------

Learn more about accessibility by using resources the community has found helpful, inspiring or influential.

### Blog posts

Read the [accessibility in government blog](https://accessibility.blog.gov.uk/) for tips and research. Popular posts include:

* [Dos and don’ts on designing for accessibility](https://accessibility.blog.gov.uk/2016/09/02/dos-and-donts-on-designing-for-accessibility/)
* [What we mean when we talk about accessibility](https://accessibility.blog.gov.uk/2016/05/16/what-we-mean-when-we-talk-about-accessibility-2/)
* [Using persona profiles to test accessibility](https://accessibility.blog.gov.uk/2019/02/11/using-persona-profiles-to-test-accessibility/)

### Books and newsletters

Read more about accessibility in:

* [‘A web for everyone’](http://rosenfeldmedia.com/books/a-web-for-everyone/) - some sections of this book are available free online, including accessibility personas
* [‘Inclusive design patterns: coding accessibility into web design’](https://www.smashingmagazine.com/2016/06/inclusive-design-patterns/) - you’ll need to pay for this book
* [‘Just ask: integrating accessibility throughout design’](http://uiaccess.com/accessucd/) - book available free online
* [Accessibility Weekly newsletter](http://a11yweekly.com/)
* [Webdev newsletter](https://groups.google.com/a/d.umn.edu/forum/?hl=en#!forum/webdev)

### Accessibility groups

Learn more from organisations and groups who promote and discuss better accessibility:

* [WebAIM](http://webaim.org/)
* [Web-a11y slack channel](https://web-a11y.slack.com/)
* [The Web Accessibility Initiative (WAI)](https://www.w3.org/WAI/)
* [TPGi blog](https://www.paciellogroup.com/blog/)

Accessibility in the Service Manual
-----------------------------------

To find out best practice for accessibility, read [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md).

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Other communities
-----------------

You may also be interested in the following communities:

* [user research community](https://www.gov.uk/service-manual/communities/user-research-community)
* [design community](https://www.gov.uk/service-manual/communities/design-community)
* [content community](https://www.gov.uk/service-manual/communities/content-community)

Updates to this page
--------------------

Published 4 April 2016

Last updated 5 September 2017
[+ show all updates](#full-history)

1. 5 September 2017

   Clarification of what the community is for. Expanded list of resources and ways to get involved.
2. 4 April 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---