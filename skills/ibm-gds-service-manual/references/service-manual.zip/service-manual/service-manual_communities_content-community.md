Content community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Content community
=================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Keep in touch](#keep-in-touch)
3. [Resources](#resources)

The content community exists to:

* help government understand how user-centred content design can contribute to delivering better public services
* collaboratively define and communicate standards and best practice guidelines for content design
* support individual content designers across government to learn and progress

Who the community is for
------------------------

You might be interested in this community if you work in the public sector and you:

* are a content designer
* work with content designers
* would like to learn more about content design

[Watch a video to learn more about the content community](https://www.youtube.com/watch?v=POwwKbjFQRs).

### GOV.UK publisher training

The GOV.UK content team runs the mandatory training for GOV.UK publishers.

[Find out more about GOV.UK publisher training](https://www.gov.uk/guidance/how-to-publish-on-gov-uk/introduction-and-access-to-whitehall-publisher).

Keep in touch
-------------

To keep in touch with the content community:

* [join the content design slack channel](https://ukgovernmentdigital.slack.com/messages/content) on the UK government Slack - you can create a Slack account using your government email address
* [join the content community basecamp](https://www.gov.uk/guidance/contact-the-government-digital-service/government-content-community#basecamp)
* use the #GovContent #ContentDesign or #ConCon10 hashtags on Twitter

Resources
---------

You may find these resources useful

* [GOV.UK style guide, content and publishing guidance](https://www.gov.uk/topic/government-digital-guidance/content-publishing)
* [guidance on writing for user interfaces](https://www.gov.uk/service-manual/design/writing-for-user-interfaces)
* [government content design role descriptions](https://www.gov.uk/government/collections/digital-data-and-technology-profession-capability-framework#user-centred-design-job-family)

Updates to this page
--------------------

Published 29 January 2020

Last updated 17 February 2021
[+ show all updates](#full-history)

1. 17 February 2021

   Added information about ConCon10 and a link to sign up to help run it. Removed section about the early career mentoring scheme as it is currently paused.
2. 26 August 2020

   Working group information added and dates updated for concon10 and next FL course run
3. 29 January 2020

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---