Get a service domain name - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Get a service domain name
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [After your alpha assessment](#after-your-alpha-assessment)
2. [Choose where you’ll host your DNS](#choose-where-youll-host-your-dns)
3. [Ensure users start their journey on GOV.UK](#ensure-users-start-their-journey-on-govuk)
4. [After your beta assessment](#after-your-beta-assessment)
5. [Set up subdomains](#set-up-subdomains)
6. [Set up security certificates](#set-up-security-certificates)
7. [Sending emails from your domain name](#sending-emails-from-your-domain-name)
8. [Getting operations support](#getting-operations-support)

You must contact the Government Digital Service (GDS) to get a domain name for your service on GOV.UK.

You should do this after working with GDS to [agree a start point for your service](service-manual_service-assessments_get-your-service-on-govuk.md). This will usually be a start page.

You must only advertise the URL (or short URL) of your GOV.UK start point. You must never advertise any other URL for your service anywhere.

This guidance only applies to service.gov.uk domains. If you need a non-service domain, for example for organisational email, follow the guidance on [naming and registering government websites](https://www.gov.uk/government/publications/naming-and-registering-government-websites/central-government-naming-and-registering-websites).

After your alpha assessment
---------------------------

Once you’ve planned a start point for your service, you’ll need to agree a service domain name with GDS.

Your domain name should describe your service, rather than mention your department or agency - for example, apply-budgeting-loan.service.gov.uk.

You’ll need to follow the:

* [guidance on naming your service](https://www.gov.uk/service-manual/design/naming-your-service#how-to-name-your-service)
* [URL standards for GOV.UK](https://www.gov.uk/guidance/content-design/url-standards-for-gov-uk)
* guidance on [naming and registering government websites](https://www.gov.uk/government/publications/naming-and-registering-government-websites/central-government-naming-and-registering-websites#naming-conventions-and-principles)

Contact GDS at [govuk-enquiries@dsit.gov.uk](mailto:govuk-enquiries@dsit.gov.uk) to request a domain name.

In your email you should briefly describe:

* what your service does
* who your users are
* what user needs you will meet

GDS may ask for more information about your service before agreeing an appropriate domain name with you. The name will likely be similar to the title of your GOV.UK start point.

Choose where you’ll host your DNS
---------------------------------

Once you’ve agreed a domain name for your service with GDS, you’ll need to choose a DNS provider or arrange to run your DNS servers yourself.

A DNS provider will publish your DNS records on the internet so that users can connect to your service.

Your provider will give you several DNS name servers. As soon as you have these, send the details to [govuk-enquiries@dsit.gov.uk](mailto:govuk-enquiries@dsit.gov.uk) so GDS can request the delegation as soon as you’ve passed your beta assessment.

You’ll need to provide at least 2 nameserver records for your domain. GDS recommends you provide 4.

DNS is often a single point of failure. Consider using multiple suppliers - that way, if one ever goes down, people will still be able to find your service.

You can search for DNS suppliers on the [Digital Marketplace](https://www.gov.uk/digital-marketplace). If you do not know which suppliers to choose, ask for advice from technical staff in your team or organisation.

Ensure users start their journey on GOV.UK
------------------------------------------

You should make sure users always start their journey on the [GOV.UK start point for your service](service-manual_service-assessments_get-your-service-on-govuk.md).

To ensure users start their journey on GOV.UK, you need to set up your service domain correctly. You must:

* redirect users to the GOV.UK start point if they go straight to a page on the service’s domain
* tell search engines not to index pages on your domain

### Telling search engines not to index pages

You can either:

* serve a meta tag on every page with the value: `noindex, nofollow`
* use a X-Robots-Tag response header with the value: `noindex, nofollow`

Do not use a robots.txt file to prevent crawling of your service. This will prevent the crawler from seeing the noindex directive, so pages on your service may still appear in search results.

### If users need to access your service directly

There are occasional exceptions to these rules. Contact [govuk-enquiries@dsit.gov.uk](mailto:govuk-enquiries@dsit.gov.uk) if you think users need to be able to access pages on your service domain directly.

After your beta assessment
--------------------------

Your service can begin using the service domain after:

* you’ve passed your beta assessment, and
* your department’s assessment team has shared the assessment report with [govuk-enquiries@dsit.gov.uk](mailto:govuk-enquiries@dsit.gov.uk) and [dbd-assessments@digital.cabinet-office.gov.uk](mailto:dbd-assessments@digital.cabinet-office.gov.uk)

Contact [govuk-enquiries@dsit.gov.uk](mailto:govuk-enquiries@dsit.gov.uk) after your assessment to request the domain delegation. GDS will then delegate the service domain. This can take up to 5 working days.

Once GDS has finished the delegation, your team will be able to manage where the domain name points to.

You’ll also need to contact the GDS content team to let them know to publish your service start point and feedback page.

Set up subdomains
-----------------

Once you have a domain name, you can set up subdomains (for example, for a staging environment or static assets).

Find out more about [managing domain names](service-manual_technology_managing-domain-names.md).

Set up security certificates
----------------------------

Once you’ve set up your DNS delegation, you’ll need to get TLS certificates from a certificate provider.

You must use a certificate provider who provides DNS validation.

Use a Certification Authority Authorisation (CAA) record on your service.gov.uk domain. This stops attackers from getting another certificate authority to issue a certificate for the domain.

If you need to use extended validation for your service, your organisation will need to act as the legal confirming party. This can be a very lengthy process.

Sending emails from your domain name
------------------------------------

If you’re planning to send emails from your domain name, you must make sure your users can receive your emails and are protected from spam.

You must follow the government guidance on [how to email your users](service-manual_technology_how-to-email-your-users.md).

If you’re not going to send emails from your domain, you must follow the government guidance on [keeping your domain protected from spoofing attacks](https://www.gov.uk/guidance/protect-domains-that-dont-send-email).

Getting operations support
--------------------------

If you have an issue you cannot resolve with your DNS supplier, you can email the GOV.UK operations support team at [hostmaster@digital.cabinet-office.gov.uk](mailto:hostmaster@digital.cabinet-office.gov.uk). The team is available on weekdays between 9am and 5pm.

If you have an emergency outside of these hours, you must contact your organisation’s single point of contact (often referred to as ‘SPOC’) who will contact the support team for you.

Updates to this page
--------------------

Published 15 September 2016

Last updated 26 August 2025
[+ show all updates](#full-history)

1. 22 August 2025

   Changed GOV.UK contact email FROM govuk-enquiries@digital.cabinet-office.gov.uk TO govuk-enquiries@dsit.gov.uk
2. 9 May 2024

   Added report sharing requirements for departmental assessment teams before a service can begin using the service domain.
3. 25 October 2022

   Removed option to request email validation as this is no longer offered.
4. 2 March 2021

   Updated the email address to use if you require email DNS validation.
5. 30 May 2018

   Slightly tweaked process for performing domain validation.
6. 1 November 2017

   Clarified the timeline for getting a service domain name.
7. 15 September 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---