Services for government users - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Services for government users
=============================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Understand the problem you’re solving](#understand-the-problem-youre-solving)
2. [Who to research with](#who-to-research-with)
3. [Accessibility](#accessibility)
4. [Logos and fonts](#logos-and-fonts)
5. [Security](#security)
6. [Share your success stories](#share-your-success-stories)
7. [Further reading](#further-reading)

Civil servants are users too - it’s important they have access to services that are easy to use.

Good internal services reduce training costs and the amount of time spent dealing with errors. This gives people more time to provide a good service to the public.

Hold internal services to the same standard you would a public-facing service. In short, this means making sure they’re:

* meeting a user need
* safe and secure
* fully accessible
* easy to change and improve

This guidance covers services for government users, whether you’re building them yourself or buying them.

You can [check if you need to get your service assessed](https://www.gov.uk/service-manual/service-assessments/check-if-you-need-a-service-assessment).

Understand the problem you’re solving
-------------------------------------

To work out how best to meet your users’ needs, you’ll need a deep understanding of the tasks they’re trying to complete and the circumstances they’re working in.

Do not assume that an existing working process is a user need. Investigate whether a working process is necessary or can be improved.

Strike a balance between simplicity and users being able to achieve their task quickly.

Start with the [design guidance in the Service Manual](https://www.gov.uk/service-manual/design). It’s okay to deviate occasionally, but you’ll need to back up these decisions with user research.

For example, a user of an admin system might need to repeat and switch between tasks quickly. Or they might need to see all of the information they’ve input about something in one place to help them make a decision. This might mean it’s not appropriate to apply a [one thing per page](https://www.gov.uk/service-manual/design/form-structure#start-with-one-thing-per-page) approach on all pages.

You may find this [blog post with a set of civil servant user profiles](https://userresearch.blog.gov.uk/2018/06/07/how-cross-government-user-profiles-of-civil-servants-can-help-you/) a useful starting point towards understanding your users.

Who to research with
--------------------

You’ll learn more about whether your service is meeting users’ needs if you test with users who have real-life experience of doing the tasks, and realistic data to test with.

It’s also important to test with a range of users, for example people who:

* have different amounts of experience doing the tasks
* work alone
* work as part of a centralised team

Accessibility
-------------

In a 2018 survey, [10% of the civil servants who declared their disability status said they were disabled](https://www.ons.gov.uk/employmentandlabourmarket/peopleinwork/publicsectorpersonnel/bulletins/civilservicestatistics/2018). Your service must be [fully accessible](https://www.gov.uk/guidance/make-things-accessible) according to the Public Sector Bodies Accessibility Regulations.

Make sure you test with disabled users.

You do not have to provide [assisted digital support](https://www.gov.uk/service-manual/helping-people-to-use-your-service/assisted-digital-support-introduction) for users who work in the public sector (including contractors) and use your service as part of their work.

### Do not design for specific hardware or software

Government workers often face technological constraints, like having to use old browsers or operating systems. [Use web standards](https://www.gov.uk/service-manual/technology/designing-for-different-browsers-and-devices) so the service is fully accessible and works on all browsers.

That way, the service will still work even if the department’s technological situation changes.

Bear in mind that your users might not be used to iteration and you might need to explain why you’re taking an iterative approach.

Logos and fonts
---------------

If your service is not on a service.gov.uk domain, you cannot use the GOV.UK crown logo.

It makes sense for public-facing services to look and feel like part of GOV.UK, so users know they’re in the right place. This is not necessary for internal services.

You also will not be able to use the New Transport font. Use the Helvetica or Arial CSS font stacks instead.

Security
--------

As more services move into the cloud, there’s little difference between internal and public-facing services from a security perspective. They’re subject to the same threats.

However, services for staff often have highly privileged functions (such as access to sensitive data) which brings additional risks. When designing cloud-based services for staff, follow the same security approach you would when building a public-facing service and include these threats in your threat modelling and mitigation.

Find out [how to make sure your information is secure](https://www.gov.uk/service-manual/technology/securing-your-information).

Share your success stories
--------------------------

It’s likely colleagues across government will be trying to solve similar problems. Share your success stories by blogging or [talking about them with the cross-government design community](https://www.gov.uk/service-manual/communities/design-community#get-involved).

This will help teams see what’s worked previously.

Further reading
---------------

You might also find the following blog posts useful:

* [Design principles for admin interfaces](https://designnotes.blog.gov.uk/2015/09/25/design-principles-for-admin-interfaces/)
* [Making our admin tools more consistent](https://designnotes.blog.gov.uk/2019/10/04/making-our-admin-tools-more-consistent/)
* [Eight things I’ve learnt from designing services for colleagues](https://dwpdigital.blog.gov.uk/2018/03/13/eight-things-ive-learnt-from-designing-services-for-colleagues/)
* [Internal service assessments: how we maintain quality](https://hodigital.blog.gov.uk/2016/09/20/internal-service-assessments-how-we-maintain-quality/)

Updates to this page
--------------------

Published 11 January 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---