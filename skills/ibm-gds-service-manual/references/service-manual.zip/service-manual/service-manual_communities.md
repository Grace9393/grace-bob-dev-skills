Communities - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Communities
===========

Connect with practitioners across government to share best practice, discuss challenges and support each other.

Accessibility community
-----------------------

For anyone with an interest in accessibility.

* [Accessibility community](service-manual_communities_accessibility-community.md)

Agile delivery community
------------------------

For anyone interested in using agile methods to deliver government projects.

* [Agile delivery community](service-manual_communities_agile-delivery-community.md)

AI for government knowledge and information management community
----------------------------------------------------------------

For people in the public sector working on AI for government knowledge and information management

* [AI for government knowledge & information management community](service-manual_communities_ai-for-government-knowledge-information-management-community.md)

Application programming interface community
-------------------------------------------

For people in government working on application programming interfaces

* [Application programming interface community](service-manual_communities_application-programming-interface-community.md)

Artificial intelligence community
---------------------------------

For anyone with an interest in using artificial intelligence in government.

* [Artificial Intelligence community](service-manual_communities_artificial-intelligence-community.md)

Assisted digital and digital take-up community
----------------------------------------------

For anyone procuring, designing or managing assisted digital support.

* [Assisted digital and digital take-up community](service-manual_communities_assisted-digital-and-digital-take-up-community.md)

Content community
-----------------

For anyone involved in content or website publishing.

* [Content community](service-manual_communities_content-community.md)

Data and artificial intelligence ethics community
-------------------------------------------------

People working in the public sector who are interested in discussing and exploring ethics in data and technology

* [Data and artificial intelligence ethics community](service-manual_communities_data-and-artificial-intelligence-ethics-community.md)

Data engineering community
--------------------------

For anyone designing and building data products and services.

* [Data engineering community](service-manual_communities_data-engineering-community.md)

Data science community
----------------------

For anyone interested in data science best practice and using evidence to make decisions.

* [Data science community](service-manual_communities_data-science-community.md)

Design community
----------------

For anyone working in interaction design, graphic design, service design or content design.

* [Design community](service-manual_communities_design-community.md)

Digital buying community
------------------------

For anyone in the public sector buying digital data and technology services.

* [Buying digital community](service-manual_communities_digital-buying-community.md)

Digital workplace community
---------------------------

For people interested in improving digital employee experience across the public sector

* [Digital workplace community](service-manual_communities_digital-workplace-community.md)

Generative AI security community
--------------------------------

For people working on the security of generative AI

* [Generative AI security community](service-manual_communities_generative-ai-security-community.md)

Linguistic data community
-------------------------

People in government, public sector or relevant not-for-profit stakeholders interested in linguistic data

* [Linguistic data community](service-manual_communities_linguistic-data-community.md)

Low code community
------------------

For people across UK Government departments and agencies who are interested in Low Code platforms

* [Low code community](service-manual_communities_low-code-community.md)

Performance analysis community
------------------------------

For anyone working with data and analytics.

* [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Policy design community
-----------------------

Discuss and learn about the role of policy design in government.

* [Policy design community](service-manual_communities_policy-design-community.md)

Product and service community
-----------------------------

For anyone using product management methods to deliver government products and services.

* [Product and service community](service-manual_communities_product-and-service-community.md)

Standards and assurance community
---------------------------------

For anyone designing, implementing or assessing government digital or technology standards.

* [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Technical cloud community
-------------------------

For anyone with an interest in using cloud technology in government.

* [Technical cloud community](service-manual_communities_technical-cloud-community.md)

Technical writing community
---------------------------

For anyone interested in writing about technology.

* [Technical writing community](service-manual_communities_technical-writing-community.md)

Technology community (backend development)
------------------------------------------

For anyone working in backend development for services.

* [Technology community (backend development)](service-manual_communities_technology-community-backend-development.md)

Technology community (frontend development)
-------------------------------------------

For anyone working in frontend development for services.

* [Technology community (frontend development)](service-manual_communities_technology-community-frontend-development.md)

Technology community (technical architecture)
---------------------------------------------

For anyone working in technical architecture for services.

* [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Technology community (web operations)
-------------------------------------

For anyone working in web operations for services.

* [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)

User research community
-----------------------

For anyone interested in improving user research practices across government.

* [User research community](service-manual_communities_user-research-community.md)

User support community
----------------------

For anyone working in user support for services.

* [User support community](service-manual_communities_user-support-community.md)

Setting up a new community
--------------------------

Set up and manage a community of practice to connect people doing similar work across government.

* [Setting up a new community of practice](service-manual_communities_setting-up-a-new-community-of-practice.md)

* [Contact the Service Manual and Service Standard team](service-manual_communities_contact-the-service-manual-and-service-standard-team.md)
* [Propose a change to the Service Manual](service-manual_communities_propose-a-change-to-the-service-manual.md)

Join the Standards and assurance community
------------------------------------------

Find out what the cross-government community does and how to get involved.

* [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/communities)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---