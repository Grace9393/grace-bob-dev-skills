Capturing research questions - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Capturing research questions
============================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to capture research questions](#when-to-capture-research-questions)
2. [Steps to follow](#steps-to-follow)
3. [Examples and case studies](#examples-and-case-studies)
4. [Related guides](#related-guides)

You can use research questions to help you plan and prioritise user research.

When to capture research questions
----------------------------------

The best time to capture research questions is at the start of a new development phase, especially discovery, alpha and beta.

You should re-visit and refine your questions as you learn more about your users and service. Understanding what your team wants to learn, and how this changes over time, is an important part of [planning user research for your service](service-manual_user-research_plan-user-research-for-your-service.md).

Steps to follow
---------------

Plan your research sessions carefully for best results.

### Plan your session

When you want to capture research questions:

* book a space big enough for your team to write questions, with a wall you can post them on
* aim for sessions to last about an hour - they can take longer with a new team or service
* invite everyone on your team - writing research questions together will help you to agree what’s most important
* make sure you have lots of sticky notes and pens

### Review the problem

Start the workshop with the service owner or product owner reminding the team about:

* the outcomes the team is trying to achieve - both for users and the organisation
* things the team will need to do in the next development phase

### Capture questions

Ask everyone to think about what they want to learn from research in the next phase. After this:

* give people 5-10 minutes to write down their questions on sticky notes
* explain that broad, open questions (like ‘who’, ‘what’, ‘when’, ‘where’ or ‘why’) are more helpful than narrow or specific ones (like ‘do’, ‘have’, ‘will’ or ‘can’)
* remind them that these are things you need to learn, not questions you will ask users

After people have finished writing their questions:

* ask everyone to place their notes on a wall and start sorting them into related groups
* allow team members to add new questions that are prompted by other people’s
* combine similar questions, refining any that are unclear
* write a summary question for each group of similar questions

### Prioritise the questions

To decide the priority:

* ask team members to identify the highest priority questions by marking a dot on the 5 questions they think need answering first
* arrange the groups - and questions in each - in priority order

### Use the research questions

Once you have your prioritised research questions:

* copy them into a shared document or team collaboration tool
* decide which research questions to focus on in your next sprint
* decide which research activities will help you to answer your questions

Examples and case studies
-------------------------

[Read a blog post about how the Open Registers team uses a kanban board to generate and share user research questions](https://userresearch.blog.gov.uk/2017/02/16/how-a-knowledge-kanban-board-can-help-your-user-research/).

Related guides
--------------

You may also find these guides useful:

* [User research in the different design phases](service-manual_user-research#user-research-in-the-different-design-phases.md)
* [Plan user research for your service](service-manual_user-research_plan-user-research-for-your-service.md)

Updates to this page
--------------------

Published 21 February 2017

Last updated 12 September 2017
[+ show all updates](#full-history)

1. 12 September 2017

   Added guidance on reviewing objectives ahead of capturing questions.
2. 21 February 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---