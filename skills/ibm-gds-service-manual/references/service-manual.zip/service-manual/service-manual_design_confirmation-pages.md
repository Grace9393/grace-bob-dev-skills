Confirmation pages – GOV.UK Design System






[Skip to main content](#main-content)


[GOV.UK


Design System](/)

Search Design system
[Sitemap](/sitemap/)

Menu

* [Get started 
  + [Get started overview](/get-started/)
  + ### Setup guides

    - [Prototyping](/get-started/prototyping/)
    - [Production](/get-started/production/)
  + ### How to guides

    - [Making labels and legends headings](/get-started/labels-legends-headings/)
    - [Extending and modifying components in production](/get-started/extending-and-modifying-components/)
    - [Understanding focus state styles](/get-started/focus-states/)
    - [Updating your service to use the new type scale](/get-started/new-type-scale/)](/get-started/)
* [Styles 
  + [Styles overview](/styles/)
  + ### Page structure

    - [Page template](/styles/page-template/)
    - [Layout](/styles/layout/)
    - [Spacing](/styles/spacing/)
    - [Section break](/styles/section-break/)
  + ### Typography

    - [Typeface](/styles/typeface/)
    - [Type scale](/styles/type-scale/)
    - [Headings](/styles/headings/)
    - [Paragraphs](/styles/paragraphs/)
    - [Links](/styles/links/)
    - [Lists](/styles/lists/)
    - [Font override classes](/styles/font-override-classes/)
  + ### Visual elements

    - [Colour](/styles/colour/)
    - [Images](/styles/images/)](/styles/)
* [Components 
  + [Components overview](/components/)
  + - [Accordion](/components/accordion/)
    - [Back link](/components/back-link/)
    - [Breadcrumbs](/components/breadcrumbs/)
    - [Button](/components/button/)
    - [Character count](/components/character-count/)
    - [Checkboxes](/components/checkboxes/)
    - [Cookie banner](/components/cookie-banner/)
    - [Date input](/components/date-input/)
    - [Details](/components/details/)
    - [Error message](/components/error-message/)
    - [Error summary](/components/error-summary/)
    - [Exit this page](/components/exit-this-page/)
    - [Fieldset](/components/fieldset/)
    - [File upload](/components/file-upload/)
    - [GOV.UK footer](/components/footer/)
    - [GOV.UK header](/components/header/)
    - [Inset text](/components/inset-text/)
    - [Notification banner](/components/notification-banner/)
    - [Pagination](/components/pagination/)
    - [Panel](/components/panel/)
    - [Password input](/components/password-input/)
    - [Phase banner](/components/phase-banner/)
    - [Radios](/components/radios/)
    - [Select](/components/select/)
    - [Service navigation](/components/service-navigation/)
    - [Skip link](/components/skip-link/)
    - [Summary list](/components/summary-list/)
    - [Table](/components/table/)
    - [Tabs](/components/tabs/)
    - [Tag](/components/tag/)
    - [Task list](/components/task-list/)
    - [Text input](/components/text-input/)
    - [Textarea](/components/textarea/)
    - [Warning text](/components/warning-text/)](/components/)
* [**Patterns 
  + [Patterns overview](/patterns/)
  + ### Ask users for…

    - [Addresses](/patterns/addresses/)
    - [Bank details](/patterns/bank-details/)
    - [Dates](/patterns/dates/)
    - [Email addresses](/patterns/email-addresses/)
    - [Equality information](/patterns/equality-information/)
    - [Names](/patterns/names/)
    - [National Insurance numbers](/patterns/national-insurance-numbers/)
    - [Passwords](/patterns/passwords/)
    - [Payment card details](/patterns/payment-card-details/)
    - [Phone numbers](/patterns/phone-numbers/)
  + ### Help users to…

    - [Check a service is suitable](/patterns/check-a-service-is-suitable/)
    - [Check answers](/patterns/check-answers/)
    - [Complete multiple tasks](/patterns/complete-multiple-tasks/)
    - [Confirm a phone number](/patterns/confirm-a-phone-number/)
    - [Confirm an email address](/patterns/confirm-an-email-address/)
    - [Contact a department or service team](/patterns/contact-a-department-or-service-team/)
    - [Create a username](/patterns/create-a-username/)
    - [Create accounts](/patterns/create-accounts/)
    - [Exit a page quickly](/patterns/exit-a-page-quickly/)
    - [Navigate a service](/patterns/navigate-a-service/)
    - [Start using a service](/patterns/start-using-a-service/)
    - [Recover from validation errors](/patterns/validation/)
  + ### Pages

    - [Confirmation pages](/patterns/confirmation-pages/)
    - [Cookies page](/patterns/cookies-page/)
    - [Page not found pages](/patterns/page-not-found-pages/)
    - [There is a problem with the service pages](/patterns/problem-with-the-service-pages/)
    - [Question pages](/patterns/question-pages/)
    - [Service unavailable pages](/patterns/service-unavailable-pages/)
    - [Step by step navigation](/patterns/step-by-step-navigation/)**](/patterns/)
* [Community 
  + [Community overview](/community/)
  + ### What we’re working on

    - [Upcoming components and patterns](/community/upcoming-components-patterns/)
    - [Roadmap](/community/roadmap/)
  + ### Ways to get involved

    - [Share findings about your users](/community/share-research-findings/)
    - [Propose a component or pattern](/community/propose-a-component-or-pattern/)
    - [Develop a component or pattern](/community/develop-a-component-or-pattern/)
    - [Propose a content change using GitHub](/community/propose-a-content-change-using-github/)
  + ### How we work

    - [Community principles](/community/community-principles/)
    - [Contribution criteria](/community/contribution-criteria/)
    - [Design System working group](/community/design-system-working-group/)
    - [Blog posts, videos and podcasts](/community/blogs-talks-podcasts/)
  + ### Resources

    - [Resources and tools](/community/resources-and-tools/)
  + ### Events and workshops

    - [Design System Day Events](/community/design-system-day/)
    - [Design System Day 2022](/community/design-system-day-2022/)
    - [Design System Day 2023](/community/design-system-day-2023/)
    - [Design System Day 2024](/community/design-system-day-2024/)
    - [Code of Conduct](/community/code-of-conduct/)](/community/)
* [Accessibility 
  + [Accessibility overview](/accessibility/)
  + - [Accessibility strategy](/accessibility/accessibility-strategy/)](/accessibility/)

Pages in this section
---------------------

### Ask users for…

* [Addresses](/patterns/addresses/)
* [Bank details](/patterns/bank-details/)
* [Dates](/patterns/dates/)
* [Email addresses](/patterns/email-addresses/)
* [Equality information](/patterns/equality-information/)
* [Names](/patterns/names/)
* [National Insurance numbers](/patterns/national-insurance-numbers/)
* [Passwords](/patterns/passwords/)
* [Payment card details](/patterns/payment-card-details/)
* [Phone numbers](/patterns/phone-numbers/)

### Help users to…

* [Check a service is suitable](/patterns/check-a-service-is-suitable/)
* [Check answers](/patterns/check-answers/)
* [Complete multiple tasks](/patterns/complete-multiple-tasks/)
* [Confirm a phone number](/patterns/confirm-a-phone-number/)
* [Confirm an email address](/patterns/confirm-an-email-address/)
* [Contact a department or service team](/patterns/contact-a-department-or-service-team/)
* [Create a username](/patterns/create-a-username/)
* [Create accounts](/patterns/create-accounts/)
* [Exit a page quickly](/patterns/exit-a-page-quickly/)
* [Navigate a service](/patterns/navigate-a-service/)
* [Start using a service](/patterns/start-using-a-service/)
* [Recover from validation errors](/patterns/validation/)

### Pages

* [Confirmation pages](/patterns/confirmation-pages/)
* [Cookies page](/patterns/cookies-page/)
* [Page not found pages](/patterns/page-not-found-pages/)
* [There is a problem with the service pages](/patterns/problem-with-the-service-pages/)
* [Question pages](/patterns/question-pages/)
* [Service unavailable pages](/patterns/service-unavailable-pages/)
* [Step by step navigation](/patterns/step-by-step-navigation/)

1. [Home](/)
2. [Patterns](/patterns)


Confirmation pages
==================

Use this pattern to let users know they’ve completed a transaction.

Include a link to the [GOV.UK feedback page](https://www.gov.uk/service-manual/service-assessments/get-feedback-page) to allow users to tell you what they think of your transaction.

[Open this example in a new tab: confirmation pages](/patterns/confirmation-pages/default/)

* [HTML](#confirmation-pages-example-html)
* [Nunjucks](#confirmation-pages-example-nunjucks)

[HTML](#confirmation-pages-example-html)

```
<div class="govuk-width-container">
  <main class="govuk-main-wrapper govuk-main-wrapper--l" id="main-content" role="main">
    <div class="govuk-grid-row">
      <div class="govuk-grid-column-two-thirds">
        <div class="govuk-panel govuk-panel--confirmation">
          <h1 class="govuk-panel__title">
            Application complete
          </h1>
          <div class="govuk-panel__body">
            Your reference number<br><strong>HDJ2123F</strong>
          </div>
        </div>
        <p class="govuk-body">We have sent you a confirmation email.</p>
        <h2 class="govuk-heading-m">What happens next</h2>
        <p class="govuk-body">
          We’ve sent your application to Hackney Electoral Register Office.
        </p>
        <p class="govuk-body">
          They will contact you either to confirm your registration, or to ask for more information.
        </p>
        <p class="govuk-body">
          <a href="#" class="govuk-link">What did you think of this service?</a> (takes 30 seconds)
        </p>
      </div>
    </div>
  </main>
</div>
```

[Nunjucks](#confirmation-pages-example-nunjucks)

```
{% set mainClasses = "govuk-main-wrapper--l" %}

{% from "govuk/components/panel/macro.njk" import govukPanel %}

{% block content %}
  <div class="govuk-grid-row">
    <div class="govuk-grid-column-two-thirds">
      {{ govukPanel({
        titleText: "Application complete",
        html: "Your reference number<br><strong>HDJ2123F</strong>"
      }) }}

      <p class="govuk-body">We have sent you a confirmation email.</p>

      <h2 class="govuk-heading-m">What happens next</h2>

      <p class="govuk-body">
        We’ve sent your application to Hackney Electoral Register Office.
      </p>
      <p class="govuk-body">
        They will contact you either to confirm your registration, or to ask for more information.
      </p>

      <p class="govuk-body">
        <a href="#" class="govuk-link">What did you think of this service?</a> (takes 30 seconds)
      </p>
    </div>
  </div>
{% endblock %}
```

When to use this pattern
------------------------

You should use a confirmation page at the end of a transaction.

How it works
------------

Confirmation pages reassure users that they have completed a transaction and helps them understand what to expect next.

Your confirmation page must include:

* a reference number, if there is one
* details of what happens next and when
* contact details for the service
* links to information or services that users are likely to need next
* a link to your [feedback page](https://www.gov.uk/service-manual/service-assessments/get-feedback-page)
* a way for users to save a record of the transaction, for example, as a PDF

If you choose to add links, buttons or other interactive elements in the green confirmation panel, they will not be accessible. You’ll need to make changes to the panel or focus state style to make them accessible and meet a minimum contrast ratio of 3:1.

### Help users who bookmark the page

Some users will bookmark the confirmation page as a form of receipt. You should allow them to return to the page, whenever possible.

If you cannot, make sure your service responds in a helpful way when users return using a bookmarked link. For example, if people use your service to make an application you could provide links to information on:

* tracking an application
* starting a new application
* what to do or who to contact if they have a problem with their application

Research on this pattern
------------------------

[Read a blog post about users who bookmark confirmation pages](https://designnotes.blog.gov.uk/2015/12/10/do-users-return-to-your-service-after-finishing/).

### Known gaps

Research is needed on the best way to confirm transactions that are part of a wider user task. For example, where you might need to emphasise next steps more than completion of that particular transaction.

Help improve this pattern
-------------------------

To help make sure that this page is useful, relevant and up to date, you can:

* take part in the
  [‘Confirmation pages’ discussion on GitHub](https://github.com/alphagov/govuk-design-system-backlog/issues/40)
  and share your research
* [propose a change on GitHub](https://github.com/alphagov/govuk-design-system/edit/main/src/patterns/confirmation-pages/index.md)
  – read more about
  [how to propose changes in GitHub](/community/propose-a-content-change-using-github/)

Need help?
----------

If you’ve got a question about the GOV.UK Design System, [contact the team](/get-in-touch/).

[Back to top](#top)