Sending text messages securely - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Sending text messages securely
==============================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Choose an SMS aggregator service](#choose-an-sms-aggregator-service)
2. [Set up a sender ID](#set-up-a-sender-id)
3. [Dealing with delivery errors](#dealing-with-delivery-errors)
4. [Testing integration](#testing-integration)
5. [Checking the format and content of your messages](#checking-the-format-and-content-of-your-messages)
6. [Related guides](#related-guides)

If you need to contact your users by text message, you must:

* do it securely
* use a provider that can support the number of text messages you want to send

Choose an SMS aggregator service
--------------------------------

You should use an SMS aggregator service provider to send text messages, and consider using [GOV.UK Notify](https://www.notifications.service.gov.uk/). You can find other suppliers on the [Digital Marketplace](https://www.digitalmarketplace.service.gov.uk/).

The supplier should use a Tier 1 SMS aggregator for direct access to mobile networks and better performance. You can consider using more than one aggregator for improved resilience.

The supplier should also:

* provide delivery receipts
* provide failover and technical support
* encrypt all data in transit and at rest
* work with you on information assurance activities

You may also need to check your supplier can send messages to overseas phone numbers if that’s relevant for your service.

There should be no additional charges for sending messages abroad.

Set up a sender ID
------------------

To send text messages to users, you must set up a sender ID. This is a name or number that identifies you as the sender of a text message.

Always text users from this sender ID. This means that if you send multiple messages to a user, they’ll receive them in a single thread.

If you want your users to be able to reply to your text messages, you should use a full length UK mobile phone number or a shortcode.

Shortcodes are 5 to 6 digit phone numbers that generally only work in the UK, but can be memorable and useful for advertising campaigns.

### Phone numbers and alphanumeric strings

You can choose a full UK mobile phone number as your sender ID. This will allow users to reply to your text messages, but they may have to pay to do this. You must also be able to read any text messages that you receive.

You can also use an alphanumeric string up to 11 characters long, for example ‘HMRC’. Doing this means your users will be able to easily identify who sent the text message. However, they won’t be able to send a reply, so don’t use one if you plan to receive messages.

### Shortcodes

If you choose a shortcode as your sender ID, you can use it to send messages from different services so that users only receive texts from one number.

If you want to do this and allow users to reply, you must create a mechanism that will distribute messages to the right service team (for example, by asking users to include a keyword).

You must not use a shared shortcode that can be used by any non-government organisations as it could leave your service and its users vulnerable to fraud.

Dealing with delivery errors
----------------------------

Permanent and temporary delivery failures happen when the service provider can’t reach your users.

Permanent failures mean the phone number you are sending your message to is broken or doesn’t exist. You should check delivery receipts regularly and remove these numbers from your database to reduce delivery costs.

Temporary failures mean a mailbox may be full or the service provider is unable to reach your users at a specific time. You should consider whether it would be helpful to send a reminder or contact the user in a different way.

Testing integration
-------------------

You should work with your service provider to regularly test the messaging integration with your service.

Most providers will provide ways to [smoke test](https://en.wikipedia.org/wiki/Smoke_testing_(software)) the integration without sending real messages.

Checking the format and content of your messages
------------------------------------------------

You should follow the guidance on [when and how to write text messages](https://www.gov.uk/service-manual/design/sending-emails-and-text-messages) to make sure yours are clear and informative for users.

Related guides
--------------

You may also find the following guides useful:

* [Planning and writing text messages and emails](service-manual_design_sending-emails-and-text-messages.md)
* [How to email your users](service-manual_technology_how-to-email-your-users.md)
* [Protecting your service against fraud](service-manual_technology_protecting-your-service-against-fraud.md)
* [Working with cookies and similar technologies](service-manual_technology_working-with-cookies-and-similar-technologies.md)

Updates to this page
--------------------

Published 19 October 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---