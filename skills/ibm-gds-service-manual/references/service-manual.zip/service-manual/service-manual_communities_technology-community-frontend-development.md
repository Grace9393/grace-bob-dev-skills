Technology community (frontend development) - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Technology community (frontend development)
===========================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Join the community](#join-the-community)
3. [Community resources](#community-resources)
4. [Frontend development in the Service Manual](#frontend-development-in-the-service-manual)

This community exists to:

* share information about frontend development for government services
* discuss and challenge how frontend development works for government services
* bring together people from across government with an interest in frontend development

Who the community is for
------------------------

You might be interested in this community if your work involves:

* making decisions about the code libraries used in frontend development
* building accessible digital services
* giving technology advice and being the technical voice in conversations about frontend development

You do not need to be a frontend developer to join.

Join the community
------------------

Use the [cross-government #frontend Slack channel](https://ukgovernmentdigital.slack.com/messages/frontend/) to discuss issues related to frontend development.

Community resources
-------------------

The [technology in government blog](https://technology.blog.gov.uk/) discusses how government builds accessible and scalable interfaces, and the code libraries to support those. These include:

* [GOV.UK Frontend](https://design-system.service.gov.uk/get-started/production/)
* [GOV.UK Design System](https://design-system.service.gov.uk)

Frontend development in the Service Manual
------------------------------------------

This is what we currently consider to be best practice in frontend development for government services:

* [Using progressive enhancement](service-manual_technology_using-progressive-enhancement.md)
* [Designing for different browsers and devices](service-manual_technology_designing-for-different-browsers-and-devices.md)
* [How to test frontend performance](https://www.gov.uk/service-manual/technology/how-to-test-frontend-performance)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* suggesting an addition or improvement by [proposing a change](https://www.gov.uk/service-manual/communities/propose-a-change-to-the-service-manual)

Updates to this page
--------------------

Published 23 May 2016

Last updated 18 June 2024
[+ show all updates](#full-history)

1. 18 June 2024

   Removed the link to the cross-government frontend developers Google group. Updated the feedback link to the new 'Propose a change to the Service Manual' page.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---