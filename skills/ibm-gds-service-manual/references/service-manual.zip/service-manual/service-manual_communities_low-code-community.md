Low code community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Low code community
==================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [How to join the community](#how-to-join-the-community)

The Low code community exists to foster a collaborative environment where members can share knowledge, best practices, and innovative solutions related to low code applications development and platforms.

Through meetings, workshops, and knowledge-sharing sessions, this community focuses on building a supportive network that encourages continuous learning, professional growth, and the effective use of low code platforms to solve real world challenges.

This community strives to empower individuals and organisations to leverage low code technologies to accelerate digital transformation, enhance productivity, and enhance public sector delivery.

The ambition of this community is to be regarded as the key stakeholder for the development and implementation of a Low Code strategy across the UK Government, encompassing people, processes and technology, and offer expertise and support when relevant and available.

Who the community is for
------------------------

The community is open to people across UK Government departments and agencies.

Members of the cross-government Low code community must:

* demonstrate a genuine interest in low code platforms and their application in government operations
* commit to actively participating in community meetings, events, and activities
* be willing to share experiences, best practices, and lessons learned with other community members
* have support from their department or agency leadership to participate in the community and contribute to its objectives
* be a civil servant or contractor working in a UK government department or agency

How to join the community
-------------------------

You can [join the community by completing this form](https://forms.office.com/pages/responsepage.aspx?id=BXCsy8EC60O0l-ZJLRst2B3zUsnqqAFNnusGvekXpZlUM0VCTDcyQUtHSVYwU1NJTE1QTFM1SE9NVi4u&route=shorturl).

To contact the Low Code Community committee you can [send an email to xgovlowcode@ics.gov.uk](mailto:xgovlowcode@ics.gov.uk).

Updates to this page
--------------------

Published 21 February 2025

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---