Application programming interfaces (APIs) - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Application programming interfaces (APIs)
=========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Use government API standards](#use-government-api-standards)
2. [How to host your API](#how-to-host-your-api)
3. [What to consider when depending on third-party APIs](#what-to-consider-when-depending-on-third-party-apis)

An application programming interface (API) is a piece of software that lets one program access or control another program. APIs allow applications to share data without requiring developers to share software code.

You should follow these guidelines to build and maintain your APIs.

Use government API standards
----------------------------

The Central Digital and Data Office’s [API design guidance](https://www.gov.uk/government/collections/api-design-guidance) helps government departments and local authorities create robust APIs. The [API data and technical standards](https://www.gov.uk/guidance/gds-api-technical-and-data-standards) promote development consistency, increase efficiency, improve security, reduce costs and provide better digital public services.

How to host your API
--------------------

You can host your APIs on [api-name].api.gov.uk. Email [api-domain-requests@digital.cabinet-office.gov.uk](mailto:api-domain-requests@digital.cabinet-office.gov.uk) for more information about using this.

What to consider when depending on third-party APIs
---------------------------------------------------

By relying on a third-party API, you could tie your service’s availability to that of the third party. In some cases this may be acceptable. But, you need to make sure you have a backup plan if the third-party is no longer in business.

The details of that backup will vary depending on your service. You may need to:

* offer users the opportunity to use an alternative service
* queue an action to take place later
* have an alternative system in place

If a third-party API failure affects your service, you should be clear with your users about what’s happening and find ways to limit the effect on users.

Prepare a communications plan in advance. This could include having things like email templates in place and a list of who you need to contact should problems arise.

Learn about [managing third-party product security risks](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-third-party-product-security-risks/).

Updates to this page
--------------------

Published 16 December 2016

Last updated 17 October 2024
[+ show all updates](#full-history)

1. 17 October 2024

   Integrated guidance on Managing third-party product security risks.
2. 16 December 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---