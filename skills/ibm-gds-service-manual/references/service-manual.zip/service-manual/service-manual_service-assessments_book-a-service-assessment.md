Book a service assessment - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

Book a service assessment
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [If your service does not meet the standard at its assessment](#if-your-service-does-not-meet-the-standard-at-its-assessment)
2. [What information you need to provide](#what-information-you-need-to-provide)
3. [Who should attend the assessment](#who-should-attend-the-assessment)
4. [Prepare for an assessment](#prepare-for-an-assessment)
5. [Related guides](#related-guides)

Before you book an assessment you should:

* check your service against the Service Standard to see if you’re covering all the points
* have a meeting with your department’s assessment team to check if your service is ready for an assessment - and whether it will be assessed by a panel from your department or a cross-government panel

Your department’s assessment team will agree a time and date for the assessment with you. They will contact GDS if a cross-government panel is needed. They should contact GDS at least 4 weeks before you want the service to be assessed.

Most services are assessed remotely. [Read more about how remote assessments are run](https://services.blog.gov.uk/2020/04/09/how-to-run-a-remote-service-assessment/).

If you’re in an agency, you may have to contact your parent department to arrange an assessment.

If your service does not meet the standard at its assessment
------------------------------------------------------------

You’ll need to book a reassessment by contacting your department’s assurance team.

You’ll get a report explaining the things you’ll need to improve to meet the standard.

What information you need to provide
------------------------------------

Before a service assessment, the assessment team will ask you to provide a short service brief, including a:

* description of your service and its users
* recent prototype or link to a development environment
* high-level technical architecture diagram

You can bring user journey maps or anything that will help you demonstrate your work to the assessment.

Who should attend the assessment
--------------------------------

You should bring the people you feel are most able to answer the questions you’re likely to be asked.

It’s recommended that at least the following team members attend:

* service owner
* technical architect or lead developer
* user researcher
* designer
* performance analyst (for beta and live assessments)

Your department’s assessment team can recommend who you should bring.

Prepare for an assessment
-------------------------

You can [find out what will happen at a service assessment](service-manual_service-assessments_how-service-assessments-work.md). This will help you plan what you’ll say and how long you’ll need to spend on each section at your assessment. You can also read [previous service assessment reports](https://www.gov.uk/service-standard-reports).

Related guides
--------------

You may find the following guides useful:

* [Check if you need a service assessment](service-manual_service-assessments_check-if-you-need-a-service-assessment.md)
* [What happens at a service assessment](service-manual_service-assessments_how-service-assessments-work.md)

Updates to this page
--------------------

Published 26 October 2017

Last updated 9 May 2024
[+ show all updates](#full-history)

1. 9 May 2024

   Updated to reflect changes in responsibilities around assessments.
2. 6 August 2018

   Added steps teams should take before booking a GDS assessment.
3. 26 October 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---