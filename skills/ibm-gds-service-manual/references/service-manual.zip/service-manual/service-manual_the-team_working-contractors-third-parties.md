Working with contractors or third parties - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

Working with contractors or third parties
=========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Identify the skills you need](#identify-the-skills-you-need)
2. [Choosing contractors or third parties](#choosing-contractors-or-third-parties)
3. [After you recruit contractors](#after-you-recruit-contractors)
4. [Related guides](#related-guides)

You need to have a range of specific [service delivery team roles](service-manual_the-team_what-each-role-does-in-service-team.md) in place to design, build and run your digital service.

If you don’t have these in your team or available to it, you may need to hire third parties or contractors.

You should only work with contractors or suppliers who are prepared to pass on their expertise.

Identify the skills you need
----------------------------

When you have an idea of the service you’re going to create, talk to your team about the skills you need.

Before you recruit anyone from outside the Civil Service, see if you have any team members who can develop these skills.

Choosing contractors or third parties
-------------------------------------

It’s important to only buy the skills you need and not to lock your service into a long contract with a fixed cost.

When you’re considering a person or company to work with, look for evidence of:

* a proven track record of using [agile methods](service-manual_agile-delivery_agile-methodologies.md) to design, build and deliver projects
* the ability and commitment to share knowledge with permanent staff in the delivery team
* how they’ll deliver in an agile way, even if your department traditionally uses [waterfall](https://en.wikipedia.org/wiki/Waterfall_model) or [PRINCE2](https://en.wikipedia.org/wiki/PRINCE2) delivery methods
* how they define, measure and maintain good quality products and services
* their ability to comply with relevant cyber security obligations

You can [use the Digital Marketplace to buy a service or find a skill](/digital-marketplace). The [Digital Marketplace buyers’ guide](https://www.gov.uk/guidance/digital-marketplace-buyers-guide) explains how to do this.

You can also use the [Digital Training and Support buyers’ guide](https://www.gov.uk/guidance/digital-training-and-support-buyers-guide) if you need to buy a service or find a skill to help you provide assisted digital support.

Products and services in the Digital Marketplace have not been security assured. Learn about [managing third-party product security risks](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-third-party-product-security-risks/).

After you recruit contractors
-----------------------------

To limit the potential of [cyber security vulnerabilities](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/discovering-vulnerabilities/), contractors and suppliers should only be given necessary access to the information and systems they need to do their job and contribute to the work of the team.

Appropriate processes should be in place to remove access when it is no longer required.

Treat contractors and permanent staff as equal team members. This will make it easier to establish a shared agile culture, with more informal learning and fewer communication overheads.

### Transferring knowledge

You must make sure you have a plan to pass knowledge from contractors to the rest of your team. This is particularly important when you move from one phase to another, or if you change supplier.

To make sure knowledge transfer happens, you could do things like:

* encourage pairing: you might need to adjust people’s workloads so they’ve got time to do this
* organise sessions for contractors to share their knowledge or experiences
* make sure any documentation is in a good state

Related guides
--------------

You may also find the following guides useful:

* [Set up a service team at each phase](https://www.gov.uk/service-manual/the-team/set-up-a-service-team)
* [What each role does in a service delivery team](service-manual_the-team_what-each-role-does-in-service-team.md)
* [Recruit your team](service-manual_the-team_recruit-your-team.md)
* [Change the size of a service team](https://www.gov.uk/service-manual/the-team/change-size-of-service-team)

Updates to this page
--------------------

Published 3 March 2016

Last updated 17 October 2024
[+ show all updates](#full-history)

1. 17 October 2024

   Integrated guidance on Managing third-party product security risks.
2. 8 July 2020

   Updated so it emphasises the importance of integrating contractors with the team rather than having everyone work in a single, shared space.
3. 21 May 2018

   Added examples of how teams can transfer knowledge from contractors
4. 12 October 2016

   Added link to 'Digital Marketplace buyers’ guide'.
5. 6 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---