Researching user experiences - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Researching user experiences
============================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Using event cards](#using-event-cards)
2. [Steps to follow](#steps-to-follow)
3. [Create an experience map](#create-an-experience-map)
4. [Examples and case studies](#examples-and-case-studies)
5. [Related guides](#related-guides)

Researching a user’s experience of a service can help you to understand it from their point of view.

Finding out what they did, thought and felt over time as they experienced different parts of the service will help your team identify and focus on users’ needs.

Using event cards
-----------------

‘Event cards’ can help you capture essential information about an experience, including what a user was doing, thinking and feeling. They usually include questions like:

* what happened?
* who/what was involved?
* what did you do?
* what were you thinking?
* how did you feel?

You can create cards by printing or writing sets of questions on paper or card.

![ ](https://assets.publishing.service.gov.uk/media/5890bb3d40f0b65934000054/Screen_Shot_2017-01-31_at_15.25.24.png)

Steps to follow
---------------

Think about what you want to learn as you plan your research.

### Plan the sessions

Researching an experience usually takes between 60 and 90 minutes, depending on the complexity of the subject. Longer sessions will give you greater detail but can make it harder to recruit participants.

When planning your sessions, you’ll need to:

* [choose a location](service-manual_user-research_choose-a-location-for-user-research.md) and decide your session length
* determine if there are distinct user groups with different needs or experiences
* [recruit research participants](service-manual_user-research_find-user-research-participants.md) who have had the experience you’re interested in
* recruit at least 4 of each type of user, if you’ve identified distinct groups
* recruit 8 people if you have not identified different user types
* arrange for interpreters or assistants to help participants that need them (for example, some may need help with writing out event cards)

### Set up

At your research location, make sure you have:

* a table and chairs
* a wall (or table) large enough to map out their experience
* a stack of event cards for each participant - expect participants to complete between 20 and 40 cards, depending on the length and complexity of the service or experience
* a space and setup that will work for disabled participants

### Do the research

[Get informed consent](https://www.gov.uk/service-manual/user-research/getting-users-consent-for-research) from all participants before you start the session. Explain that you want to learn about their experience and will work together, using the event cards, to create a picture of everything that happened. To do this:

* ask the participant to begin by telling you about their experience so you have a good overall picture of what happened
* pick a place to start and ask the participant to write a few event cards to cover the things that happened at that point
* encourage participants to write clearly, so you can read their cards later
* ask them to talk you through their cards to make sure you understand them, adding any points they talk about but have not written down

### Order the cards

Once a participant has completed a few cards, start arranging them on the wall (or table) in time order from left to right. Encourage participants to:

* continue writing cards until they’ve covered everything that happened
* group closely related cards in the same column
* look over their map to check it accurately represents their experience - if they remember more events, ask them to add these

### Add improvement ideas

Once a participant has finished describing their experience, you can find out about improvements. Ask participants to:

* look at the most problematic parts of the experience and think about how it could have been better for them
* use a different colour pen and more event cards to write ‘what should have happened’ cards - these should describe what a good experience would have been like
* add the ‘what should have happened’ cards to the map so you can see how they relate to the participant’s actual experience

### Wrap up the session

Once you’ve finished writing cards:

* thank the participant for their time and what they’ve helped you learn
* explain what will happen with your research
* ask the participant what they thought of the session, so you can improve next time

### Capture the cards

It’s important to record what happened during a research session so you can analyse experiences and reconstruct the map if you need to. Recordings can also help you understand any cards that are unclear.

After you’ve thanked a participant and let them go, you should:

* write a participant number and sequence number on each card, and take a photo of their map
* stack all the cards in number order and clip them together so you can refer to them easily

Create an experience map
------------------------

Once you’ve captured the experience of several users, you can combine them to [create an experience map](service-manual_user-research_creating-an-experience-map.md).

These help you to visualise how users experience the current service.

Examples and case studies
-------------------------

Learn how [mapping is helping teams to improve the digital justice system](https://gds.blog.gov.uk/2015/08/18/mapping-new-ideas-for-the-digital-justice-system-2/).

Related guides
--------------

You may also find these guides useful:

* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Using in-depth interviews](service-manual_user-research_using-in-depth-interviews.md)

Updates to this page
--------------------

Published 21 February 2017

Last updated 25 August 2017
[+ show all updates](#full-history)

1. 25 August 2017

   Clarified guidance on how to end research sessions.
2. 21 February 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---