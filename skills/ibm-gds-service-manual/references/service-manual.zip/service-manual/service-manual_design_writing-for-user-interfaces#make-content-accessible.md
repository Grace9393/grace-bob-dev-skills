Writing for user interfaces - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Writing for user interfaces
===========================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Think about alternatives before you add more words](#think-about-alternatives-before-you-add-more-words)
2. [Keep copy short and direct](#keep-copy-short-and-direct)
3. [Tone](#tone)
4. [Don't exclude anyone](#dont-exclude-anyone)
5. [Style](#style)
6. [URLs](#urls)
7. [Legal content](#legal-content)
8. [Further reading](#further-reading)

Aim to minimise [cognitive load](https://www.nngroup.com/articles/minimize-cognitive-load/) by being as clear as possible and using the same language as your users. This helps:

* reduce the amount of time you spend dealing with mistakes
* make your service inclusive for people who struggle with reading or have limited English
* make your service accessible

Even specialist users prefer clear language. No one likes having their time wasted, [especially busy people like health workers](https://gds.blog.gov.uk/2014/02/17/guest-post-clarity-is-king-the-evidence-that-reveals-the-desperate-need-to-re-think-the-way-we-write).

It’s especially important to [choose an intuitive name for your service](https://www.gov.uk/service-manual/design/naming-your-service). If your title reflects your users’ language, they’ll be able to find your service and understand what it does.

Don’t follow strict grammar conventions if it makes things clearer not to.

Think about alternatives before you add more words
--------------------------------------------------

On the internet [people tend to scan rather than read](https://www.nngroup.com/articles/how-users-read-on-the-web). Even more so when they’re using a transactional service.

So start with less. If you’re creating a form, [start with some simple questions](https://www.gov.uk/service-manual/design/designing-good-questions) and only add help text if user research shows that you need it.

Design your service to take account of the fact that lots of people won’t read the content in detail. For example, [ask questions to establish eligibility](https://design-system.service.gov.uk/patterns/check-a-service-is-suitable/) rather than putting a long list of eligibility conditions on the start page.

If you find yourself having to explain how the user interface works, that’s a sign something has gone wrong. Fix the interface so it doesn’t need explaining.

Keep copy short and direct
--------------------------

Break up copy into short sentences. One idea per sentence.

Space is at a premium with user interfaces. So put the important words first and drop any unnecessary words.

For example, if you’re writing [help text](service-manual_design_designing-good-questions#add-help-text-where-necessary.md) there’s usually no need to say ‘This is the total cost’. Just say ‘Total cost’. If you’re writing an error message, don’t say ‘You have entered the wrong password’. Say ‘Wrong password’.

You don’t usually need the word ‘now’. For example, just say ‘apply’ rather than ‘apply now’ (unless you’re giving the user two options: apply now or apply later).

Tone
----

Be approachable and helpful, but not overly familiar. Remember that it’s government ‘speaking’.

Say ‘sorry’ if something serious has gone wrong - for example, the service has stopped working completely. ‘Sorry, there is a technical problem. Please try again in a few moments.’

There’s no need to say ‘sorry’ in validation error messages.

There’s usually no need to say ‘please’ or ‘please note’.

There’s usually no need to say thank you. For example, it’s fine to say ‘Application complete’ rather than ‘Thank you for your application’.

Avoid things like humorous error messages. People often use government services for serious things or when under stress.

If people don’t notice your copy, you’re probably doing it right. [Aim to be boring](https://capwatkins.com/blog/the-boring-designer).

Don’t exclude anyone
--------------------

Don’t rely on shape, size, colour or location alone to communicate information, because not all users will share that frame of reference. For example, don’t say things like:

* ‘click the green button’
* ‘use the menu on the left of the page’
* ‘find more information in the square box’

Break up long pages with headings. It’s easier to scan and read. Headings should describe the purpose of the text that follows - they shouldn’t be part of the text.

Screen reader users often read out lists of links in isolation, so make the purpose of the link clear from the link text alone. For example, ‘click here’ is not accessible link text.

Sometimes you need to shorten link text to avoid lots of duplication. If you do that, make sure links are still accessible to screen readers. For example, by adding hidden text to the ‘change’ links on [check your answers pages](https://www.gov.uk/service-manual/design/check-your-answers-pages).

Style
-----

Follow the [GOV.UK style guide](https://www.gov.uk/styleguide) on how to write times and dates, spelling, punctuation, acronyms and other conventions.

### Headings and `<title>`

It’s fine to have headings as questions. In fact, it can help to remove duplication.

But make sure every text box, set of radio buttons or other input field still has a question directly associated with it in the html, so it makes sense to screen readers. For example, by using a visually hidden `<legend>` or `<label>`.

Each page should have a single `<h1>`. The `<h1>` should describe what the page does.

The `<title>` should be based on the `<h1>`, and follow this format:

Where do you live? - Register to vote - GOV.UK

### Pronouns (we, you, me, my)

Forms are like a conversation between the service and the user.

If it’s the service ‘speaking’, the user is ‘you’ or ‘your’ and the service is ‘we’, ‘us’, ‘our’ and so on.

If it’s the user ‘speaking’, use ‘I’, ‘me’ or ‘my’.

This applies to all microcopy, including headings, input labels and link text.

For example, the Register to vote service asks users ‘What is your National Insurance number?’. If the user doesn’t know their number, they can click a link labelled ‘I don’t know my National Insurance number’.

![ ](https://assets.publishing.service.gov.uk/media/59dcbf1540f0b63118216855/Register_to_vote_3.png)

Use ‘they’ instead of ‘he or she’ or ‘he/she’. It’s simpler, and works better for people who don’t identify as male or female.

### Capitalisation and punctuation

Use sentence case everywhere, except for proper nouns.

Headings and input field labels are sentence case, but not punctuated. Write other copy in full sentences, with a full stop at the end.

### Contractions, abbreviations and acronyms

Don’t use ‘ie’. Use ‘for example’ instead of ‘eg’.

Use simple contractions like ‘you’re’ and ‘we’ll’.

Avoid:

* should’ve, could’ve, would’ve, they’ve - these can be hard to read
* negative contractions like ‘can’t’ and ‘don’t’ - some users find them harder to read, or misread them as the opposite of what they say

Include any relevant acronyms on your GOV.UK start page for SEO purposes, but try to avoid using them inside the transaction.

And if you do use them, spell them out in full on each page. Don’t rely on people remembering them across different pages.

URLs
----

Make sure your URLs are clear and readable. This will help users understand where they are in your service.

Don’t include personal information (like a user’s name or date of birth) in the `<title>` field of a URL - you don’t want it to show up in your site analytics.

Legal content
-------------

All language should be as simple to understand as possible, including privacy policies and declarations. Explaining users’ rights and obligations clearly is good legal practice as well as being good for usability.

Further reading
---------------

Read these blogs to find out more about writing for user interfaces:

* [Writing for user interfaces](http://uiwriting.tumblr.com)
* [Interface writing: code for humans](http://nicolefenton.com/interface-writing)
* [Bring out your inner UX writer](https://medium.com/@rachaelamullins/bring-out-your-inner-ux-writer-ddd813d1411d)
* [Tips for testing your words](https://userresearch.blog.gov.uk/2015/07/01/what-does-this-mean-tips-for-testing-your-words)
* [Content is crucial, but the right design is essential](https://hodigital.blog.gov.uk/2018/12/20/content-is-crucial-but-the-right-design-is-essential/)

Updates to this page
--------------------

Published 10 October 2017

Last updated 16 April 2018
[+ show all updates](#full-history)

1. 16 April 2018

   Added guidance about using contractions and abbreviations.
2. 3 November 2017

   Added guidance on designing URLs.
3. 10 October 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---