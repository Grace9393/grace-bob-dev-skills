Spend controls: check if you need approval to spend money on a service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Spend controls: check if you need approval to spend money on a service
======================================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Why some services must get spend approval](#why-some-services-must-get-spend-approval)
2. [How CDDO decides which services need approval](#how-cddo-decides-which-services-need-approval)
3. [When your service is considered a digital service](#when-your-service-is-considered-a-digital-service)
4. [When you need approval for digital services](#when-you-need-approval-for-digital-services)
5. [When your service is considered a technology service](#when-your-service-is-considered-a-technology-service)
6. [When you need approval for technology](#when-you-need-approval-for-technology)
7. [Technology spending that counts as part of your total spend](#technology-spending-that-counts-as-part-of-your-total-spend)
8. [Projects that usually will not be approved](#projects-that-usually-will-not-be-approved)
9. [Apply for approval](#apply-for-approval)
10. [Managing public money](#managing-public-money)

If you want to spend money on a digital or technology service, you may have to get approval from the Central Digital and Data Office (CDDO).

This process is known as ‘spend controls’.

This guidance is about the older spend controls process. Follow the newer [spend controls pipeline process](service-manual_agile-delivery_spend-controls-pipeline-process.md) if your department is using it. Check with your digital or technology lead to find out.

Why some services must get spend approval
-----------------------------------------

CDDO requires services to get spending approval to make sure they’re built in line with the [Technology Code of Practice](/government/publications/technology-code-of-practice/technology-code-of-practice).

You should read the code before starting work on your service and use it when making decisions about technology.

The spend controls process exists to make sure:

* you’ve considered the needs of the people who’ll use the service
* you get the best value
* you only spend on programmes and projects that meet government digital and technology strategies
* private businesses and members of the public can see how government makes decisions about spending money on digital projects or technology
* you discover and solve any problems with your service before you spend money
* you develop services using [agile methods](https://www.gov.uk/service-manual/agile-delivery)

How CDDO decides which services need approval
---------------------------------------------

CDDO decides whether your service needs approval based on these 3 factors:

* whether your department is a central government department - [download the public sector classification guide](https://www.ons.gov.uk/methodology/classificationsandstandards/economicstatisticsclassifications/introductiontoeconomicstatisticsclassifications) to find out
* whether CDDO classes your service as a digital service or a technology service
* the amount of money you want to spend

When your service is considered a digital service
-------------------------------------------------

CDDO considers your service a digital service if it’s online and it’ll be used by people who are not part of government, for example:

* citizens
* businesses
* other non-government organisations

The following are examples of digital services:

* transactional services (a service where the user gives personal details to government, for example applying for a passport)
* information services (a service where the user does not have to give personal details, for example a tax or benefit calculator)
* web applications
* mobile apps
* websites
* extranets

CDDO does not consider your service a digital service if you’re creating content (and not a service) on:

* existing sites
* intranets
* areas listed under the [advertising, marketing and communications controls](https://www.gov.uk/government/publications/cabinet-office-controls) (see Annex 3)

When you need approval for digital services
-------------------------------------------

You must get approval to spend any amount of money on a new digital service that meets one or more of these conditions:

* it’s for the general public
* it uses [identity assurance](https://gds.blog.gov.uk/2014/01/23/what-is-identity-assurance/)
* it requires domain registration
* it uses external-facing digital transactions
* it features website or mobile apps

For any other digital service, you must get approval to spend more than £100,000.

When your service is considered a technology service
----------------------------------------------------

CDDO considers your service a technology service if it meets all of these conditions:

* it’s internal facing
* it’s delivered by government for government

When you need approval for technology
-------------------------------------

You must get approval to spend more than £1 million on technology.

If you are spending more than £1 million on any technology which is also delivered by Government Shared Services, you must also contact them at [SSfG-Secretariat@cabinetoffice.gov.uk](mailto:SSfG-Secretariat@cabinetoffice.gov.uk) to discuss the spend. This includes technology such as:

* enterprise resource planning (ERP) systems
* human resource systems
* finance or accounting systems
* procurement systems

‘Technology’ means all parts of the service you’re proposing to build, including the following types of support:

* contacts in hosting
* data centres
* voice and video
* security
* third party support

Technology spending that counts as part of your total spend
-----------------------------------------------------------

If CDDO has classed your project as a technology project, any money you spend on the following counts as part of the total spend figure you must use when checking if you need spend approval:

* contract amendments, extensions or renewals
* licences
* spending through existing frameworks, for example cloud or commercial
* feasibility or proof of concept studies
* pilots
* projects (or any part of a project) and programmes - [find out the difference between projects and programmes](https://apmg-international.com/article/difference-between-project-and-program)
* any changes, enhancements, maintenance or refreshes
* common infrastructure solutions including voice and data communications
* [PSN](https://www.gov.uk/government/groups/public-services-network), whether fixed or mobile
* programmes that you’ve broken into smaller projects which individually are below the thresholds, but which are above them in total

### Assisted digital spending that counts as part of your total spend

You should consider the following types of [assisted digital support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md) as part of your spend:

* face-to-face support
* phone support, for example call centres
* third party intermediary support, like service integrators, consultancies or partners
* other channels that allow users to access the digital service, such as letters

Projects that usually will not be approved
------------------------------------------

CDDO usually will not give you approval to spend money on the following activities:

* entering into an IT contract that’s worth more than £100 million
* contracting a company to supply you with system integration after you’ve already contracted them to provide you with a service in the same part of government - [find out why government has moved away from a towers model](https://governmenttechnology.blog.gov.uk/2015/02/18/knocking-down-the-towers-of-siam/)
* renewing contracts automatically
* offering new hosting contracts that last longer than 2 years
* building native or hybrid apps

If you want approval to spend money on one of these activities, contact CDDO by emailing [gdsassurance@digital.cabinet-office.gov.uk](mailto:gdsassurance@digital.cabinet-office.gov.uk).

Apply for approval
------------------

Find out how to [apply for approval to spend money on a service](service-manual_spending-money-on-your-service_apply-for-approval-to-spend-money-on-a-service.md).

Managing public money
---------------------

As well as following this guidance, you must follow the rules on [managing public money](https://www.gov.uk/government/publications/managing-public-money).

Updates to this page
--------------------

Published 16 May 2016

Last updated 29 July 2021
[+ show all updates](#full-history)

1. 29 July 2021

   Updated the amount of technology spend that needs approval from over £5 million to over £1 million.
2. 25 October 2016

   Added native and hybrid apps to projects that won't usually be approved
3. 16 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---