Buying digital community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Buying digital community
========================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)

The buying digital community exists to:

* make sure that procurement practices support agile ways of working
* create and support a peer group of buyers across government
* share knowledge and best practice for buying digital and technology services
* discuss common challenges and develop solutions
* build commercial awareness across central government and the wider public sector

Who the community is for
------------------------

The community is for buyers of digital data and technology services across central government and wider public sector, particularly those using the [Digital Marketplace](https://www.digitalmarketplace.service.gov.uk/).

This includes:

* procurement managers
* contract managers
* commercial leads
* delivery teams involved in buying
* operations teams involved in buying

Get involved
------------

### Online

If you’re interested in getting involved in the buying digital community, you can:

* join the buying digital community mailing list by sending an email to [cloud\_digital@crowncommercial.gov.uk](mailto:cloud_digital@crowncommercial.gov.uk)
* join the community of practice group on [Knowledge Hub](https://khub.net/welcome)
* read the [Digital Marketplace blog](https://digitalmarketplace.blog.gov.uk/)
* follow [@gov\_procurement](https://twitter.com/gov_procurement) on Twitter
* follow [@GOVUKdigimkt](https://twitter.com/GOVUKdigimkt) on Twitter

If you have a question, email [cloud\_digital@crowncommercial.gov.uk](mailto:cloud_digital@crowncommercial.gov.uk).

### Training and events

The Crown Commercial Service runs workshops in departments every month, to help buyers get the most out of the Digital Marketplace. If you think your team might benefit from a workshop, call 0345 410 2222.

The community also has meet ups every 2 months. Join the [Knowledge Hub](https://khub.net/welcome) to make sure you’re notified.

Community resources
-------------------

If you’re a buyer using the Digital Marketplace for the first time, start by reading the [Digital Marketplace buyer’s guide](https://www.gov.uk/guidance/digital-marketplace-buyers-guide).

Other resources are:

* the [Technology Code of Practice](https://www.gov.uk/guidance/define-your-purchasing-strategy), which covers the principles departments must follow to get spending approval
* the [Supplier Standard](https://www.gov.uk/government/consultations/supplier-standard-for-digital-and-technology-service-providers), which covers how government should work with digital and technology providers
* the [Service Standard](https://www.gov.uk/service-manual/service-standard), which covers how delivery teams should build and operate services

Updates to this page
--------------------

Published 3 August 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---