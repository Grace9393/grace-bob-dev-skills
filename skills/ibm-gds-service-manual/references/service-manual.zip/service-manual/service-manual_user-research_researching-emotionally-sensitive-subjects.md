Researching emotionally sensitive subjects - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Researching emotionally sensitive subjects
==========================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Preparing for sessions](#preparing-for-sessions)
2. [Building a rapport with participants](#building-a-rapport-with-participants)
3. [Helping people who need more support](#helping-people-who-need-more-support)
4. [Dealing with the emotional impact of the research](#dealing-with-the-emotional-impact-of-the-research)
5. [Tell us about your experiences](#tell-us-about-your-experiences)

Sometimes you’ll need to run research sessions with vulnerable participants, exploring topics that are sensitive or difficult to talk about.

There are a few things you’ll need to consider to protect you and your participants’ wellbeing.

Preparing for sessions
----------------------

There are a few extra things to factor into your [research planning](https://www.gov.uk/service-manual/user-research/plan-round-of-user-research) if you’re dealing with emotionally sensitive subjects or working with vulnerable participants.

### Learn about the subject matter you’ll be discussing

It’s important that you’re not overwhelmed by the topics you’re researching, as this will make it harder for participants to feel comfortable talking openly. The best way to prevent this is to familiarise yourself with the subject matter ahead of the session.

You can do this through desk research, or by speaking to an expert or someone who’s done similar research before. Experts like charities and support networks might also be able to help you [recruit participants](https://www.gov.uk/service-manual/user-research/find-user-research-participants).

Learning about the subject will help you decide whether you feel comfortable doing the research. If you react negatively to the subject matter, or have traumatic associations with it, it’s absolutely fine to say you do not feel the project is right for you.

### Think about the whole research process

It’s worth remembering that the participant’s journey begins before they sit down and start talking to you. So you need to make a positive first impression.

This means considering things like the language you’re using in recruitment materials and your [information sheets](https://www.gov.uk/service-manual/user-research/getting-users-consent-for-research#getting-informed-consent).

A team at the Home Office paid extra attention to this when working with users whose physical appearance made it difficult for them to use the passport service photo checker. The team made sure the materials asked questions in a sensitive way.

Make sure to check these things even if you’re using an external recruitment agency.

### Make sure you’re not doing the research alone

It’s useful to take a colleague with you if you’re doing research on a sensitive topic. Firstly, they can take notes which allows you to concentrate on your conversation with the participant.

But it also means you’ve got someone to travel to and from the research with. This gives you the chance to talk about anything you found difficult and means you’re not dealing with the emotional impact of the research on your own.

### Leave more time between sessions than usual

On a standard project, you might do 3 or 4 full days of research in a row. If you’re working on something emotionally sensitive, this probably is not a good idea.

In these cases, it’s better to leave a day or so in between rounds of research - and do fewer sessions per day. This gives you time to reflect on what you’ve heard and make sure you’re ready to tackle the next round.

### Consider the location

It’s worth thinking about [the location you choose for research](https://www.gov.uk/service-manual/user-research/choose-a-location-for-user-research). A standard research lab environment might not always be appropriate.

For example, a team at the Home Office chose to run sessions in a library room in their office, as they were concerned that their users would not feel comfortable talking in an environment that felt too formal.

### Be prepared to cut the session short

Sometimes, you’ll sense that your participant is finding the discussion difficult and that you need to end the session.

Make sure you’ve thought of a gentle way to cut the session short, as ending abruptly could be upsetting if the participant has been talking about something very personal or difficult.

Building a rapport with participants
------------------------------------

It can often be difficult for participants to discuss sensitive or personal issues. This means it’s extra important to build a rapport at the start of the session, so they feel comfortable enough to participate.

This might involve including some time at the beginning of the session for the participant to choose what to talk about, or being prepared to go off script if the conversation moves in a different direction.

You could also go through the consent form and clarify that you’re there to hear about their experiences.

Once you start the session, let the participant control the conversation as much as possible. A few ways of doing this include:

* regularly reminding them that they can stop any time
* framing your questions so it’s easy for them to indicate whether they want to answer - for example by starting them with “May I ask about…” or “Do you mind if I ask about…”
* making it clear they do not have to answer any question they do not want to
* offering them breaks during the session

It’s helpful if your questions are reasonably specific, as it’s easy to drift off topic when you’re discussing very personal things.

You should also think about [what to say at the end of the session](https://www.gov.uk/service-manual/user-research/using-in-depth-interviews#after-the-interview).

Helping people who need more support
------------------------------------

It’s tempting to give advice or to try to help people out when you see they’re in distress or going through something difficult.

As a researcher you need to remain objective - your role is to understand, not advise. But it’s okay to direct the participant to places where they could get more information and support following the session.

A subject matter expert should be able to let you know where to point participants who need extra support.

Dealing with the emotional impact of the research
-------------------------------------------------

Listening to people’s traumatic experiences can be distressing, especially if you’re running several sessions on the same subject.

Make sure you take some time to relax after the sessions - it’s important to unwind and switch off from the work you’re doing.

You could also take part in:

* peer support sessions, in which you take the time to reflect on the research with someone else
* support services run by your department, like listening services

You should also acknowledge that, after a particularly difficult session, you might find it hard to concentrate on other work. That’s absolutely fine and a natural part of doing research like this. It might also be an indication that you should take some time to relax or talk to someone.

Tell us about your experiences
------------------------------

If you’ve done user research of this nature, we’d love to hear how you did it. [Get in touch with us](https://www.gov.uk/service-manual/communities/contact-the-service-manual-and-service-standard-team).

Updates to this page
--------------------

Published 12 February 2019

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---