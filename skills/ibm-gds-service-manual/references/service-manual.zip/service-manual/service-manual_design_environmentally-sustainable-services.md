Environmentally sustainable services - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Environmentally sustainable services
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Software, hardware and power](#software-hardware-and-power)
2. [Data use](#data-use)
3. [Third party suppliers](#third-party-suppliers)

The Greening Government Commitments require government to [reduce the CO2 emissions and waste caused by its information technology](https://www.gov.uk/government/publications/greening-government-ict-annual-report-2023-to-2024/greening-government-commitments-ict-annual-report-2023-to-2024#:~:text=2022%20and%202023.-,Detail%20of%20government%20ICT%20emissions%20footprint,compared%20to%202022%20and%202023.).

You should work to reduce your service’s impact to an environmentally sustainable level. This is important to avoid contributing unnecessarily to harmful biodiversity loss, global heating and negative impacts on people’s health and wellbeing.

To help understand, reduce and mitigate the environmental impact of your services, you should:

* measure your service’s emissions and other environmental impacts throughout its lifecycle, and report them to your department
* have a plan for reducing environmental impacts that is in line with departmental goals

You should seek to understand the environmental impacts of all aspects of your service, including:

* mining resources, manufacturing, maintenance, transportation, generating power for and disposing of hardware (including servers, routers and optical fibres)
* generating power for software (including storing and moving data)
* activities of all providers and users, across all channels (for example downloading files and software, buying new hardware, travel and transport, postal services, lighting and heating, and physical materials like paper)

The National Grid explains more about [different scopes of emissions](https://www.nationalgrid.com/stories/energy-explained/what-are-scope-1-2-3-carbon-emissions). The [Technology Carbon Standard](https://www.techcarbonstandard.org/) can help you identify and reduce emissions.

Software, hardware and power
----------------------------

You should design software to require minimal processing power and water consumption (from server cooling systems). You might do this by:

* reducing servers’ energy use by caching and using [content delivery networks](https://www.cloudflare.com/learning/cdn/what-is-a-cdn/)
* using energy efficient software, hardware and infrastructure
* reusing, recycling, or maximising the lifespan of and/or disposing of hardware effectively
* using renewable energy sources for powering data centres and computing resources
* minimising the use of high-energy content, such as video and AI

Data use
--------

Minimise the impacts from data storage and transmission by using [efficient data handling practices](https://www.linkedin.com/pulse/best-practices-data-management-tips-tricks-efficient-1c).

Use data compression and aggregation to reduce storage and bandwidth requirements.

Regularly review and retire the data you hold to help reduce its volume and impact.

Third party suppliers
---------------------

When inviting third party suppliers to bid for projects, you should require them to:

* explain their proposal’s environmental impact
* show how they will reduce and minimise the environmental impact

You should use this information when choosing suppliers. This could be by weighting selections towards suppliers whose proposals have the most sustainable environmental impact, or by working with chosen suppliers to reduce their proposal’s environmental impact.

You can read more about sustainability and third party suppliers in the [Greening Government Commitments](https://www.gov.uk/government/collections/greening-government-commitments).

Updates to this page
--------------------

Published 24 February 2025

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---