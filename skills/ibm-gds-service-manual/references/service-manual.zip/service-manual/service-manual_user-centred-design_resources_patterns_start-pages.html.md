Start pages (archived) – GOV.UK Design System






[Skip to main content](#main-content)


[GOV.UK


Design System](/)

Search Design system
[Sitemap](/sitemap/)

Menu

* [Get started 
  + [Get started overview](/get-started/)
  + ### Setup guides

    - [Prototyping](/get-started/prototyping/)
    - [Production](/get-started/production/)
  + ### How to guides

    - [Making labels and legends headings](/get-started/labels-legends-headings/)
    - [Extending and modifying components in production](/get-started/extending-and-modifying-components/)
    - [Understanding focus state styles](/get-started/focus-states/)
    - [Updating your service to use the new type scale](/get-started/new-type-scale/)](/get-started/)
* [Styles 
  + [Styles overview](/styles/)
  + ### Page structure

    - [Page template](/styles/page-template/)
    - [Layout](/styles/layout/)
    - [Spacing](/styles/spacing/)
    - [Section break](/styles/section-break/)
  + ### Typography

    - [Typeface](/styles/typeface/)
    - [Type scale](/styles/type-scale/)
    - [Headings](/styles/headings/)
    - [Paragraphs](/styles/paragraphs/)
    - [Links](/styles/links/)
    - [Lists](/styles/lists/)
    - [Font override classes](/styles/font-override-classes/)
  + ### Visual elements

    - [Colour](/styles/colour/)
    - [Images](/styles/images/)](/styles/)
* [Components 
  + [Components overview](/components/)
  + - [Accordion](/components/accordion/)
    - [Back link](/components/back-link/)
    - [Breadcrumbs](/components/breadcrumbs/)
    - [Button](/components/button/)
    - [Character count](/components/character-count/)
    - [Checkboxes](/components/checkboxes/)
    - [Cookie banner](/components/cookie-banner/)
    - [Date input](/components/date-input/)
    - [Details](/components/details/)
    - [Error message](/components/error-message/)
    - [Error summary](/components/error-summary/)
    - [Exit this page](/components/exit-this-page/)
    - [Fieldset](/components/fieldset/)
    - [File upload](/components/file-upload/)
    - [GOV.UK footer](/components/footer/)
    - [GOV.UK header](/components/header/)
    - [Inset text](/components/inset-text/)
    - [Notification banner](/components/notification-banner/)
    - [Pagination](/components/pagination/)
    - [Panel](/components/panel/)
    - [Password input](/components/password-input/)
    - [Phase banner](/components/phase-banner/)
    - [Radios](/components/radios/)
    - [Select](/components/select/)
    - [Service navigation](/components/service-navigation/)
    - [Skip link](/components/skip-link/)
    - [Summary list](/components/summary-list/)
    - [Table](/components/table/)
    - [Tabs](/components/tabs/)
    - [Tag](/components/tag/)
    - [Task list](/components/task-list/)
    - [Text input](/components/text-input/)
    - [Textarea](/components/textarea/)
    - [Warning text](/components/warning-text/)](/components/)
* [**Patterns 
  + [Patterns overview](/patterns/)
  + ### Ask users for…

    - [Addresses](/patterns/addresses/)
    - [Bank details](/patterns/bank-details/)
    - [Dates](/patterns/dates/)
    - [Email addresses](/patterns/email-addresses/)
    - [Equality information](/patterns/equality-information/)
    - [Names](/patterns/names/)
    - [National Insurance numbers](/patterns/national-insurance-numbers/)
    - [Passwords](/patterns/passwords/)
    - [Payment card details](/patterns/payment-card-details/)
    - [Phone numbers](/patterns/phone-numbers/)
  + ### Help users to…

    - [Check a service is suitable](/patterns/check-a-service-is-suitable/)
    - [Check answers](/patterns/check-answers/)
    - [Complete multiple tasks](/patterns/complete-multiple-tasks/)
    - [Confirm a phone number](/patterns/confirm-a-phone-number/)
    - [Confirm an email address](/patterns/confirm-an-email-address/)
    - [Contact a department or service team](/patterns/contact-a-department-or-service-team/)
    - [Create a username](/patterns/create-a-username/)
    - [Create accounts](/patterns/create-accounts/)
    - [Exit a page quickly](/patterns/exit-a-page-quickly/)
    - [Navigate a service](/patterns/navigate-a-service/)
    - [Start using a service](/patterns/start-using-a-service/)
    - [Recover from validation errors](/patterns/validation/)
  + ### Pages

    - [Confirmation pages](/patterns/confirmation-pages/)
    - [Cookies page](/patterns/cookies-page/)
    - [Page not found pages](/patterns/page-not-found-pages/)
    - [There is a problem with the service pages](/patterns/problem-with-the-service-pages/)
    - [Question pages](/patterns/question-pages/)
    - [Service unavailable pages](/patterns/service-unavailable-pages/)
    - [Step by step navigation](/patterns/step-by-step-navigation/)**](/patterns/)
* [Community 
  + [Community overview](/community/)
  + ### What we’re working on

    - [Upcoming components and patterns](/community/upcoming-components-patterns/)
    - [Roadmap](/community/roadmap/)
  + ### Ways to get involved

    - [Share findings about your users](/community/share-research-findings/)
    - [Propose a component or pattern](/community/propose-a-component-or-pattern/)
    - [Develop a component or pattern](/community/develop-a-component-or-pattern/)
    - [Propose a content change using GitHub](/community/propose-a-content-change-using-github/)
  + ### How we work

    - [Community principles](/community/community-principles/)
    - [Contribution criteria](/community/contribution-criteria/)
    - [Design System working group](/community/design-system-working-group/)
    - [Blog posts, videos and podcasts](/community/blogs-talks-podcasts/)
  + ### Resources

    - [Resources and tools](/community/resources-and-tools/)
  + ### Events and workshops

    - [Design System Day Events](/community/design-system-day/)
    - [Design System Day 2022](/community/design-system-day-2022/)
    - [Design System Day 2023](/community/design-system-day-2023/)
    - [Design System Day 2024](/community/design-system-day-2024/)
    - [Code of Conduct](/community/code-of-conduct/)](/community/)
* [Accessibility 
  + [Accessibility overview](/accessibility/)
  + - [Accessibility strategy](/accessibility/accessibility-strategy/)](/accessibility/)

1. [Home](/)
2. [Patterns](/patterns)


This page has been archived
===========================

In March 2022, we replaced the ‘Start pages’ pattern with a new, expanded pattern to help users [Start using a service](/patterns/start-using-a-service/).

You can also
[check for previous versions of this page in the UK Government Web Archive](https://webarchive.nationalarchives.gov.uk/*/https://design-system.service.gov.uk/patterns/start-pages).