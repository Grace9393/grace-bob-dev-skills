Measuring success - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Measuring success
=================

How to use data to improve your service: measuring, reporting, analytics tools and techniques.

Getting started with performance data
-------------------------------------

How and why to measure performance and benefits.

* [Using performance data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Measuring the success of your service](service-manual_measuring-success_measuring-the-success-of-your-service.md)
* [How to set performance metrics for your service](service-manual_measuring-success_how-to-set-performance-metrics-for-your-service.md)
* [Measuring the benefits of your service](service-manual_measuring-success_measuring-service-benefits.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)
* [Usability benchmarking a website or whole service](service-manual_measuring-success_usability-benchmarking-a-website-or-whole-service.md)

Data you must measure and report
--------------------------------

Measuring and sharing performance data.

* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)
* [Product and service community](service-manual_communities_product-and-service-community.md)
* [User research community](service-manual_communities_user-research-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/measuring-success)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---