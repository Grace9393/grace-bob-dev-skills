Test your service's performance - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Test your service's performance
===============================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (backend development)](service-manual_communities_technology-community-backend-development.md)

Contents
--------

1. [Start with capacity planning](#start-with-capacity-planning)
2. [How to run performance tests](#how-to-run-performance-tests)
3. [Further reading](#further-reading)
4. [Related guides](#related-guides)

You must make sure your service can perform the tasks that users need it to do, even when it receives high levels of traffic.

If your service can’t handle expected (and unexpected) levels of traffic it may slow down or completely stop working, creating a negative user experience.

You need to do capacity planning during beta and then test your service’s performance regularly to make sure it hasn’t got worse over time.

Start with capacity planning
----------------------------

You need to do capacity planning before you can set up realistic performance tests for your service.

Capacity planning helps you decide the resources you need to keep your service operational. During beta, you should work out:

* how much traffic you expect under normal conditions
* how traffic and database queries will increase every month as the service grows
* whether there could be spikes in volume on certain days or months, for example on self-assessment deadlines, bank holidays or after advertising campaigns

This will help you decide which storage, hardware, software and infrastructure your live service needs.

You should check your capacity plan regularly to predict traffic numbers and make sure your service can handle estimated traffic levels. You should also look at performance results over time to:

* identify trends, for example if there are more users using your service on weekends
* estimate future technology costs

How to run performance tests
----------------------------

You must run regular performance tests to check how your service handles the number of users and interactions you expect.

One of the most valuable forms of performance testing is ‘load testing’. This is when you test your site or application to see how much traffic it can handle while still being able to function properly.

You should carry out regular load testing against your pre-production environments with:

* realistic traffic loads
* loads in excess of your expected traffic levels, for example by simulating a [distributed denial-of-service (DDoS)](https://en.wikipedia.org/wiki/Denial-of-service_attack) attack

When you load test your service, you should gradually increase the load until the service breaks in some way and your [monitoring tools](service-manual_technology_monitoring-the-status-of-your-service.md) alert you to an issue.

### Record test results

When testing your service, you should record:

* the load at which the service broke
* how the service broke and what went wrong

### Assess the risk

The service owner should decide if what you’ve recorded is an acceptable risk for your service. If it isn’t, you’ll need to change how your service behaves under extreme loads.

You could, for example:

* use caching to improve the performance of memory-intensive operations
* improve the performance of your code
* disable certain features when a certain load level is reached to keep the rest of the system working

Further reading
---------------

Find out more about:

* [load testing](https://en.wikipedia.org/wiki/Load_testing) on Wikipedia
* other ways to [test software performance](https://en.wikipedia.org/wiki/Software_performance_testing) on Wikipedia

Related guides
--------------

You may also find these guides useful:

* [Quality assurance: testing your service regularly](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [Testing for accessibility](service-manual_technology_testing-for-accessibility.md)
* [Exploratory testing](service-manual_technology_exploratory-testing.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)

Updates to this page
--------------------

Published 23 May 2016

Last updated 6 February 2017
[+ show all updates](#full-history)

1. 6 February 2017

   Added guidance on capacity planning and how to use performance test results.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---