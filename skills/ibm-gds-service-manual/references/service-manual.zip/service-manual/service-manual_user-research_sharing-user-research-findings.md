Sharing user research findings - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Sharing user research findings
==============================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Who you should share your research with](#who-you-should-share-your-research-with)
2. [How to share research findings](#how-to-share-research-findings)
3. [Presenting your findings](#presenting-your-findings)
4. [Examples and case studies](#examples-and-case-studies)
5. [Related guides](#related-guides)

User research is only useful if your team can use what you’ve learned to improve your service.

Who you should share your research with
---------------------------------------

Whenever you do user research, you should share your findings with your team so they can use what you’ve learned to:

* make design decisions
* prioritise their work
* write new user stories
* refine existing user needs
* develop your proposition or product roadmap

Depending on how you carried out your research and what you learned, you might also want to share it with:

* stakeholders
* other researchers
* other service teams
* users of your service
* members of the public

The more you share, the more people will learn about your users and your service. They’ll also ask questions, spot gaps and comment on what you’re doing - all of which will help you design a better service.

How to share research findings
------------------------------

It’s important to update your team regularly, ideally at a fixed time each week or sprint. You should also look for opportunities to share findings with people outside your team.

You can share what you’ve learned by:

* presenting findings at show and tells
* updating your research wall (eg a wall in your team space where you put up journey maps, personas, insights, screenshots, analytics etc)
* presenting video clips of your research
* creating posters with quotes from participants
* blogging on a departmental blog
* [putting together an empathy map](https://www.nngroup.com/articles/empathy-mapping/), which shows what you’ve learned about your users

You should share your findings as soon as possible. The sooner the team understands what you’ve learned, the sooner they can use the findings to make informed decisions about how to design and build the service.

[Find out how to build a research wall](https://gds.blog.gov.uk/2014/09/03/vertical-campfires-our-user-research-walls/).

Presenting your findings
------------------------

A simple way to present research findings is to create a group of slides (or ‘slide deck’) that includes:

* 1 or 2 slides that outline the research you did
* 5-10 slides that describe your findings
* 1 or 2 slides that show what you’re doing next (if relevant)

Slide decks in this format are easy to talk through at a show and tell. They also make sense on their own, so can be shared and understood easily by people who miss your presentation.

As sprints go by, your collection of slide decks will provide a record of what you’ve learned about your users. This is useful because researchers on an agile team won’t have time to write research reports (though they might produce brief research summaries).

### Structuring research slides

When writing findings slides for a show and tell, answer the basic questions of ‘who’, ‘what’, ‘when’, ‘where’, ‘why’ and ‘how’.

Each findings slide should include:

* a headline that communicates something you’ve learned
* 1 or 2 sentences that describe the essential facts of the finding
* 1 or 2 sentences that explain its importance and any consequences
* a relevant photo or screenshot of what you were testing, or a quote from a participant

You might also want to include:

* analytics data that supports your findings
* design work or sketches for any potential solutions
* short video clips from your research (1 or 2 minutes is usually enough)
* summaries of other research which is relevant to your team’s work

Focus every finding on your users. Try to explain who they are, what they do, how they think, what they need and what happened during the session.

Examples and case studies
-------------------------

To find out more about sharing your research:

* [get tips on presenting user research](https://userresearch.blog.gov.uk/2015/06/03/tips-for-presenting-user-research-at-show-and-tell/)
* [see how Government as a Platform involves developers in research](https://governmentasaplatform.blog.gov.uk/2016/04/11/developers-user-research/)

Related guides
--------------

You may also find these guides useful:

* [Analyse a research session](service-manual_user-research_analyse-a-research-session.md)
* [Start by learning user needs](service-manual_user-research_start-by-learning-user-needs.md)

Updates to this page
--------------------

Published 24 May 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---