Design - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Design
======

Naming, structuring and scoping your service, prototyping, using design patterns and design training.

Designing the right service
---------------------------

Introduction, scoping, naming and prototyping.

* [Designing good government services: an introduction](service-manual_design_introduction-designing-government-services.md)
* [Understanding and meeting policy intent](service-manual_design_understanding-and-meeting-policy-intent.md)
* [Designing with data: an introduction](service-manual_design_designing-with-data-an-introduction.md)
* [Environmentally sustainable services](service-manual_design_environmentally-sustainable-services.md)
* [Create a list of services](service-manual_design_create-a-list-of-services.md)
* [Map and understand a user's whole problem](service-manual_design_map-a-users-whole-problem.md)
* [Working across organisational boundaries with service communities](service-manual_design_working-across-organisational-boundaries.md)
* [Getting the scope of your transaction right](service-manual_design_scoping-your-service.md)
* [Naming your service](service-manual_design_naming-your-service.md)
* [Designing how GOV.UK content and transactions work together](service-manual_design_govuk-content-transactions.md)
* [Structuring forms](service-manual_design_form-structure.md)
* [Collecting personal information from users](service-manual_design_collecting-personal-information-from-users.md)
* [Checking users’ identities](service-manual_design_checking-users-identities.md)
* [Services for government users](service-manual_design_services-for-government-users.md)

Building your service so it's simple to use
-------------------------------------------

Prototyping, patterns and content.

* [Using, adapting and creating patterns](service-manual_design_using-adapting-and-creating-patterns.md)
* [Making prototypes](service-manual_design_making-prototypes.md)
* [Making your service more inclusive](service-manual_design_making-your-service-more-inclusive.md)
* [Writing for user interfaces](service-manual_design_writing-for-user-interfaces.md)
* [Designing good questions](service-manual_design_designing-good-questions.md)
* [Making your service look like GOV.UK](service-manual_design_making-your-service-look-like-govuk.md)
* [Planning and writing text messages and emails](service-manual_design_sending-emails-and-text-messages.md)
* [Writing effective letters](service-manual_design_writing-effective-letters.md)

Training and events
-------------------

Training and events for practitioners and people interested in design, accessibility and user research

* [User-centred design: training and events](service-manual_design_user-centred-design-training-and-events.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [Design community](service-manual_communities_design-community.md)
* [Policy design community](service-manual_communities_policy-design-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/design)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---