Understanding and meeting policy intent - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Understanding and meeting policy intent
=======================================

[Give feedback about this page](/contact/govuk)

From:
:   [Policy design community](service-manual_communities_policy-design-community.md)

Contents
--------

1. [Service design and policy design](#service-design-and-policy-design)
2. [Understanding policy intent](#understanding-policy-intent)
3. [Delivering policy intent](#delivering-policy-intent)
4. [Collaborating with stakeholders](#collaborating-with-stakeholders)
5. [Measuring policy intent](#measuring-policy-intent)
6. [Related resources](#related-resources)

Service teams need to have a clear understanding of what government wants to change or achieve through its policies. You should find this information in a statement of policy intent. This will explain what outcome or set of outcomes the policy has been designed to deliver. It may also outline what outcomes should not change.

If you do not have a statement of policy intent, this may be implied in other documents such as policy papers, policy guidance, legislation, ministerial commitments or submissions. It will be useful to extract the statement of policy intent from these documents if it does not already exist. You can use this to make sure your team or working group has a shared understanding of the intent.

Policy intent is set by ministers or senior officials who commission the work. It can change over time for reasons including changes in public or parliamentary opinion, changes in party leadership or evidence, and unexpected events.

**Examples of policy intent**

Published on GOV.UK, these examples set out the government’s policy intent to:

* [encourage individuals with occupational pensions to take appropriate pensions guidance](https://www.gov.uk/government/publications/stronger-nudge-to-pensions-guidance-statement-of-policy-intent)
* [help refugees settle and integrate into UK society](https://www.gov.uk/government/publications/resettlement-policy-statement)

Service design and policy design
--------------------------------

Service teams are expected to deliver new, existing or changing policy when they are developing a service. Both policymakers and service teams face similar challenges in translating government priorities into policies and services that affect people’s lives.

Policy teams design, develop and propose solutions to help meet ministerial objectives based on research and evidence. They ensure the effective delivery of policy, evaluating its impact and adapting as necessary.

Many government departments are trying to embed user-centred design into policy making. Service teams may have the opportunity to work with policy professionals to design a range of policy options so that ministers can make more informed decisions about which one to follow. Your role may involve highlighting unintended consequences and risks and showing how a particular policy might not work.

You can find out more about policy making by:

* completing an [Introduction to policy](https://learn.civilservice.gov.uk/courses/AgT2tmTfTZuRCyHQ-Qlawg) on Civil Service Learning
* reading [a short guide to policy for government digital professionals](https://medium.com/@maltbyps/one-team-government-a-short-guide-to-policy-for-government-digital-professionals-c3cc1e421406)
* reading a Policy Lab blog post on [Introducing a ‘Government as a System’ toolkit](https://openpolicy.blog.gov.uk/2020/03/06/introducing-a-government-as-a-system-toolkit/)
* joining the [policy design community](https://www.gov.uk/service-manual/communities/policy-design-community)

Understanding policy intent
---------------------------

Before you build or redesign a service, the main things you need to know are:

* what do ministers want to change: what is the intended outcome?
* who will be affected by the policy: think about [what your users need](https://www.gov.uk/service-manual/user-research/start-by-learning-user-needs), not what government thinks they want
* [how will this be measured](https://www.gov.uk/service-manual/measuring-success): this will allow you to evaluate the solution and explore whether other options might be more appropriate

This information will come from the policy owner who might be a senior official or minister.

Ask the policy professionals working with you to share any research and evidence they have gathered from experts, delivery partners and users by public consultation. This will help you to identify any gaps or unanswered questions, and make sure work is not repeated.

You may also have to take into consideration related policies, regulation frameworks, contractual commitments and devolved legislation.

### What to do if the policy intent is not clear

If the policy intent is not well defined or agreed, you should:

* know what has started the work, such as a sudden-onset or slowly emerging crisis, efficiency drive, political commitment, change in regulation or team plan
* examine any statements on your commission for information about the circumstances, what should change, requirements and limitations
* use GOV.UK to find related policy information to help understand the political context, for example legislation, guidance documents, responses to parliamentary questions and press information
* work in collaboration with the policy team to help define this, for example using journey mapping
* explore this further with the people who commissioned the work

Delivering policy intent
------------------------

To deliver the policy intent, you should know:

* [what problem is being solved](https://dwpdigital.blog.gov.uk/2017/10/30/how-understanding-problems-helps-us-to-help-users/), who is it a problem for and what are the causes
* what is out of scope or not part of the problem: it’s important not to zoom out too far when the problem has already been scoped
* what is possible financially and technologically
* who is setting and driving the policy: understanding where the issue has come from and why it’s important now will put you in the best position to recommend the most effective solution
* how long you have to develop a solution

If a solution has been largely prescribed, either in legislation, ministerial commitments, or requests from senior leadership, you should still work with policy colleagues to determine if this will solve the problem and achieve the right outcomes. You should still explore alternative options and advise ministers on the benefits and consequences of all options.

Collaborating with stakeholders
-------------------------------

It is important to work out who you need to be talking to. There will be a range of stakeholders from policy and other areas of your organisation or department who should be involved in the development process, for example:

* operations
* legal
* security
* communications
* change
* delivery
* commercials
* analytical
* senior leaders

### Building trust

Engaging with stakeholders as soon as possible gives them the opportunity to understand what’s being asked of the service team and why. It’s also a chance to build trust and understanding of each other’s needs and ways of working and lets them plan their time and involvement with the project.

When communicating with stakeholders, be mindful that they may not be familiar with agile ways of working or user-centred design. Communicate what you’re doing and why you need to do it in a way that everyone understands. Read how the West Midlands Combined Authority achieved this in [Bridging the language gap when working with new people](https://services.blog.gov.uk/2021/07/22/bridging-the-language-gap-when-working-with-new-people/).

Look for opportunities to break silos by inviting stakeholders to regular collaborative sessions, stand-ups, reviews and other [agile ceremonies](https://www.gov.uk/service-manual/agile-delivery/agile-tools-techniques).

These sessions can be used to:

* collect and document issues with the policy intent
* make sure everyone has the same understanding of what needs to be fixed or developed, mapping user journeys together
* understand what the blockers and enablers are of achieving the desired outcomes
* establish what [cyber security implications](https://security.gov.uk/policy-and-guidance/secure-by-design/activities/considering-security-within-the-business-case/) need to be considered
* share and get timely feedback on potential solutions, for example prototypes that visually show suggested changes such as different ways of asking questions that still meet the policy intent
* understand roles and responsibilities, each other’s ways of working and terminology

For example, impact mapping and ranking exercises were just some of the techniques used to [create a service for new teachers](https://dfedigital.blog.gov.uk/2021/06/17/policy-intent/). This helped the service team to understand what mattered most to the policy team and focus their efforts.

You may have to [work across organisational boundaries](https://www.gov.uk/service-manual/design/working-across-organisational-boundaries) if the thing you’re working cuts across multiple policy areas. Read how the [Department for Work and Pensions worked with HM Revenue and Customs](https://dwpdigital.blog.gov.uk/2016/11/01/one-million-up-what-weve-learned-from-building-check-your-state-pension/) to develop the Check your State Pension Forecast service.

Bringing together the policy and delivery team in the same physical location can provide an opportunity for closer working. A senior policy adviser shares how successful this approach was when [developing the Apprenticeship Service](https://sfadigital.blog.gov.uk/2017/03/24/dont-bring-policy-and-delivery-closer-together-make-them-the-same-thing/).

Measuring policy intent
-----------------------

The work you do to understand the policy intent will help you to define core problem statements. In collaboration with policy colleagues and other stakeholders, these statements can be used to establish target outcomes that show the policy intent has been met.

When these target outcomes are agreed, you’ll need to [define measurements for each outcome](https://www.gov.uk/service-manual/measuring-success). Think about what success looks like and the types of data to collect. What elements need to be tracked? For example inputs, process steps or outputs? Will quantitative data, qualitative data or both be needed? This will help to identify whether the service has met the policy intent and capture insights that can be applied to future policy and iterations to the service.

If there is an existing paper or digital service, start by finding out if the policy intent is being delivered, whether this is being measured and how. Having a measured baseline is useful when evaluating success. Where you identify gaps, consider commissioning primary research to get the bigger picture of how the service is meeting or not meeting the target outcomes.

If you need to set new measures, work with the policy and analytical team to:

* understand what data or metrics matter most to your key stakeholders
* identify where the data or metrics will come from, for example operations data or web analytics
* consider short, medium and long term indicators
* understand policy colleagues expectations, for example how many people it will affect

Throughout development, share lessons learned and relevant data with the policy team. They still have a responsibility to monitor progress and identify improvements that may be needed to the policy.

Related resources
-----------------

### Toolkit

[Open Policy Making toolkit](https://www.gov.uk/guidance/open-policy-making-toolkit): this manual includes information about Open Policy Making as well as the tools and techniques policy makers can use to create more open and user led policy.

[The Delivery Book](https://www.deliverybook.uk/understand-what-has-inspired-your-w): produced by the Department for Education, this book provides the tools to take an idea and develop it into a policy or service designed around the needs of the people who’ll use it.

### Blog posts

[Refugee integration loans: a Policy CoLab case study](https://hodigital.blog.gov.uk/2021/12/21/refugee-integration-loans-a-policy-colab-case-study/) (Home Office)

[Meeting policy intent and user needs at the same time](https://dfedigital.blog.gov.uk/2021/06/17/policy-intent/) (Department for Education)

[How we designed a digital service at pace](https://services.blog.gov.uk/2021/05/21/how-we-designed-a-digital-service-at-pace/) (Department for Work and Pensions)

[Commissioning public policy and services differently](https://publicpolicydesign.blog.gov.uk/2021/07/29/commissioning-public-policy-and-services-differently/) (Public Policy Design)

[If you could change just one thing: hacking the policy system](https://publicpolicydesign.blog.gov.uk/2021/07/22/hacking-the-policymaking-system/) (Public Policy Design)

[Defining policy outcomes for event fees](https://dluhcdigital.blog.gov.uk/2019/03/28/defining-policy-outcomes-for-event-fees/) (Department for Levelling Up, Housing and Communities)

[Service ownership and policy](https://dfedigital.blog.gov.uk/2020/02/06/top-tips-on-service-ownership/) (Department for Education)

[The tips and ‘cheat codes’ I’ve discovered leading a Policy Lab](https://ayymanduh.medium.com/the-tips-and-cheat-codes-i-ve-discovered-leading-a-policy-lab-394055e400b9) (Medium)

Updates to this page
--------------------

Published 8 April 2022

Last updated 22 October 2024
[+ show all updates](#full-history)

1. 22 October 2024

   Integrated guidance on Understanding business objectives and user needs, Understanding cyber security obligations, and Sourcing a threat assessment.
2. 8 April 2022

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---