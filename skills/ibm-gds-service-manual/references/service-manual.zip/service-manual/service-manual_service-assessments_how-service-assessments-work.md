What happens at a service assessment - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

What happens at a service assessment
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Preparing for an assessment](#preparing-for-an-assessment)
2. [What to cover on the day](#what-to-cover-on-the-day)
3. [Answer questions from the panel](#answer-questions-from-the-panel)
4. [Get your result](#get-your-result)
5. [Assessment reports](#assessment-reports)
6. [Examples and case studies](#examples-and-case-studies)
7. [Related guides](#related-guides)

You may need to [book a service assessment](service-manual_service-assessments_book-a-service-assessment.md) to check you’re meeting the Service Standard. [Check if you need an assessment](service-manual_service-assessments_check-if-you-need-a-service-assessment.md) if you’re not sure.

Your assessment will be run by a panel of experienced specialists from the Government Digital and Data community. Panels are normally made up of a lead assessor, a user researcher, a designer, a technical lead and sometimes a performance analyst. There might also be one or two observers, but they will not ask questions.

Assessments usually last about 4 hours.

Check with your department’s assessment team for more information about what will happen at the assessment.

Preparing for an assessment
---------------------------

It can be tempting to spend a long time preparing for assessments.

But try not to over-prepare. Do just enough to make sure you can give an open and honest account of the work you’ve done and what you’ve built.

And remember that the panel is not there to catch you out. They offer a peer review of the work you’ve done and help you understand anything you’ll need to change or improve.

What to cover on the day
------------------------

Spend the first 30 minutes of the assessment talking about and demonstrating what you’ve built. During that time, you’ll need to:

* give an overview of your service
* walk the panel through the user journey

### Give an overview of your service

In any assessment, it’s useful to start by briefly setting the scene. This usually means talking about the things you learnt during your discovery and alpha, including:

* [why you’re solving the problem you’re solving](https://www.gov.uk/service-manual/agile-delivery/how-the-discovery-phase-works)
* [who your users are and what they’re trying to do](https://www.gov.uk/service-manual/user-research/start-by-learning-user-needs)
* the work you’ve done to [understand the user’s wider journey](https://www.gov.uk/service-manual/agile-delivery/how-the-alpha-phase-works#solving-a-whole-problem-for-users), if there is one

It’s also useful to explain any changes you made based on the feedback the service got at its previous assessment, if it had one.

You probably shouldn’t spend more than 10 minutes covering these issues.

### Walk the panel through the user journey

Once you’ve explained what your service is and why you’re building it, spend around 20 minutes walking the panel through what you’ve built.

You might not have time to show every screen, but you should make sure to show any particularly important interactions.

And don’t just focus on the happy path. Also show what happens to users who are not eligible, or who cannot provide a piece of evidence at the right time.

Remember to talk about the whole user journey, including offline channels. This means explaining the processes that support staff need to follow to deliver the service, as well as the skills and capabilities they need to have.

At the alpha stage, you don’t necessarily need to prototype the entire user journey - just enough to [test your riskiest assumptions](https://www.gov.uk/service-manual/agile-delivery/how-the-alpha-phase-works). It might be worth bringing along a set of user needs or a rough journey map to your assessment too.

This post on the services in government blog gives advice about how to [tell the story of your service](https://services.blog.gov.uk/2020/10/12/service-demos-how-to-tell-the-story-of-your-service/).

Answer questions from the panel
-------------------------------

Once you’ve demonstrated your service, the panel will spend the remaining time asking questions about the decisions you’ve made and how you’ve built your service.

There’s no specific set of questions that a panel will ask during an assessment. It’ll differ depending on the service you’ve built and which development phase you’re in.

It’s a good idea to make sure you and your team are familiar with:

* the [Service Standard](https://www.gov.uk/service-manual/service-standard)
* the requirements for [the development phase you’re working in](https://www.gov.uk/service-manual/agile-delivery#phase-of-an-agile-project)

There’s also guidance on [how assessors will apply the Service Standard](https://www.gov.uk/service-manual/service-assessments/how-to-apply-the-service-standard).

Get your result
---------------

Your service will be assessed as ‘green’, ‘amber’ or ‘red’.

‘Green’ means that the service has met the standard and can continue to the next phase of delivery.

‘Amber’ means that the standard has not yet been met, but the issues are not critical. The service can continue to the next phase of delivery while you work on the amber issues.

You need to fix amber issues within a reasonable period of time, usually up to 3 months. You must record your progress in a live ‘tracking amber evidence’ document which will be visible to the assessments team.

‘Red’ means that the standard has not yet been met and the issues are critical. The service will stay in its current phase of delivery. Further work needs to be done on the points that did not meet the standard before they can be reassessed. [Not meeting the Service Standard doesn’t mean that you failed](https://services.blog.gov.uk/2020/10/23/not-meeting-the-service-standard-doesnt-mean-you-failed/).

If your service has been assessed by a cross-government panel you’ll get your result in a report within 3 to 5 working days.

What happens next depends on the result of the assessment, and the delivery phase your service is in.

### Departmental assessments

There can be exceptions to red, amber and green assessment ratings.

Your service may be assessed as ‘met’ or ‘not met’ if the assessment was done by a panel from your own department. Contact your department’s assurance team to ask how your service will be assessed and when you’ll get the result.

Assessment reports
------------------

GDS will publish the outcome of the assessment - see the [list of published Service Standard Reports](https://www.gov.uk/service-standard-reports). You’ll have the chance to fact check it before it’s published.

Examples and case studies
-------------------------

Read the Department for Work and Pensions’ blog post on [what the Secure Communications team learned from their alpha assessment](https://dwpdigital.blog.gov.uk/2015/07/02/our-successful-gds-alpha-review-what-i-learned/).

Read the Office of the Public Guardian’s (OPG) blog post on how they [prepared the Complete the deputy report service for live assessment](https://mojdigital.blog.gov.uk/2021/02/02/the-5-year-beta-phase-how-we-prepared-for-live-assessment/).

Related guides
--------------

You may also find the following guides useful:

* [Check if you need a service assessment](service-manual_service-assessments_check-if-you-need-a-service-assessment.md)
* [Book a service assessment](service-manual_service-assessments_book-a-service-assessment.md)

Updates to this page
--------------------

Published 13 April 2016

Last updated 9 May 2024
[+ show all updates](#full-history)

1. 9 May 2024

   Corrected timings and updated out of date references.
2. 25 April 2024

   This guidance has been updated to reflect a change in the way assessments are rated.
3. 28 June 2019

   Added detail on how and what to prepare for a service assessment.
4. 26 October 2017

   Clarified guidance on what happens at a service assessment.
5. 5 July 2017

   Updated the address for GDS assessments to The White Chapel Building.
6. 2 August 2016

   Added link to 'How your assisted digital support will be assessed'.
7. 18 April 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---