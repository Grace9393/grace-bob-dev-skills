Creating an agile working environment - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Creating an agile working environment
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [What an agile environment looks like](#what-an-agile-environment-looks-like)
2. [Decide what you need from your environment](#decide-what-you-need-from-your-environment)
3. [Your physical environment](#your-physical-environment)
4. [The right technology](#the-right-technology)
5. [Visit agile working environments](#visit-agile-working-environments)
6. [Related guides](#related-guides)

Things move quickly in agile, so digital teams need easy ways to coordinate their activities, communicate progress and collaborate.

You should design your physical working environment and choose suitable technology to encourage agile ways of working.

What an agile environment looks like
------------------------------------

You should expect to see lots of short meetings throughout each day, often around walls covered in notes or reference material. This may seem strange in office cultures that are more used to formal meetings or conference calls.

Those working in creative and technical fields often need plenty of space for focused, detailed work. It’s common to see people spend most of the day with headphones on to help them focus, or deep in conversation with just one person with whom they’re pairing.

Decide what you need from your environment
------------------------------------------

Working spaces for digital projects will vary. At the beginning of a project, decide with your team:

* how to structure your space
* the tools you need

Your physical environment
-------------------------

The space a team works in is a tool. It’s just as important as the choice of programming language or project management tools.

### Sitting together

Ideally, your team will work from the same location and sit together.

Short, informal conversations are an important way to test assumptions. These are much harder when a team is spread across an office or in different buildings.

### Hacking the environment

Removing dividers between desks makes a big difference and allows conversation between the team to flow more freely. If large monitors are getting in the way, remove them.

You might also want to think about getting a desk organiser.

This process is known as ‘hacking the environment’.

### Wall space

Teams using agile approaches need wall space in their work area. If you can’t use a wall, you could try whiteboards or windows.

You need sticky notes or cards and blu-tack to post records of your work on the walls.

The wall creates a physical focus for the team so they can:

* gather round it at their daily standup
* refer to and update it during the day
* show the status of their work to anyone outside of the team

This helps the team to:

* discuss what they’re working on
* sort out problems
* talk through ideas

This is called ‘visual management’.

Find out [how to set up your team wall](service-manual_agile-delivery_team-wall.md).

The right technology
--------------------

As a team, you also need online tools to help you communicate and manage your work.

Individual members of the team may also need access to tools to help them with their role (for example, your user researcher may need access to video editing software).

You should check if anyone needs training to use the tools you choose.

### Online communication

Meetings like standups or retrospectives help people to keep in touch but you also need a tool for online discussions.

An online tool helps the team to stay in contact and means you can:

* make quick decisions
* provide support and information
* keep everyone informed about the work you’re doing

The Government Digital Service (GDS) uses [Slack](https://slack.com/), the Environment Agency uses [Yammer](https://www.yammer.com/), the NHS uses [Microsoft Teams](https://www.microsoft.com/en-gb/microsoft-365/microsoft-teams/group-chat-software) and the Ministry of Justice (MoJ) uses [Hipchat](https://www.hipchat.com/).

These tools work like chatrooms and allow your team to talk in a more conversational way than they would with emails.

They stop large backlogs of emails building up for people who are out of the office and allow the team to communicate even if they’re not in the same room.

### Collaboration

You must have a browser-based editing tool so your team can work on the same documents at the same time.

This is a mandatory [open standard](/government/publications/open-standards-for-government/sharing-or-collaborating-with-government-documents) requirement for government.

It also helps you avoid having multiple versions of the same document. GDS, MoJ and many other departments use [Google Drive](https://www.google.com/drive/).

GDS and MoJ also use collaboration tools like [Confluence](https://www.atlassian.com/software/confluence) for internal wikis, while GDS uses [Basecamp](https://basecamp.com/) for cross-government communities.

### Managing your backlog

You might find an online board helps you to manage your backlog, in addition to your physical wall.

Online boards allow you to record further detail behind backlog items (like draft designs) and to link to discussions on collaboration tools.

Teams at GDS use Trello. HMRC, Home Office and MoJ use JIRA.

Visit agile working environments
--------------------------------

If you’re setting up an agile working environment for your team, you might find it useful to go and look at how other agile teams are working.

Get in touch with the [agile delivery community](service-manual_agile-delivery-community.md) to arrange a tour.

Related guides
--------------

You may also find the following guides useful:

* [Team wall](service-manual_agile-delivery_team-wall.md)
* [Agile tools and techniques](service-manual_agile-delivery_agile-tools-techniques.md)

Updates to this page
--------------------

Published 16 February 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 17 March 2016

   Added details of collaborative tools, including Trello, Slack, Basecamp, Yammer, Hipchat, Confluence, and Google Drive.
2. 6 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---