Working across organisational boundaries with service communities - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Working across organisational boundaries with service communities
=================================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Using service communities for better collaboration](#using-service-communities-for-better-collaboration)
2. [Set up a service community](#set-up-a-service-community)
3. [Run your service community](#run-your-service-community)
4. [Share your experiences](#share-your-experiences)
5. [Further reading](#further-reading)

You’ll sometimes need to work with other teams from inside and outside of your organisation, especially if the thing you’re working on is part of a wider journey that cuts across organisational boundaries.

Working together is difficult. It requires you to balance different priorities, ways of working and funding cycles - and can add extra layers of bureaucracy.

It also often involves working remotely from different locations. Read about how the Government Digital Service (GDS) changed some processes to [work with the Rwandan government remotely](https://gds.blog.gov.uk/2021/02/05/delivering-digital-transformation-through-remote-partnerships/).

Using service communities for better collaboration
--------------------------------------------------

Some teams across government have had success working in groups called ‘service communities’. Service communities are networks of people formed around user journeys.

These journeys tend to be made up of several elements and transactions and often cut across organisational boundaries.

Service communities can help people from across the public sector, including policy, digital and operations, to work together.

Collaborating in this way has helped the community members address the more common collaboration challenges, as well as do things like:

* better understand their users - for example, some communities have developed personas to help them gain a better understanding of what their users are trying to do
* collaborate across organisational boundaries - for example, by gaining access to the people they need to talk to at regular meetings and workshops
* shape the design of the wider user journey

You can [read more about communities and why they’re helpful](https://gds.blog.gov.uk/2019/01/28/what-service-communities-are-achieving-across-government/).

Set up a service community
--------------------------

Before you set up a community, first check whether there’s already one in place for your area of interest.

You can do this by joining the [#servicecommunities cross-government Slack channel](https://ukgovernmentdigital.slack.com/messages/C63GY4WJW/).

If there isn’t a service community for the area you’re working in, you could adopt some of their ways of working to either:

* start a service community of your own
* work across organisational boundaries (or across functional boundaries within your organisation) in a less formal way

For your community to be successful, you’ll need to make sure you’re involving the right people and that it has a clear purpose.

### Work out what your community is for and invite people to join it

It’ll be much easier to get people to join your community if you can give them a clear idea of the problem they’ll be helping to solve and why it’s a good use of their time. So start by working out what you want to achieve.

Once you’ve done that, put together a statement (sometimes called a ‘proposal document’) that explains what the community will do together and why. You can send this to everyone you think needs to be involved.

You can [read the import-export community’s proposal document](https://assets.publishing.service.gov.uk/media/5cc1b875e5274a467d84f296/Import-Export_community_proposal_document.odt) to see what sort of information to include.

Ideally, your community would be made up of people from:

* all the organisations who have a stake in the service area you’re looking at
* across the policy, operations and digital professions

It’d also include a mix of senior people who can influence the strategic direction of the service and people at delivery level, who understand the detail.

You probably won’t be able to get all those people together in one go, though. So start by inviting the people you know and build from there.

### Agree ways of working

Once you’ve got a few people together, it’s useful to agree and document things like:

* why you’ve set up the community
* common objectives
* whether meetings or calls will take place and how often
* who’s in charge of facilitating meetings
* how you’ll share information and resources

The document you put together is sometimes called a ‘terms of reference’. You could also use something like a Trello board.

### Map your service area

Once you’ve agreed ways of working, it’s useful to map your service area. Start by [building a ‘service landscape’](https://www.gov.uk/service-manual/design/map-a-users-whole-problem#map-user-journeys-together), which shows how the service is currently delivered both online and offline.

This will help you build a common understanding of what needs fixing and where you could have most impact.

### Set up communication channels

Communication issues are a common blocker to cross-departmental working.

It’s crucial you can talk to each other between meetings. This will help you strengthen relationships, get feedback or input on your work and make sure everyone maintains the same understanding of what you’re doing.

Setting up digital channels is usually the best way of making this happen. For example, you could:

* set up a Google group, which acts as an online forum and email list
* create a Slack channel for everyone to use
* arrange workshops and calls that everyone can dial into
* have a shared online calendar

Sharing things like documents and calendars can be tricky, as departments tend to use a range of different admin systems.

HM Revenue and Customs (HMRC) and the Department for Work and Pensions (DWP) faced this challenge when they [worked together on the Check your State Pension service](https://dwpdigital.blog.gov.uk/2016/11/01/one-million-up-what-weve-learned-from-building-check-your-state-pension/).

The DWP members of the team initially couldn’t access HMRC’s project management tools. The team got access for their DWP colleagues by providing HMRC email addresses for them to use during the project.

Don’t worry if it’s not possible to get everyone using your preferred tool, though. The most important thing is to share things regularly - even if you have to email documents to one another.

And where possible, work in the open and publish things on the internet. Anyone can access a blog post.

Run your service community
--------------------------

Once you’ve set up your community, there are some ways of working it might be useful for you to adopt.

### Share research insights and data where possible

Collaborating on research and [sharing research findings](https://www.gov.uk/service-manual/user-research/sharing-user-research-findings) is useful for several reasons. Firstly, it’s cheaper, because you don’t have to run separate rounds of research.

It also spreads knowledge and gives community members access to insights they wouldn’t otherwise have.

So invite people from a range of professions to attend your research sessions.

HMRC and DWP did this when they worked on Check your State Pension. It allowed them to introduce their policy and legal colleagues to user-centred design principles and made it much easier to set up pairing sessions with content designers.

It’s also much easier to solve disagreements if everyone has access to the evidence.

### Agree a common language

Agreeing a common language can also prove useful. The start a business community found this helped them keep everyone on the same page.

It allowed them to agree on the meaning of important words like ‘company’, ‘sole trader’ and ‘validation’. Having different interpretations of these words could have made it more difficult for them to progress their work.

### Create a common backlog

Some of the existing service communities have had success working from a common backlog.

If you’re struggling to come up with things to put on the backlog, any potential improvements you found when working on your service landscape are a good place to start.

Each of the teams within the community will also have their own departmental priorities. It’s useful to talk about these when you’re working out what should go in your backlog.

Existing communities have included the following sorts of things on their common backlogs:

* the creation of [step by step navigation](https://design-system.service.gov.uk/patterns/step-by-step-navigation/)
* signposting to relevant transactions

The start a business community uses a Trello board to help them keep track of the work they’re doing.

Share your experiences
----------------------

We’d love to hear about your experiences of working in this way. Post in the [#servicecommunities cross-government Slack channel](https://ukgovernmentdigital.slack.com/messages/C63GY4WJW/) and share your experiences by blogging.

Further reading
---------------

You can read about [how the Taiwanese government have collaborated across boundaries](https://apolitical.co/solution_article/meet-the-network-tearing-down-walls-between-departments-in-taiwan/) to solve big problems for users.

Updates to this page
--------------------

Published 1 May 2019

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---