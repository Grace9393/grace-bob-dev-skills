Agile delivery - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Agile delivery
==============

How to work in an agile way: principles, tools and governance.

Understanding agile project management
--------------------------------------

Introductions, methods, core features.

* [Agile and government services: an introduction](service-manual_agile-delivery_agile-government-services-introduction.md)
* [Agile methods: an introduction](service-manual_agile-delivery_agile-methodologies.md)
* [Core principles of agile](service-manual_agile-delivery_core-principles-agile.md)

Working with agile methods
--------------------------

Workspaces, tools and techniques, user stories, planning.

* [Creating an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md)
* [Agile tools and techniques](service-manual_agile-delivery_agile-tools-techniques.md)
* [Set up a team wall](service-manual_agile-delivery_team-wall.md)
* [Writing user stories](service-manual_agile-delivery_writing-user-stories.md)
* [Planning in agile](service-manual_agile-delivery_planning-agile.md)
* [Deciding on priorities](service-manual_agile-delivery_deciding-on-priorities.md)
* [Developing a roadmap](service-manual_agile-delivery_developing-a-roadmap.md)
* [Making services in an emergency](service-manual_agile-delivery_making-services-in-an-emergency.md)

Governing agile services
------------------------

Principles, measuring progress, spending money.

* [Governance principles for agile service delivery](service-manual_agile-delivery_governance-principles-for-agile-service-delivery.md)
* [Measuring and reporting progress](service-manual_agile-delivery_measuring-reporting-progress.md)
* [Spend controls: check if you need approval to spend money on a service](service-manual_agile-delivery_spend-controls-check-if-you-need-approval-to-spend-money-on-a-service.md)
* [Spend controls: apply for approval to spend money on a service](service-manual_agile-delivery_apply-for-approval-to-spend-money-on-a-service.md)
* [Spend controls: the pipeline process](service-manual_agile-delivery_spend-controls-pipeline-process.md)
* [Running your service in a sustainable way](service-manual_agile-delivery_running-your-service-in-a-sustainable-way.md)

Phases of an agile project
--------------------------

Discovery, alpha, beta, live and retirement.

* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [How the alpha phase works](service-manual_agile-delivery_how-the-alpha-phase-works.md)
* [How the beta phase works](service-manual_agile-delivery_how-the-beta-phase-works.md)
* [How the live phase works](service-manual_agile-delivery_how-the-live-phase-works.md)
* [Retiring your service](service-manual_agile-delivery_retiring-your-service.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [Agile delivery community](service-manual_communities_agile-delivery-community.md)
* [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)
* [Product and service community](service-manual_communities_product-and-service-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/agile-delivery)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---