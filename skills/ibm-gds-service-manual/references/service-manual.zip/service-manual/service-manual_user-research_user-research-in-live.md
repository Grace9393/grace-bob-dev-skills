User research in live - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

User research in live
=====================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [How to do user research in live](#how-to-do-user-research-in-live)
2. [Related guides](#related-guides)

The aim of user research in the [live phase](service-manual_agile-delivery_how-the-live-phase-works.md) is to:

* assess people’s experience of using your service
* understand evolving user needs
* test new features, changes or improvements to your service

How to do user research in live
-------------------------------

You need to think about your service from end to end and consider all the ways that users interact with it (including all tools, transactions, support and offline steps).

### Who to research with

You must do research with a broad range of users, including:

* those with limited digital access and confidence
* people with a range of visual, hearing, motor and cognitive impairments
* people who use assistive technologies, like screen readers or speech recognition software

You should also include people who provide the service or who support other users (for example, caseworkers, call centre agents and charity workers).

[Learn more about finding user research participants](service-manual_user-research_find-user-research-participants.md).

### Typical user research activities

In live, you can learn more about your users’ needs by:

* reviewing web analytics and back-office data to [measure service performance](service-manual_measuring-success.md)
* [analysing support tickets](https://userresearch.blog.gov.uk/2018/10/23/how-user-support-ticket-analysis-shapes-what-we-do-on-government-as-a-platform/) to identify problems users have with your service
* doing surveys to collect broader feedback
* using interviews, visits and usability testing to get a deeper understanding of any problems users tell you about
* doing face-to-face and remote usability tests to find usability and accessibility issues with features you’ve added or changed
* doing A/B testing (comparing 2 versions of a web page to see which performs better) on new and changed features

From these activities you’ll typically get:

* a deeper understanding of how different kinds of users experience your service
* insight into usability and accessibility issues and how to fix them
* ideas for ways to improve your service in the future

You’ll be doing enough research when you understand how different kinds of people experience your service, and how their needs may be changing.

Related guides
--------------

You may also find these guides useful:

* [Learning about users and their needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Analyse a research session](service-manual_user-research_analyse-a-research-session.md)
* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Running research sessions with disabled people](service-manual_user-research_running-research-sessions-with-people-with-disabilities.md)
* [Usability benchmarking a website or whole service](service-manual_measuring-success_usability-benchmarking-a-website-or-whole-service.md)

Updates to this page
--------------------

Published 18 November 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---