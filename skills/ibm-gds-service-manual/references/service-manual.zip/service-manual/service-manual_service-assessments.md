Service assessments and applying the Service Standard - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Service assessments and applying the Service Standard
=====================================================

How to apply the Service Standard, check if you need a service assessment, get your service on GOV.UK and become a service assessor.

* [Check if you need to meet the Service Standard or get an assessment](service-manual_service-assessments_check-if-need-to-meet-service-standard.md)
* [What a service is](service-manual_service-assessments_what-a-service-is.md)
* [Book a service assessment](service-manual_service-assessments_book-a-service-assessment.md)
* [What happens at a service assessment](service-manual_service-assessments_how-service-assessments-work.md)
* [How to apply the Service Standard](service-manual_service-assessments_how-to-apply-the-service-standard.md)
* [Get your service on GOV.UK](service-manual_service-assessments_get-your-service-on-govuk.md)
* [Get a GOV.UK feedback page](service-manual_service-assessments_get-feedback-page.md)
* [Digital Service Standard (pre-July 2019)](service-manual_service-assessments_pre-july-2019-digital-service-standard.md)
* [Become a service assessor](service-manual_service-assessments_become-a-service-assessor.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)
* [Design community](service-manual_communities_design-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/service-assessments)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---