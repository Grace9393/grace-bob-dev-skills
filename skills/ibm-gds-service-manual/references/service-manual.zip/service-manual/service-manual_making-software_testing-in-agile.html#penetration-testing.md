Quality assurance: testing your service regularly - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Quality assurance: testing your service regularly
=================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (backend development)](service-manual_communities_technology-community-backend-development.md)

Contents
--------

1. [Involving the whole team](#involving-the-whole-team)
2. [Why test for quality](#why-test-for-quality)
3. [How to test](#how-to-test)
4. [Review your testing process](#review-your-testing-process)
5. [Types of testing](#types-of-testing)
6. [Related guides](#related-guides)

You need to test your service regularly as part of quality assurance (QA) to make sure that it:

* is easy to use for anyone who needs to use it, regardless of the device they’re using
* is stable, secure and works quickly, regardless of how many people need to use it
* can be iterated quickly to meet changes to user needs or the political environment

You should test the usability of your service as well as the technical parts.

Learn more about [how user research improves service design](service-manual_user-research_how-user-research-improves-service-design.md).

Involving the whole team
------------------------

You should make sure all members of your team know how to:

* set goals for quality and measure your service’s performance against them
* identify problems or risks with any aspect of your service
* take action to fix any issues and improve quality

Why test for quality
--------------------

You will not know how good your product is until you test it in simulations of both normal and unusual conditions (for example, when your service has lots of visitors or is attacked).

Testing for quality helps you:

* make sure your service does what your users need it to do
* build your service at a cost that is acceptable to your organisation (this cost includes business change and risk, as well as money)

How to test
-----------

From [discovery](service-manual_agile-delivery_how-the-discovery-phase-works.md), you should think about the quality of your service. During development, you should test for quality in a way that confirms:

* your code works the way you expect it to
* your service is protected against malicious attacks
* iterating your code will not break existing functionality

From [beta](service-manual_agile-delivery_how-the-beta-phase-works.md), you should test to check that your service meets [government accessibility requirements](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction#meeting-government-accessibility-requirements.md).

### Automated testing

You should aim to automate as much of your testing as possible and run your test suite as part of continuous integration (where your tests form part of your codebase). By testing your code automatically every time you make a change, you’ll be able to find defects more quickly.

Getting fast feedback means you can respond to any problems quickly and make changes when you need to. You can also spot defects before they develop into bigger problems that are more complicated and expensive to fix.

Review your testing process
---------------------------

You should review your testing process regularly to identify where it could be improved. For example, you could look at how to automate more tests or check if your team’s delivery style supports your testing process.

Types of testing
----------------

You should run different types of tests depending on what you need to check, for example:

* [load and performance testing](service-manual_technology_test-your-services-performance.md) - to check how much traffic your service can handle, and how stable and responsive it is
* [vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md) - to check how secure your system is
* [exploratory testing](service-manual_technology_exploratory-testing.md) - to manually check for bugs and defects
* [accessibility testing](service-manual_technology_testing-for-accessibility.md) - to check that everyone, including disabled people, can use your service
* [acceptance and unit testing](https://en.wikipedia.org/wiki/Functional_testing) - to check that your code works as it should do and you expect it to

You may find it’s useful to hire experts from outside your team, especially for some types of testing (for example, [vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)).

Learn more about [working with contractors and third parties](service-manual_the-team_working-contractors-third-parties.md).

Related guides
--------------

You may find these guides useful:

* [Test your service’s performance](service-manual_technology_test-your-services-performance.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* [Exploratory testing](service-manual_technology_exploratory-testing.md)
* [Testing for accessibility](service-manual_technology_testing-for-accessibility.md)
* [Core principles of agile](service-manual_agile-delivery_core-principles-agile.md)

Updates to this page
--------------------

Published 23 May 2016

Last updated 28 June 2017
[+ show all updates](#full-history)

1. 28 June 2017

   Clarified guidance on why and how to test, and condensed information on hiring QAs. Changes based on user testing.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---