Making your service more inclusive - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Making your service more inclusive
==================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Legal obligations](#legal-obligations)
2. [Addressing barriers](#addressing-barriers)
3. [Ways to prevent exclusion](#ways-to-prevent-exclusion)
4. [Identifying pain points](#identifying-pain-points)
5. [Universal barriers to inclusion](#universal-barriers-to-inclusion)

There’s usually no alternative to using government services, so they have to work for everyone. Making your service inclusive means making sure anyone who needs to can use it as easily as possible.

Legal obligations
-----------------

When you’re providing a public service, you have a legal duty under [the Equality Act 2010](https://www.gov.uk/guidance/equality-act-2010-guidance) not to exclude protected groups.

It’s usually against the law to discriminate against someone because of:

* age
* gender reassignment
* being married or in a civil partnership
* being pregnant or having recently given birth
* disability
* race, nationality, ethnic or national origin
* religion, belief or lack of religion or belief
* sex
* sexual orientation

Addressing barriers
-------------------

[Making your service accessible to disabled users](https://www.gov.uk/service-manual/helping-people-to-use-your-service/making-your-service-accessible-an-introduction) is an important part of making your service inclusive. So is providing [assisted digital support](https://www.gov.uk/service-manual/helping-people-to-use-your-service/assisted-digital-support-introduction) to people who lack digital skills or internet access.

But you’ll also need to consider whether you’re excluding other groups and all the reasons that anyone might be excluded as well.

Do this by:

* [recruiting user research participants](https://www.gov.uk/service-manual/user-research/find-user-research-participants) who represent the full range of people using your service
* making sure you design for their needs and continually test your service with them
* using [research techniques that help to include users in hard to reach groups](https://gds.blog.gov.uk/2013/11/22/reaching-all-our-users/)
* looking for points in the service that could exclude particular groups

You must also operate your service in line with your department’s Welsh language scheme, if there is one. Here’s [an example of a Welsh language scheme](https://www.gov.uk/government/organisations/department-for-work-pensions/about/welsh-language-scheme).

Ways to prevent exclusion
-------------------------

You must seek to understand and address any points in your service where users experience problems.

There will be pain points which are specific to your service depending on what it does and who your users are. It’s up to you to find these points.

For example, somebody who’s pregnant for the first time may already be a parent. They may be in a same-sex relationship, and their partner was pregnant with their first child. This makes answering the common question “is this your first baby?” problematic.

Think about what the service really needs to know. In the example above, maybe it’s whether they have been pregnant or given birth before so the service can establish how many antenatal checks they need.

Start with work you’ve done to understand how users interact with your service, such as your [user journey map](https://www.gov.uk/service-manual/user-research/creating-an-experience-map).

Identifying pain points
-----------------------

Consider whether common types of pain points are present in your service. There are several pain points which regularly appear across government services.

### Insisting on the use of particular channels

Provide whatever mix of channels users need for each interaction, and make it easy to move between channels.

### Setting inflexible deadlines

Circumstances affect how quickly users can act. For example, homeless users or users without stable accommodation may not be able to easily charge their phones or check email. Do not assume users will respond quickly just because you’ve sent them an email or text message rather than a letter.

### Accepting only a limited range of documents and evidence

It can be hard for users to provide documentation and evidence. For example, people born in non-UK jurisdictions may face significant challenges getting hold of some types of paperwork. Meanwhile, requiring transgender users to submit certain information might amount to asking them to ‘out’ themselves, or lead to harmful gender dysphoria.

Only ask for things you truly need. When evidence is required, accept as wide a range as possible.

### Failing to signpost or refer users to other services

Ineffective signposting or handovers may exclude users who need help you cannot provide. For example, users might not be able to afford travel or the phone calls necessary to use the support you’ve signposted them to. Marginalised users might feel demotivated to interact with another part of government if one part has failed to help them before.

### Impacting users’ experience of your service through the way you measure its performance

Poorly designed targets can have detrimental knock-on effects. For example, strict time limits on appointments may actually lead to the need for more appointments and therefore more time and money.

Set performance targets carefully. [Design user centred metrics for your service](https://www.gov.uk/service-manual/measuring-success/how-to-set-performance-metrics-for-your-service), and consider all the ways you can [show the value of your service](https://www.gov.uk/service-manual/measuring-success/measuring-service-benefits).

Universal barriers to inclusion
-------------------------------

While people in some groups are more likely to be excluded from services than others, anyone can face barriers to using your service. There are many reasons this might happen.

When reviewing your service, think about the following 11 areas of inclusion. You can read more about [how the barriers were identified](https://gds.blog.gov.uk/2019/03/26/understanding-all-the-barriers-service-users-might-face/).

### Awareness

Users need to know that your service exists. Users who do not know about your service will be excluded. For example:

* users who do not have access to the internet will be less able to search for your service online
* users who do not easily understand English may not be able to read information written in English

### Device and interaction skills

Users will be excluded if they can’t interact with the devices or people involved in your service. For example, a poor quality phone call connection might mean they can’t understand what a call centre worker is saying.

### Time

Users could be excluded if they don’t have the time required to use your service. For example, someone with caring responsibilities might struggle to find time to gather information, fill in forms, travel to an appointment or wait on the phone.

### Enthusiasm

Users could be excluded if the benefits of your service don’t appear to outweigh the effort required to use it. This could be particularly relevant if users familiar with an offline service are being required to do something online instead.

### Access

Users could be excluded if your service requires them to use something that’s hard for them to access, like a place, channel or device. For example, they might not have a printer, be able to check their emails often, or access reliable public transport.

### Comprehension skills

If your service requires users to fully understand spoken advice or written content, you’ll exclude users who do not have these skills. For example, you may be working with non-native English speakers or [people with low literacy skills](https://defradigital.blog.gov.uk/2022/09/21/recognising-the-power-of-literacy-when-designing-services/).

### Evidence

Not all users have access to the same types of evidence. If your service requires a certain type of evidence, such as a passport, driving licence, or even a fixed address, you’ll exclude users who do not have those things.

### Self confidence

If your service is complex, you’re more likely to exclude users who don’t believe in their own ability to understand a process and complete complex tasks. For example, users with lower digital skills may lack confidence in using online services.

### Finance

If your service requires users to pay a fee or spend money in any way - for example to use a phone or get the bus - you’re more likely to exclude users. For example, users may be unwilling to lose income from taking time off work to attend appointments, or may worry about getting a fine for doing something wrong.

### Trust

Users have to trust that the people and technology involved in your service are secure and reliable. For example, if they do not trust the security of making payments online or have had negative experiences with your organisation in the past, they may be excluded.

### Emotional state

If a user does not feel emotionally strong enough to take on the task required by your service, they are more likely to be excluded. For example, users may be exhausted from caring duties or worried about money.

Updates to this page
--------------------

Published 14 August 2018

Last updated 7 January 2025
[+ show all updates](#full-history)

1. 7 January 2025

   Page update to include additional guidance on how to consider inclusion, incorporating universal barrier types, aiming to encourage consideration of how any user can be excluded. You can read more about how the barriers were identified in this blog post: https://gds.blog.gov.uk/2019/03/26/understanding-all-the-barriers-service-users-might-face/
2. 14 August 2018

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---