Doing user research during coronavirus (COVID-19): choosing face to face or remote research - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Doing user research during coronavirus (COVID-19): choosing face to face or remote research
===========================================================================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Benefits of face to face and remote research](#benefits-of-face-to-face-and-remote-research)
2. [Doing a risk assessment of face to face research](#doing-a-risk-assessment-of-face-to-face-research)
3. [Managing ongoing risks](#managing-ongoing-risks)
4. [Protecting researchers](#protecting-researchers)
5. [Approval for conducting face to face research](#approval-for-conducting-face-to-face-research)

The coronavirus (COVID-19) outbreak has created challenges for user research. We have a responsibility to ensure the safety of participants and ourselves.
As national restrictions relax, reintroducing some face to face research could become possible in some situations.

Any decisions about conducting face to face research must comply with [current government guidance about COVID-19](https://www.gov.uk/coronavirus) in place at the time.

Benefits of face to face and remote research
--------------------------------------------

[Remote research](service-manual_user-research_remote-user-research-phone-video-call.md) can be highly effective but it has limitations. For example:

* it can be harder to recruit some groups to take part
* it can be more difficult to understand the needs of people using assistive technology
* it can be harder to learn about the context in which users are based

Face to face research may overcome these limitations but it also raises risks for the researchers and participants. User researchers must consider the benefits of reintroducing face to face research against the risks by doing a risk assessment.
The final decision about whether the risks of face to face research are justified should be made by your department. You can do this on a project by project basis, though it may be useful to have departmental guidelines in place.

You must keep a copy of the risk assessment. It must be signed off by the head of user research or lead for the project and someone senior with responsibility for health and safety.

Doing a risk assessment of face to face research
------------------------------------------------

Capture the risk review in a formal risk assessment document. Keep it with your other project files and keep updating it over the course of the research.

The risk assessment should consider the following questions.

### Is there genuinely a need for face to face research right now?

Could “good enough” data be captured by other methods for example remote research, desk research or researching proxy audiences?

Can the research wait until the COVID-19 risk is reduced?

### If face to face research is required, have we identified the risks and tried to mitigate them?

Do any of the specific user groups or individual participants being researched have extra vulnerabilities that would increase their level of risk? How can you reduce this risk?

In the overall research plan, is face to face research kept to a minimum?
Have we done what we can to make sure the research location is COVID-safe? For example, is there access to hand sanitiser? Is a one-way system in place? Does the place allow for social distancing? What cleaning protocol is in place? Does the place have COVID-safe certification?

Do the research methods allow the researchers and participants to minimise any risks? Is social distancing possible? Can you use personal protective equipment (PPE)? Can you minimise the amount of time people spend in contact with each other? Can you conduct the research outdoors? Can you reduce the number of other people attending the research?

Is there anything that might lead participants to take undue risks to take part in the research? For example, if they are struggling financially, would they take unnecessary risks for the incentive payment? What can you do to prevent unnecessary risk-taking?

### Do the benefits of the face to face research outweigh the risks to researchers and participants?

Do an overall assessment of the remaining level of risk. Work with the teams in your organisation that are responsible for risk assessment and health and safety. This will make sure your organisation is aware of the risks and approves of the research going ahead.

Review the risk assessment regularly, for example at the end of each round of research or when COVID-19 guidance changes.

Managing ongoing risks
----------------------

For every research project you also need to consider:

* what processes are in place if either participants or researchers show symptoms of COVID-19 at any point during the research or immediately afterwards?
* how will participants or researchers tell each other if they get COVID-19 symptoms or test positive?
* how can you make sure research contractors, recruitment agencies or other third parties stick to your risk mitigation processes?

Protecting researchers
----------------------

Researchers must never be put in a position where they are uncomfortable with the risks of conducting face to face research.

Organisations should have COVID-19 operating guidelines to minimise the risk to researchers. These should include:

* considering how vulnerable each researcher may be (including for example their age, ethnicity and any relevant health conditions)
* if researchers will be given personal protective equipment (PPE) and hand sanitiser
* considering how researchers will travel to and from research sessions and any ways that risk can be reduced, for example allowing researchers to drive their own vehicles rather than using public transport
* having guidance for researchers so they can make real-time decisions about whether where they are is COVID-secure and allow them to end a session if they feel they are being exposed to too much risk
* having clear, easy processes to follow after fieldwork sessions, including cleaning equipment and yourself and disposing of contaminated things

Approval for conducting face to face research
---------------------------------------------

The Head of User Research or other project lead can reject or approve the proposal to conduct face to face research. They should make sure the research team has spoken with the relevant risk and health and safety teams. They should also make sure any other relevant parts of the organisation are aware of and support the decision.

### Approving face to face research

If face to face research is approved then, at a minimum, the risk assessment document should include:

* why this research needs to be done now
* why it needs to be conducted face to face
* what the limitations would be if the research was done remotely
* the specific face to face method to be used
* the risk assessment
* why the benefits of face to face research outweigh the risks
* sign off from the departmental Head of User Research (or designated lead), including confirmation of compliance with the department’s existing risk management processes

### Deciding on remote-only research

If the decision is to continue with remote research rather than face to face research, keep a note on the project file saying why. Consider and record the limitations on the user insight the research is likely to get. It may also be useful to plan further research to compensate for these limitations when the risk of COVID-19 has reduced. This could be helpful when you present the user research at service assessments.

Updates to this page
--------------------

Published 28 May 2021

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---