How your assisted digital support will be assessed - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Accessibility and assisted digital](service-manual_helping-people-to-use-your-service.md)

Accessibility and assisted digital

How your assisted digital support will be assessed
==================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Assisted digital and digital take-up community](service-manual_communities_assisted-digital-and-digital-take-up-community.md)

Contents
--------

1. [What to do in discovery and alpha](#what-to-do-in-discovery-and-alpha)
2. [Alpha assessment](#alpha-assessment)
3. [What to do in private beta](#what-to-do-in-private-beta)
4. [Private beta assessment](#private-beta-assessment)
5. [What to do in public beta](#what-to-do-in-public-beta)
6. [Live assessment](#live-assessment)
7. [After your service has gone live](#after-your-service-has-gone-live)
8. [Related guides](#related-guides)

Assisted digital support is help for people who can’t use digital government services on their own.

You’ll have to explain how you’ve provided assisted digital support in your [service assessments](service-manual_service-assessments_check-if-you-need-a-service-assessment.md).

This page outlines some of what you must discuss but your assessment will vary depending on your service and what it does.

[Find out more about assisted digital support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md) and when you must provide it.

What to do in discovery and alpha
---------------------------------

During the discovery and alpha phase, you must [carry out user research](service-manual_user-research_understanding-users-who-dont-use-digital-services.md) to:

* understand your users’ digital skill, confidence and access
* find out why some of your users can’t use the digital service independently, for example language difficulties or no access to the internet
* find out user needs for support

You must also:

* confirm that all support will be sustainable
* develop a plan to carry out further user research and to design support in private beta - base the plan on your user research so far

Alpha assessment
----------------

You must discuss the work you’ve done in discovery and alpha so that your service can pass its alpha assessment and move into beta.

You’ll have to answer questions on the following topics:

* user research and user needs
* your assisted digital lead
* providing free and sustainable assisted digital support
* designing the support elements of your service
* analysing your support’s performance

### User research and user needs

You need to discuss:

* the research you’ve done to understand users’ assisted digital support needs
* how your recruitment and research methods are appropriate for reaching users most likely to need assisted digital support
* the user needs you’ve identified for users who need assisted digital support
* the stories, personas, profiles or other ways you’re describing users who need assisted digital support

You must show that you’ve conducted user research with users who:

* already use your service or would use it
* have the lowest level of digital skills, confidence and access
* currently seek assisted digital support from third parties (like friends and family, colleagues, companies, charities or trade bodies)

You must also show how you’re responding to user research by discussing:

* the people in your team who are dedicated to doing ongoing user research into your users’ assisted digital support needs
* how you’re using what you’ve learned from research and support testing to change the way you develop the assisted digital support elements of your service

### Your assisted digital lead

You’ll need to discuss whether someone in your team is assisted digital lead for the service and responsible for delivering assisted digital support.

You’ll also need to explain how your assisted digital lead has the time and the skills to design, build, operate and continuously improve the service’s assisted digital support model.

### Providing free and sustainable assisted digital support

You’ll need to discuss how you’ll make sure that:

* all assisted digital support for your service, including routes provided by third parties, is free to the user
* the support you provide is sustainable

### Designing the support elements of your service

You’ll need to discuss:

* how users of your service currently get assisted digital support
* your assisted digital support model, the providers you intend to use and why
* the design challenges for your service’s support model

### Analysing your support’s performance

You’ll need to discuss:

* the person in your team who’s responsible for identifying data insights that you can use to improve your assisted digital support
* how you’re measuring the performance of the existing service’s support

What to do in private beta
--------------------------

During private beta you must:

* continue to do user research to find out the support your users need
* design assisted digital support to meet your users’ needs
* decide how you’ll measure the effectiveness of your support model, including how to measure the 4 key performance indicators (KPIs)
* make a plan to test the full support model in public beta, including all user journeys, via all routes, from all providers, and end-to-end

Read these topics to find out more:

* [Designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md)
* [Measuring the success of your service](service-manual_measuring-success.md)

Private beta assessment
-----------------------

To pass the beta assessment, you must discuss the work you’ve done in the private beta phase.

You’ll have to answer questions about:

* user research and user needs
* your service team
* your assisted digital support design
* testing your assisted digital support
* analysing your support’s performance

### User research and user needs

You need to explain how your team’s research into user needs continues to meet the requirements you discussed in the alpha assessment.

You’ll also need to show:

* you have the resources to do regular user research with users who need assisted digital support
* how often you’ll do this research

### Your service team

You’ll need to:

* discuss how you are responsible for making decisions to improve the assisted digital support elements of your service during beta
* give examples of how the service owner had the power to make decisions on assisted digital support during alpha

### Your assisted digital support design

You’ll need to discuss:

* the design options you’re considering for your assisted digital support
* how the team is designing the service’s assisted digital support (all routes from all providers) to meet user needs
* how you’re using what you’ve learned from user research and testing to influence the design of your service’s assisted digital support model
* the end-to-end user journeys for assisted digital support - you’ll be asked to explain these (including identity assurance if your service requires it)
* why you’ve decided not to provide any particular routes of assisted digital support
* whether you can continuously improve all of your service’s assisted digital support (all routes from all providers) for the full end-to-end user journey
* the design challenges for your service with assisted digital users

### Testing your assisted digital support

You’ll need to discuss:

* whether the resources are in place to do regular usability testing of all assisted digital support from all providers
* how you’ll test the end-to-end user journey for your assisted digital support (all routes from all providers), including identity assurance segments
* how you’re checking that all of the assisted digital support (all routes from all providers) will be able to handle the number of support requests you expect

### Analysing your support’s performance

You’ll need to discuss:

* the person in the team who’s responsible for identifying data insights during the beta that you’ll use to improve assisted digital support
* how you’re measuring the performance of all your assisted digital support (existing and beta) for your service
* how you’ll analyse the performance of the assisted digital support for your service in future

What to do in public beta
-------------------------

During public beta, you must:

* allow people who need support to test your service - pick a range of users, with different support needs
* continuously improve your support model in response to testing, user research and analytics
* make sure that your support model is meeting user needs

Live assessment
---------------

Before your service can go fully live on GOV.UK, it must pass a live assessment, which takes place close to the end of the beta phase.

To pass the live assessment, you must discuss the work you’ve done in alpha, private beta and public beta.

You’ll have to answer questions on the following topics:

* user research, user testing and your service team
* your assisted digital support design
* analysing your support’s performance

Every service is different, so you may also have to answer other questions about your service.

### User research, user testing and your service team

You need to explain how your team’s work in these areas continues to meet the alpha and beta requirements, and how you’ll meet them when the service goes live.

You’ll need to talk about:

* how often you carried out user research and usability testing during public beta
* what you learned, during public beta, from testing the end-to-end user journey for your assisted digital support (all routes from all providers), including any identity assurance
* any changes you’ve made in response to what you learned, giving examples
* the types of assisted digital support that you tested during beta and the providers you tested

You also need to discuss:

* how you’re checking that all of the assisted digital support (all routes from all providers) will be able to handle the number of support requests you expect
* how you can be sure your assisted digital support testing was done with users who have the lowest level of digital skills, confidence and access
* how you checked users low on digital skills were users of your service
* whether the users you tested were receiving support from third parties, for example friends and family, charities, trade bodies or companies
* how your recruitment and research methods made sure you reached users with low digital skills

### Your assisted digital support design

You’ll need to discuss:

* the options your service gives to users currently choosing support that’s independent from what you provide - like getting help from friends and family, third parties etc
* how the assisted digital support has been designed and continuously improved based on what you learned from testing, metrics and user feedback
* how you chose routes and providers in the support model and why you excluded any routes - for example telephone, web chat or face to face, talk through or on-behalf-of

You’ll also need to discuss how you know that users’ needs are being met in the following areas:

* awareness of support
* availability of support
* wait times for support
* your approach to digital inclusion (helping users build digital skills and confidence)
* your approach to users’ privacy
* the technology and equipment your service works with
* how consistent your support is with support for similar government transactions

### Analysing your support’s performance

You’ll have to discuss:

* who in the team is responsible for identifying data that you can use to improve your assisted digital support and who’ll do this once the service is live
* the metrics and data sources you’ve chosen to measure your assisted digital support and its performance, and why
* whether you can track users’ progress and identify completions and areas of poor performance
* how you’re using data analytics to find out how many users will need assisted digital support

After your service has gone live
--------------------------------

After your service is live, you must keep improving the support model in response to usability testing, user research, feedback and analytics.

Related guides
--------------

You may also find the following guides useful:

* [Understanding users who don’t use digital services](service-manual_user-research_understanding-users-who-dont-use-digital-services.md)
* [Designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md)
* [Encouraging people to use your digital service](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md)

Updates to this page
--------------------

Published 8 April 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---