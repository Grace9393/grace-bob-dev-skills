Get your service on GOV.UK - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

Get your service on GOV.UK
==========================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Before your alpha assessment](#before-your-alpha-assessment)
2. [After your alpha assessment](#after-your-alpha-assessment)
3. [After your beta assessment](#after-your-beta-assessment)
4. [Related guides](#related-guides)

Public-facing services in public beta or live must have a starting point hosted on GOV.UK. This is usually a start page.

You should start planning this before your alpha assessment.

Before your alpha assessment
----------------------------

Your service owner or content designer should get in touch with the Government Digital Service (GDS) content team. Do this midway through your alpha, once you’ve got:

* a name for your service
* a set of user needs you know the service needs to meet
* an idea of the sorts of changes to GOV.UK content you think might be necessary

It’s useful to share anything else you’ve got that explains what your service will do, for example any sketches you’ve done.

Before you get in touch, speak to the people in your organisation responsible for publishing on GOV.UK - they can chat about your request and help you raise a ticket. Ask them to copy you into the ticket so you can talk to the GDS content team directly.

The GDS content team will consider the impact your service will have on other GOV.UK content, and assess whether any of that related content needs to change. Throughout the development process, they’ll also:

* work with you to draft a start point for your service on GOV.UK - this will usually be a start page
* create a [feedback page](service-manual_service-assessments_get-feedback-page.md) - also known as a ‘done’ page

Once you’ve talked about [how your start point on GOV.UK might look](service-manual_design_govuk-content-transactions.md), you can [prototype the journey and test it during your private beta](https://design-system.service.gov.uk/patterns/start-pages/).

The pages will not be published on GOV.UK until your service has passed its beta assessment.

After your alpha assessment
---------------------------

Once you’ve agreed the start point for your service, you’ll need to [get a service domain name](https://www.gov.uk/service-manual/technology/get-a-domain-name).

You must only advertise the URL (or short URL) for your start point on GOV.UK - and only once it’s been agreed.

It’s important your users [start their journey from the GOV.UK start point](https://www.gov.uk/service-manual/technology/get-a-domain-name#ensure-users-start-their-journey-on-govuk) for your service. This is because your GOV.UK start point includes the information a user needs to complete the service.

After your beta assessment
--------------------------

You can begin using your service domain once you’ve passed your beta assessment.

To do this, you’ll need to [request your domain name delegation](https://www.gov.uk/service-manual/technology/get-a-domain-name#after-your-beta-assessment).

Setting up delegation can take up to 5 working days. Once it’s done, use DNS to [perform domain validation and set up security certificates](https://www.gov.uk/service-manual/technology/get-a-domain-name#set-up-security-certificates) for your service.

You’ll also need to contact the GDS content team to let them know to publish your service start point and feedback page.

Related guides
--------------

You may also find these guides useful:

* [Get a service domain](service-manual_technology_get-a-domain-name.md)
* [Managing domain names](service-manual_technology_managing-domain-names.md)

Updates to this page
--------------------

Published 16 January 2018

Last updated 2 March 2021
[+ show all updates](#full-history)

1. 2 March 2021

   Removed duplicative content that is on the 'Get a service domain' page and clarified when to contact GDS to get a domain name.
2. 14 August 2019

   Added detail on when service teams should get in touch with the GDS content team.
3. 30 May 2018

   Slightly tweaked process for performing domain validation.
4. 16 January 2018

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---