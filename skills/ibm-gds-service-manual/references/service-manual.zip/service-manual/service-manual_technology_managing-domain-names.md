Managing service domains - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Managing service domains
========================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Create additional subdomains](#create-additional-subdomains)
2. [Securing your domain name](#securing-your-domain-name)
3. [Emailing your users](#emailing-your-users)
4. [If you won't send emails from your service domain](#if-you-wont-send-emails-from-your-service-domain)
5. [Related guides](#related-guides)

Once you have a [service domain name](service-manual_technology_get-a-domain-name.md), you can set up subdomains for different environments. You must keep these subdomains secure.

This guidance only applies to service.gov.uk domains. For more information about non-service domains, follow the guidance on [naming and registering government websites](https://www.gov.uk/government/publications/naming-and-registering-government-websites/central-government-naming-and-registering-websites).

Create additional subdomains
----------------------------

After you [get a public-facing domain name](service-manual_technology_get-a-domain-name.md), you can create additional subdomains (for example, for different environments).

You should try to avoid creating separate domains for APIs unless it makes sense for your service. For example, if you need to meet different availability criteria for your API than for the user facing service.

This means you must make sure your service is only accessible through [HTTPS with an HTTP Strict Transport Security (HSTS) configuration](https://www.gov.uk/service-manual/technology/using-https).

### Setting up domains for multiple environments

You should have multiple ‘environments’ for the staging, testing and live (also known as ‘production’) versions of your service.

Using separate [staging and testing environments](https://www.gov.uk/service-manual/technology/working-in-pre-production-environments) will allow you to assess the accuracy and quality of the service before it goes live.

You should structure your staging and testing environment subdomains to follow the same format as the subdomains in your live service, for example www-preview.servicename.service.gov.uk.

Protect any testing and staging domains, including APIs, with a username and password.

If the service is a private alpha or private beta release, you must protect it with a username and password that’s known only to your development team and any users testing the service.

Securing your domain name
-------------------------

You must make sure that your service.gov.uk domain can only be accessed through HTTPS. Your service must not accept HTTP connections under any circumstances.

This will make sure that any personal information your service collects from users can’t be intercepted by malicious third parties as it travels over the internet.

Once you have set up HTTPS, you must enable HTTP Strict Transport Security (HSTS) on any production domains, for example www.servicename.service.gov.uk. You can do this by setting an HTTP response header such as `Strict-Transport-Security: max-age=31536000, includeSubDomains;` for 14 days.

Once you’re confident that HSTS is working, you should increase the timescale to up to one year.

Emailing your users
-------------------

If you want to use your service domain to send emails to users, you must follow the government [guidance on emailing your users](service-manual_technology_how-to-email-your-users.md) guide to make sure they get your emails and protect them from spam and phishing.

If you won’t send emails from your service domain
-------------------------------------------------

If you don’t intend to email users from your service domain, you must make sure it’s [protected from spoofing attacks](https://www.gov.uk/guidance/protect-domains-that-dont-send-email).

Related guides
--------------

You may also find the [Deciding how to host your service](service-manual_technology_deciding-how-to-host-your-service.md) guide useful.

Updates to this page
--------------------

Published 20 October 2016

Last updated 1 November 2017
[+ show all updates](#full-history)

1. 1 November 2017

   Clarified the guidance on creating and managing subdomains.
2. 16 November 2016

   Opening line changed to clarify this guidance is only for service.gov.uk domains.
3. 20 October 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---