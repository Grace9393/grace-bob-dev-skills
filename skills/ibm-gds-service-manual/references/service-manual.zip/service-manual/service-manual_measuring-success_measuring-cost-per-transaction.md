Measuring cost per transaction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Measuring cost per transaction
==============================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Calculating cost per transaction](#calculating-cost-per-transaction)
2. [Cost per transaction through each service phase](#cost-per-transaction-through-each-service-phase)
3. [Data you must publish](#data-you-must-publish)
4. [Related guides](#related-guides)

The cost to government each time someone completes the task your service provides is known as ‘cost per transaction’.

Calculating your service’s cost per transaction allows you to:

* measure how cost-efficient your service is
* use your results to change the service and make it more cost-efficient

Calculating cost per transaction
--------------------------------

Do the following to calculate cost per transaction:

1. Work out the total cost of providing the service - including assisted digital support costs - through all channels.
2. Divide it by the total number of completed transactions.

Because your cost per transaction calculation includes all channels, you can use it to predict how much you’ll save by moving a higher proportion of people to digital channels.

### What to include in your ‘total cost’

In your total cost, include the following:

* accommodation and capital charges for freehold properties
* fixtures, fittings, maintenance and utilities
* office equipment, including IT systems
* postage, printing and telecommunications
* total employment and training costs for people who provide the service
* overheads, eg (shares of) payroll, audit, top management costs, legal services etc
* raw materials and stocks
* research and development
* depreciation of start up and one-off capital items
* taxes (VAT, council tax, stamp duty etc)
* capital charges (if you did not pay these separately when the service was established)
* speculative or actual insurance premiums
* fees to sub-contractors
* distribution costs, including transport
* all costs associated with promoting the service
* bad debts
* provisions (ie an amount put aside to cover a future liability)

You must also include all the costs of providing [assisted digital support](https://www.gov.uk/service-manual/assisted-digital) as part of your total cost for the service.

### Working out costs shared with other services

If your service shares the cost of any items on this list with other services, you’ll need to work what proportion of that cost is yours.

1. Divide the cost of the item by the number of full-time equivalents from all the teams and services responsible for it.
2. Multiply the result by the number of full-time equivalents on your team

If your service shares a call centre with other services, you’ll need to work out what proportion of that cost is yours.

1. Find out the percentage of time spent on calls to do with your service.
2. Add that percentage of the call centre’s cost to your total cost.

### What not to include in ‘total cost’

Do not include these costs:

* enforcement costs
* replacement costs of items notionally insured
* start-up costs (those which can be capitalised in the accounts)

Cost per transaction through each service phase
-----------------------------------------------

If you’re transforming an existing service, measure the cost per transaction of that service (through all available channels) in the discovery and alpha phases.

Use this data as a baseline against which to measure future cost per transaction data.
From beta onwards, include costs for the new digital service when calculating cost per transaction.

If this is an entirely new service, you’ll need to wait until the end of the first quarter of public beta before you have any data to report.

Data you must publish
---------------------

From the start of public beta you must take a measurement of cost per transaction every 3 months.

Here’s how to calculate your first 4 measurements:

1. Use data for the first 3 months.
2. Use data for the first 6 months.
3. Use data for the first 9 months.
4. Use data for the first 12 months.

From then on, measure cost per transaction every 3 months, based on data for the previous 12 months. You then need to [publish the data](service-manual_measuring-success_data-you-must-publish.md).

Related guides
--------------

You may also find these guides useful:

* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)

Updates to this page
--------------------

Published 29 March 2016

Last updated 19 February 2021
[+ show all updates](#full-history)

1. 19 February 2021

   Removed reference to Performance Platform as this is being retired.
2. 29 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---