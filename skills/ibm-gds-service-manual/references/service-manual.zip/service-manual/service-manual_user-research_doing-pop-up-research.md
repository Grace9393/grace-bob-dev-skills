Doing pop-up research - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Doing pop-up research
=====================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to do pop-up research](#when-to-do-pop-up-research)
2. [Steps to follow](#steps-to-follow)
3. [Examples and case studies](#examples-and-case-studies)
4. [Related guides](#related-guides)

With pop-up research, you do short informal interviews or usability tests in places used by the people you want to talk to (for example libraries, day centres, offices or colleges).

When to do pop-up research
--------------------------

Pop-up research works best when you have clear, simple objectives (for example, you want to see if people can find certain guidance or provide specific information). This means your research activity needs to be short and easy to explain.

Pop-up research can be particularly helpful if you need to:

* get insights quickly
* research with a broad cross-section of the public
* talk to specific user groups that may be difficult to reach - for example, care home residents, homeless people or A level students
* learn about regional variations - so you need to research in different places

The limitations of pop-up research (for example, short sessions, random participants, recording problems etc) mean you’ll always need to combine it with other research methods.

Steps to follow
---------------

Plan and prepare your pop-up research sessions carefully for best results.

### Plan your visit

When planning pop-up research, you’ll need to:

* identify places where the people you want to talk to are likely to be - don’t rule out noisy or crowded places as these can be more realistic environments than silent usability labs
* contact venues and ask for permission to carry out research - explain what you want to do, when you want to do it and how long it will take
* line up several venues and dates in advance
* make sure each venue is accessible to the users you’re trying to see
* use a checklist to make sure you take everything you’ll need on the day

### Work in pairs

Always do pop-up research in pairs - it’s easier and safer. Having 2 of you there means:

* one of you can recruit participants while the other is setting up the next session
* one of you can take notes and recordings while the other leads the session
* one of you can watch your equipment and bags while the other gets drinks and food, or goes to the toilet
* more team members get the chance to meet and learn from users first hand

### Set up

Once you arrive at a venue, you should:

* set up in a place where people are likely to pause or have some free time, for example a break out area or café
* choose a position where people passing by can see what you’re doing - this can attract participants, as well as reassure them
* make yourself visible, for example with banners and signs
* look around, talk to people and take photos of things that might be relevant to your research or give you a better understanding of your users or your service
* take care of your equipment and personal belongings - it’s easy to forget that you’re in a public place

### Find participants

Unlike other types of research, you’ll need to [recruit research participants](service-manual_user-research_find-user-research-participants.md) at the venue on the day itself. You should:

* approach people who may be able to take part in your research
* be able to explain what you’re doing - and that you’re not selling anything - in less than 30 seconds
* make it clear that you’re there to learn from them, or to have them try something so you can see how well it works for them
* consider offering small incentives like drinks or snacks - don’t offer money for pop-up research as it can be hard to manage and could put you at risk
* [get informed consent](service-manual_user-research_getting-users-consent-for-research.md) from all participants before you start

### Do the research

Focus on 1 or 2 important tasks or questions. For best results:

* come prepared with a short set of questions, tests based on paper or digital prototypes, or tests of existing services
* choose inclusive activities and be flexible on the day so as many people as possible can participate - for example, allow people with access needs to use their own device and assistive technology
* aim for sessions to last around 10 minutes - once people are engaged, they may stay longer
* use simple data capture sheets (for example, paper divided into boxes) to make it easier for you to take notes
* use your phone, laptop and online tools to record screen activity, the participant’s face and your conversation
* be prepared that some venues and participants won’t let you record or photograph sessions - particularly if the topic you’re researching is sensitive

### Pack up

Once you’ve finished:

* pack away your equipment - use your planning checklist
* make sure any personal data you’ve collected (on paper or in recordings) is stored safely so you can transport it securely
* tidy up the area you’ve been working in and return everything to its normal place
* thank everybody for their time and support
* ask if you can come back another time

Examples and case studies
-------------------------

To learn more about pop-up research, read a blog post about [how the ‘register to vote’ service was tested with under-registered groups at venues around the UK](https://gds.blog.gov.uk/2013/11/22/reaching-all-our-users/).

Related guides
--------------

You may also find these guides useful:

* [Choose a location for user research](service-manual_user-research_choose-a-location-for-user-research.md)
* [Analyse a research session](service-manual_user-research_analyse-a-research-session.md)

Updates to this page
--------------------

Published 21 February 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---