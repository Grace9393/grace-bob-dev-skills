Measuring digital take-up - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Measuring digital take-up
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Calculating digital take-up](#calculating-digital-take-up)
2. [Digital take-up through each service phase](#digital-take-up-through-each-service-phase)
3. [Publish the data](#publish-the-data)
4. [Related guides](#related-guides)

You must plan to continually increase digital take-up. Digital take-up is the percentage of people using government services online in relation to other channels, for example paper or telephone.

When calculating digital take-up, include people who get support from someone else to use the digital service (known as [‘assisted digital’ support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)).

Calculating digital take-up
---------------------------

You must measure digital take-up from public beta onwards.

To calculate digital take-up, follow these steps:

1. Find the number of completed digital transactions over any fixed period (include digital transactions where assisted digital support was used).
2. Divide that number by the total number of transactions from all channels in the same period.
3. Show the result as a percentage.

Digital take-up through each service phase
------------------------------------------

### Discovery

In discovery, you must carry out user research to understand the different types of people who need to use your service. This will help you understand your users’ level of digital skill, literacy and willingness to use digital services.

Use your user research and your understanding of the relative complexity of your service to set initial targets for:

* the digital take-up for your service
* the type and level of assisted digital support your service will need

### Alpha

If you have an existing service, use the available data to set a ‘baseline’ for digital take-up. A baseline is your first measurement of the percentage of people using digital channels to complete your service. As you progress, use this baseline to check how the new service is improving digital take-up.

You should start creating a model of how people use your service. To do this:

* work out what channels people currently use to complete the task your service provides
* make a projection of what channels they are likely to use in the future (including assisted digital support channels)
* begin planning how you’ll move users from non-digital channels to digital ones (known as ‘channel shift’)

Your channel shift plan must:

* describe how and when you propose to move non-digital users onto the digital service
* estimate how much assisted digital support your users will need, what forms this should take, and how this is likely to reduce as digital take-up increases

Regardless of whether you have an existing service, you should also look at similar services and see how they measure digital take-up and the tactics they’ve used to increase it.

### Beta

During beta, validate the modelling work you did in alpha with actual data that you’re starting to collect. Use this data to refine your target for digital take-up and your plan for channel shift.

You must also start getting your delivery partners and other stakeholders ready to promote the digital service when it goes live.

Find out [how to increase digital take-up](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md).

### Live

Once the service is live, you must continue to implement your channel shift plan, checking it every six months or annually.

Publish the data
----------------

You must measure digital take-up data every month and [publish the data](service-manual_measuring-success_data-you-must-publish.md).

Related guides
--------------

You may also find these guides useful:

* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)

Updates to this page
--------------------

Published 30 March 2016

Last updated 19 February 2021
[+ show all updates](#full-history)

1. 19 February 2021

   Removed reference to Performance Platform as it is being retired. Added link to new guidance about publishing data instead.
2. 30 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---