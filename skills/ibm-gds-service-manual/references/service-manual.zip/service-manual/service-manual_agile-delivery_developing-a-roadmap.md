Developing a roadmap - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Developing a roadmap
====================

[Give feedback about this page](/contact/govuk)

From:
:   [Product and service community](service-manual_communities_product-and-service-community.md)

Contents
--------

1. [Why roadmaps are important](#why-roadmaps-are-important)
2. [Roadmap principles](#roadmap-principles)
3. [Examples and case studies](#examples-and-case-studies)
4. [Discuss and contribute](#discuss-and-contribute)

A roadmap is a plan that shows how a product or service is likely to develop over time.

Roadmaps need to be easy to understand, and simple to adjust when priorities change - as often happens with agile ways of working.

Why roadmaps are important
--------------------------

A roadmap makes it clear what you’re trying to achieve and the steps you’ll take towards that end goal. This applies whether you’re working on a whole service or a product that supports a service.

As well as making it clear what you’re doing, a roadmap also explains what you’re not doing.

A roadmap helps the wider team understand how what they’re working on now relates to future work and priorities.

Anyone involved in providing a budget or governance for your work needs to see a roadmap so they understand when and how your team is likely to deliver value to users.

Having an open roadmap also makes it clear to other delivery teams what you’re working on, so everyone can see where things might overlap and you can avoid duplicating work. When things are open, it’s easier to find and share useful code, patterns and supporting materials across products.

Users of your product or service may want to find out what your plans are for developing it, as might people who deliver public services or hold government to account.

Roadmap principles
------------------

### 1. Your roadmap takes you towards a vision, in iterations

Your product or service should have a long-term vision that explains what it’s ultimately trying to achieve for users. Your roadmap should be broken down into the stages, or product iterations, that will get you there. At GDS each product iteration is known as a ‘mission’.

### 2. A roadmap shows what you’re trying to achieve

Products and services should be judged by the value they deliver to users. Examples of value are making things quicker, making things simpler and saving people effort.

Roadmaps are a tool to express what the value of a product will be. They show the stages in which that value will be understood and released to users.

### 3. Each service or product should have a roadmap

A product can have its own roadmap or it can be part of a wider roadmap that gives a collective view of products related to a service.

It’s best to keep your roadmap online using a spreadsheet or other software, to minimise the risk of losing any information.

If the needs of your users or team mean you need more than one version of your roadmap, like one on a wall and one online, use one as your master version but make sure each version is always up to date with the latest information.

### 4. Roadmaps are developed iteratively and regularly

Creating and iterating a roadmap is something you do collaboratively, usually led by your product manager. [The delivery team and stakeholders should all be involved](http://www.jamiearnold.com/blog/2014/07/22/seven-questions-to-build-a-roadmap), and you must also use things you’ve learnt from [performance analysis](service-manual_measuring-success.md) and [user research](service-manual_user-research.md) to inform the decisions you make. At GDS roadmaps are iterated on at least a quarterly basis.

### 5. A roadmap should be open

It should be available for other civil servants to view and should where possible be in the public domain. The main exceptions are when there’s a very good security reason not to make a roadmap available, or if there are political sensitivities around sharing plans.

### 6. It needs to be easy to understand

A roadmap should use simple visuals to make it easy and quick to understand. It should also be in [plain English](https://www.gov.uk/guidance/content-design/writing-for-gov-uk#plain-english) and free of jargon so it’s accessible and usable for the range of people who will use it. It can contain links to places where users can find more information, like a backlog or blog.

### 7. Product iterations have clear objectives

Each product iteration in your roadmap should have an objective that gets you closer to achieving your long-term vision. There should be a clear goal each time (often a problem to be solved) and an explanation of how you’ll measure progress.

Roadmaps are not the same as [backlogs](http://www.scrumguides.org/scrum-guide.html#artifacts-productbacklog), which are used by teams to manage the delivery of features and tasks in smaller, time-boxed periods.

### 8. Missions and phases have fixed time periods

Missions are mapped over time - this might be done in quarters. These segments of time need to be consistent.

When the roadmap includes [phases](service-manual_agile-delivery#phases-of-an-agile-project.md) (like discovery or beta) these should be timeboxed.

### 9. Roadmaps are clear about priority

A good roadmap shows what’s been done and what’s coming next in order of priority. [The way you prioritise](service-manual_agile-delivery_deciding-on-priorities.md) needs to be consistent and transparent.

### 10. Roadmaps capture intent and allow for change

Roadmaps allow you to plan for change. They capture intent, not solutions.

The further into the future a mission will take place, the more uncertain it is. The closer it gets, the more you learn and the more confident you become about whether it’s the right thing to work on.

Things can be added to or dropped from roadmaps.

### 11. They explain the ‘who’ and the ‘how’

A roadmap should have an explanation of who it’s for and how to read it.

It should also include information about who maintains the roadmap, how often it’s updated and how to contribute to developing it.

### 12. They’re reusable

When you use software to create a roadmap, the content should be exportable so it can be transferred if needed.

Examples and case studies
-------------------------

* [How we are using roadmaps in government](https://gds.blog.gov.uk/2017/03/27/how-we-are-using-roadmaps-in-government/)
* [The 2017 to 2018 GOV.UK roadmap](https://insidegovuk.blog.gov.uk/2017/02/13/the-2017-to-2018-gov-uk-roadmap/)
* [How we made the GOV.UK roadmap](https://insidegovuk.blog.gov.uk/2017/03/17/how-we-made-the-gov-uk-roadmap/)
* [Make the most of your roadmap](https://gds.blog.gov.uk/2017/08/03/make-the-most-of-your-roadmap/)

Discuss and contribute
----------------------

* [Read and comment on ‘Roadmap elements’](https://medium.com/@rossferg/roadmap-elements-b311f74b7ba4) - the original Medium post this guide is based on
* [Discuss on the Product People mailing list or UK government Slack](https://www.gov.uk/service-manual/communities/product-and-service-community#get-involved)

Updates to this page
--------------------

Published 16 November 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---