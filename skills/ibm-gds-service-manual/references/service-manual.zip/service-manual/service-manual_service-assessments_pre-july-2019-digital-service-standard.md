Digital Service Standard (pre-July 2019) - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

Digital Service Standard (pre-July 2019)
========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Summary](#summary)
2. [1. Understand user needs](#understand-user-needs-1)
3. [2. Do ongoing user research](#do-ongoing-user-research-1)
4. [3. Have a multidisciplinary team](#have-a-multidisciplinary-team-1)
5. [4. Use agile methods](#use-agile-methods-1)
6. [5. Iterate and improve frequently](#iterate-and-improve-frequently-1)
7. [6. Evaluate tools and systems](#evaluate-tools-and-systems-1)
8. [7. Understand security and privacy issues](#understand-security-and-privacy-issues-1)
9. [8. Make all new source code open](#make-all-new-source-code-open-1)
10. [9. Use open standards and common platforms](#use-open-standards-and-common-platforms-1)
11. [10. Test the end-to-end service](#test-the-end-to-end-service-1)
12. [11. Make a plan for being offline](#make-a-plan-for-being-offline-1)
13. [12. Make sure users succeed first time](#make-sure-users-succeed-first-time-1)
14. [13. Make the user experience consistent with GOV.UK](#make-the-user-experience-consistent-with-govuk-1)
15. [14. Encourage everyone to use the digital service](#encourage-everyone-to-use-the-digital-service-1)
16. [15. Collect performance data](#collect-performance-data-1)
17. [16. Identify performance indicators](#identify-performance-indicators-1)
18. [17. Report performance data on the Performance Platform](#report-performance-data-on-the-performance-platform-1)
19. [18. Test with the minister](#test-with-the-minister-1)

If you started a discovery after 30 June 2019, use the [newer version of the Service Standard](service-manual_service-standard.md).

A new Service Standard came into force at the end of June 2019. From that date, anyone starting a discovery needs to work towards the new version. You can read a blog post about [how and why the standard was updated](https://gds.blog.gov.uk/2019/05/09/welcome-to-the-updated-service-standard/).

If you’re working on a service for central government that started its discovery before July 2019, you might be able to continue to use the older version of the standard. Email [dbd-assessments@digital.cabinet-office.gov.uk](mailto:dbd-assessments@digital.cabinet-office.gov.uk) if you want to continue to use the older version.

Summary
-------

The Digital Service Standard is a set of 18 criteria to help government create and run good digital services.

### 1. Understand user needs

Understand user needs. Research to develop a deep knowledge of who the service users are and what that means for the design of the service.

[Read more about point 1](#understand-user-needs-1).

### 2. Do ongoing user research

Put a plan in place for ongoing user research and usability testing to continuously seek feedback from users to improve the service.

[Read more about point 2](#do-ongoing-user-research-1).

### 3. Have a multidisciplinary team

Put in place a sustainable multidisciplinary team that can design, build and operate the service, led by a suitably skilled and senior service owner with decision-making responsibility.

[Read more about point 3](#have-a-multidisciplinary-team-1).

### 4. Use agile methods

Build your service using the agile, iterative and user-centred methods set out in the manual.

[Read more about point 4](#use-agile-methods-1).

### 5. Iterate and improve frequently

Build a service that can be iterated and improved on a frequent basis and make sure that you have the capacity, resources and technical flexibility to do so.

[Read more about point 5](#iterate-and-improve-frequently-1).

### 6. Evaluate tools and systems

Evaluate what tools and systems will be used to build, host, operate and measure the service, and how to procure them.

[Read more about point 6](#evaluate-tools-and-systems-1).

### 7. Understand security and privacy issues

Evaluate what user data and information the digital service will be providing or storing and address the security level, legal responsibilities, privacy issues and risks associated with the service (consulting with experts where appropriate).

[Read more about point 7](#understand-security-and-privacy-issues-1).

### 8. Make all new source code open

Make all new source code open and reusable, and publish it under appropriate licences (or provide a convincing explanation as to why this cannot be done for specific subsets of the source code).

[Read more about point 8](#make-all-new-source-code-open-1).

### 9. Use open standards and common platforms

Use open standards and common government platforms where available, including GOV.UK Verify as an option for identity assurance.

[Read more about point 9](#use-open-standards-and-common-platforms-1).

### 10. Test the end-to-end service

Be able to test the end-to-end service in an environment identical to that of the live version, including on all common browsers and devices, and using dummy accounts and a representative sample of users.

[Read more about point 10](#test-the-end-to-end-service-1).

### 11. Make a plan for being offline

Make a plan for the event of the digital service being taken temporarily offline.

[Read more about point 11](#make-a-plan-for-being-offline-1).

### 12. Make sure users succeed first time

Create a service which is simple to use and intuitive enough that users succeed the first time.

[Read more about point 12](#make-sure-users-succeed-first-time-1).

### 13. Make the user experience consistent with GOV.UK

Build a service consistent with the user experience of the rest of GOV.UK including using the design patterns and style guide.

[Read more about point 13](#make-the-user-experience-consistent-with-govuk-1).

### 14. Encourage everyone to use the digital service

Encourage all users to use the digital service (with assisted digital support if required) alongside an appropriate plan to phase out non-digital channels and services.

[Read more about point 14](#encourage-everyone-to-use-the-digital-service-1).

### 15. Collect performance data

Use tools for analysis that collect performance data. Use this data to analyse the success of the service and to translate this into features and tasks for the next phase of development.

[Read more about point 15](#collect-performance-data-1).

### 16. Identify performance indicators

Identify performance indicators for the service, including the 4 mandatory key performance indicators (KPIs) defined in the manual. Establish a benchmark for each metric and make a plan to enable improvements.

[Read more about point 16](#identify-performance-indicators-1).

### 17. Report performance data on the Performance Platform

Why you should report data and how you’ll be assessed.

[Read more about point 17](#report-performance-data-on-the-performance-platform-1).

### 18. Test with the minister

Test the service from beginning to end with the minister responsible for it.

[Read more about point 18](#test-with-the-minister-1).

1. Understand user needs
------------------------

You must understand user needs to meet point 1 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 1 improves your service

You need to understand the needs of your users so that you can build a service that:

* helps users do the thing they want to do at the first attempt without having to understand government
* is built on your users’ real needs, not your assumptions

Your service assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass the alpha assessment, you usually need to show:

* the user needs you’ve found for your service in discovery and how you found those needs, including any needs for assisted digital users
* how you’ve been [writing user stories](service-manual_agile-delivery_writing-user-stories.md) for your service - including for users who need assisted digital support
* research that identifies parts of the task which users find difficult - you’ll have to explain how you’ve changed the service to make these parts of the task easier for users and how you tested and researched to confirm this
* any problems that you found in research which you’ll have to overcome to design the service

### How you’ll be assessed at beta

To pass the beta assessment, you usually need to:

* talk about the private beta, including how many users you tested with, how you recruited them, how you used analytics in your research, and what you learned that you did not find in alpha
* explain who your users are and what you’ve done to understand their needs, including users who need assisted digital support
* explain any changes to user needs you’ve identified as a result of researching with users
* discuss the users of your service whose needs are most difficult to meet, and how you’ve been learning about those needs
* talk about the design challenges your users’ needs pose for your service
* talk about the research you’ve done in private beta, ie who you did research with, where and when - this should include research with users who need assisted digital support
* give examples of user stories, personas or profiles for your service - ie identify people who need to use the service and what they use it for, including users who need assisted digital support

You also need to:

* discuss research that identifies parts of the task which users find difficult - you’ll have to explain how you’ve changed the service to make these parts of the task easier for users and how you tested and researched to confirm this
* discuss any problems that you found in research which you’ll have to overcome to design the service
* explain the research you did to understand whether your support model meets user needs and how that research informed iteration and testing
* show how the design of the service has changed over time because of what you found in user research

### How you’ll be assessed at live

To pass the live assessment, you usually need to:

* show research that identifies parts of the task which users find difficult - you’ll have to explain how you’ve changed the service to make these parts of the task easier for users and how you tested and researched to confirm this
* talk about the research you did in public beta and how you’ll use the results to continuously improve your service, ie who you did research with, how often, when and where - include users who need assisted digital support
* give examples of user stories for your service - ie identify someone who needs to use the service and what they use it for - include assisted digital users
* show the user needs you’ve found for your service, including for users who need assisted digital support

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you understand user needs:

* [Start by learning user needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Improve service design with user research](service-manual_user-research_how-user-research-improves-service-design.md)

Find out more about:

* [user research](service-manual_user-research.md)
* [service assessments](service-manual_service-assessments.md)
* [assisted digital support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)

2. Do ongoing user research
---------------------------

You must do ongoing user research to meet point 2 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 2 improves your service

Doing ongoing user research means you can:

* check your service is helping users to do the tasks they need to do
* keep improving the service based on users’ needs

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass the alpha assessment, you usually need to show:

* what your private beta will look like and how you’ll use what you find to improve the service
* you can pay for user research and usability tests throughout the design of the service and after it’s built
* how often you’ll carry out research and usability tests and how you’ll use the results to improve the design of your service
* a user research plan for private beta and a plan for carrying out user research on the live service

### How you’ll be assessed at beta and live

To pass the beta and live assessments, you usually need to show:

* you can pay for user research and usability tests throughout the design of the service and you’ll be able to pay after the service is built
* how often you’ll carry out research and usability tests and how the results will affect the way you design the service
* a user research plan for the service at the next phase and a plan for carrying out user research on the live service
* how you’ve done user research with people who have accessibility needs from the time you started designing the service
* how you’ve tested with users who need assisted digital support
* how you’re using analytics data in your user research plan for the service
* any problems you’ve found through testing and how you solved them
* any problems you have not been able to solve in beta and how you’ll handle them in public beta

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Find out more about:

* [user research](service-manual_user-research.md)
* [service assessments](service-manual_service-assessments.md)
* [assisted digital support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)

3. Have a multidisciplinary team
--------------------------------

You must have a multidisciplinary team to meet point 3 of the Digital Service Standard.

You’ll have to discuss how your team works at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 3 improves your service

A multidisciplinary team helps you to:

* build your service
* keep improving it based on user needs
* make decisions quickly

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to:

* describe your delivery team - you need to employ people in the following roles: service owner, product manager, delivery manager, technical architect, assisted digital lead, designer, user researcher, developer, content designer, web operations engineer, performance analyst, front-end developer
* show you have a service owner with the knowledge and power to make day-to-day decisions to improve the service
* show you have at least one user researcher working at least 3 days each week
* explain how the separation of key roles in the team means that nobody is performing multiple roles

You also need to:

* show you understand where gaps may emerge in the team and how to fill them
* explain your plan to transfer knowledge and skills from contractors to permanent staff
* show that there’s a person on your team who’s responsible for user research and usability tests
* show you’ll have a team that can keep improving the service after it goes live
* show the team fully understands the service after it’s gone live

In the live assessment only, you must explain how your team and your way of working can keep improving the service.

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Find out more about:

* [user research](service-manual_user-research.md)
* [service assessments](service-manual_service-assessments.md)
* [setting up the right team](https://www.gov.uk/service-manual/the-team)

4. Use agile methods
--------------------

You must use agile methods to meet point 4 of the Digital Service Standard.

You’ll have to discuss how you’ve used agile methods at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 4 improves your service

Using agile methods helps you to build services that:

* meet the needs of your users
* are easy and convenient for people to use
* you can change easily, eg if government policy or technology policy changes
* you can keep improving, eg based on user feedback
* cost less and are more accountable

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to:

* explain how you’re working in an agile way, using agile tools and techniques, and how you’ll continue to do so when the service is live
* explain how you and your team have reviewed and iterated the ways you work to fix problems
* explain how your team is using agile tools and techniques to communicate with each other
* give an example of how the team has responded to user research and usability testing
* show that your governance is agile, based on clear and measurable goals, and has a clear focus on managing change and risk in real time

You also need to discuss:

* the design options you explored for your prototype and the reasons you discarded some
* how the design of the service has changed over time because of what you found in user research
* the design options you’re considering for your assisted digital support
* any problems that you found in research which you’ll have to solve to design the service, and how you plan to solve them

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Find out more about:

* [agile delivery](service-manual_agile-delivery.md)
* [assessments](service-manual_service-assessments.md)
* [assisted digital support](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)

5. Iterate and improve frequently
---------------------------------

You must iterate your service and improve it frequently to meet point 5 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 5 improves your service

You need to build a service which you can iterate and keep improving so that you can:

* easily respond to changes in policy which affect the service
* make sure your service keeps meeting user needs

### How you’ll be assessed

Your assessment and the questions assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to:

* explain what you’ve built in that phase and why you built it
* describe the lifecycle of a user story from user research to production
* show you understand how your service is built to meet user needs
* explain your process for identifying and prioritising insights from user research
* show you can move user stories quickly and smoothly between user research and production
* show there’s minimal risk associated with the technology you chose
* prove you have the ability to deploy software frequently with minimal disruption to users
* show you’re analysing user research and using it to improve your service
* show you’re solving any technical problems you’ve found

At the beta assessment, you also need to explain:

* how long you expect your service to be in beta and why
* your way of [deploying software](service-manual_making-software_deployment.html.md), ie how you can deploy frequently with minimum impact on users

At the live assessment you also need to explain:

* how you’re practising zero downtime deployments in a way that does not stop users using the service
* how you plan to have enough staff to keep improving the service

### Explain your service’s evolution

At each phase you should explain how your service has evolved since its last assessment.

### Related guides

Find out more about:

* [agile delivery](service-manual_agile-delivery.md)
* [service assessments](service-manual_service-assessments.md)

6. Evaluate tools and systems
-----------------------------

You must spend time checking the value of tools and systems to meet point 6 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 6 improves your service

Evaluating the tools and systems you use to build your service helps you to:

* check any risks or constraints associated with them
* avoid contracts that lock you in and stop you improving your service
* build a sustainable system which you can easily manage after your service goes live

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass point 6 in the alpha assessment, you usually need to describe:

* the languages, frameworks and other technical choices you’ve made in alpha, and how this will affect the decisions you make in beta
* the set of programming tools you’d like to choose for beta and why
* how you’ll get value for money when buying any tools
* how you’ll [monitor the status of your service](service-manual_technology_monitoring-the-status-of-your-service.md)

### How you’ll be assessed at beta

To pass point 6 in the beta assessment you usually need to explain:

* how you’re managing the limits placed on your service by the technology stack and development toolchain you’ve chosen
* what you’ve bought and how you’re getting value for money
* demonstrate how you’ll [monitor the status of your service](service-manual_technology_monitoring-the-status-of-your-service.md)
* the support arrangements you have in place, in normal hours and out of hours
* any decisions you’ve outsourced to third parties and why you chose to do this

### How you’ll be assessed at live

To pass point 6 in the live assessment, you usually need to:

* describe the tech stack changes you made during beta and why
* describe the development toolchain changes you’ve made during beta and why
* explain how you’re continuing to get value for money from the systems you chose and bought at beta
* explain or demonstrate how you’ll check if the service is healthy
* explain the support arrangements that you’ve set up for live
* explain any decisions you’ve outsourced and why you chose to do this

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Find out more about:

* [choosing technology](service-manual_technology_choosing-technology-an-introduction.md)
* [service assessments](service-manual_service-assessments.md)

7. Understand security and privacy issues
-----------------------------------------

You must understand security and privacy issues to meet point 7 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 7 improves your service

Users will not use your service unless you can guarantee:

* it’s confidential
* they can access their information in the service when they need to

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass the alpha assessment for point 7 you usually need to explain:

* how you’ve identified threats to your service, including potential pathways for hackers, and tested ways of reducing them
* how you plan to keep up to date about threats to your service and how to deal with them
* any threats of fraud (fraud vectors) which exist and the controls you’re prototyping

### How you’ll be assessed at beta

To pass the beta assessment for point 7 you usually need to:

* describe your team’s approach to security and risk management
* describe the security and privacy threats to your service
* explain the fraud vectors that exist and the controls you’re putting in place
* describe how you’ve worked with the business and information risk teams, for example the senior information risk owner (SIRO), information asset owner (IAO) and data guardians, and how you’re working to meet any security regulations without putting delivery at risk
* describe any outstanding legal concerns, eg how you’ll protect data or your policy on sharing it
* present your cookie and privacy policy and explain how you arrived at it

### How you’ll be assessed at live

To pass the live assessment for point 7 you usually need to:

* describe your team’s approach to security and risk management
* describe your ongoing interactions with the business and information risk teams, eg SIRO, IAO and data guardians
* describe any outstanding legal concerns, eg data protection or data sharing
* explain how you’re keeping your understanding of the threats to your service up to date, and explain how the threats have changed during beta
* explain how you’re keeping your cookie policy and privacy policy up to date

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you understand security and privacy issues:

* [Information security](service-manual_making-software_information-security.html.md)
* [Cloud security](service-manual_operations_cloud-security.html.md)
* [User accounts and logins](service-manual_design_user-accounts.md)

Find out more about:

* [technology for services](service-manual_technology.md)
* [service assessments](service-manual_service-assessments.md)

8. Make all new source code open
--------------------------------

You must make all new source code open to meet point 8 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 8 improves your service

Making your source code open means:

* other services can reuse the software you’ve created
* other services do not end up doing work you’ve already done and you reduce costs in government as a whole
* you avoid starting technology contracts that you cannot end easily

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass, you usually need to:

* explain how you plan to make all new source code open and reusable
* confirm that you own the intellectual property
* explain how someone else can reuse your code

### How you’ll be assessed at beta

To pass, you usually need to:

* explain how you’re making new source code open and reusable
* show your code in an open internet source code repository
* explain the licences you’re using to release code during beta
* confirm that you own the intellectual property
* explain how a team in another department can reuse your code
* explain how you’re using code from other teams or services

### How you’ll be assessed at live

To pass, you usually need to:

* explain how you’re making new source code open and reusable
* show your code in an open internet source code repository
* describe how you accept contributions and comments on the code
* explain how you’re handling updates and bug fixes to the code
* explain the licences you’re using to release code
* confirm that you own the intellectual property
* explain the code you’ve not made open and why
* explain how a team in another department can reuse your code

### Explain your service’s evolution

At each phase you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you make all new source code open:

* [Making source code open and reusable](service-manual_technology_making-source-code-open-and-reusable.md)
* [Using open source software](service-manual_making-software_open-source.html.md)
* [Choosing technology: an introduction](service-manual_technology_choosing-technology-an-introduction.md)

Find out more about:

* [technology for services](service-manual_technology.md)
* [service assessments](service-manual_service-assessments.md)

9. Use open standards and common platforms
------------------------------------------

You must use open standards and common platforms to meet point 9 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 9 improves your service

Using open standards and common government platforms means you:

* save time and money by reusing things that are already available, such as GOV.UK Verify for identity assurance
* can move between different technologies when you need to and do not get locked into contracts which are difficult to end
* can quickly and easily change your service when you need to
* can give your users a more consistent experience when using government services online - this builds trust

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass your alpha assessment, you usually need to explain how you:

* use open standards and common platforms to avoid getting locked into contracts
* use common platforms for your system, such as GOV.UK Verify as an option for identity assurance
* identify the common user needs your service meets and what you reuse from across government to help meet those user needs

### How you’ll be assessed at beta

To pass your beta assessment, you usually need to explain how you:

* use open standards and common platforms to avoid getting locked into contracts
* manage what the service outputs to users is and in what format
* manage common data you hold and your commitment to publishing it
* use common government platforms, such as GOV.UK Verify as an option for identity assurance
* integrate with any legacy systems
* identify the common user needs your service meets and what you reuse from across government to help meet those user needs

### How you’ll be assessed at live

To pass your live assessment, you usually need to explain how you:

* use open standards and common platforms to avoid getting locked into contracts
* use common government platforms, such as GOV.UK Verify as an option for identity assurance
* integrate with any external systems
* manage the common data you hold and meet your open data responsibility
* identify the common user needs your service meets and what you reuse from across government to help meet those user needs

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Read the [Working with open standards](service-manual_making-software_open-standards-and-licensing.html.md) guide to help you pass point 9.

Find out more about:

* [technology for services](service-manual_technology.md)
* [service assessments](service-manual_service-assessments.md)

10. Test the end-to-end service
-------------------------------

You must test the end-to-end service to meet point 10 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 10 improves your service

Testing the end-to-end service allows you to find problems and check that the service will work for the number of people who want to use it.

This means you’re more likely to build something which works for your users.

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to show that you:

* have an [effective deployment environment](service-manual_making-software_deployment.html#repeatable-auditable-deployments.md)
* can create new environments quickly and easily
* know the data that exists in your pre-production environments
* are designing and testing your service to work with the devices and browsers your users use - [find out the browsers you must test with](service-manual_technology_designing-for-different-browsers-and-devices#test-for-compatibility.md)
* are testing your service in an environment that’s as similar to live as possible
* know that your service can keep working when the number of expected users try to use it, including for users who need assisted digital support
* understand the systems you need and the testing environments for non-digital parts of the service
* are testing your service frequently - you’ll have to explain how you’ve decided how often to test

### Explain your service’s evolution

At each phase you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you test the end-to-end service:

* [Quality assurance: testing your service regularly](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [Designing for different browsers and devices](service-manual_technology_designing-for-different-browsers-and-devices.md)
* [Performance testing](service-manual_technology_test-your-services-performance.md)
* [Exploratory testing](service-manual_technology_exploratory-testing.md)
* [Deployment environments](service-manual_making-software_deployment.html.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)

Find out more about:

* [technology for services](service-manual_technology.md)
* [service assessments](service-manual_service-assessments.md)

11. Make a plan for being offline
---------------------------------

You must make a plan for your service going offline, to meet point 11 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 11 improves your service

Users may expect that an online service is available 24 hours a day, 365 days a year.

You need to have a plan for what to do if your service goes offline so that you know how users will be affected and how to get it back online.

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass the alpha assessment you need to be able to explain how users would be affected if your service was unavailable for any length of time.

### How you’ll be assessed at beta

To pass you usually need to explain:

* how users of the beta service would be affected if the service was unavailable for any length of time
* how you’re selecting technology and platforms that meet your availability requirements
* your data recovery strategy and how you’ve tested it
* the most likely causes for the service going offline and how you plan to stop them from happening
* your strategy for dealing with outages, including who’s responsible and the decisions they can make

### How you’ll be assessed at live

To pass you usually need to explain:

* how users would be affected if your service was unavailable for any length of time and how that’s changed since beta
* how you’re making sure the technology and platforms you’ve selected still meet your availability requirements
* your data recovery strategy and how often you’re testing it
* the most likely ways the service could go offline and how you plan to stop them
* your strategy for dealing with outages, including who’s responsible and the decisions they can make

### Explain your service’s evolution

At each phase you should explain how your service has evolved since its last assessment.

### Related guides

Read about [keeping your service online](service-manual_technology_uptime-and-availability-keeping-your-service-online.md) to help you pass point 11.

Find out more about:

* [technology for services](service-manual_technology.md)
* [service assessments](service-manual_service-assessments.md)

12. Make sure users succeed first time
--------------------------------------

You must create a service that users find easy to use to meet point 12 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 12 improves your service

All users should be able to complete the task your service provides the first time they try, as quickly and easily as possible.

This includes [disabled users](https://www.gov.uk/service-manual/helping-people-to-use-your-service/making-your-service-accessible-an-introduction) or those who need [assisted digital support](https://www.gov.uk/service-manual/helping-people-to-use-your-service/assisted-digital-support-introduction).

If users find it difficult to complete the task the first time, they may avoid using your service or contact your organisation to get help.

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to:

* explain your service and what it does
* show the majority of users of your service are succeeding the first time they try to use it
* explain how you used research, testing and analytics to make substantial iterations to your service, including the assisted digital support model
* explain all end-to-end user journeys, including assisted digital journeys, demonstrate that they work and how you tested them
* explain the design options you’re considering for your assisted digital support
* explain how you’ve designed your assisted digital support model to meet user needs and how you’re providing it - if you’re not providing it by telephone, face-to-face, talk through and on-behalf-of, you must explain why
* explain how your assisted digital support will be sustainably funded and free to users

At the beta and live assessments you also need to:

* show your service is accessible
* explain how you’ve done usability testing, including users with the lowest level of digital skills
* explain what you learned by testing your assisted digital support model
* explain how you made design and content decisions based on user research, usability testing and analytics
* discuss how many rounds of usability testing you’ve done, the users you included, the tasks you set, and the materials you gave them to complete the task
* explain how you’ve changed the interface design in response to usability testing, showing your build, measure, and learn cycles, the hypotheses you tested, what happened and how you reacted

You also need to:

* show how most people can get through the service end-to-end without assistance
* explain how you’ve tested your assisted digital support model (the way you plan to help people who lack the skills, confidence or internet access to complete the service on their own)
* discuss whether your usability testing included the supporting content and proposed start page for the service
* explain how you tested whether the name of your service makes sense to your users
* how you’ve used analytics and user research to reduce dropout rates for your digital service

### Explain your service’s evolution

At each phase you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you create a service that’s simple:

* [How user research improves service design](service-manual_user-research_how-user-research-improves-service-design.md)
* [Start by learning user needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Understanding users who do not use digital services](service-manual_user-research_understanding-users-who-dont-use-digital-services.md)
* [Assisted digital support: an introduction](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)
* [Making your service accessible: an introduction](https://www.gov.uk/service-manual/helping-people-to-use-your-service/making-your-service-accessible-an-introduction)

Find out more about:

* [user research](service-manual_user-research.md)
* [service assessments](service-manual_service-assessments.md)

13. Make the user experience consistent with GOV.UK
---------------------------------------------------

You must make the user experience consistent with GOV.UK to meet point 13 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 13 improves your service

Using the same language and design patterns as the rest of GOV.UK means:

* users trust GOV.UK services because they recognise the style
* you do not have to build something entirely new so you save time and can focus on unique parts of your service
* you’re using patterns and style which are based on data and user research

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass your alpha, beta, and live assessments you usually need to:

* explain how your team has included designers, content designers and frontend developers
* explain how the service has used the styles, components and patterns in the [GOV.UK Design System](https://design-system.service.gov.uk/) or the GOV.UK frontend toolkit and elements

To pass the beta and live assessments you also need to show:

* the service is responsive and works on mobile devices
* the headers and footers match the GOV.UK style
* you’ve got a start and end page on GOV.UK and that both are optimised for users

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### GOV.UK Design System and style guide

Use these tools to make the user experience consistent with GOV.UK:

* [GOV.UK Design System](https://design-system.service.gov.uk/)
* [GOV.UK style guide](/guidance/style-guide/a-to-z-of-gov-uk-style)

### Related guides

Find out more about:

* [service assessments](service-manual_service-assessments.md)
* [design](service-manual_design.md)

14. Encourage everyone to use the digital service
-------------------------------------------------

You must encourage everyone to use the digital service to meet point 14 of the Digital Service Standard.

You’ll have to explain how you’ve done this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 14 improves your service

Encouraging people to use your digital service allows you to:

* save money by reducing the number of people using non-digital channels, eg call centres
* help your users to develop their digital skills
* give better assisted digital support to those who cannot use digital services on their own

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

### How you’ll be assessed at alpha

To pass, you usually need to talk about:

* your plan for increasing digital take-up
* the other channels your service is delivered through
* the data you collect on your other channels
* how you collect data on service usage for each channel
* the organisations and groups that help your user with the existing digital or non-digital services
* insights from research with real users, user demographics, attitudes, behaviours and channel preferences, and user journey maps
* how each channel meets different users’ needs
* how you’ve designed the digital service in a way that gives it clear advantages over other channels

### How you’ll be assessed at beta

To pass, you usually need to:

* explain how you plan to increase digital take-up during beta
* show the evidence behind your plans for increasing digital take-up
* show weekly analytics or metrics for usage volumes across channels
* show how you’ve improved the way you communicate with users based on user insight
* discuss analytics data that shows how your new ways of communicating have performed
* explain how you’re planning to promote digital take-up

### How you’ll be assessed at live

To pass you usually need to explain:

* your plan for moving users to the digital service including yearly targets for increasing digital take-up for the next 5 years
* your plan to phase out non-digital channels as digital take-up increases in the next 5 years
* the evidence behind your plans for increasing digital take-up and phasing out non-digital channels
* usage volumes (and trends) per channel

### Explain your service’s evolution

At each phase you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you encourage everyone to use your digital service:

* [How to measure digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Encouraging people to use your digital service](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md)

Find out more about:

* [helping people to use your service](service-manual_helping-people-to-use-your-service.md)
* [service assessments](service-manual_service-assessments.md)

15. Collect performance data
----------------------------

You must collect performance data to meet point 15 of the Digital Service Standard.

You’ll have to explain how you did this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 15 improves your service

Collecting performance data means you can continuously improve your service by:

* learning its strengths and weaknesses
* using the data to support improvements you make

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to:

* explain how you decided the data you need to capture, where you need to capture it from and how you’ll capture it based on the projected size and shape of the service
* show you have an ongoing roadmap for performance analysis and someone in the team responsible for identifying actionable data insights during alpha, including assisted digital support
* show you’ve used qualitative and quantitative data to help improve your understanding of user needs and identify areas for improvement
* explain how you’ve chosen suitable data analysis tools
* show you’ve addressed information security and privacy issues appropriately
* explain how you’ve mapped user journeys through the service and tracked them to identify completions and areas of poor performance
* show how you’re measuring assisted digital support
* explain the next user story related to performance analysis
* show you’ve discussed a start page and feedback page with GOV.UK (beta assessment only)

To pass the beta and live assessments you usually need to show how you’ll collect feedback from users, during and after their user journey.

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you collect performance data:

* [Using data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Sharing data on the Performance Platform](service-manual_measuring-success_sharing-your-data-with-the-performance-platform.md)

Find out more about [service assessments](service-manual_service-assessments.md).

16. Identify performance indicators
-----------------------------------

You must identify performance indicators to meet point 16 of the Digital Service Standard.

You’ll have to explain how you did this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 16 improves your service

Setting performance indicators allows you to continuously improve your service by:

* learning its strengths and weaknesses
* using data to support improvements you make

### How you’ll be assessed

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

To pass the alpha, beta and live assessments, you usually need to explain:

* how you’ve set a performance baseline for the old service, if there was one
* your plan to lower [cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md) or equivalent, for non-transactional user journeys
* your plan to [improve user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* your plan to [increase completion rate](service-manual_measuring-success_measuring-completion-rate.md) or equivalent, for non-transactional user journeys
* your plan to [increase digital take-up](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md) and reduce reliance on assisted digital

You also need to explain:

* how you’ve assessed the potential for channel shift and the level of assisted digital your service needs
* other metrics that you’ll measure, when you’ll start, and how you’ll use them to improve your service
* where you’re getting the data for your metrics
* how you’ve set up your analytics package to collect user journey data
* how you’ve made sure all stakeholders are actively involved in promoting or supporting digital delivery of the new service
* how you’ll track people moving from using the offline service to the online one (beta assessment only)

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you identify performance indicators:

* [Using data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Sharing data on the Performance Platform](service-manual_measuring-success_sharing-your-data-with-the-performance-platform.md)

Find out more about:

* [measuring success](service-manual_measuring-success.md)
* [service assessments](service-manual_service-assessments.md)

17. Report performance data on the Performance Platform
-------------------------------------------------------

You must report your performance data to meet point 17 of the Digital Service Standard.

You’ll have to explain how you did this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### How point 17 improves your service

The Performance Platform collects your service’s data and presents it in a consistent, structured and easily digestible format - this helps you to:

* make quick, data-driven decisions about how to improve your service
* compare data across multiple government services
* be open and transparent to the public about your service’s performance

Your assessment and the questions the assessors ask you will vary depending on your service and what it does.

At each phase you should explain how your service has evolved since its last assessment.

### How you’ll be assessed at alpha

To pass you usually need to show you’ve:

* registered your service with the Performance Platform
* checked that it can support the metrics you want to present on your dashboard

### How you’ll be assessed at beta

To pass you usually need to show:

* your beta dashboard with baseline data, explain your audience for beta and describe how you’ve been using the dashboard during beta
* the metrics that are uploading to the Performance Platform and whether they’re being uploaded manually or automatically
* your published performance dashboard

### How you’ll be assessed at live

To pass, you usually need to:

* show your published Performance Platform dashboard, including metrics for the 4 key performance indicators (KPIs), and other metrics
* explain what your other key metrics are and why you’ve chosen them

### Explain your service’s evolution

At each phase, you should explain how your service has evolved since its last assessment.

### Related guides

Read these guides to help you report data on the Performance Platform:

* [Using data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Sharing data on the Performance Platform](service-manual_measuring-success_sharing-your-data-with-the-performance-platform.md)

Find out more about:

* [measuring success](service-manual_measuring-success.md)
* [service assessments](service-manual_service-assessments.md)

18. Test with the minister
--------------------------

You must test your service with the minister to meet point 18 of the Digital Service Standard.

You’ll have to explain how you did this at your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### Why you must test with the minister

Ministers are accountable for everything produced by their departments, so you need to show them your service before it goes live.

### How you’ll be assessed at alpha

To pass the alpha assessment, you need to confirm that the minister responsible for the service will test it before it goes live.

### How you’ll be assessed at beta

To pass the beta assessment you need to explain how you’ll test the service with the minister responsible for it.

### How you’ll be assessed at live

To pass the live assessment, you need to show evidence (a video, photos or a signed letter) that the minister responsible for the service has tested the full service from beginning to end, including any legacy or offline parts.

### Related guides

Find out more about [service assessments](service-manual_service-assessments.md).

Updates to this page
--------------------

Published 8 May 2019

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---