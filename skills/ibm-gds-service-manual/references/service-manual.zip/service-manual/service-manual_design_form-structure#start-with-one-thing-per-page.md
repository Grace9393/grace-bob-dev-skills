Structuring forms - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Structuring forms
=================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Design your forms for the format they'll appear in](#design-your-forms-for-the-format-theyll-appear-in)
2. [Know why you’re asking every question](#know-why-youre-asking-every-question)
3. [Design for the most common scenarios first](#design-for-the-most-common-scenarios-first)
4. [Start with one thing per page](#start-with-one-thing-per-page)
5. [Structure your form to help users](#structure-your-form-to-help-users)
6. [Further reading](#further-reading)
7. [Related guides](#related-guides)

This guide explains how to structure online forms.

Design your forms for the format they’ll appear in
--------------------------------------------------

Paper forms and digital forms have different strengths and weaknesses. Design for both formats with the same amount of care and attention.

The movement from paper to digital is an opportunity to transform how your service is delivered - don’t just put your paper forms online.

Know why you’re asking every question
-------------------------------------

Before you start, make a list of all the information you need from your users.

Only add a question if you know:

* that you need the information to deliver the service
* why you need the information
* what you’ll do with it
* which users need to give you the information
* how you’ll check the information is accurate
* how to keep the information up to date and secure

This list is called a ‘question protocol’ - it’s different from the form itself because it’s about how you’ll use the answers.

A question protocol forces you (and your organisation) to question why you’re asking users for each item of information. It gives you a way of challenging and pushing back against unnecessary questions if you need to.

Once you’ve worked out what you need to ask, you can start thinking about [how to ask the questions](service-manual_design_designing-good-questions.md).

Design for the most common scenarios first
------------------------------------------

Once you have a question protocol, you can start to decide how to order your questions.

Start with questions that will let users know if they’re not eligible for the service, so you don’t waste people’s time.

Use ‘branching’ questions so people only have to answer questions that are relevant to them.

You need to decide which group of users you want to prioritise. Make sure you know the relative size of your different user groups and how your decisions will affect them.

Start with one thing per page
-----------------------------

Start by splitting the form across multiple pages with each page containing just one thing, for example:

* one piece of information you’re telling a user
* one decision they have to make
* one question they have to answer

User research will tell you when you can merge pages together. For example, if you’re designing an internal [service for government users](service-manual_design_services-for-government-users.md) who need to repeat and switch between tasks quickly.

Starting with one thing on a page helps people to:

* understand what you’re asking them to do
* focus on the specific question and its answer
* find their way through an unfamiliar process
* use the service on a mobile device
* recover easily from form errors

It also helps you to:

* save a user’s answers automatically as they go
* capture analytics about each question
* handle branching questions and loops

Try the [Register to vote](/register-to-vote) service on GOV.UK to see an example of this approach.

Structure your form to help users
---------------------------------

Asking a question doesn’t necessarily mean you should use one form field. For example, date of birth is best captured with 3 text fields.

For page titles you can use either a question or a statement. For example, ‘What is your date of birth?’ or just ‘Date of birth’.

Use questions or statements consistently to help users get into a rhythm of answering. This lets them focus on the content of the questions rather than their presentation.

Further reading
---------------

[Learn more about using a question protocol](http://www.uxmatters.com/mt/archives/2010/06/the-question-protocol-how-to-make-sure-every-form-field-is-necessary.php).

[Find out whether you can use the GOV.UK Forms platform](https://www.gov.uk/forms) to create a form interface without needing to know any code.

Read blog posts about:

* [how the ‘Register to vote’ service used forms](https://designnotes.blog.gov.uk/2014/07/14/things-we-learnt-designing-register-to-vote)
* [how the US healthcare service ordered complex eligibility questions](https://blog.navapbc.com/structuring-a-complex-eligibility-form-for-healthcare-gov-37d79a5ad6)

You can use the [Check a service is suitable](https://design-system.service.gov.uk/patterns/check-a-service-is-suitable/) design pattern to ask users questions to help them work out if they can or should use your service.

Related guides
--------------

You may also find these guides useful:

* [Using, adapting and creating patterns](service-manual_design_using-adapting-and-creating-patterns.md)
* [Making your service look like GOV.UK](service-manual_design_making-your-service-look-like-govuk.md)
* [Making prototypes](service-manual_design_making-prototypes.md)
* [Designing how GOV.UK content and transactions work together](https://www.gov.uk/service-manual/design/govuk-content-transactions)

Updates to this page
--------------------

Published 7 December 2016

Last updated 7 August 2018
[+ show all updates](#full-history)

1. 7 August 2018

   Added links to the Check a service is suitable design pattern and a blog post about the US healthcare service
2. 7 December 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---