Choosing technology: an introduction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Choosing technology: an introduction
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Following the Technology Code of Practice](#following-the-technology-code-of-practice)
2. [What to consider when choosing technology](#what-to-consider-when-choosing-technology)
3. [How to make decisions about technology](#how-to-make-decisions-about-technology)

Choosing technology is often the most significant area of investment you’ll make when developing or maintaining your service.

Your choice of technologies has a huge impact on the quality of your service and your team’s ability to operate and iterate it.

Following the Technology Code of Practice
-----------------------------------------

You must follow the [Technology Code of Practice](/government/publications/technology-code-of-practice/technology-code-of-practice) when choosing technology.

What to consider when choosing technology
-----------------------------------------

When choosing technology, the most important thing is to make choices that allow you to:

* change your mind at a later stage
* adapt your technology as your understanding of how to meet user needs changes
* make effective security risk management decisions

You and your team should also try to:

* keep up to date with the latest technology developments so you can choose the best tools for your service
* minimise the total cost of ownership, including reducing the chance of getting locked in to long contracts for specific tools and providers
* use [standard government technology components](https://www.gov.uk/service-toolkit#components) where possible
* use software that other departments have built, and make it easy to use software that you build - read the [Application programming interfaces (APIs)](https://www.gov.uk/service-manual/technology/application-programming-interfaces-apis) guide to find out more
* make sure you always have full control of any data you store
* be aware of any relevant [cyber security obligations](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/understanding-cyber-security-obligations/)

How to make decisions about technology
--------------------------------------

Every service is different, and many of the decisions you make about technology will be unique to your service.

Follow these steps to help you make good decisions for your service’s technology:

* understand the landscape
* explore the opportunities
* start with prototypes
* make and maintain a map
* allow for evolution

### Understand the landscape

No service exists in a vacuum. You need to understand the technology context you’re working in.

You should consider:

* existing technology systems and data sources that your service may need to work with, whether they’re changing and how, for example, your department might be replacing any legacy systems
* the reasons why previous technology decisions were made, for example some departments have preferred programming languages or databases
* where to look for available tools: even if you don’t yet know what you need it’s worth knowing where to look for existing components
* potential security threats and how to mitigate them

Learn more about [the role of a technical architect in discovery](https://gdstechnology.blog.gov.uk/2016/02/08/the-role-of-an-architect-in-discovery/) and [how to include security within your business case](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/considering-security-within-the-business-case/).

### Explore the opportunities

You should have people in your team who have the knowledge to explore whether changes in technology are changing the constraints.

For example, you can investigate:

* [artificial intelligence](https://www.gov.uk/government/collections/artificial-intelligence-resources-for-the-public-sector) (AI) to see if it could analyse user enquiries
* cloud technologies to see if they allow you to find simpler ways to make your service robust

You need to check if new techniques and standards remove constraints or open up new ways of thinking about the problem.

Use this knowledge to inform conversations about how to design your service and help you test whether your approach is sufficiently adaptable.

If a new technique isn’t ready for you to use but would let you meet user needs better in the future, consider how you can make it easier to integrate at a later stage.

Learn more by reading:

* [Learning through prototyping](https://dwpdigital.blog.gov.uk/2016/02/19/learning-through-prototyping-tools-for-universal-credit-claimants/): a Department for Work and Pensions (DWP) blog about their Universal Credit service
* [Managing third-party product security risks](https://www.security.gov.uk/guidance/secure-by-design/activities/managing-third-party-product-security-risks): part of the cross-government Secure by Design approach
* [The AI Playbook](https://www.gov.uk/government/publications/ai-playbook-for-the-uk-government): how to select, buy and deploy AI in government

### Start with prototypes

Start testing what it’ll take to meet your users’ needs as soon as you can.

During the discovery and alpha phases you should use prototypes to:

* help you test your emerging understanding of user needs
* explore assumptions about technologies that could improve your service and check if the technologies are secure and ready to use
* establish the type of data you’ll be collecting and what compliance requirements there are for managing it
* make sure that interfaces with other systems work as you expect and that the process and all technical constraints are clear
* develop a map of the likely primary components of your service

It can be tempting to break services into separate components very early on, but it’s very easy to get the boundaries between those components wrong.

Use your prototyping to get an early understanding of components, but always be prepared to re-evaluate decisions as you go along.

### Make and maintain a map

Once you understand the landscape, the opportunities and what you need to do, you should start mapping out the components.

You can use techniques like [Wardley mapping](https://governmenttechnology.blog.gov.uk/2014/04/16/guest-post-mapping-the-way-to-a-strategy/) to learn what you’ll need to build and what you can buy or get for free.

Your map will:

* help you to understand your architecture, particularly the parts of your system that are mature enough to treat as stable, and those which will change frequently
* allow you to minimise the number of long-term decisions you’ll have to make
* give you an idea of where security vulnerabilities may exist

Even if you don’t have a great understanding of the components of your architecture, it’s good to sketch out what you know as this will help you prioritise more exploration.

You should keep updating your map and using it as part of your planning and prioritisation.

### Allow for evolution

As your service develops, you’ll get a better understanding of:

* your users and their needs
* the systems you need to integrate with
* the best way to structure any software you’re building
* the nature of security threats you may be facing

Give your team space to make changes and talk to them regularly to decide the right time to make structural improvements.

If they’re available you should [use open standards](service-manual_technology_working-with-open-standards.md) to manage the interfaces between parts of your system. Using open standards makes it easier to make changes later.

Updates to this page
--------------------

Published 23 May 2016

Last updated 15 October 2024
[+ show all updates](#full-history)

1. 15 October 2024

   Integrated elements on working out security risk appetite, managing third-party product security risks and understanding cyber security obligations.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---