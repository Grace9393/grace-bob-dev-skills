Plan user research for your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Plan user research for your service
===================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Decide your objectives and approach](#decide-your-objectives-and-approach)
2. [Map out rounds of research](#map-out-rounds-of-research)
3. [Involve your team](#involve-your-team)
4. [Share your findings](#share-your-findings)
5. [Examples and case studies](#examples-and-case-studies)
6. [Related guides](#related-guides)

You should plan user research at the start of each development phase, and regularly update your plan as you learn more about your users.

Agreeing your objectives and the approach you want to take will help you build a service that meets the needs of your users.

Decide your objectives and approach
-----------------------------------

Work with your team to define your research objectives and decide how you’ll approach the research.

### Agree research questions

Start by running a workshop to [capture and prioritise your research questions](service-manual_user-research_capturing-research-questions.md). In the workshop be careful to turn any unfounded assumptions and opinions into research questions.

Knowing the questions you need to answer and the assumptions you need to test will help you focus on the most important things your team needs to know.

In [discovery](service-manual_user-research_user-research-in-discovery.md), your research questions are likely to be broad and evolve quickly as you learn.

They should become more specific in [later development phases](service-manual_user-research#user-research-in-the-different-design-phases.md), as you focus on particular user groups and parts of your service.

### Identify user groups

Decide who you need to research with. Depending on what you need to learn, this could include all the different users of your service, or just specific groups.

In the discovery phase for a new service, you may not have a clear idea of who your likely users will be. Research this as a priority.
As you learn about your users, you can create personas or profiles to capture and present what you’ve learned.

### Choose relevant research activities

You also need to decide which [research methods](https://www.gov.uk/service-manual/user-research#user-research-methods) to use. Your choices will depend on what you want to learn and the [development phase](service-manual_user-research#user-research-in-the-different-design-phases.md) you’re in.

Choose research activities that will provide strong evidence and reliable answers to your questions, for the least time, effort and cost.

If the team does not have much experience with user research, prefer simple methods like interviews and usability testing that the team can easily understand and join in with.

You’ll also need to consider what you need to do to access funding and how long it might take to arrange. Speak to your budget holder to find out more - this may be your delivery, product or service owner.

### Decide your recruitment approach

There are different ways to [recruit participants for user research](https://www.gov.uk/service-manual/user-research/find-user-research-participants). Once you know the research activities you want to do and the groups you want to research with, you can decide which recruitment methods will work best for you.

Some research methods have longer lead times than others, and some require an agreement with a supplier. Deciding your approach early on will avoid problems and delays later.

Map out rounds of research
--------------------------

Once you’ve worked out your research questions, user groups and activities, you can start [preparing ‘rounds’ of research](https://www.gov.uk/service-manual/user-research/plan-round-of-user-research). Each of these should answer specific research questions with specific user groups.

Aim to do at least one round of research every 2 weeks.

### Focus on your most important questions

Prepare just the rounds of research you need to answer your highest priority questions. You can arrange more rounds as you learn more about your users and your service.

As you prepare more rounds, make sure you stay in sync with your team’s high-level [roadmap](service-manual_agile-delivery_planning-agile.md).

Do not do lots of research that the team cannot respond to, or get left behind if they’re making quick progress.

### Work out participant numbers

The number of people you need to research with in each round will depend on the method you’re using.

You’ll usually need between 4 and 8 participants for each round using methods like [experience mapping](service-manual_user-research_creating-an-experience-map.md), [contextual research](https://www.gov.uk/service-manual/user-research/contextual-research-and-observation), [in-depth interviews](https://www.gov.uk/service-manual/user-research/using-in-depth-interviews) or [usability testing](service-manual_user-research_using-moderated-usability-testing.md).

If you need more participants to get clear findings, do more rounds rather than one big round. That way you can adjust after each round.

For methods like surveys, A/B testing and benchmarking, you will need hundreds of participants to produce clear findings.

### Be inclusive

Whenever you [recruit participants](https://www.gov.uk/service-manual/user-research/find-user-research-participants) from a user group, make sure you include a good variety of the users within that group.

If your service has a broad audience, you should include [disabled users](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md) and [people who may need support to use your service](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md) in every round of research.

This may not be possible for smaller or more specialist user groups. In this case, plan specific rounds of research to:

* look at the most significant barriers that disabled users are likely to face
* identify support needs and test your support model

### Book ahead

Procurement can take longer than you think so find out about it early. Ask your budget holder about how to access funding and any processes you need to follow when choosing or appointing suppliers or agencies.

Start booking facilities and sending briefs to suppliers as soon as you can. Do not wait until you’ve finalised your plans and [recruited research participants](service-manual_user-research_find-user-research-participants.md) or it may be too late to make arrangements.

Using [appropriate procurement frameworks](https://www.digitalmarketplace.service.gov.uk/) and call off contracts will make it easier to work with suppliers in an agile way.

Involve your team
-----------------

Record your plan in a shared document or collaboration tool. Be clear what research questions each round will aim to answer and how it will help the team make decisions.

To help members get the most from your research, involve them in:

* observing research sessions - everyone should observe at least 2 hours of research every 6 weeks
* helping with user research activities (for example, [note-taking](service-manual_user-research_taking-notes-and-recording-user-research-sessions.md), pairing on site visits, running workshops)
* [making prototypes](service-manual_design_making-prototypes.md) and other materials - like letters, leaflets or posters
* [analysing results](service-manual_user-research_analyse-a-research-session.md)

This will help your team stay focused on [user needs](https://www.gov.uk/service-manual/agile-delivery/core-principles-agile#focus-on-user-needs).

Share your findings
-------------------

Agree how to feed research findings into your team’s [agile tools and practices](https://www.gov.uk/service-manual/agile-delivery/agile-tools-techniques) (like planning and prioritisation meetings, story backlogs, and any other ways that design decisions are made).

Make sure you have space for research on your [team wall](https://www.gov.uk/service-manual/agile-delivery/team-wall). Use it to highlight questions the team is exploring and share information about your research activities and findings.

Store your research findings and other research outputs in your team’s collaboration tool or shared folders so it’s easy for everyone to use and share them.

You should also make sure you have regular opportunities at show and tells and other events to [share research findings](https://www.gov.uk/service-manual/user-research/sharing-user-research-findings) with your team and with wider stakeholders.

Examples and case studies
-------------------------

Read more about [choosing the best methods to answer research questions](https://userresearch.blog.gov.uk/2016/06/08/choosing-the-best-methods-to-answer-user-research-questions/).

Related guides
--------------

You may also find the following guides useful:

* [Plan a round of user research](https://www.gov.uk/service-manual/user-research/plan-round-of-user-research)
* [Writing user stories](https://www.gov.uk/service-manual/agile-delivery/writing-user-stories)

Updates to this page
--------------------

Published 14 March 2016

Last updated 21 September 2018
[+ show all updates](#full-history)

1. 21 September 2018

   Added section on deciding on an approach to recruiting research participants
2. 15 June 2018

   Added a line about favouring research methods that your team can understand and join in with.
3. 10 October 2017

   Added guidance on agreeing research questions, identifying participants and mapping out rounds of research.
4. 14 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---