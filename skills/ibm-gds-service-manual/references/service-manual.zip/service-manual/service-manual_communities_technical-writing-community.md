Technical writing community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Technical writing community
===========================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Training, events, and recruitment](#training-events-and-recruitment)
3. [Keep in touch](#keep-in-touch)
4. [Resources](#resources)

Technical writing community
===========================

Technical writing helps turn technical concepts into clear, concise and useful information. We write technical documentation and guidance to help technologists use products and services.

The technical writing community exists to:

* help government understand how user-centred technical content can contribute to building and delivering better public services
* define standards and best practice guidelines for technical content
* build capability and skills within the profession

Who the community is for
------------------------

You do not need to be a technical writer to join. You might be interested in this community if you work in the public sector and you:

* are a technical writer
* are a content designer
* write for technologists
* work with technical writers
* want to know more about technical writing

Training, events, and recruitment
---------------------------------

Currently, we’re not able to offer these due to capacity limitations.

Keep in touch
-------------

You can get in touch with us for informal, ad-hoc advice for technical writing challenges. Contact the technical writing community on:

* the [#technical-writing channel on the cross-government Slack](https://ukgovernmentdigital.slack.com/archives/C1ZM2T0SG) - you can create an account using your government email address
* [technical-writers@digital.cabinet-office.gov.uk](mailto:technical-writers@digital.cabinet-office.gov.uk)

Resources
---------

Articles, courses, training and communities for people who do technical writing, or are interested in learning about technical writing.

### What technical writers do and how we work

* [What it’s like being a tech writer at the Government Digital Service (GDS)](https://digitalpeople.blog.gov.uk/2019/10/09/what-its-like-being-a-technical-writer-at-gds/)
* [The Product is Docs](https://www.splunk.com/en_us/blog/splunklife/the-product-is-docs.html)
* [Why the dev should not write the docs (and how they can help anyway)](https://www.linkedin.com/pulse/why-dev-shouldnt-write-docs-how-can-help-anyway-erin-grace)
* [How we use pair writing - GDS blog](https://gds.blog.gov.uk/2016/09/21/it-takes-2-how-we-use-pair-writing/)
* Email the technical writing team at [technical-writers@digital.cabinet-office.gov.uk](https://www.gov.uk/service-manual/communities/technical-writers@digital.cabinet-office.gov.uk) about attending a group content review (‘crit’), show and tell or weekly meeting

### How we write

#### GOV.UK style and content principles

* [Content design: planning, writing and managing content](https://www.gov.uk/guidance/content-design/writing-for-gov-uk)
* [Introduction to content design course](https://www.futurelearn.com/courses/introduction-to-content-design)
* [Clarity is king - GDS blog](https://gds.blog.gov.uk/2014/02/17/guest-post-clarity-is-king-the-evidence-that-reveals-the-desperate-need-to-re-think-the-way-we-write/)
* [GOV. UK style guide](https://www.gov.uk/guidance/style-guide/a-to-z-of-gov-uk-style)

#### Writing for technologists

* [Documenting APIs](https://www.gov.uk/guidance/how-to-document-apis) and [Writing API reference documentation](https://www.gov.uk/guidance/writing-api-reference-documentation)
* [Google’s technical writing courses](https://developers.google.com/tech-writing/)
* [Documenting APIs: a guide for technical writers and engineers](https://idratherbewriting.com/learnapidoc/)
* [Building navigation for your doc site: 5 best practices](https://www.writethedocs.org/videos/na/2017/building-navigation-for-your-doc-site-5-best-practices-tom-johnson/)

#### Writing accessible content

* Examples of [improving link accessibility](https://github.com/alphagov/pay-tech-docs/pull/370) and [improving image accessibility](https://github.com/alphagov/pay-tech-docs/pull/377) from GOV.UK Pay tech docs

### Tools and techniques we use

#### Docs as code

* [Why we use a ‘docs as code’ approach for technical documentation - Technology blog](https://technology.blog.gov.uk/2017/08/25/why-we-use-a-docs-as-code-approach-for-technical-documentation/)
* [Docs like Code](https://www.docslikecode.com/)
* [Docs as code tools](https://idratherbewriting.com/learnapidoc/pubapis_docs_as_code.html)

#### Git and GitHub for writers

* [GitHub Learning Lab](https://lab.github.com/)
* [Git and GitHub for poets](https://www.youtube.com/playlist?list=PLRqwX-V7Uu6ZF9C0YMKuns9sLDzK6zoiV)
* [Introduction to version control and Git](https://tutorials.codebar.io/version-control/introduction/tutorial.html)
* [Learn Git branching](https://learngitbranching.js.org/)

#### Measuring content performance

* [Google’s Analytics Academy](https://analytics.google.com/analytics/academy/)
* [Quicker UX research synthesis](https://uxtools.co/blog/quicker-ux-research-synthesis/)

### Writing types of content

#### GitHub

* [Learning to love release notes](https://www.writethedocs.org/videos/prague/2018/learning-to-love-release-notes-anne-edwards/)
* [A README checklist](https://github.com/ddbeck/readme-checklist/blob/main/checklist.md)

#### Error messages

* [How to write and design user-friendly error messages](https://medium.com/thinking-design/how-to-write-design-user-friendly-error-messages-87d0207bb902)

#### Blogs

* [How to write a good blog post - GDS Digital Engagement blog](https://gdsengagement.blog.gov.uk/2016/10/11/how-to-write-a-good-blog-post/)
* [How to make blog posts accessible - GDS Digital Engagement blog](https://gdsengagement.blog.gov.uk/2016/11/28/how-to-make-blog-posts-accessible/)

### Learning about APIs and API design

* [freeCodeCamp](https://www.freecodecamp.org/) has a course on APIs
* [API Handyman](https://apihandyman.io/)

### Learning about technical topics

* Sign up for [GDS’s Learn to Code sessions](https://gds.blog.gov.uk/2019/07/18/learning-to-code-at-gds/) on Ruby
* [Beginner JavaScript notes and reference](https://wesbos.com/javascript)
* [Continuous Deployment (CD) for documentation sites](https://www.docslikecode.com/learn/05-cd-for-docs/)

### Communities

* [#technical-writing on cross-government Slack](https://app.slack.com/client/T04V6EBTR/C1ZM2T0SG)
* [Write the Docs Slack](https://www.writethedocs.org/slack/)
* [Institute of Scientific and Technical Communicators (ISTC)](https://istc.org.uk/)
* [The UX Crunch](https://www.meetup.com/UXcrunch/)
* [tcworld conference](https://tcworldconference.tekom.de/)
* [Technical Communication UK (TCUK) conference](http://technicalcommunicationuk.com/)

### Newsletters and mailing lists

* [Write the Docs newsletter](https://www.writethedocs.org/newsletter/)
* [API the Docs](https://apithedocs.us6.list-manage.com/subscribe?u=5756ad9696bad5dc41c7b93f9&id=d0ce41a2f4)

### Podcasts

* [I’d Rather Be Writing podcast](https://idratherbewriting.com/category-podcasts/)
* [Cherryleaf podcast](https://www.cherryleaf.com/podcast/)
* [Write the Docs podcast](https://podcast.writethedocs.org/)

### Blogs

* [Write the Docs blog](https://www.writethedocs.org/blog/)
* [API the Docs blog](https://apithedocs.org/)

Updates to this page
--------------------

Published 29 May 2020

Last updated 22 November 2022
[+ show all updates](#full-history)

1. 22 November 2022

   Amendments to the support currently available from Technical Writing community.
2. 11 January 2022

   Added several new resources for the technical writing community.
3. 29 May 2020

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---