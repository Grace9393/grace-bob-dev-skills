Designing assisted digital support - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Accessibility and assisted digital](service-manual_helping-people-to-use-your-service.md)

Accessibility and assisted digital

Designing assisted digital support
==================================

[Give feedback about this page](/contact/govuk)

From:
:   [Assisted digital and digital take-up community](service-manual_communities_assisted-digital-and-digital-take-up-community.md)

Contents
--------

1. [Decide how to provide support](#decide-how-to-provide-support)
2. [Avoid paper](#avoid-paper)
3. [Who provides the support](#who-provides-the-support)
4. [Tell users about assisted digital support](#tell-users-about-assisted-digital-support)
5. [Providing the right support](#providing-the-right-support)
6. [Check how your support is performing](#check-how-your-support-is-performing)
7. [Related guides](#related-guides)

Helping people use online parts of your service is known as providing ‘assisted digital support’. Good assisted digital support ensures users aren’t excluded when they can’t or won’t complete tasks online.

Do research ​to [understand how users might struggle to use your service online](service-manual_user-research_understanding-users-who-dont-use-digital-services.md) before you design your assisted digital support.

Decide how to provide support
-----------------------------

You can provide assisted digital support:

* in person
* on the telephone
* via webchat

### In person

The person providing the support sits with the user and either:

* helps them use the computer themselves
* uses it on their behalf

Both user and support provider should be able to see the screen.

Ideally, users type in their own information. This helps the interaction be more trustworthy and secure, and helps the user learn digital skills and build confidence.

Your user research may show that different users need in-person support at different locations, for example:

* a convenient high street location, such as the Post Office, a charity, a library, or the offices of a social housing provider
* their own home
* their workplace
* a hospital or care home

Make sure support is provided in the place your users need it.

### On the telephone

The person providing the support guides the user through the online parts of your service over the phone. If a user cannot enter their information themselves (if, for example, they lack digital skills or have no internet access) the support provider enters it for them.

### Via webchat

The person providing the support helps the user complete the online parts of the service by talking to them over the internet. You can read more about [using chatbots and webchat tools to improve users’ experience](https://www.gov.uk/guidance/using-chatbots-and-webchat-tools) of your service.

Avoid paper
-----------

Don’t use a paper-based system, such as letters and forms. This is because paper systems generally:

* take users longer to complete and cost government more to run
* can’t easily direct the user to what they need, if they’re in the wrong place
* make errors more likely
* are harder to improve iteratively
* don’t help build the user’s digital skills and confidence

Who provides the support
------------------------

You can use existing infrastructure in your organisation like call centres or local offices. Make sure staff are able to help users overcome problems they have using your service online, including when users need staff to do something for them.

Whoever provides support, you must make sure they:

* are sustainably funded
* can handle changes in demand for support, like seasonal peaks or increases when non-digital channels are phased out
* don’t charge users for support
* use suitably trained people
* use technology and equipment that users find convenient and easy to use
* keep information about users secure and protect their privacy
* provide a user experience that’s consistent with the assisted digital support that other relevant digital government services provide
* can provide feedback on and reliable data about the support they’re providing, for example user satisfaction and completion rate
* can work with you to test and iterate the support they deliver
* can guide users easily through other government platforms where necessary

Tell users about assisted digital support
-----------------------------------------

You must make sure users who need assisted digital support know that it’s available and how to access it.

You can give users information about assisted digital support via:

* your online service - for example on a GOV.UK start page or within your transaction
* other communications - letters, emails, posters, leaflets, social media, forums, radio advertising, online advertising, third party face to face support channels

Providing the right support
---------------------------

Not all users who require support to use a digital service have the same needs. You must support each user in a way that’s right for them.

Your provider must follow these steps when a user contacts them.

1. Check the user is eligible to use the service in the first place.
2. Find out what’s stopping them from completing the service online independently. For example, if someone has internet access at home but lacks the skills or motivation to complete their task online, this could change the type of support or awareness raising that’s right for them. The support they need may change over time as they gain skills and confidence.
3. If you confirm that a user needs support, remind them what they’ll need to complete the service, for example any documentation, addresses, ID or reference numbers.

Talk to teams providing similar services about how they assess user needs and eligibility criteria for assisted digital support.

### Tailor the support to the user

Use evidence from user research to tailor your support to meet user needs. For example, make phone lines or in-person support available at times and places that work for users. Measure how long users have to wait for appointments or for calls to be answered and confirm that these times meet user needs.

### Opportunities to increase digital take-up

The support you give must also make it more likely that users can complete tasks online independently next time. For example, the prison visit booking service points users who say they are interested in improving their digital skills to training provided by UK Online Centres or Age UK.

This will help [encourage people to use your service online](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md).

Check how your support is performing
------------------------------------

You must be able to check how your service’s assisted digital support is performing across all routes, including support provided by third parties. This will help you:

* make sure your assisted digital support is working effectively
* identify areas for improvement

Related guides
--------------

You may find the following guides useful:

* [How your assisted digital support will be assessed](service-manual_helping-people-to-use-your-service_how-your-assisted-digital-support-will-be-assessed.md)
* [Encouraging people to use your digital service](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md)
* [Understanding users who don’t use digital services](service-manual_user-research_understanding-users-who-dont-use-digital-services.md)
* [Making your service accessible](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)

Updates to this page
--------------------

Published 8 April 2016

Last updated 24 July 2018
[+ show all updates](#full-history)

1. 24 July 2018

   Removed out of date procurement content.
2. 2 August 2016

   Added details of the framework teams can use to buy assisted digital support.
3. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---