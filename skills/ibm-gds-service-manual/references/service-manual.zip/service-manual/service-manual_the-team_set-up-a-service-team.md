Set up a service team at each phase - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

Set up a service team at each phase
===================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Delivery and operational roles](#delivery-and-operational-roles)
2. [The service team you need in each phase](#the-service-team-you-need-in-each-phase)
3. [Working with other teams in your organisation](#working-with-other-teams-in-your-organisation)
4. [Get help with what roles you need](#get-help-with-what-roles-you-need)
5. [Related guides](#related-guides)

To successfully build and run a digital service, your delivery team needs to be multidisciplinary and have a range of skills.

Your team must be able to work with teams from across your organisation and you may need to [work with contractors or third parties](service-manual_the-team_working-contractors-third-parties.md).

Delivery and operational roles
------------------------------

Service design is not just about creating or improving a digital service. A digital service is usually part of a wider change to how an organisation operates, for example changes to a contact centre based on a new scheme or policy coming into effect.

It’s sensible then to differentiate between:

* the service team
* collaborative work with [other teams in your organisation](#working-with-other-teams-in-your-organisation)

The service team you need in each phase
---------------------------------------

Your team’s size and the roles you need will change as you build your service. You’ll need different skills during the [different development phases](service-manual_phases.md) and be able to [identify the resources required to adopt secure practices throughout](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/identifying-security-resources/) digital delivery.

All service teams must have the skills to:

* analyse [user needs](service-manual_user-centred-design_user-needs.html.md), including accessibility and assisted digital needs, and turn these into user stories
* create [user stories](service-manual_agile-delivery_writing-user-stories.md) and prioritise them
* manage and report to stakeholders and manage dependencies on other teams
* procure services from third parties, if needed
* design, build, test and iterate software, and deploy and host the software
* ensure robust security protections for the service and the data it manages
* test with real users
* measure the performance of the service
* find ways of accrediting and handling data
* support the live running of the service (monitoring, fixing things when they break, responding to users)

### Discovery

During the [discovery phase](service-manual_agile-delivery_how-the-discovery-phase-works.md) you’ll need a team with the skills to:

* research and understand the user need for your proposed service
* be aware of other services that exist and their development plans
* start planning what your initial prototypes will explore
* consider the cyber security implications and obligations of the service

This means you should have the following roles:

* someone with [product management](service-manual_the-team_what-each-role-does-in-service-team#product-manager.md) skills (this could be a service owner but does not have to be in this phase)
* a user researcher
* a service designer

You may also find it helpful to have a:

* content designer
* developer
* performance analyst
* business analyst
* cyber security professional

You can read [a blog post about how the Department for Work and Pensions got the right people for a discovery](https://digitaltransformation.blog.gov.uk/2015/03/06/lessons-from-the-sharp-end-personal-independence-payments/).

### Alpha

If your service progresses to the [alpha phase](service-manual_agile-delivery_how-the-alpha-phase-works.md) you’ll need the skills to:

* explore ideas and build prototypes
* solve the harder potential problems on the project
* understand and mitigate cyber security risks

You must appoint a service owner during alpha.

Depending on the size and complexity of your service, you should also have the following roles in your service team by the alpha phase:

* a product manager
* a delivery manager or scrum master
* one or more user researchers
* one or more content designers
* one or more designers
* a developer
* a technical lead
* a security lead
* an assisted digital lead
* an accessibility lead

You should also have access to:

* a performance analyst
* a technical architect
* a web operations engineer
* quality assurance and testing skills
* cyber security professionals

During alpha, your team may also need [agile coaching](service-manual_the-team_agile-training-learning-and-support#agile-coaching.md) and [business analysis](service-manual_the-team_what-each-role-does-in-service-team.md) skills.

By the end of the alpha, you should have a clear idea of what your beta will be and the team you’ll need to build it.

### Beta

In the [beta phase](service-manual_agile-delivery_how-the-beta-phase-works.md), the main priority is creating a simple, clear, fast and secure service while your team works toward live operation. The team needs to have the skills to make frequent iterations based on regular user and security testing.

At this phase, you may need to [increase the size of the team](service-manual_the-team_change-size-of-service-team.md).

You may need more input from performance analysts, web operations and developers, security professionals and an increase in the number of designers and content designers.

### Live

When your service moves from beta to the [live phase](service-manual_agile-delivery_how-the-live-phase-works.md), you’ll usually have met most of your user needs, managed security risks and have less work left to do. However, you must still plan to have a sustainable, multidisciplinary team that can:

* finish building any additional features you’ve planned for your service
* manage and maintain your service
* iterate and improve your service frequently based on changes in your users’ needs or other circumstances (for example, changes to technology or other government policy or programmes)
* [evaluate the security impact of changes](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/evaluating-the-security-impact-of-changes/)
* [discover vulnerabilities](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/discovering-vulnerabilities/) and [manage security alerts](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-observability/)
* [retire service components securely](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/retiring-service-components-securely/)

This means you’ll need to plan how and when you change the size of your team and the roles in it. To work out when and how to do this, you and your team should review your service’s roadmap, release plans and product backlog.

Changes can also affect morale. Talk to your team to:

* let them know what’s happening
* discover how they feel about any changes
* find out how they want to deal with the changes

You can read [a blog post about the Carer’s Allowance service team for live operation](https://gds.blog.gov.uk/2015/11/13/carers-allowance-life-after-transformation).

Working with other teams in your organisation
---------------------------------------------

You’ll also need the skills of a wide range of people working in other teams or areas of your department or organisation, for example:

* policy and legal
* security
* contact centre operations
* communications
* procurement
* recruitment and training

You may need to change how you work when working with teams that are not using [agile delivery methods](https://www.gov.uk/service-manual/agile-delivery).

Read this [agile for non-digital projects](https://mojdigital.blog.gov.uk/2014/10/01/agile-for-non-digital-projects/) blog post to find out how you can apply agile methods to other parts of your organisation.

Get help with what roles you need
---------------------------------

If you have any questions about the roles in service teams, email the Government Digital and Data profession at: [digitalanddataprofession@digital.cabinet-office.gov.uk](mailto:digitalanddataprofession@digital.cabinet-office.gov.uk)

Related guides
--------------

You may also find the following guides useful:

* [Recruit your team](service-manual_the-team_recruit-your-team.md)
* [Create an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md)
* [What each role does on a service team](service-manual_the-team_what-each-role-does-in-service-team.md)
* [Identifying security resources](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/identifying-security-resources/)
* [Agreeing security roles and responsibilities](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/agreeing-roles-and-responsibilities/)

Updates to this page
--------------------

Published 3 March 2016

Last updated 29 January 2025
[+ show all updates](#full-history)

1. 29 January 2025

   We have clarified that a service designer should work on service teams during Discovery.
2. 22 October 2024

   Integrated guidance on Identifying security resources
3. 28 June 2024

   The content has been updated to include Business Analyst in the list of roles that may be helpful to have in the team.
4. 21 June 2021

   Added performance analyst to the roles you may need on your team at discovery.
5. 12 February 2021

   Added contact details for DDaT profession team.
6. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---