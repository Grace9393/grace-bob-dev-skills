Standards and assurance community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Standards and assurance community
=================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [Standards and assurance in the Service Manual](#standards-and-assurance-in-the-service-manual)

The standards and assurance community exists to:

* bring together people with an interest in government digital standards
* discuss and challenge government digital standards
* examine how people understand and apply digital standards to build high quality services that meet the needs of users

Who the community is for
------------------------

You might be interested in this community if your work involves:

* designing, implementing or assessing government digital or technology standards
* assessing commercial and infrastructure decisions related to digital or technology projects
* writing advice for ministers about spend controls for digital or technology projects
* assuring or submitting digital and business cases within the spending controls process

You do not have to be in a standards-related role to join.

Get involved
------------

[Join the standards and assurance community mailing list](https://groups.google.com/a/digital.cabinet-office.gov.uk/forum/?hl=en-GB#!forum/standards-and-assurance-community) to discuss issues related to government digital standards (request access using your government email address).

If you cannot access this discussion space, please email [gdsassurance@digital.cabinet-office.gov.uk](mailto:gdsassurance@digital.cabinet-office.gov.uk) for help.

Community resources
-------------------

Use these resources to learn more about government standards and assurance:

* [Service Standard](service-manual_service-standard.md)
* [All service assessments and self-certifications](https://www.gov.uk/service-standard-reports) - a list of all service assessments and self-assessments carried out to date
* [GDS blog](https://gds.blog.gov.uk/?s=service+standard) - stories and case studies about how the Service Standard has been understood and applied across government
* [Services in government blog](https://services.blog.gov.uk/) - stories from people who are transforming services all across the public sector
* [Government technology blog](https://governmenttechnology.blog.gov.uk/category/reform/) - stories about spend controls, reform and the Technology Code of Practice

Standards and assurance in the Service Manual
---------------------------------------------

These guides show what we currently believe to be best practice in standards and assurance for government services:

* [How service assessments work](service-manual_service-assessments_how-service-assessments-work.md)
* [Check if you need to get your service assessed](service-manual_service-assessments_check-if-you-need-a-service-assessment.md)
* [Spend controls: check if you need approval to spend money on a service](service-manual_agile-delivery_spend-controls-check-if-you-need-approval-to-spend-money-on-a-service.md)
* [Spend controls: apply for approval to spend money on a service](service-manual_agile-delivery_apply-for-approval-to-spend-money-on-a-service.md)
* [Working with standalone mobile apps](service-manual_technology_working-with-standalone-mobile-apps.md)
* [Get a domain name](service-manual_technology_get-a-domain-name.md)
* [Managing domain names](service-manual_technology_managing-domain-names.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link in each guide

Updates to this page
--------------------

Published 8 March 2016

Last updated 18 May 2016
[+ show all updates](#full-history)

1. 8 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---