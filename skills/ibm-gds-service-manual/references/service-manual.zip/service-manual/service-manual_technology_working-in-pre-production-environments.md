Working in pre-production environments - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Working in pre-production environments
======================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)

Contents
--------

1. [Development environments](#development-environments)
2. [Shared environments](#shared-environments)
3. [The staging environment](#the-staging-environment)
4. [Example: GOV.UK pre-production environments](#example-govuk-pre-production-environments)
5. [Related guides](#related-guides)

Pre-production environments are where your team builds and tests software for the digital service.

Your pre-production environments will most likely include:

* one or more development environments where your developers can build and experiment with new software
* an integration environment where you can combine all the code from your development environments and see if it works as intended
* a staging environment where you can do most of your testing in an environment that closely mimics the live site (or ‘production environment’)

Development environments
------------------------

Set up your development environment so that your developers can:

* experiment quickly with new approaches
* develop software rapidly and iteratively in a production-like architecture
* write automated tests for their code (these will run when the code is committed to the integration environment)

Shared environments
-------------------

Every member of a service team must have access to a shared environment (integration or staging) where they can see the current state of the entire service and check development progress.

The staging environment
-----------------------

Before you deploy any software to a live environment, you must test it thoroughly in a staging environment that replicates the production environment as closely as possible.

This is where you can do:

* [quality assurance testing](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [exploratory testing](service-manual_technology_exploratory-testing.md)
* [vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* [testing on your service’s performance](service-manual_technology_test-your-services-performance.md)

Example: GOV.UK pre-production environments
-------------------------------------------

The team working on GOV.UK uses:

* the [Vagrant tool](https://en.wikipedia.org/wiki/Vagrant_(software)) to provide all developers with a development environment that’s similar to the production environment
* an integration environment that’s updated by a continuous integration system to automatically include any code changes or updates
* a staging environment where the team can review specific changes before they go to the production environment

### Why GOV.UK does it this way

GOV.UK sets up its environments like this because:

* everyone on the team should be able to see the latest developments to the system they’re working on
* every team member should be able to understand their work in the context of how it fits into the entire service
* the team should be confident that the service as a whole works before making it available to the public

Related guides
--------------

You may also find these guides useful:

* [Choosing your technology: an introduction](service-manual_technology_choosing-technology-an-introduction.md)
* [Quality assurance: testing your service regularly](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [Exploratory testing](service-manual_technology_exploratory-testing.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* [Test your service’s performance](service-manual_technology_test-your-services-performance.md)

Updates to this page
--------------------

Published 23 May 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---