Taking notes and recording user research sessions - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Taking notes and recording user research sessions
=================================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Privacy and consent](#privacy-and-consent)
2. [Taking notes](#taking-notes)
3. [Taking photos](#taking-photos)
4. [Audio recordings](#audio-recordings)
5. [Video recordings](#video-recordings)
6. [Screen recordings](#screen-recordings)
7. [Collecting materials](#collecting-materials)
8. [Streaming research sessions to remote observers](#streaming-research-sessions-to-remote-observers)
9. [Related guides](#related-guides)

To get the most from a user research session, you need to make a detailed record of what happens. You can do this by taking notes and photos, making audio and video recordings and taking copies of things that participants use or refer to (like notes, forms, or instructions).

After a round of research you can [analyse your notes and recordings](service-manual_user-research_analyse-a-research-session.md) to produce useful findings that will help you design and deliver your service.

You can also use quotes, photos, sound and video clips to [illustrate your findings](service-manual_user-research_sharing-user-research-findings.md).

Privacy and consent
-------------------

Research notes and recordings often contain [personal data](https://ico.org.uk/for-organisations/guide-to-data-protection/guide-to-the-general-data-protection-regulation-gdpr/what-is-personal-data/what-is-personal-data/). Before you take any notes or start any recording, you must get [informed consent](service-manual_user-research_getting-users-consent-for-research.md) from all participants at the session.

When working with personal data, you must remember to:

* only use notes and recordings for what has been agreed on the consent form
* store consent forms and personal data (on paper or in digital files) securely, especially if you need to transport them
* delete any notes or recordings on your personal devices as soon as you have stored them securely
* make sure team members understand the importance of consent and privacy, and how they can use and share research data and materials
* get permission from venues if you want to video or photograph sessions outside the research lab - for example, if you want to do [contextual interviews](service-manual_user-research_contextual-research-and-observation.md) or [pop-up research](service-manual_user-research_doing-pop-up-research.md)

### Anonymous notes and recordings

If you’re dealing with a sensitive subject, you may want to keep your notes anonymous to protect the identity of participants. You will still need to get their informed consent.

During research sessions, avoid collecting any details that could reveal a participant’s identity - such as names, locations or organisations.

After your sessions, review all notes, recordings and research materials (for example, photographs and videos) to remove any personal or confidential data. Make sure other observers and note-takers do the same.

Taking notes
------------

Notes are the most common way to record what happens during a research session.

You can take brief notes yourself but always try to invite an observer who can also act as a note-taker. This will allow you to focus on the participant and means you will have at least one full set of notes.

Typed notes are the easiest to keep and analyse later. However, you’ll need a place to sit and a surface for the laptop. Pen and paper allow you to be more flexible, but take more time and effort to use later.

### What to record

Good notes stick to observations (for example, something you see or hear during a session) rather than personal interpretations.

Ask observers to look for:

* things people do - like processes, tasks, tools, problems and barriers
* how they think - including their goals, triggers, choices, reasons, knowledge and gaps
* how they feel - for example, their motivations, reactions, fears and frustrations

Taking good notes is a skill that needs to be developed so give team members lots of opportunity to practice.

### Using sticky notes

For some kinds of research (like [usability testing](service-manual_user-research_using-moderated-usability-testing.md)) experienced observers can write observations directly onto sticky notes. This saves time in later [research analysis](service-manual_user-research_analyse-a-research-session.md).

Ask observers to make notes that are:

* written clearly so they’re easy to read
* brief but clear and easy to understand
* based on a single point or observation, so they’re easy to analyse and sort
* labelled with the relevant participant and session number

You should also ask observers to use colours consistently so you can sort the notes into observations, findings and actions.

You can use this [poster with tips for observers](https://github.com/alphagov/govdesign/blob/master/Poster_UserResearchTips.pdf) to help people take notes.

Taking photos
-------------

Photos are a fast and simple way to record details about a participant and their environment. You can also use them to capture the results of workshops and other research activities.

Adding photos to your research findings helps team members and stakeholders understand:

* the variety of people who use your service
* the different places and situations they’re in
* the kinds of research activities you do

It’s good practice to confirm that you have consent each time you want to take a photo. This is especially important on visits as you may be allowed to take photos in some places and of some things, but not others.

Audio recordings
----------------

Audio recordings are good for in-depth interviews. They’re easier to make than video recordings and participants often find them less intrusive and feel less self-conscious.

User research studios and labs can usually provide audio recordings of interviews and workshops, but check before you book.

If you use your own device, laptop or smartphone, attach a microphone to get clearer recordings and make sure you record everyone who speaks.

To record telephone calls, use a conference call service or application that lets you record the call. This will also allow other participants and observers to join the call.

### Getting transcripts

You can hire a transcription service to create a text record of your interviews. This saves time and gives you searchable text with much more detail than regular notes.

Transcription is less useful for sessions that involve physical interaction, like content evaluations and usability testing.

Services typically offer different levels of transcript:

* full verbatim - this gives you all spoken sounds, including repeated words, filler words (like ‘you know’ or ‘sort of’) and non-words (like ‘um’ and ‘ah’)
* intelligent verbatim - this gives you all speech but with repeated words, filler words and unnecessary noises edited out
* summary or notes - this gives you the general meaning or theme of what’s said, but not the exact words

Different transcription services describe these levels differently, so check before you book.

It’s usually best to ask for intelligent verbatim. This provides good detail for analysis and is easier to read than full verbatim.

Once you get a transcript, add a brief description to the top of the document to help you identify it (for example, date, research aim and session number).

Video recordings
----------------

Videos provide a detailed record of research sessions and can be valuable during analysis.

You can also use video clips to illustrate your research findings. This helps teams members and stakeholders understand:

* the variety of people who use your service
* the different places and situations they’re in
* the kinds of research activities you do

User research studios and labs can usually provide video recordings of interviews and workshops, but check before you book.

If you’re doing your own video recording, make sure you can set up the camera quickly and reliably. Practice in different environments so you know how to get clear recordings.

During the research, place the camera and tripod or mount out of sight so participants don’t get distracted or feel self-conscious. You should also avoid moving or adjusting the camera during the session.

Videoing someone outside of the lab (for example, at home or at work) can feel intrusive or raise security concerns. Think carefully about how you will manage the recording to avoid this.

Screen recordings
-----------------

Screen recordings help you review how users navigate a site, interpret content or interact with a transaction. They’re most useful when you’re doing [usability testing](service-manual_user-research_using-moderated-usability-testing.md) on prototypes or the service you’ve built.

User research studios and labs can usually provide you with recordings of screen activity. They should also be able to combine these with audio and video recordings of the participant, but check before you book.

You can also record usability tests yourself by using an application that captures what appears on the screen (for example, researchers at GDS often use [Silverback](https://silverbackapp.com/) or [Camtasia](https://www.techsmith.com/video-editor.html)). These capture mouse clicks and taps, and often use the camera and microphone to record what the participant is doing and saying.

If a participant is using their own device, you can:

* connect a device to the participant’s video output and use recording software to record from it
* use a kit that attaches a small camera to their device and record from that
* mount a camera on a small tripod or flexible bracket and arrange the camera to record the screen

If a participant uses a screen reader or has an interpreter, make sure you record them too.

### Recording video calls

For a [remote research session](https://www.gov.uk/service-manual/user-research/remote-user-research-phone-video-call) you can use a video call service to view and record the participant’s screen.

To record the test, you can either:

* use a video call service that supports recording
* record the video and sound on your computer with an app like QuickTime

Make sure participants have set up and tested the video call service you want to use before your session begins. You should also know how to fix common problems so you don’t waste time getting the screen-sharing to work.

### Eyetracking

Some user research labs have eyetracking equipment that shows where on the screen a participant is looking. This usually appears as lines and dots in screen recordings that represent how the participant’s eyes move around the screen.

Eyetracking is useful when you’re trying to solve a usability problem. Seeing a participant’s unconscious gaze shows you:

* what content or parts of a page they do and don’t pay attention too
* how long they spend looking at different things
* how their attention moves between items

Analysing this can help you understand why people are having a problem using your service, and whether it’s because they aren’t seeing or understanding something.

Eyetracking can influence usability sessions as participants need to sit still and face the screen. It also excludes some participants, for example people with visual impairments, varifocal glasses or age-related eye conditions. This means you should only use eyetracking to help you solve usability issues related to what people are looking at (or missing).

Collecting materials
--------------------

During analysis, it’s often useful to have an example of anything that a participant used or referred to during the session (for example, a form they’ve submitted or document they had to provide).

You can collect originals, take photos, make photocopies, print examples or ask the participant to send you copies by email or post.

Always check that you have consent before you touch or copy materials. You should also make sure that anything personal or confidential is stored securely so you can transport it safely.

Streaming research sessions to remote observers
-----------------------------------------------

When you’re doing research away from your office, it can be useful to stream sound and pictures to another location so that more of your team can observe the research and take notes.

If you’ve got a suitably secure channel, you can stream sound and pictures back to a meeting room at your office.

Avoid streaming research sessions to colleagues at home, or to staff of partner or supplier organisations. This can put participant privacy at risk, as you can’t control who’s observing or recording.

Related guides
--------------

You may also find these guides useful:

* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Analyse a research session](https://www.gov.uk/service-manual/user-research/analyse-a-research-session)
* [Using in-depth interviews](service-manual_user-research_using-in-depth-interviews.md)
* [Contextual research and observation](service-manual_user-research_contextual-research-and-observation.md)

Updates to this page
--------------------

Published 1 September 2017

Last updated 19 September 2017
[+ show all updates](#full-history)

1. 19 September 2017

   Clarified guidance on anonymising research data to protect the identity of participants.
2. 1 September 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---