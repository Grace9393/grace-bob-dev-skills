Running your service in a sustainable way - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Running your service in a sustainable way
=========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Go beyond essential maintenance](#go-beyond-essential-maintenance)
2. [Budget for uncertainty](#budget-for-uncertainty)
3. [Deciding where to focus](#deciding-where-to-focus)

Your service should be backed by a plan and budget that allows for continuous large and small improvements throughout its lifetime.

Making improvements can mean:

* carrying out user research to better understand what users need for the service
* responding to technical problems and changes in user behaviour
* making the service simpler to use or more cost effective to run
* adding new features - for example, the Carer’s Allowance service [worked with operations colleagues to speed up processing of claims](https://dwpdigital.blog.gov.uk/2016/07/08/a-live-service-is-not-the-end-of-the-story/)
* supporting the service as it’s used more widely - for example by expanding [user support](https://www.gov.uk/service-manual/helping-people-to-use-your-service/set-up-and-manage-user-support) or training operations colleagues so they can help people to use the service

Go beyond essential maintenance
-------------------------------

Operating a service means doing more than basic things like fixing bugs in code, upgrading software, fixing security vulnerabilities and keeping call centre scripts up to date. If you only respond to issues as they arise, you risk building up technical debt and leave yourself open to emerging security threats. And your service [may stop meeting user needs](https://18f.gsa.gov/2016/02/23/software-maintenance-is-an-anti-pattern/).

You’ll need to do continuous improvement. This will allow you to respond to changes in user needs, technology or government policy throughout the lifetime of your service.

Make sure services have access to [people with the skills needed to do continuous improvement](https://www.gov.uk/service-manual/the-team/set-up-a-service-team). Keep the technology [as flexible as possible](https://www.gov.uk/service-manual/technology/choosing-technology-an-introduction), so it’s easy to iterate and improve your service often.

Budget for uncertainty
----------------------

Allocate people and resources for continuous improvement in a way that lets teams focus on doing the work that has the most value. Try to avoid limiting your focus to a single transaction or a particular channel. Service teams need to be able to tackle the root cause of problems, wherever they are.

Some organisations change how they allocate people and resources to work on services once they’re in the live phase. For example, they might not have a full team working on every service for 100% of the time. If you choose to do this, it’s important that it does not stop you doing continuous improvement.

Responsibility for keeping services running should not just belong to the service team, but the whole organisation. Look for ways to maximise flexibility. For example, by agreeing a common set of languages, tools, and ways of working for technical staff - either informally, or through something more formal like [the GDS way](https://gds-way.cloudapps.digital/#content).

Deciding where to focus
-----------------------

All services will need to do continuous improvement. But the amount of work your team needs to do will depend on:

* what the service health indicators say
* whether there are external factors the service needs to respond to, such as changes in technology or government policy
* how critical the service is to users and government

Service health indicators could include:

* [performance metrics](https://www.gov.uk/service-manual/measuring-success/how-to-set-performance-metrics-for-your-service)
* analysis of [support tickets](https://userresearch.blog.gov.uk/2018/10/23/how-user-support-ticket-analysis-shapes-what-we-do-on-government-as-a-platform/) and user feedback
* [user satisfaction](https://www.gov.uk/service-manual/measuring-success/measuring-user-satisfaction)
* web analytics (for example, changes to how long it takes a website page to load, or the number of people leaving abandoning an application at a particular point)

You will not be able to do everything you want to do, so you’ll have to [decide on priorities](https://www.gov.uk/service-manual/agile-delivery/deciding-on-priorities).

Updates to this page
--------------------

Published 26 November 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---