User research in alpha - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

User research in alpha
======================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [How to do user research in alpha](#how-to-do-user-research-in-alpha)
2. [Related guides](#related-guides)

The aim of user research in the [alpha phase](service-manual_agile-delivery_how-the-alpha-phase-works.md) is to:

* improve the team’s understanding of your users and their needs
* test different design ideas and service prototypes with likely users
* learn how to build or improve your service so that it helps users achieve their goal

How to do user research in alpha
--------------------------------

You need to think about your service from end to end and consider all the ways that users interact with it (including all tools, transactions, support and offline steps).

### Who to research with

You must do research with a broad range of users, including:

* those with limited digital access and confidence
* people with a range of visual, hearing, motor and cognitive impairments

You should include people who provide the service or who support other users (for example, caseworkers, call centre agents and charity workers).

[Learn more about finding user research participants](service-manual_user-research_find-user-research-participants.md).

### Typical user research activities

You can learn more about your users and your design ideas by:

* using interviews and visits to deepen your understanding of relevant aspects of your users’ lives and work
* trying out design concepts with likely users to see how well they meet user needs
* testing interactive prototypes to explore the usability of different designs

When you’re recruiting participants with disabilities, it might not be possible to test:

* paper prototypes with users who are blind or partially sighted
* prototype code with people who use assistive technologies like screen readers or speech recognition software - you can do this in beta when you start working with production code

From these research activities, you’ll typically get:

* a better understanding of your users’ needs, including their support and access requirements
* feedback on how well your designs work for users
* helpful insight into usability issues related to layout, functionality and content

You’ll have done enough research when you’re confident that your design solutions will meet the needs of your users, including those with disabilities and support needs.

Related guides
--------------

You may also find these guides useful:

* [Start by learning user needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Running research sessions with people with disabilities](service-manual_user-research_running-research-sessions-with-people-with-disabilities.md)
* [Analyse a research session](service-manual_user-research_analyse-a-research-session.md)

Updates to this page
--------------------

Published 18 November 2016

Last updated 3 October 2017
[+ show all updates](#full-history)

1. 3 October 2017

   Clarified accessibility requirements.
2. 18 November 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---