Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

Service Manual
==============

Helping teams to create and run great public services that meet the [Service Standard](service-manual_service-standard.md).

Search the service manual

Search

[Contact the Service Manual team](service-manual_communities_contact-the-service-manual-and-service-standard-team.md)
with any comments or questions.

* [Accessibility and assisted digital](service-manual_helping-people-to-use-your-service.md)
  ------------------------------------------------------------------------------------------

  Help and encourage people to use your service: accessibility, assisted digital, user support.
* [Agile delivery](service-manual_agile-delivery.md)
  --------------------------------------------------

  How to work in an agile way: principles, tools and governance.
* [Design](service-manual_design.md)
  ----------------------------------

  Naming, structuring and scoping your service, prototyping, using design patterns and design training.
* [Measuring success](service-manual_measuring-success.md)
  --------------------------------------------------------

  How to use data to improve your service: measuring, reporting, analytics tools and techniques.
* [Service assessments and applying the Service Standard](service-manual_service-assessments.md)
  ----------------------------------------------------------------------------------------------

  How to apply the Service Standard, check if you need a service assessment, get your service on GOV.UK and become a service assessor.
* [Technology](service-manual_technology.md)
  ------------------------------------------

  Choosing technology, development, integration, hosting, testing, security and maintenance.
* [The team](service-manual_the-team.md)
  --------------------------------------

  Managing a service team: roles, recruiting the people you need, working with contractors, training.
* [User research](service-manual_user-research.md)
  ------------------------------------------------

  Understand user needs: plan research, prepare for sessions, share and analyse findings.

The Service Standard
--------------------

The [Service Standard](service-manual_service-standard.md) provides the principles of building a good service. This manual explains what teams can do to build great services that will meet the standard.

Communities of practice
-----------------------

You can view the [communities of practice](service-manual_communities.md) to find more learning resources, see who has written the guidance in the manual and connect with digital people like you from across government.

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---