Measuring and reporting progress - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Measuring and reporting progress
================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Measuring and reporting progress in agile](#measuring-and-reporting-progress-in-agile)
2. [Reporting when you have more than one team](#reporting-when-you-have-more-than-one-team)
3. [Related guides](#related-guides)

Good reporting helps senior responsible officers (SROs) and service managers make decisions and give feedback when necessary. It should show a clear view of progress without creating any extra work for the team.

Measuring and reporting progress in agile
-----------------------------------------

Measuring and reporting progress are built into agile ways of working so service teams will continuously produce the data you need. This includes:

* continuous planning - setting a vision, goals and objectives, developing a roadmap and tracking progress against them
* visual management - team walls and a backlog open to everyone
* face to face meetings - standup, show and tell, retrospectives for the team and the rest of the organisation

If you think you need extra reporting, make sure it’s really necessary and adds value. Too many reporting requirements become counterproductive as the team has less time to spend on delivery work. This is especially important for you to transition from one phase to another without the team losing momentum.

Reporting when you have more than one team
------------------------------------------

If you’re working with more than one team on a service, having some consistency in how they report means you can more effectively:

* see progress
* support service teams
* make informed decisions
* communicate with the rest of your organisation (and the public) about the service

Don’t try to force more consistency than is practical because the circumstances of each team will be different.

Related guides
--------------

The following guides have more information on governing agile teams:

* [governance principles for agile service delivery](service-manual_agile-delivery_governance-principles-for-agile-service-delivery.md)
* [planning in agile](service-manual_agile-delivery_planning-agile.md)

Updates to this page
--------------------

Published 17 February 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---