Write a recruitment brief - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Write a recruitment brief
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [What to put in your brief](#what-to-put-in-your-brief)
2. [Reviewing the screener](#reviewing-the-screener)
3. [Related guides](#related-guides)

A recruitment brief is a set of instructions sent to an agency for recruiting user research participants.

They will use this to write a ‘screener’, a script for recruiting participants.

What to put in your brief
-------------------------

You should always send the agency a written brief, even if they’re happy to take instructions over the phone. This will provide a record in case there are problems with the recruitment.

In your brief, you should cover:

* research dates, including times and length of each session
* research location - this will often be a research lab, but there may be times when you’ll need to [visit participants at their home or work](service-manual_user-research_choose-a-location-for-user-research#going-to-a-participants-work-or-home.md)
* the number of participants you want to recruit
* a description of the types of people you want to recruit (often referred to by agencies as ‘recruitment criteria’)
* incentives (you should ask the agency to handle incentives)

Make it clear that you welcome disabled people and people with limited digital skills. This is important because:

* recruiters often exclude these groups by default
* including disabled people is part of meeting [government accessibility requirements](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction#meeting-government-accessibility-requirements.md)

Reviewing the screener
----------------------

The agency will send you a screener based on the criteria you sent them. Always check this matches your needs because it’s not unusual for them to miss points you’ve included in your brief.

They can also add standard agency questions, which may exclude participants you’d like to recruit.

Related guides
--------------

You may also find the following guides useful:

* [Find research participants](service-manual_user-research_find-user-research-participants.md)
* [Plan a round of user research](service-manual_user-research_plan-user-research-for-your-service.md)
* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)

Updates to this page
--------------------

Published 15 March 2016

Last updated 31 March 2016
[+ show all updates](#full-history)

1. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---