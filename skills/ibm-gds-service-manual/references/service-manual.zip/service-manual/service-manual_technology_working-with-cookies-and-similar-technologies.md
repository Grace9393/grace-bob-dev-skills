Working with cookies and similar technologies - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Working with cookies and similar technologies
=============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [How to use cookies](#how-to-use-cookies)
2. [How to create a cookies page](#how-to-create-a-cookies-page)
3. [Where to apply cookies](#where-to-apply-cookies)
4. [Related guides](#related-guides)

Cookies are small data files that a website sends to a user’s computer. They’re used to store information about how users browse a website.

This guidance is about how to use cookies, but you should also follow it when using any other technologies that store information on a user’s device, like HTML5 local storage.

How to use cookies
------------------

Keep use of cookies to a minimum, and be transparent about the ones you do use. You must:

* use as few cookies as possible, and stop setting any cookies that are not needed anymore
* store the smallest amount of information that you need, for as short a time as necessary
* publish a cookie policy telling users about the cookies you’re using
* get users’ consent before you set any cookies that are not essential to providing the service

How to create a cookies page
----------------------------

There’s information on the GOV.UK Design System about:

* [how to create a cookies page](https://design-system.service.gov.uk/patterns/cookies-page/) including which cookies you need consent for
* [how to create a cookie banner](https://design-system.service.gov.uk/components/cookie-banner)

Where to apply cookies
----------------------

Cookies must only apply to your originating domain name. For example, www.servicename.service.gov.uk not .gov.uk.

Do not use cookies on domains that host only static assets like images or JavaScript - they slow response times for users without providing any benefit.

You should only send cookies with the Secure attribute and, when appropriate, the HttpOnly attribute. These flags provide additional assurances about how browsers should handle cookies.

Related guides
--------------

You might find the guidance on [choosing digital analytics tools](https://www.gov.uk/service-manual/measuring-success/choosing-digital-analytics-tools) useful.

Updates to this page
--------------------

Published 15 September 2016

Last updated 8 February 2021
[+ show all updates](#full-history)

1. 8 February 2021

   Removed some information about publishing your cookie policy and getting consent, providing links to where these now live in the design system. Reviewed the content to make sure it is up to date.
2. 20 December 2019

   Updated guidance on how and when to get users' consent to set cookies.
3. 15 September 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---