Making source code open and reusable - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Making source code open and reusable
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Making the code open](#making-the-code-open)
2. [Make your code open from the start](#make-your-code-open-from-the-start)
3. [How to make existing code open](#how-to-make-existing-code-open)
4. [When it’s acceptable for code to be closed source](#when-its-acceptable-for-code-to-be-closed-source)
5. [You must not store secret keys or credentials in the source code](#you-must-not-store-secret-keys-or-credentials-in-the-source-code)
6. [Making configuration code open](#making-configuration-code-open)
7. [Making code with a security-enforcing function open](#making-code-with-a-security-enforcing-function-open)
8. [Licensing your code](#licensing-your-code)
9. [Taking responsibility for open source code](#taking-responsibility-for-open-source-code)
10. [Tracking changes to your code](#tracking-changes-to-your-code)
11. [Dealing with security issues in published code](#dealing-with-security-issues-in-published-code)
12. [Related guides](#related-guides)

When you create new source code, you must make it open so that other developers (including those outside government) can:

* benefit from your work and build on it
* learn from your experiences
* find uses for your code which you had not found

Making the code open
--------------------

You should make your code publicly available in an open internet source code repository. For example, GDS’ code is on [GitHub](https://github.com/alphagov). This includes code developed for you by a third party, such as a development agency.

When publishing your code you need to make sure:

* you’re clear about who owns the code and how others can use it
* you do not release [information that should remain closed](https://www.gov.uk/government/publications/open-source-guidance/when-code-should-be-open-or-closed)
* you store it in a repository managed by your department
* any third-party tools you use to host or manage your code follow the National Cyber Security Centre’s [cloud security guidance](https://www.ncsc.gov.uk/guidance/cloud-security-collection)

Make your code open from the start
----------------------------------

It is much easier to [write your code in the open](https://gds.blog.gov.uk/2012/10/12/coding-in-the-open/) from the beginning of a project than it is to to open an existing repository later, because you can address security and other issues as you go along. If you do not do this, you will have to spend a costly period of time at the end of the project checking your code is all safe to be released.

Coding in the open from the start means you can:

* plan how you’ll avoid publishing sensitive information later in the project
* follow best practices from the beginning, for example keeping good documentation
* set in place processes that will allow you to continuously publish code as it is written
* allow others to identify parts of your code for reuse which you might not have recognised yourself
* allow others to contribute ideas as the project is in progress; for example if they know of existing tools that could help

How to make existing code open
------------------------------

When making existing code open you must review the code to check for:

* security flaws
* inappropriate content, for example rude messages in comments
* good documentation, including [good commit messages](http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html)

You should make the code open while preserving the history as this provides [useful documentation](https://mislav.net/2014/02/hidden-documentation/). If this is not possible, you may release a snapshot, but this should be a last resort.

Once the code is open you should move to a model where you continue development on the open code, but if you plan to continue to develop your code in a closed way you must explain how you are going to keep the open code up to date.

When it’s acceptable for code to be closed source
-------------------------------------------------

There are very few examples of code that must not be published in the open.

The main reason for code to be closed source is when it relates to policy that has not yet been announced. In this case, you must make the code open as soon as possible after the policy is published.

You may also need to keep some code closed for security reasons, for example code that protects against fraud. Follow the guidance on [code you should keep closed](/government/publications/open-source-guidance/when-code-should-be-open-or-closed) and [security considerations for open code](/government/publications/open-source-guidance/security-considerations-when-coding-in-the-open).

You must not store secret keys or credentials in the source code
----------------------------------------------------------------

You must store secret keys and credentials separately, for example with a secret management system, and inject them into the code. This protects the keys from being accessed by unauthorised staff, and makes it easy to provision different keys for different environments and rotate keys if needed.

Making configuration code open
------------------------------

You should publish configuration code. For example, [GOV.UK’s Puppet code](https://github.com/alphagov/govuk-puppet) is coded in the open. However, if you publish the exact versions of software used in the stack, it can be easier for attackers to identify out of date software. Whether your code is open or closed, you must have a plan for how to upgrade or patch software you use.

Making code with a security-enforcing function open
---------------------------------------------------

Code that contributes to your service’s security does not need to be kept closed. Many security-enforcing functions, such as cryptographic algorithms, are provably better when openly examined and understood while the keys are kept private. Most cryptographic standards are developed in the open by standards authorities. The US National Institute of Standards and Technology (NIST) recently concluded a [9-year process from open competition to standardisation](http://csrc.nist.gov/groups/ST/hash/sha-3/index.html) for the SHA-3 cryptographic hashing algorithm.

Find out more about [security considerations for code that is open](https://www.gov.uk/government/publications/open-source-guidance/security-considerations-when-coding-in-the-open).

If you’re not sure which parts of your code can be published in the open, talk to a third party that you trust. For example, a technical architect in your department or another government department.

You can find a technical architect by joining the [technical architecture community](service-manual_communities_technology-community-technical-architecture.md).

Licensing your code
-------------------

You should publish your code under an [Open Source Initiative compatible licence](https://opensource.org/licenses). For example, GDS uses the [MIT licence](https://gds-way.cloudapps.digital/manuals/licensing.html).

All code produced by civil servants is automatically covered by [Crown Copyright](https://www.nationalarchives.gov.uk/information-management/re-using-public-sector-information/uk-government-licensing-framework/crown-copyright/).

Taking responsibility for open source code
------------------------------------------

When you make your code open, you should:

* [use Semantic Versioning](http://semver.org/) to make it clear when you release an update to your code
* be clear about how you’ll communicate with users of your code, for example on support channels and email lists

Encouraging contributions from people who use your code can help make your code more robust, as people will spot bugs and suggest new features. If you would like to encourage contributions, you should:

* include contributing guidelines
* set time aside to maintain your code
* maintain a public issues list

You might also find it useful to read:

* [the GOV.UK Frontend contribution guidelines](https://github.com/alphagov/govuk-frontend/blob/master/CONTRIBUTING.md)
* [the GOV.UK style guide for pull requests](https://github.com/alphagov/styleguides/blob/master/pull-requests.md)

Tracking changes to your code
-----------------------------

When your code is open, you must keep track of changes to it using [version control](service-manual_technology_maintaining-version-control-in-coding.md).

Services like [GitHub](https://github.com/) make version control much easier. They allow you to track issues and read documentation alongside your code so you understand what has changed and why.

Dealing with security issues in published code
----------------------------------------------

If you find a security issue in your code after you’ve published it, you need to be able to [deploy fixes quickly](https://www.gov.uk/service-manual/technology/deploying-software-regularly) without disclosing too much information about the vulnerability until you’ve dealt with it.

Fixing security issues in public copies of the code does not work for every team. It’s possible to use scripts to switch between private and public copies of the code to manage fixes securely.

You should follow the specific security policies in your team or organisation as well as [general security best practices for dealing with vulnerabilities](https://www.gov.uk/government/publications/open-source-guidance/security-considerations-when-coding-in-the-open#deal-with-security-vulnerabilities) quickly.

Related guides
--------------

You might also find these guides useful:

* [Maintaining version control in coding](service-manual_technology_maintaining-version-control-in-coding.md)
* [Deploying software regularly](service-manual_technology_deploying-software-regularly.md)

Updates to this page
--------------------

Published 26 August 2016

Last updated 5 October 2017
[+ show all updates](#full-history)

1. 5 October 2017

   Added more guidance on security in response to user feedback and input from cross-government technology community.
2. 26 August 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---