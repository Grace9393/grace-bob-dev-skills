Testing with assistive technologies - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Testing with assistive technologies
===================================

[Give feedback about this page](/contact/govuk)

From:
:   [Accessibility community](service-manual_communities_accessibility-community.md)

Contents
--------

1. [Which assistive technologies to test with](#which-assistive-technologies-to-test-with)
2. [How to test](#how-to-test)
3. [What to do if you find an issue](#what-to-do-if-you-find-an-issue)
4. [Include assistive technology users in your user research](#include-assistive-technology-users-in-your-user-research)
5. [Get help](#get-help)
6. [Related guides](#related-guides)

You must make sure your service works with assistive technologies. This is so everyone can use your service with the technology they rely on, such as a screen reader or speech recognition software.

Testing with assistive technology should be part of the overall [accessibility testing](service-manual_technology_testing-for-accessibility.md) for your service.

Which assistive technologies to test with
-----------------------------------------

Test your service with assistive technologies throughout development, especially when you introduce a significant feature or make any major change.

### Meeting the Service Standard

To meet the Service Standard, your service must work with at least the following combinations of assistive technologies and browsers before it goes into public beta.

|  | Software version | Browser |
| --- | --- | --- |
| JAWS (desktop screen reader) | 2019 or later | Chrome or Edge (latest version) |
| NVDA (desktop screen reader) | Latest | Chrome, Firefox or Edge (latest version) |
| VoiceOver on iOS (mobile screen reader) | Latest | Safari (latest version |
| TalkBack (mobile screen reader) | Latest | Chrome (latest version) |
| Windows Magnifier or Apple Zoom (screen magnifiers) | Latest | Any |
| Dragon (speech recognition) | 15 or later | Chrome (latest version) |

This table is based on the [2016 survey of assistive technologies used to access GOV.UK](https://accessibility.blog.gov.uk/2016/11/01/results-of-the-2016-gov-uk-assistive-technology-survey/) and the more recent [WebAIM screen reader survey](https://webaim.org/projects/screenreadersurvey9/).

You can do this testing yourself, or ask for it to be done as part of your [accessibility audit](https://www.gov.uk/service-manual/helping-people-to-use-your-service/getting-an-accessibility-audit).

### Other assistive technologies you may want to test with

Where possible, it’s good practice to test with other assistive technologies, browsers and OS settings. We recommend prioritising:

* older versions of assistive technology - especially JAWS and TalkBack
* other assistive technologies - especially VoiceOver on macOS (screen reader) with Safari and ZoomText (screen magnifier)
* changing colours - using Windows High Contrast mode and Firefox browser settings
* testing with other combinations of browsers and assistive technologies

Other combinations of browsers and assistive technologies to prioritise are:

* Firefox (latest version) and JAWS
* Firefox (latest version) and NVDA
* Firefox (latest version) and Dragon

### Continuous testing

The more often you test during development, the more likely you are to identify any accessibility problems. If you can, it’s best to do continuous testing using the assistive technologies commonly used by your users.

But if that’s not practical, [test using the assistive technology you have access to](https://accessibility.blog.gov.uk/2018/09/27/assistive-technology-tools-you-can-use-at-no-cost/). Try to include a desktop screen reader, a mobile screen reader, a screen magnifier and some speech recognition software.

How to test
-----------

Test with the actual device or technology where possible. Consider using a virtual machine if you cannot get access to a device or technology.

When testing, you should check:

* you can get access to information
* the information is understandable
* everything on the interface is usable

### Screen readers

You should test with screen readers by using them to:

* read every element and header
* tab through every link
* check every landmark, for example your footer and any navigation
* check your use of Accessible Rich Internet Applications (ARIA)
* check you can fill in any editable fields, for example writing and submitting a form

For more information about using screen readers, including keyboard commands, read these WebAim articles on:

* [using JAWS to evaluate web accessibility](https://webaim.org/articles/jaws/)
* [using NVDA to evaluate web accessibility](https://webaim.org/articles/nvda/)
* [using VoiceOver to evaluate web accessibility](https://webaim.org/articles/voiceover/)

### Screen magnifiers

When using screen magnifiers, test up to at least 4 times magnification. Check:

* the spacing between elements, for example the gap between a form label and field
* that page elements display consistently on different page layouts - so someone who is zoomed in to a page can always find the search box, for example
* that users know when something happens outside the viewport - for example, with modals or error messages

### Speech recognition

To test your service with speech recognition technology, use speech to:

* navigate to each feature
* activate every link, button, or interactive element, for example form controls or a media player
* enter text into any forms if applicable to your service

Make sure you speak clearly, but naturally. You should also use a high quality headset rather than an in-built microphone in your local machine and make sure you’re at a consistent distance from the microphone. Say punctuation out loud and correct any spelling mistakes you make.

Check the [user guides for Dragon](https://www.nuance.com/dragon/user-documentation.html) for more information on how to install, give voice commands and dictate different types of text.

What to do if you find an issue
-------------------------------

If you identify an issue while testing, document it clearly so it can be replicated and re-tested.

Before you document a problem or spend any time trying to fix it, make sure:

* you are using the assistive technology correctly
* [your code does not have any bugs or errors](https://www.gov.uk/service-manual/technology/quality-assurance-testing-your-service-regularly)
* there are no known bugs in the browser or assistive technology that could affect your tests

When documenting an issue, you should describe:

* the problem
* who it impacts
* what browser, operating system, and version of the technology you were using at the time

You may also find it helpful to include screenshots.

If you’re documenting several issues, you may find it helpful to categorise them by severity so they can be prioritised. For example, if you find an issue that is a complete barrier to a set of users, you may want to class this a higher priority than one that your users can easily work around.

Consider:

* sharing your findings with the wider [accessibility community](service-manual_communities_accessibility-community.md) so others can learn from your testing
* reporting any bugs to the browser or assistive technology vendor

Include assistive technology users in your user research
--------------------------------------------------------

You should also include users of assistive technologies in your user research. Participants do not need to use any specific combinations of software - any set up will help you learn about how well your service works with assistive technologies.

Get help
--------

Get in touch with the [accessibility community](service-manual_communities_accessibility-community.md) directly to:

* discuss this page
* share ideas across government
* find support from teams that have worked on similar services

Related guides
--------------

You may also find the guidance on [designing for different browsers and devices](service-manual_technology_designing-for-different-browsers-and-devices.md) useful.

Updates to this page
--------------------

Published 26 October 2017

Last updated 24 May 2022
[+ show all updates](#full-history)

1. 24 May 2022

   Page reviewed and updated.
2. 21 September 2020

   Updated list of assistive technology and browser combinations to test with
3. 26 October 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---