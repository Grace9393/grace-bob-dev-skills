Get a GOV.UK feedback page - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

Get a GOV.UK feedback page
==========================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [The GOV.UK feedback page](#the-govuk-feedback-page)
2. [Get a feedback page](#get-a-feedback-page)
3. [Viewing feedback](#viewing-feedback)
4. [Related guides](#related-guides)

You must allow users to tell you what they think of your service once they’ve finished using it.

You can do this with the GOV.UK feedback page.

You should also allow users to give feedback at [other stages of using your service](service-manual_measuring-success_measuring-user-satisfaction.md), for example before they’ve finished using it.

The GOV.UK feedback page
------------------------

GOV.UK feedback pages let users rate their experience from ‘very satisfied’ to ‘very dissatisfied’ and suggest improvements. They follow a specific format like this example from ‘Register a boat’.

![ ](https://assets.publishing.service.gov.uk/media/5fbe7c998fa8f559e44d2d96/screenshot-register-a-boat2.png)

Get a feedback page
-------------------

To get a GOV.UK feedback page, ask your departments’s web publishing team to [raise a request with GDS](https://www.gov.uk/guidance/contact-the-government-digital-service/request-a-thing) at least 1 month before your beta assessment.

This is part of the process of [getting your service on GOV.UK](service-manual_service-assessments_get-your-service-on-govuk.md).

If your service is in alpha or private beta, you can create your own feedback page.

You can use your own feedback page if you need to ask specific questions.

Viewing feedback
----------------

You can download the data for your service from the Feedback Explorer app. If you do not have access, contact the team in your organisation that publishes to GOV.UK, if you have one. They will be able to share this information with you. Or you can [ask GDS to let you view it yourself](https://www.gov.uk/guidance/contact-the-government-digital-service/request-a-thing).

Related guides
--------------

You may also find these guides useful:

* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Using data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Alpha and beta banners](https://design-system.service.gov.uk/components/phase-banner/)

Updates to this page
--------------------

Published 22 June 2018

Last updated 19 February 2021
[+ show all updates](#full-history)

1. 19 February 2021

   Updated the page because of the retirement of the Performance Platform.
2. 22 June 2018

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---