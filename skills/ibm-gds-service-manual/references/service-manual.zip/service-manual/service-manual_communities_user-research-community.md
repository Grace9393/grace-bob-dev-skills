User research community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

User research community
=======================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [User research in the Service Manual](#user-research-in-the-service-manual)
5. [Other communities](#other-communities)

The user research community exists to:

* develop user research knowledge and skills across government
* discuss and challenge the way government carries out user research to improve services and content
* bring together people with an interest in improving user research practices across government

Who the community is for
------------------------

You might be interested in this community if you:

* are involved in user research
* want to learn about users of government services

You don’t have to be in a user research role.

Get involved
------------

### Online

Use these online spaces to discuss user research issues:

* user research for government services discussion group - to get access, contact [join-digital-user-research@digital.cabinet-office.gov.uk](mailto:join-digital-user-research@digital.cabinet-office.gov.uk) using your government email address
* [UK Government Digital #user-research Slack channel](https://ukgovernmentdigital.slack.com/messages/user-research/) - a place to chat and share real-time news about user research issues (create a Slack account using your government email address)

If you can’t access these, please email [join-digital-user-research@digital.cabinet-office.gov.uk](mailto:join-digital-user-research@digital.cabinet-office.gov.uk) for help.

### Training and events

The community co-hosts regular training sessions and events for colleagues across government, including:

* [cross-government user research meetups](https://userresearch.blog.gov.uk/cross-government-user-research-meetups/) - informal show and tell events that take place every other month
* [user research and other training on user-centred design](service-manual_design_user-centred-design-training-and-events.md) - including training for people who are new to user research and masterclasses for experienced practitioners

As a civil servant, you can also book a place on user research fundamentals training through [Civil Service Learning](https://civilservicelearning.civilservice.gov.uk/learning-opportunities/facetoface/user-research-fundamentals). This will give you 5 days of practical user research experience.

Community resources
-------------------

Use these resources to learn more about user research in government:

* [user research blog](https://userresearch.blog.gov.uk/) - user research stories and case studies from across government
* [Inside GOV.UK blog](https://insidegovuk.blog.gov.uk/category/user-insights/) - stories about how data and user research have helped improve GOV.UK

Use these for hiring user researchers:

* [DDaT profession user researcher role, level and capability definitions](/government/collections/digital-data-and-technology-profession-capability-framework#user-centred-design:-user-researcher)
* [job description for a user researcher](https://www.gov.uk/service-manual/the-team/what-each-role-does-in-service-team#user-researcher)

User research in the Service Manual
-----------------------------------

The [Service Manual guides to user research](service-manual_user-research.md) show what we currently believe to be best practice for government services. They cover:

* understanding user research
* user research in the different design phases
* preparing for user research
* user research methods
* analysing and sharing findings

Help us keep the Service Manual up to date by:

* contributing to discussions in our [user research guidance group](https://groups.google.com/a/digital.cabinet-office.gov.uk/forum/#!forum/user-research-guidance)
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Other communities
-----------------

You may want to find out more about the following communities:

* [design community](https://www.gov.uk/service-manual/communities/design-community)
* [content community](https://www.gov.uk/service-manual/communities/content-community)
* [accessibility community](https://www.gov.uk/service-manual/communities/accessibility-community)

Updates to this page
--------------------

Published 1 March 2016

Last updated 24 May 2016
[+ show all updates](#full-history)

1. 21 November 2016

   Added guides for research in discovery, alpha, beta and live.
2. 24 May 2016

   Added guides to getting users' consent for research, sharing findings and analysing research sessions.
3. 1 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---