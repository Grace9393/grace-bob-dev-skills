Designing with data: an introduction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Designing with data: an introduction
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Using data to inform decisions](#using-data-to-inform-decisions)
2. [Types of data](#types-of-data)
3. [Data security](#data-security)
4. [Data quality](#data-quality)
5. [Sharing and reusing data](#sharing-and-reusing-data)
6. [Using metadata](#using-metadata)
7. [Restructuring data](#restructuring-data)
8. [Working with large amounts of data](#working-with-large-amounts-of-data)

Data is distinct pieces of information. When designing and running services you should make appropriate use of data to inform your choices and improve the experience for users.

There are various types of data, which can be quantitative or qualitative:

* information from user research to help you understand user needs
* analytics to help you understand how people are using your service and how it’s performing
* information in a database, on which the service runs
* personal data to help personalise the service for users so it’s easier and more relevant for them
* statistical and reporting data, which you might use to make decisions about your service

​​Only use data if you have the right permissions to do so. Make sure you [protect sensitive or personal information](https://www.gov.uk/service-manual/service-standard/point-9-create-a-secure-service).

Using data to inform decisions
------------------------------

Data plays an important and integral part in the planning and development of a service. Use data to inform decisions as early as possible. This will help to avoid more expensive, difficult and time-consuming changes later on.

Setting and testing hypotheses helps you make improvements. You should set hypotheses that include what action you will take, what impact you expect and how you will measure it. Test the hypotheses and analyse the data to understand their effect. Your hypotheses could be based around particular [outcomes for users](https://methods.18f.gov/decide/design-hypothesis/), or changes to [performance KPIs](https://insidegovuk.blog.gov.uk/2017/09/06/making-better-decisions-with-data/).

Identify what data you will need to collect, and plan how to go about collecting it.

[Choosing the right analytics tools](https://www.gov.uk/service-manual/measuring-success/choosing-digital-analytics-tools) will help you measure, collect and analyse useful data.

[Using data and analytics tools for content](https://www.gov.uk/guidance/content-design/data-and-analytics), like Feedex, Content Data and Google Analytics, can help you find data specifically to improve your content. For example, they can help you with search engine optimisation (SEO) and understanding how users are interacting with your content.

Types of data
-------------

You should consider what types, sources and formats of data might be appropriate throughout the planning and design of your service. This will help you to provide a service that [solves a whole problem for users](https://www.gov.uk/service-manual/service-standard/point-2-solve-a-whole-problem).

This is particularly important for users who are more likely to need to use offline channels and interact with multiple organisations.

Data can:

* include words, numbers, photos, decisions and audio
* come from many sources, for example the user directly, a legacy system’s database, another department’s database, someone transcribing an interview or someone transferring data from a paper form
* be stored physically or digitally, and in various formats, for example a spreadsheet, an image, a text document, an audio recording or a slide deck

Data can capture and record many different things, for example a decision, a measurement or an image.

Data security
-------------

You must protect data from unauthorised access, corruption, or theft throughout its lifecycle.

This involves:

* [understanding your data assets](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/documenting-service-assets/)
* [assessing how important they are to your business](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/assessing-the-importance-of-service-assets/)
* making appropriate [risk management decisions](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/responding-to-and-mitigating-security-risks/)
* deciding [what security controls should be implemented](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/agreeing-a-security-controls-set-for-your-service/) to protect data

Data quality
------------

Better data helps you make better decisions about your service. Good quality data is easier for service teams to use and share, and makes it easier to maintain privacy and security. It’s also easier for service users to understand, access and use.

[The Government Data Quality Framework](https://www.gov.uk/government/publications/the-government-data-quality-framework/the-government-data-quality-framework-guidance) provides guidance, tools and techniques to assess, communicate and improve data quality. For example, the section about data lifecycles describes the different stages data will go through and how to manage quality throughout.

[Data privacy impact assessments (DPIA)](https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/accountability-and-governance/data-protection-impact-assessments-dpias/) help you make sure your data use and privacy practices comply with the law, including when using data with algorithmic tools.

Using consistent formats and structures for data will help maintain quality. Your service’s users and people working on other services will be more likely to understand and be able to use the data.

For example, data like dates or addresses should use the same format throughout the service. The [GOV.UK Design System](https://design-system.service.gov.uk/) has guidance on reusable components and patterns. This also makes it easier for other people providing services to reuse data across different services, without having to reformat it.

You should [use open formats](https://www.gov.uk/guidance/using-open-document-formats-odf-in-your-organisation) like ODT instead of proprietary file types like XLS, so that users can use any software to open and use files they need to download.

Check to see if there are [Open standards for government data and technology](https://www.gov.uk/government/collections/open-standards-for-government-data-and-technology) that you could or must use.

Sharing and reusing data
------------------------

You should consider how other teams may benefit from using the data you collect, so you can make it as reusable as possible. In addition, your service may be better to use and easier to run if it gets data from other parts of government.

Reusing existing data can:

* improve the quality of services by avoiding asking users for more information than is necessary
* save teams and users time and money
* avoid unnecessary duplication of data
* increase the efficiency of cyber security measures
* reduce the risk of errors and inconsistencies

You can look for existing [government data sets](https://data.gov.uk/) that you might be able to use to meet the needs of your service.

Application programming interfaces (APIs) are another useful way to share and reuse data across services. An API is software that connects websites and mobile applications to databases so that they can exchange data, without giving direct access to the database. This exchange could be one way or reciprocal - other teams may benefit from using your data, too.

The APIs in the [API Catalogue](https://www.api.gov.uk/#uk-public-sector-apis) are published by public sector organisations in the UK. You can use it to find and access inter-departmental data exchanges.

If you are building your own API, follow the [API technical and data standards](https://www.gov.uk/guidance/gds-api-technical-and-data-standards#follow-the-technology-code-of-practice) and read the guidance on [designing, building and managing APIs](https://www.gov.uk/government/collections/api-design-guidance).

Using metadata
--------------

Metadata is data that describes other data. This might include:

* when the data was created
* who published the data - for example, the name of the department
* when the data was last updated or the version number, as applicable

Metadata helps users of the data know what it’s about, how reliable it is and who to contact if they have any issues with the data.

You should follow [standards for sharing and publishing metadata](https://www.gov.uk/government/collections/metadata-standards-for-sharing-and-publishing-data).

Restructuring data
------------------

Before you change or restructure a data set, check if the data already exists in the structure, form or combination you need it in. This will help avoid creating duplicate or disconnected data sets, which can reduce data quality across government.

When working with data, including data from somewhere other than your own sources, you may need to change its structure to improve its quality and make it easier to use. This could involve combining multiple sets of data into a single set.

In some cases, you may also need to standardise or change how data is structured before you can use it for your service. For example, if you need to take data from a spreadsheet and feed it into automated tools, you might need to [use CSV file format](https://www.gov.uk/guidance/using-csv-file-format) to make the data machine-readable.

You may need to convert data into different formats, for example if you need to use or combine data from multiple sources. This will help you capture and use data from all parts of a service, for example paper forms and call centre logs and [make sure your service includes or joins up with everything users need it to](https://www.gov.uk/service-manual/design/scoping-your-service).

Working with large amounts of data
----------------------------------

Data sets can be harder for software to access and process if they have complex structures with a lot of pieces of information.

Understanding how large data sets are set up and organised will help you find or create applications that query the data in the most effective and efficient way.

Make sure you use software that can handle the size and complexity of data sets you will need. This will help software and your service work quickly, and avoid breaking down. For example, older versions of Microsoft Excel have a lower limit on their maximum number of rows than more recent versions.

You can read more about [using large CSV files](https://www.gov.uk/guidance/using-csv-file-format).

Updates to this page
--------------------

Published 31 March 2022

Last updated 25 November 2024
[+ show all updates](#full-history)

1. 25 November 2024

   Integrated elements on understanding business objectives and user needs, understanding cyber security obligations, and sourcing a threat assessment.
2. 13 April 2022

   Information added on use of design hypotheses, consistent format, the GOV.UK Design System and open formats.
3. 31 March 2022

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---