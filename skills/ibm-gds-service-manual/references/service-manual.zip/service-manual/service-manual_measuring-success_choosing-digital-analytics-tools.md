Choosing digital analytics tools - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Choosing digital analytics tools
================================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Choosing functions and features](#choosing-functions-and-features)
2. [Information security and privacy](#information-security-and-privacy)
3. [Comparing vendors](#comparing-vendors)
4. [Data you need to capture](#data-you-need-to-capture)
5. [Other tools you may need](#other-tools-you-may-need)
6. [Related guides](#related-guides)

You need to choose the right tools to help you measure, collect and analyse data about how people are using your digital service.

You should check whether a tool meets your needs before you decide to use it.

Choosing functions and features
-------------------------------

To choose the right features and functions for your analytics tools, you should ask yourself:

* what you need to do - for example, whether you need to do A/B or multivariate testing
* how much it will cost
* where the data is stored and how you’ll access it
* what the quality of the data is
* what you can do with the data
* what support is available to help you use the tool

### How much it will cost

You’ll need to consider:

* the total cost of ownership, which includes purchase, licensing, support, hosting, consultancy and any ongoing fees after the first year
* the functionality that’s included and whether you need features that have extra costs

### Where the data is stored and how you access it

You’ll need to consider:

* who owns the data - it should be your organisation
* whether a tool is hosted by the vendor or in-house - you’ll need to choose between a simple cloud-based solution or a more secure but expensive hosted solution, depending on your technical, privacy and security requirements
* how long a tool retains data and keeps it available for you to access - you’ll need to make sure the time frame works for you and that you can retain the data if you move to a different tool
* whether a tool’s admin system allows you to control different levels of access for people who need to use the tool

### What the quality of the data is

You’ll need to consider:

* whether the amount of sampling done to large volumes of data or near real-time data meets your needs
* whether a tool allows you to upload external data sets - like contact centre data - to extend and enrich your insights

### What you can do with the data

You’ll need to consider:

* whether a tool provides an application programming interface (API) or has restrictions on exporting data - an API with no restrictions is useful if you need build your own custom reports with the data
* whether a tool provides a comprehensive set of standard reports that meet your needs
* whether the tool can measure transactions through funnels and goals

### What support is available to help you use the tool

You’ll need to consider:

* the support that’s available to help you implement and manage a tool, and whether the cost of this is included in the price you paid for the tool
* whether a tool has an active online community of users for ad-hoc advice
* whether your technical team accepts a tool’s tracking methodology - often cookies

Information security and privacy
--------------------------------

To protect a user’s personal data when people use your service, you need to check that your analytics solutions:

* are set up so they do not collect and process any personal or personally identifiable information - the terms and conditions of your analytics provider will probably forbid you from doing this
* have any data sharing settings switched off - some suppliers may collect data anonymously for internal benchmarking
* anonymise IP addresses - remove the last octet (8 digits) of IPv4 addresses and the last 10 octets of IPv6 addresses
* meet the requirements of relevant privacy legislation
* have data centres that meet EU data security standards
* have tools that control how your staff can access data and stop your vendor’s employees viewing data without your approval
* allow you to own analytics data that you’ve exported - pay attention to any terms or conditions of your product (especially if it’s a free product) that may prevent this

If your analytics solution uses cookies or similar technologies to store information on a user’s device, you must [follow the guidance about using cookies](service-manual_technology_working-with-cookies-and-similar-technologies.md).

Comparing vendors
-----------------

There are many vendors of analytics software and solutions in the marketplace as well as many free open source solutions.

Search for ‘analytics tools comparison’ to see some useful web resources where you can compare options.

You can also find and compare suppliers on the [Digital Marketplace](https://www.gov.uk/digital-marketplace).

Data you need to capture
------------------------

The data that your digital analytics tools need to capture will depend on your service. However, there are some types of data that most services will need.

Make sure your suite of digital analytics tools can be set up to record the following:

* user journeys through your service and any problem areas where users drop out of it before they’ve completed the task it was designed for
* the results of A/B and multivariate tests – so that you can iteratively improve the design of your service, and the speed and ease with which users can complete transactions
* segmented data - so that you can analyse user behaviour according to where they’ve just come from on the web, where they live, their age, the choices they’ve made in their user journey, etc
* user surveys – so that you can get feedback on users’ experience of the service

Other tools you may need
------------------------

It’s unlikely that your main digital analytics tool will meet all of your needs. For instance, you may need to:

* analyse complex data from different sources, including non-digital
* visualise and share data in bespoke ways across your team and organisation

To do this, you’ll need to find other tools to analyse, process and visualise your data, for example spreadsheets, business analytics tools, survey analysis tools or data visualisation tools.

If your data sets are large and complex it can be more efficient to analyse using tools like [R](https://en.wikipedia.org/wiki/R_(programming_language)) or [Python](https://en.wikipedia.org/wiki/Python_(programming_language)).

Related guides
--------------

You may also find these guides useful:

* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)

Updates to this page
--------------------

Published 23 March 2016

Last updated 24 May 2018
[+ show all updates](#full-history)

1. 24 May 2018

   Clarified how to anonymise IPv6 IP addresses
2. 23 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---