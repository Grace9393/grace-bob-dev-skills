Making your service look like GOV.UK - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Making your service look like GOV.UK
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [If the existing patterns don’t meet your needs](#if-the-existing-patterns-dont-meet-your-needs)
2. [Researching design solutions](#researching-design-solutions)
3. [If your service isn't on GOV.UK](#if-your-service-isnt-on-govuk)
4. [Examples and case studies](#examples-and-case-studies)
5. [Related guides](#related-guides)

Your site must look like GOV.UK if it’s on one of the following domains:

* gov.uk/myservice
* myservice.service.gov.uk
* myblog.blog.gov.uk

This ensures that users get a consistent experience and trust they’re in the right place if they follow a link to your service from elsewhere on GOV.UK.

When building these types of services, you must use the:

* [design principles](https://www.gov.uk/design-principles)
* design patterns, components and styles in the [GOV.UK Design System](https://design-system.service.gov.uk/)
* [GOV.UK content style guide](/guidance/style-guide/a-to-z-of-gov-uk-style)
* [phase banner](https://design-system.service.gov.uk/components/phase-banner/), if your service is in alpha or beta

You’ll need to use the [GOV.UK Design System and GOV.UK Frontend](https://design-system.service.gov.uk/get-started/production/) to implement the patterns and typeface.

You can use the typeface on the offline parts of your service too if the digital part has passed a beta assessment.

Unless it’s a blog, your service must also have a GOV.UK:

* [start page](https://design-system.service.gov.uk/patterns/start-pages/)
* [feedback page](service-manual_design_feedback-pages.md)

If the existing patterns don’t meet your needs
----------------------------------------------

If research shows that none of the existing GOV.UK patterns meet the needs of your users, you can:

* adapt an existing pattern
* create a new pattern

In a service assessment, you’ll need to provide research and evidence to prove how your design works better for users.

Learn more about [using, adapting and creating patterns](service-manual_design_using-adapting-and-creating-patterns.md).

Researching design solutions
----------------------------

GOV.UK design patterns are reviewed regularly and tested with users on live government services.

You can read the research and join discussions about them on the [GOV.UK Design System](https://design-system.service.gov.uk).

If your service isn’t on GOV.UK
-------------------------------

You’re welcome to use the GOV.UK patterns and frontend code even if your service isn’t considered part of GOV.UK. Although you’ll sometimes need to use different patterns, for example if [you’re building something like an admin interface](https://www.gov.uk/service-manual/design/services-for-government-users).

While you can use the patterns, your site or service must not:

* identify itself as being part of GOV.UK
* use the crown or GOV.UK logotype in the header
* use the GDS Transport typeface
* suggest that it’s an official UK government website if it’s not

These things are there to provide a consistent identity and navigation between GOV.UK and the sites and transactional services that hang off it. If your service isn’t on GOV.UK, there’s no need to maintain that identity - in fact, you might confuse or mislead people if you do.

You should also use the brand logo and font of your organisation.

Examples and case studies
-------------------------

Examples that show you how to make your service consistent with GOV.UK include:

* [One thing per page](https://designnotes.blog.gov.uk/2015/07/03/one-thing-per-page/)
* [Prototyping tips](https://designnotes.blog.gov.uk/2015/03/19/prototyping-tips/)
* [How to use our design patterns – even if your service isn’t part of GOV.UK](https://designnotes.blog.gov.uk/2015/09/08/how-to-use-our-design-patterns-even-if-your-service-isnt-part-of-gov-uk/)

Related guides
--------------

* [Making prototypes](service-manual_design_making-prototypes.md)
* [Using progressive enhancement](service-manual_technology_using-progressive-enhancement.md)

Updates to this page
--------------------

Published 9 December 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---