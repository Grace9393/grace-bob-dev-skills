Contextual research and observation - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Contextual research and observation
===================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to do contextual research](#when-to-do-contextual-research)
2. [Steps to follow](#steps-to-follow)
3. [Examples and case studies](#examples-and-case-studies)
4. [Related guides](#related-guides)

Contextual research means visiting people in their everyday environment (like their home, work or school) to observe how they do an activity.

Watching someone complete a task in familiar surroundings with their own equipment (and usual distractions) can help you understand what they need from your service.

When to do contextual research
------------------------------

Contextual research and observation is helpful when you want to:

* understand the wider problem that your service is trying to solve
* see how people use your service in a real-life context using real data, documents and devices
* learn more about any barriers or problems people experience, and how they try to overcome them

It can also be useful for understanding how a service is operated or supported. For example, you can learn a lot by observing people inside and outside your organisation like caseworkers, contact centre staff or charity workers.

Steps to follow
---------------

Plan contextual research sessions carefully so you make the most of being able to observe someone in their own environment. You’ll need to be adaptable as you never know exactly what you’ll find on a visit.

### Plan the research

Contextual research visits usually take between 1 and 3 hours. Observation is demanding, so do not plan more than 4 one-hour visits or 2 three-hour visits in a day.

Before planning any visits, work with your team to agree which of your research questions and user groups you want to focus on. You also need to decide what you want to observe. You can then [recruit research participants](service-manual_user-research_find-user-research-participants.md) and [choose research locations](service-manual_user-research_choose-a-location-for-user-research.md).

As part of planning, you also need to decide what you’ll do if there’s a problem or emergency during your visit.

### Design the visits

To get the most from a visit, think carefully about the activities your team wants to learn about, and how best to observe them. Make sure your approach does not exclude [disabled people](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md) or [people who may need support to use your service](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md).

On a visit you can:

* observe silently without asking questions - this allows the participant to carry out their activity as usual, but you may not always understand what’s happening or why
* ask occasional questions - this interrupts the natural flow of the activity but allows you to learn more, providing a good balance between authenticity and understanding
* ask participants to explain each step of an activity as they go along - this means participants will not do things exactly as they normally do, but it will give you the deepest understanding

You’ll need to decide how to [take notes and record what you observe](service-manual_user-research_taking-notes-and-recording-user-research-sessions.md) in the sessions. Fewer team members can observe contextual research, so good notes and recordings are important for creating and communicating findings.

### Work in pairs

Contextual research works best in pairs - it’s easier and safer. Having 2 of you there means:

* one of you can take notes, photos and recordings while the other manages participants and leads the visit
* one of you can watch your equipment and bags while the other gets drinks and food, or goes to the toilet
* you can split up and observe more participants and activities
  more team members get the chance to meet and learn from users first hand - but without overwhelming participants

### Create a discussion guide

Once you’ve planned your visit, create a ‘discussion guide’. This should include:

* your introduction script - this tells participants who you are, explains the research and reminds them about things like recording
* the visit structure - including instructions for other researchers and participants
* a planning checklist to make sure you’ll have everything you need on the day

You can use your discussion guide to:

* review the intended visit structure with your team
* stay on track during a visit
* make sure multiple researchers cover the same topics and participants have a consistent experience
* maintain a record of what you do in this round of research

### Do the research

Before you leave:

* use your checklist to make sure you take everything you’ll need
* check that you have the correct addresses and contact details - share these with a colleague so they know where you’re going
* think about how you dress - try not to look out of place as this can be distracting for people

Once you’ve arrived:

* take a few minutes to look around and ask the participant some general questions about themselves and the activity - this will help you understand what you observe
* get [informed consent](service-manual_user-research_getting-users-consent-for-research.md) from all participants - do not forget anyone who joins in later
* run through your introduction script to make sure the participants understand what you’ll be doing

When observing participants:

* follow your discussion guide to manage the visit - but be flexible when you discover unexpected or interesting things
* allow activities to unfold as naturally as possible - try to keep quiet and still to minimise your influence
* if you observe something and you’re not sure what’s happening or why, ask questions either during or after the session to make sure you understand
* confirm that you still have consent before taking photos or recordings of anything new

Reserve some time at the end of the session to:

* ask follow-up questions about anything you observed but did not clearly understand
* check if there’s anything else the participant wanted to talk about or show you

At the end of the visit:

* thank the participant for their time and what they’ve helped you learn
* explain what will happen with your research
* ask the participant how the session was for them, so you can improve next time
* ask the participant if they’d like to take part in future research, or know anyone else who would

When you’re ready to leave:

* make sure any personal data you’ve collected (including anything you’ve written, photographed or recorded) is stored securely so you can transport it safely
* pack away your equipment - use your planning checklist

### Use the results

After the visits, [analyse the research](service-manual_user-research_analyse-a-research-session.md) with your team to generate findings they can use. Quotes, photos and video clips from contextual research make particularly compelling illustrations for your findings.

You can also use your observations to help [create an experience map](service-manual_user-research_creating-an-experience-map.md) that shows how people carry out the activity you’re researching.

Examples and case studies
-------------------------

You may find these examples and case studies useful:

* [how contextual interviews helped define the technical needs of people who have experienced domestic abuse](https://wearesnook.com/projects/techvsabuse/)
* [how user research by the Department for Work and Pensions is helping terminally ill users](https://dwpdigital.blog.gov.uk/2016/07/28/how-user-research-is-helping-terminally-ill-users/)
* [how a GOV.UK team used contextual interviews to learn more about their audience](https://userresearch.blog.gov.uk/2016/10/20/practice-makes-perfect-evolving-our-user-research-for-gov-uk/)

Related guides
--------------

You may also find these guides useful:

* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Using in-depth interviews](service-manual_user-research_using-in-depth-interviews.md)
* [Researching user experiences](service-manual_user-research_researching-user-experiences.md)
* [Taking notes and recording user research sessions](service-manual_user-research_taking-notes-and-recording-user-research-sessions.md)

Updates to this page
--------------------

Published 1 September 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---