How the beta phase works - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

How the beta phase works
========================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [What to focus on during beta](#what-to-focus-on-during-beta)
2. [Meeting the Service Standard at beta](#meeting-the-service-standard-at-beta)
3. [Solving a whole problem for users](#solving-a-whole-problem-for-users)
4. [Providing a joined up experience across different channels](#providing-a-joined-up-experience-across-different-channels)
5. [Making sure everyone can use your service](#making-sure-everyone-can-use-your-service)
6. [Other things to consider at beta](#other-things-to-consider-at-beta)
7. [Moving from public beta into live](#moving-from-public-beta-into-live)
8. [Related guides](#related-guides)

The beta phase is where you take your best idea from alpha and start building it for real. It also involves thinking about how your service will integrate with (or start to replace) existing services, and preparing for the transition to live.

Structure your beta phase so you can roll out the service to real users - while minimising risk and maximising the potential to learn and iterate the service. Make sure:

* the service team has the capacity to sustain that learning and iteration throughout the beta period
* support staff are able to cope with new users who might struggle to use the service in ways you have not foreseen

You’ll start out in ‘private beta’. This involves inviting a limited number of people to use your service so you can get feedback and improve it.

Once you’ve improved the service and are confident you can run it at scale, you take an assessment to move into ‘public beta’. This involves opening up your service to anyone who needs it. If you’re replacing a legacy service, keep the legacy service running until your new service moves into its live phase.

You should [book your assessment](https://www.gov.uk/service-manual/service-assessments/book-a-service-assessment) 6 weeks before you want to be assessed.

You can [download a poster that explains what the beta phase is for](https://github.com/eliothill/service-design-posters).

What to focus on during beta
----------------------------

By now you’ll have developed a strong understanding of your users’ needs and, by the end of alpha, chosen a way of meeting those needs.

During beta, focus on making sure that the solution you’ve chosen works as well as possible by carrying out [user research](https://www.gov.uk/service-manual/user-research/user-research-in-beta) and starting to gather data on [how successful the service is](service-manual_measuring-success.md) based on the success metrics you identified in alpha. Iterate the service based on what you learn.

Meeting the Service Standard at beta
------------------------------------

Meeting points 2 and 3 of the standard at beta involves slightly different things than it did at alpha.

Solving a whole problem for users
---------------------------------

Point 2 of the standard says you need to work towards solving a whole problem for users.

### Getting the scope of your part of the journey right

At alpha, you’ll have tried different approaches and developed an idea of how to [scope your transaction so it makes sense to users](service-manual_design_scoping-your-service.md).

Use the beta phase to continue to test and refine that scope.

### Joining up with the user’s wider journey

At alpha, you’ll have worked out whether your service is part of a wider journey. At your beta assessment, you’ll need to show how the service you’ve built operates within that wider journey, [working across organisational boundaries](https://www.gov.uk/service-manual/agile-delivery/working-across-organisational-boundaries) where necessary.

For a GOV.UK transaction, you’ll need to agree the following things with the GOV.UK team at GDS before going into public beta:

* how the transaction will [join up with GOV.UK guidance or any start page](service-manual_design_govuk-content-transactions.md)
* a [subdomain name and any content changes needed](service-manual_service-assessments_get-your-service-on-govuk.md)

### Working in the open

Continue to work in the open during beta - for example, by blogging and by inviting operational delivery colleagues to open show and tells so they know what you’re doing.

If what you’re building at beta is going to be part of a wider journey involving other organisations or services, it’s especially important to talk publicly about your plans. It’s also worth looking into whether you could [start or join a service community](https://www.gov.uk/service-manual/design/service-communities).

### Dealing with constraints

You’ll have used the alpha phase to understand any constraints that are likely to affect your service.

For example, contracts or the organisation’s plans for a wider change programme might influence how fast you can [move away from legacy technology](https://www.gov.uk/service-manual/technology/moving-away-from-legacy-systems).

At the beta assessment you should be able to explain how the organisation as a whole is making reasonable progress towards addressing these constraints.

### Reusing users’ information where possible

If you’re building a service that reuses information users have already provided to another part of government, you’ll need to show that users’ information is being shared in a way that’s secure, stable and works at scale. This might be through an Application Programming Interface (API) that follows the [government API standards](https://www.gov.uk/guidance/gds-api-technical-and-data-standards).

You’ll also need to make sure any information sharing happens in a way that [protects users’ privacy](https://www.gov.uk/service-manual/design/collecting-personal-information-from-users).

Providing a joined up experience across different channels
----------------------------------------------------------

Point 3 of the standard says that you should work towards providing a service that works well across all the channels a user might use to access it.

You’ll need to show that you’re making reasonable progress in improving the user’s experience in different channels. For example, by testing and iterating letters users get from the service or improving the way a call centre refers people online.

You should be able to explain how you know your [assisted digital support model](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md) meets the needs of users who need help doing things online. And how you’ve set up your [user support model](service-manual_helping-people-to-use-your-service_set-up-and-manage-user-support.md).

You should also be able to show that the organisation as a whole is tackling any long term constraints that make it difficult to improve offline channels. Like a process for creating automated letters that makes it expensive to change things.

You should be able to explain how you’re involving colleagues from operational delivery in:

* prioritising what you work on
* designing how the service works - for example, by inviting them to attend and analyse user research

And you should be able to explain the organisation’s process for solving problems that show up in one channel, but need to be fixed by making changes in another.

Making sure everyone can use your service
-----------------------------------------

As part of providing a service that everyone can use, at your beta assessment you’ll need to show how you’ve [run regular accessibility testing](service-manual_technology_testing-for-accessibility.md) on your service and run research sessions with disabled people.

You’ll also need to talk about the results of your [accessibility audit](https://www.gov.uk/service-manual/technology/testing-for-accessibility#getting-an-accessibility-audit) and fix any issues before moving into public beta.

You’ll need to show that you’ve considered whether the service has any [pain points that might lead to people being excluded](service-manual_design_making-your-service-more-inclusive.md), and what steps you are taking to address them.

When you move into public beta, you will need to [publish an accessibility page for your service](service-manual_helping-people-to-use-your-service_publishing-information-about-your-services-accessibility.md).

Other things to consider at beta
--------------------------------

You’ll usually need to talk about how you use technology, for example:

* the way you deploy software, proving you can deploy frequently without impacting users
* [how you’ve made your service secure](https://www.gov.uk/service-manual/technology/securing-your-information) so users’ data is safe
* how you’ll work with cookies and similar technologies
* how you’re making source code open
* how you’re managing the limits placed on your service by the technology stack and development toolchain you’ve chosen
* how you’re using open standards and common platforms
* what the effect would be if your service was unavailable for any length of time and how you’re managing this
* [how you’re testing your technology](https://www.gov.uk/service-manual/technology/quality-assurance-testing-your-service-regularly)

You’ll probably also be asked about:

* your beta dashboard and the [performance data you’ve published](service-manual_measuring-success_data-you-must-publish.md)
* how you’re using styles, components and patterns in the [GOV.UK Design System](https://design-system.service.gov.uk/)
* your future user research plans and budgets

If you’ve created any new design patterns - or learned anything useful about an existing design pattern - you should share what you’ve learned through the [GOV.UK Design System](https://design-system.service.gov.uk/).

Moving from public beta into live
---------------------------------

Read our guidance on [how the live phase works](service-manual_agile-delivery_how-the-live-phase-works.md) to find out what operating a live service involves.

You can [book an assessment](https://www.gov.uk/service-manual/service-assessments/book-a-service-assessment) when you think you’re ready to move into live.

Related guides
--------------

You may find these guides useful:

* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [How the alpha phase works](service-manual_agile-delivery_how-the-alpha-phase-works.md)
* [How the live phase works](service-manual_agile-delivery_how-the-live-phase-works.md)
* [Retiring your service](service-manual_agile-delivery_retiring-your-service.md)

Updates to this page
--------------------

Published 4 August 2016

Last updated 19 February 2021
[+ show all updates](#full-history)

1. 19 February 2021

   Updated a link to the Performance Platform as it is being retired. Linked to new guidance about data you must publish instead.
2. 8 May 2019

   Updated to reflect the requirements outlined in the updated Service Standard.
3. 3 October 2017

   Added guidance on how to meet government accessibility requirements in beta.
4. 4 August 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---