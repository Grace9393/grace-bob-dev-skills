Measuring user satisfaction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Measuring user satisfaction
===========================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Set up your service to measure user satisfaction](#set-up-your-service-to-measure-user-satisfaction)
2. [User satisfaction through each service phase](#user-satisfaction-through-each-service-phase)
3. [Planning to increase user satisfaction](#planning-to-increase-user-satisfaction)
4. [Publishing data](#publishing-data)
5. [Related guides](#related-guides)

You must plan to continually improve the user experience of your service. By tracking user satisfaction you can find out what users think about the service and which parts of it cause them problems. This will help you decide what to improve.

Set up your service to measure user satisfaction
------------------------------------------------

You should allow users to give feedback about your service at various stages of using it.

### At the end of your online service

You must allow users to tell you what they think of your service once they’ve finished using it.

You can create your own feedback page to do this while your service is in alpha or private beta.

Before you go into public beta, you must either:

* [request a standard GOV.UK feedback page](service-manual_design_feedback-pages.md)
* continue using your own feedback page if you need to ask specific questions about your service

### Within your service

You’ll also want users to be able to give feedback from any page in your service. To do this, you can create an in-service feedback page and link to it from:

* the footer on every page of your service
* your alpha or beta banner

There is no formal guidance on what questions you must ask. You should at least have an open-ended question about how to improve the service, similar to the one on the GOV.UK feedback page.

### When users drop out

Users can drop out of a service at any point for various reasons. You should try to get feedback from these users as they’ll likely have important insights about how you can improve your service.

To do this:

* use your in-service feedback page
* set up your web analytics to record the point in the service where your users submit feedback and also any feedback scores they give

### Measuring users’ satisfaction with the whole service

Sometimes the end of a transaction is not the end of a user’s experience with the service. For example, if a user claims Carer’s Allowance, the end of the transaction is when they’ve finished submitting their claim. But their experience with the service is not over until they get a decision.

You must still prompt users to give feedback when they finish the digital part of the service and publish this data. However, to measure satisfaction with the whole service, make sure you have a way to collect feedback at the very end of a user’s involvement with it (the ‘end point’).

For example, for users claiming Carer’s Allowance, you could set up a system where you email them when they get a decision.

Services often have many different end points for users. Make sure there’s a way to collect feedback at all of them.

### Include assisted digital support

Some of your users will need help using your digital service, whether over the phone or face to face. This is called [‘assisted digital’ support](https://www.gov.uk/service-manual/assisted-digital). You must measure user satisfaction for your assisted digital support.

The way you should measure these users’ satisfaction differs depending on their circumstances and the support they’ve chosen.

For example, if the user gets support over the phone, you could use interactive voice response (IVR) technology for a survey after they’re finished.

If the user needs face-to-face support because they cannot get online easily, you may have to send out a follow-up survey by post.

User satisfaction through each service phase
--------------------------------------------

### Discovery

You can only measure user satisfaction in discovery if there is an existing service. Use the results as a baseline to see if the new service improves the user experience.

### Alpha

In alpha, find out how satisfied users are with early prototypes of the new service by doing remote usability testing or surveys.

See: [Usability testing](https://en.wikipedia.org/wiki/Usability_testing) on Wikipedia.

### Beta

In beta, continue to measure user satisfaction by doing remote usability testing or satisfaction surveys.

You should also identify why user dissatisfaction with parts of the service may be causing people to drop out, then try to make changes to the service to improve user satisfaction levels.

See: [Usability testing](https://en.wikipedia.org/wiki/Usability_testing) on Wikipedia.

### Live

Once the service is live, measure user satisfaction continually and publish results at least once a month.
You should get feedback from other sources besides your online surveys, for example:

* helpdesks - if your service has one users might tell people who work on it what they think of the service
* social media or discussion forums - users might talk about what they think of your service online

Planning to increase user satisfaction
--------------------------------------

Once live, you must take the following steps to continually improve user satisfaction:

1. Identify statistically significant patterns in satisfaction data and user feedback.
2. Use this data to choose which parts of the service to change.
3. Test these changes on real users using a prototype of the service.
4. Implement any changes that test well.
5. Repeat this process regularly.
6. Continually monitor user satisfaction ratings to make sure that changes have the effect you anticipated.

Publishing data
---------------

Once live, you must [publish user satisfaction data](service-manual_measuring-success_data-you-must-publish.md) at least once a month.

Related guides
--------------

You may find these other guides useful:

* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)

Updates to this page
--------------------

Published 22 March 2016

Last updated 19 February 2021
[+ show all updates](#full-history)

1. 19 February 2021

   Removed reference to the performance platform as this is being retired.
2. 22 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---