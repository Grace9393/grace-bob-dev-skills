Measuring the success of your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Measuring the success of your service
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Measuring transactions](#measuring-transactions)
2. [Measuring an end-to-end journey or non-transactional website](#measuring-an-end-to-end-journey-or-non-transactional-website)
3. [Assessing whether you’re addressing an organisational strategy or policy issue](#assessing-whether-youre-addressing-an-organisational-strategy-or-policy-issue)

There are different ways to measure how your service is performing. The method you should use depends on what you’re trying to find out and whether you’re measuring:

* a transactional service
* an end-to-end user journey, or something non-transactional like a website
* how your service is helping to achieve an organisational strategy or policy

Measuring transactions
----------------------

You can usually see how well a transaction is working for users by using [performance metrics](https://www.gov.uk/service-manual/measuring-success/how-to-set-performance-metrics-for-your-service) combined with user research methods like [usability testing](https://www.gov.uk/service-manual/user-research/using-moderated-usability-testing).

When designing your metrics, think about the types of data to collect that will show you how your transaction is performing.

Don’t just rely on digital analytics. Use a range of data sources – for example user feedback, call centre data or financial information like the costs of hosting your transaction.

Have a performance analyst on your team from the start of discovery and make them part of the process of building your transaction.

Measuring an end-to-end journey or non-transactional website
------------------------------------------------------------

You sometimes need other tools in addition to performance metrics to measure whether something is working.

For example if you need to measure:

* a user journey from GOV.UK guidance into your transaction
* a user journey across multiple transactions that solve a [whole problem](https://www.gov.uk/service-manual/design/scoping-your-service) for users
* a non-transactional service, like information on a website

In these cases, you can use [usability benchmarking](https://www.gov.uk/service-manual/measuring-success/usability-benchmarking-a-website-or-whole-service).

This involves setting users a series of tasks that span across a journey and seeing how easy the tasks are for them to complete.

It commonly involves measuring task completion rates and the time it takes the user to complete each task.

By repeating the process periodically and comparing results you can see if the tasks are getting easier to complete over time.

Assessing whether you’re addressing an organisational strategy or policy issue
------------------------------------------------------------------------------

If you’re looking to prove that your work is addressing a wider strategy - or talk about your work in a way that appeals to stakeholders - use [benefits realisation techniques](https://www.gov.uk/service-manual/measuring-success/measuring-service-benefits).

This helps you work out:

* the size of the problem you’re solving
* how fixing the problems contribute to wider organisational aims or strategies
* how to make a robust case for making one type of intervention over another

Updates to this page
--------------------

Published 6 August 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---