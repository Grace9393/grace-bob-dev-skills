Performance analysis community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Performance analysis community
==============================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Training and events](#training-and-events)
4. [Community resources](#community-resources)
5. [Performance analysis in the Service Manual](#performance-analysis-in-the-service-manual)

The performance analysis community exists to:

* bring together performance analysts across government
* work with user researchers and other analysts to build an evidence-based culture
* discuss and challenge the way government uses digital and non-digital data to improve services and content
* develop and share digital analytics best practice

Who the community is for
------------------------

You might be interested in this community if your work involves:

* making sure decisions are based on evidence
* using analytics (especially digital analytics) to build and improve services for users
* helping product and service owners identify key performance indicators (KPIs) and metrics, measure performance and improve services
* choosing analytics technology and tools
* deciding how to implement digital analytics tools
* exploring new analytics techniques and tools

Get involved
------------

You can use the following online spaces to discuss performance analysis issues:

* [cross-government performance analysts Basecamp](https://basecamp.com/2308334/projects/12291201) - the main cross-government forum for issues related to service performance (request access using your government email address)
* [GOV.UK performance analysts Basecamp](https://launchpad.37signals.com/basecamp/2289933/signin) - a discussion space for anyone using analytics to measure the performance of GOV.UK
* [UK Government Digital #performanceanalysis Slack channel](https://ukgovernmentdigital.slack.com/messages/performance-analysis/) - a place to share news and discussions (create a Slack account using your government email address)

### How to join a Basecamp group

You can either:

* request access by emailing [join-data-performance-analysis@digital.cabinet-office.gov.uk](mailto:join-data-performance-analysis@digital.cabinet-office.gov.uk)
* ask a colleague who’s already part of the group to invite you to it

Training and events
-------------------

The community runs meetups roughly every 2 months. There’s usually a guest speaker from outside government, 2 presentations, and workshops or [show and tells](service-manual_agile-delivery_agile-tools-techniques#team-review-show-and-tell.md). You’ll get an invitation if you’re a member of the cross-government performance analysis community.

Members of the community also present and run workshops at cross-government events such as the Content Conference (ConCon).

Community resources
-------------------

Use these resources to learn more about performance analysis in government:

* [performance analyst role requirements](https://www.gov.uk/government/collections/digital-data-and-technology-job-roles-in-government#data:-performance-analyst) - explains the skills you’ll need to be a performance analyst in government
* [data in government blog](https://gdsdata.blog.gov.uk) - discusses the tools and techniques that government uses for data analysis
* [guide to setting performance metrics](service-manual_measuring-success_how-to-set-performance-metrics-for-your-service.md) - a set of principles for using data to improve your service
* [Inside GOV.UK blog](https://insidegovuk.blog.gov.uk/category/user-insights) - discusses how user insights from data and research have helped improve GOV.UK

Performance analysis in the Service Manual
------------------------------------------

These guides show what we currently believe is best practice in performance analysis in government:

* [Using data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Updates to this page
--------------------

Published 29 March 2016

Last updated 3 November 2022
[+ show all updates](#full-history)

1. 3 November 2022

   Removed mention of the GDS Academy, which has now closed.
2. 19 February 2021

   Removed reference to the Performance Platform as this is being retired.
3. 22 September 2017

   Added details on training courses offered by the community.
4. 22 June 2016

   Added link to the digital analysts UK government services (DAUGS) Basecamp.
5. 29 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---