Design community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Design community
================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Getting involved](#getting-involved)
3. [User-centred design training, events and meetups](#user-centred-design-training-events-and-meetups)
4. [Community resources](#community-resources)

The design community exists to:

* make sure that government services are designed to meet user needs
* create and support a peer group of designers across government
* collaboratively create and improve design patterns and best practice
* build and support the practice of design in government
* share and develop design knowledge and skills across government
* discuss and challenge the way government designs services

Who the community is for
------------------------

You might be interested in this community if you work on government services in any of these roles:

* interaction designer
* graphic designer
* service designer
* content designer
* product analyst

[Watch a video to learn more about the UK government design community](https://www.youtube.com/watch?v=c9Blsd9VZo4).

Getting involved
----------------

If you’re interested in discussing design issues, you can:

* join the digital service designers mailing list - you can request access by emailing [join-digital-service-designers@digital.cabinet-office.gov.uk](mailto:join-digital-service-designers@digital.cabinet-office.gov.uk) using your government email address.
* join the [design channel](https://ukgovernmentdigital.slack.com/messages/design/) or [content design channel](https://ukgovernmentdigital.slack.com/messages/content) on the UK government Slack - you can create a Slack account using your government email address
* share ideas on the [GOV.UK Design System community backlog](https://design-system.service.gov.uk/community/backlog/)
* write blog posts for the [design in government blog](https://designnotes.blog.gov.uk/) or the [services in government blog](https://services.blog.gov.uk/)
* follow and use the [#GovDesign](https://twitter.com/search?f=tweets&vertical=default&q=%23govdesign&src=typd) and [#GovContent](https://twitter.com/hashtag/govcontent) hashtags on Twitter
* join the cross-government [content community Basecamp](https://www.gov.uk/guidance/contact-the-government-digital-service/government-content-community#basecamp)

If you cannot access any of these discussion spaces, email [join-digital-service-designers@digital.cabinet-office.gov.uk](mailto:join-digital-service-designers@digital.cabinet-office.gov.uk) for help.

User-centred design training, events and meetups
------------------------------------------------

The user-centred design communities run [user-centred design training, events and meetups](service-manual_design_user-centred-design-training-and-events.md)
to help support research and design practitioners across government.

The team is also responsible for [Services Week](https://services.blog.gov.uk/2021/03/11/in-case-you-missed-it-this-was-services-week-2021/), a nationwide, cross-government event that looks at how we can work together to deliver end-to-end, user-focused services.

Community resources
-------------------

You may find these resources useful:

* the [Service Manual](https://www.gov.uk/service-manual) to understand how to meet the Service Standard
* the [government design principles](https://www.gov.uk/guidance/government-design-principles) to guide your work
* the [GOV.UK Design System](https://design-system.service.gov.uk) to source styles, components and patterns for your designs
* the [design in government blog](https://designnotes.blog.gov.uk/) to learn more about design in government
* [videos of talks](https://www.youtube.com/channel/UC8aJfySeA2sWfm_DPvZ3uMA/featured) about user-centred design in government
* the [GOV.UK Prototype Kit](https://github.com/alphagov/govuk_prototype_kit) to prototype services that look and work like GOV.UK
* the [govdesign tumblr](https://govdesign.tumblr.com) to find posters and stickers from the government design community

You should also read the:

* [user research in government blog](https://userresearch.blog.gov.uk/)
* [accessibility in government blog](https://accessibility.blog.gov.uk/)
* [services in government blog](https://services.blog.gov.uk/)

Some blog posts worth reading:

* [What we mean by service design](https://gds.blog.gov.uk/2016/04/18/what-we-mean-by-service-design/)
* [The different types of design in government](https://designnotes.blog.gov.uk/2016/04/22/the-different-types-of-design-in-government/)
* [Identifying a good service](https://designnotes.blog.gov.uk/2016/04/22/identifying-a-good-service/)
* [Getting permission to use GOV.UK fonts](https://designnotes.blog.gov.uk/2015/03/11/can-i-use-the-gov-uk-fonts/)

You may also be interested in the following communities:

* [user research community](https://www.gov.uk/service-manual/communities/user-research-community)
* [content community](https://www.gov.uk/service-manual/communities/content-community)
* [accessibility community](https://www.gov.uk/service-manual/communities/accessibility-community)

Updates to this page
--------------------

Published 18 October 2016

Last updated 23 January 2020
[+ show all updates](#full-history)

1. 23 January 2020

   Added links to several new course dates
2. 6 January 2020

   Added link to training now open for registration: user research in government: a basic introduction (London).
3. 18 October 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---