Data you must publish - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Data you must publish
=====================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Data you should also publish](#data-you-should-also-publish)
2. [Where to get information from](#where-to-get-information-from)
3. [Hosting the data and adding to data.gov.uk](#hosting-the-data-and-adding-to-datagovuk)
4. [Data formats you must use](#data-formats-you-must-use)
5. [Visualise your data (optional)](#visualise-your-data-optional)
6. [Make your data available through an API (optional)](#make-your-data-available-through-an-api-optional)
7. [Historical data from the Performance Platform](#historical-data-from-the-performance-platform)
8. [Other KPIs you can use to improve your service](#other-kpis-you-can-use-to-improve-your-service)
9. [Get help](#get-help)
10. [Related guides](#related-guides)
11. [Help improve this guidance](#help-improve-this-guidance)

You must publish data about the performance of your service, and add it to data.gov.uk.

You must publish data on the 4 mandatory key performance indicators (KPIs), which are:

* [cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)

You can no longer share your service’s performance data with the Performance Platform. [The Performance Platform was closed in March 2021](https://dataingovernment.blog.gov.uk/2021/02/18/new-guidance-for-publishing-data/).

Data you should also publish
----------------------------

You should also publish data on your other KPIs. This blog post from the Data in Government blog describes [how the team set up a performance framework for the UK Parliament website](https://dataingovernment.blog.gov.uk/2016/11/02/setting-up-a-performance-framework-for-the-uk-parliament-website/).

Where to get information from
-----------------------------

To gather this data you may need to use information from:

* service desks, call centres and user support
* back-end systems, for example monitoring systems for response times and availability
* web analytics software
* surveys
* finance data

### Getting user satisfaction data

You need to gather, format and publish user satisfaction data manually.

1. Download the data for your service from [Feedback explorer](https://support.publishing.service.gov.uk/anonymous_feedback/explore) if you have a GOV.UK feedback page. If you do not have access, you can [request it from GDS](https://www.gov.uk/guidance/contact-the-government-digital-service/request-a-thing).
2. Remove the comments.
3. Create an overall percentage satisfaction score from the ratings results, including how many users have submitted feedback and numbers for each level of satisfaction, for example ‘Very dissatisfied’, ‘Dissatisfied’ and so on.
4. Create an overall satisfaction rating.
5. Add this to the data you publish for the other mandatory KPIs.

Hosting the data and adding to data.gov.uk
------------------------------------------

You will need to host the data somewhere. You can host the data on your service’s own hosting.

### Add the data to data.gov.uk

You must add the data to data.gov.uk in the [‘Digital service performance’ topic](https://data.gov.uk/search?filters%5Btopic%5D=Digital+service+performance). Find out [how to publish and manage data on data.gov.uk](https://guidance.data.gov.uk/publish_and_manage_data/). If your data is already available through an Application Programming Interface (API) you can link to it directly. You can also link to other formats if they are available.

Do not link to the performance data from your service. People will be able to find all available performance data in a topic on data.gov.uk.

Data formats you must use
-------------------------

You must use open, machine-readable formats to publish your data. Include the mandatory KPIs formatted like [this example data file](https://drive.google.com/file/d/16xbe8X0F8R-VyJeZ0q7pYClzDAJ-K5_O/view?usp=sharing).

The fields you will need to fill in are:

* Transactions
* Cost
* Cost per transaction
* Digital take-up
* Completion rate
* User satisfaction – very dissatisfied (number)
* User satisfaction – dissatisfied (number)
* User satisfaction – neither satisfied nor dissatisfied (number)
* User satisfaction – satisfied (number)
* User satisfaction – very satisfied (number)
* User satisfaction (percent)

If you are providing your data through an API, use this [API data format for service data](https://docs.google.com/document/d/1ho2VLWAm5154KsTKcHYLWt_UWkvtO-vcY5F3L-7wVRw/).

Use as few files as possible for your data, using a single file for each release. Do not upload separate files for data updated regularly. Publish your data in a single data set.

Publish in JSON or CSV format unless you are using a publicly accessible dashboard that makes the data available in another open format. Find out more about [recommended open standards for government](https://www.gov.uk/government/publications/recommended-open-standards-for-government).

Publish as frequently as you can, at least monthly.

Visualise your data (optional)
------------------------------

Data visualisations make your data easier for people to understand. They can also help encourage change in your organisation. The Office for National Statistics publishes a [good practice guide on data visualisation](https://style.ons.gov.uk/category/data-visualisation/).

You do not need to spend a lot of money to make data easier to interpret. Your existing analytics package may be able to produce a dashboard at little to no cost. For example, [Google Data Studio](https://datastudio.google.com/overview) is free and can produce reports. [Grafana](https://grafana.com/grafana/dashboards) is another product some teams use. Remember that any data visualisation must be [accessible to users of assistive technology](https://www.gov.uk/guidance/content-design/images).

This Companies House [blog post about collecting, analysing and presenting data](https://companieshouse.blog.gov.uk/2016/05/31/big-insights-collecting-analysing-and-presenting-data/) talks about the different dashboards they have produced.

Make your data available through an API (optional)
--------------------------------------------------

APIs can help other services make use of your data more easily. Include your API in the [API catalogue](https://api.gov.uk/).

Historical data from the Performance Platform
---------------------------------------------

The Performance Platform was a service provided by the Government Digital Service until March 15 2021. It provided data on the performance of government services.

The National Archives captured [historical service data from the Performance Platform on 15 March 2021](https://webarchive.nationalarchives.gov.uk/20210315084926/https://www.gov.uk/performance).

Other KPIs you can use to improve your service
----------------------------------------------

The mandatory KPIs are a minimum but you will need to gather more data to work out if your service is meeting users’ needs. Learn more about [how to set performance metrics for your service](service-manual_measuring-success_how-to-set-performance-metrics-for-your-service.md).

Get help
--------

If you need help with what data to collect and how to present it, email [performance@digital.cabinet-office.gov.uk](mailto:performance@digital.cabinet-office.gov.uk)

Related guides
--------------

You may also find these guides useful:

* [Using data to improve your service: an introduction](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction.md)
* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)

Help improve this guidance
--------------------------

If you have feedback, a question or a suggestion about this guidance, you can:

* complete the [GOV.UK feedback form](/contact/govuk)
* message us on the [#servicemanual channel on cross-government Slack](https://ukgovernmentdigital.slack.com/archives/C062HDSJU)
* [contact us](https://www.gov.uk/service-manual/communities/contact-the-service-manual-and-service-standard-team)

Updates to this page
--------------------

Published 19 February 2021

Last updated 6 April 2021
[+ show all updates](#full-history)

1. 6 April 2021

   Added a link to historical Performance Platform data, captured by The National Archives on 15 March 2021.
2. 19 February 2021

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---