User-centred design: training and events - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

User-centred design: training and events
========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Service Design Case Studies](#service-design-case-studies)
2. [Capability](#capability)
3. [Get feedback sessions](#get-feedback-sessions)
4. [Services Week](#services-week)
5. [Get involved with the user-centred design communities](#get-involved-with-the-user-centred-design-communities)

The Government Digital Service (GDS) is committed to user-centred design (UCD) as the best way to do digital transformation in government. As the UCD community has matured and grown in scale, we are looking at new, more sustainable models of how we work together across government.

We are identifying different ways for providing support focussing on standards and guidance, supporting departments to deliver their digital transformation programmes.

Service Design Case Studies
---------------------------

Over the years, we’ve gathered service design case studies from various public sector organisations. Previously, we ran monthly online sessions to hear from teams on how they’ve developed their services called Service Thursdays. All sessions were recorded and they are available to UK Public Servants only. Links to the recordings are shared in the [#servicedesign channel on cross-gov Slack](https://ukgovernmentdigital.slack.com/archives/C06GG0NNS) and [#design channel on the local government Slack](https://app.slack.com/client/T02E44UQ5/C3AQZTCLD) under bookmarks.

Capability
----------

The design team at GDS used to meet monthly to discuss a design challenge around a particular topic. Links to the recordings are on the [#servicedesign channel on cross-gov Slack](https://ukgovernmentdigital.slack.com/archives/C06GG0NNS).

Heads of Design across government meet monthly to share challenges, work on shared objectives, and support each other. If you are a head of design in government, Parliament or the NHS you are eligible to join. Email [Government Heads of Design](mailto:government-heads-of-design@digital.cabinet-office.gov.uk) to be added.

Heads of design across government regularly iterate the design skills in the [Government Digital and Data Profession Capability Framework](https://ddat-capability-framework.service.gov.uk/role/graphic-designer). The framework is used to guide the recruitment of designers and to assess capability levels.

Get feedback sessions
---------------------

These are remote design critiques with the cross-government UCD community. They are held in small groups and in a safe and inclusive environment. They take place every Wednesday from 11am to 12:30pm.

Join these sessions if:

* you would like service, interaction, content or graphic design feedback on your work
* you would like to give feedback to help fellow cross-government peers

You do not have to be doing a user-centred design role to join these sessions. For example, they could be helpful for you if you’re on a project team without design help.

Information about how to join these sessions is shared on the [Padlet ‘Get feedback sign up board’](https://padlet.com/getfeedback/get-feedback-sign-up-board-sxqycc6t51o6gy5a).

Services Week
-------------

Services Week is an annual cross public sector event. The aims are to showcase good practice and case studies, upskill public servants in user-centred design, and increase service literacy. The event usually runs in February or March. Any public servant can get involved by running an event, workshop, or show and tell, running training, or blogging.

Find out more on the [#servicesweek channel on cross-gov Slack](https://ukgovernmentdigital.slack.com/archives/CFFU401M3).

Get involved with the user-centred design communities
-----------------------------------------------------

You can find out more about the:

* [design community](service-manual_communities_design-community.md)
* [user research community](service-manual_communities_user-research-community.md)
* [content community](https://www.gov.uk/service-manual/communities/content-community)
* [accessibility community](https://www.gov.uk/service-manual/communities/accessibility-community)

If you’re interested in learning more you can read updates on the community blogs:

* [Design in government blog](https://designnotes.blog.gov.uk/)
* [Services in government blog](https://services.blog.gov.uk/)
* [User research in government blog](https://userresearch.blog.gov.uk/)
* [Accessibility in government blog](https://accessibility.blog.gov.uk/)

Updates to this page
--------------------

Published 14 February 2020

Last updated 16 April 2025
[+ show all updates](#full-history)

1. 16 April 2025

   Updated with information about Services Week and new links to feedback sessions. Service Thursdays and Design Challenges removed.
2. 16 July 2020

   This page has been updated to reflect the recent announcement of the changes to the UCD communities team.
3. 14 February 2020

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---