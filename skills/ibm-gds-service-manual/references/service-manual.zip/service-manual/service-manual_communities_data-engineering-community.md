Data engineering community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Data engineering community
==========================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [Related communities](#related-communities)

The data engineering community exists to:

* share data engineering ideas, experiences and good practice
* increase innovation in data engineering in the public sector
* develop and agree consistent definitions, standards and principles
* champion and facilitate professional development
* promote and support investment in data innovation
* share knowledge, collaboration, and career development opportunities among data professionals

Who the community is for
------------------------

The community is open to anyone working in central government with an interest in data and data engineering. You do not need to be a data engineer to join. Some events are open more widely to all public sector employees.

You might be interested in this community if you are involved in:

* designing and building data products and services
* automating manual data processes
* exploring new data engineering tools and techniques
* producing and maintaining data models
* improving access to high quality data
* translating data into insights that inform decisions
* developing and applying data standards and principles
* working with digital and technology, analysis, policy and operations to understand where data can add the most value

Get involved
------------

To get involved you can:

* [sign up to the data engineering community mailing list](https://forms.office.com/e/GMyrFNry4n) - we’ll use this to let you know about all our events and activities
* join the [#dataengineering channel](https://govdatascience.slack.com/archives/C98RXUW10) on the cross-government data science Slack - you’ll need a public sector email address to join

If you would like to get involved in running the community and organising events and activities, email the community at: [dataengineering@digital.justice.gov.uk](mailto:dataengineering@digital.justice.gov.uk)

Community resources
-------------------

You may find these resources about data engineering in government useful:

* [the role of a data engineer](https://www.gov.uk/guidance/data-engineer) - what a data engineer in government does and the skills you need to do the job
* [Data in government blog](https://dataingovernment.blog.gov.uk/) - discusses how data is being used across government to improve service delivery and policy outcomes

Related communities
-------------------

You may also be interested in the [data science community](service-manual_communities_data-science-community.md) and the [application programming interface community](https://www.gov.uk/service-manual/communities/application-programming-interface-community).

Updates to this page
--------------------

Published 6 July 2021

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---