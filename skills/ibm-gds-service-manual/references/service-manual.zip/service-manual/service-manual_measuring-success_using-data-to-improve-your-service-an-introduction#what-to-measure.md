Using performance data to improve your service: an introduction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Using performance data to improve your service: an introduction
===============================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [What to measure](#what-to-measure)
2. [Measuring from the start](#measuring-from-the-start)
3. [Publishing your performance data](#publishing-your-performance-data)
4. [How to use your performance data](#how-to-use-your-performance-data)
5. [Related guides](#related-guides)

You should consider [all types and uses of data](http://gov.uk/service-manual/design/designing-with-data-an-introduction). Collecting certain data about your service allows you to measure its performance. You can use performance data to make sure:

* the service is meeting user needs
* the service allows users to easily complete the task it provides
* there are enough people using the service to make it cost-efficient
* people know about the service and are choosing to use it

What to measure
---------------

You must collect data that shows how your service is performing against these 4 metrics:

* [cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md) - how much it costs the government each time someone completes the task your service provides
* [user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md) - what percentage of users are satisfied with their experience of using your service
* [completion rate](service-manual_measuring-success_measuring-completion-rate.md) - what percentage of transactions users successfully complete
* [digital take-up](service-manual_measuring-success_measuring-digital-take-up.md) - what percentage of users choose your digital service to complete their task over non-digital channels

These metrics are called the 4 key performance indicators (KPIs).

You’ll also need to choose other KPIs to measure. These will vary depending on your service. Use the work you’ve done to [set performance metrics for your service](service-manual_measuring-success_how-to-set-performance-metrics-for-your-service.md) as the basis for any decisions you make to measure service performance.

### Metrics and measurements

Metrics are measurements that tell you how well something is performing. Typically they’re expressed as a percentage.

For example, if 2000 people tried to complete your service, that’s a ‘measurement’ of total attempts. If 1000 of them successfully completed your service, that’s a ‘measurement’ of completions. Combine the two and you get a ‘metric’ for how often people using the service manage to complete it. In this example the completion rate is 50%.

Measuring from the start
------------------------

You must consider how you’ll measure your service from the start of your project.

In discovery and early alpha, you need to:

* have an analyst as part of your team (or available to your team) so that you can start asking the right questions about how you’re going to measure service performance
* start to [set performance metrics for your service](service-manual_measuring-success_how-to-set-performance-metrics-for-your-service.md) - outline your service’s objectives and explain what data your team should gather to meet them
* estimate the number of people you expect to use the service - be aware that large numbers may mean you need powerful analytics tools
* find out the analytics tools your organisation already has and whether they’re suitable for the type and volume of data you’re expecting
* find out where all your existing data is kept and how you’re going to access it, aggregate it and make it usable so that you can measure your service’s KPIs
* start thinking about the different ways users will interact with your service so you can plan how you’ll gather data

Publishing your performance data
--------------------------------

You must [publish performance data](service-manual_measuring-success_data-you-must-publish.md).

How to use your performance data
--------------------------------

It’s important to use the data you’ve collected to find ways to improve your service and prioritise them.

For example, your completion rate data can help you identify the stages in your user journeys when users are dropping out. Work with your user researcher and plan a round of user research to try to understand why.

You can also segment your user data based on the characteristics of groups of users. For example, you could check if users who are a certain age find the service harder to complete than other users.

If this is the case, you could then work with your user researcher to plan a round of user research with those users.

See: [plan a round of user research](service-manual_user-research_plan-round-of-user-research.md).

Related guides
--------------

You may also find these guides useful:

* [Designing with data: an introduction](service-manual_design_designing-with-data-an-introduction.md)
* [Measuring completion rate](service-manual_measuring-success_measuring-completion-rate.md)
* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)

Updates to this page
--------------------

Published 23 March 2016

Last updated 6 April 2022
[+ show all updates](#full-history)

1. 6 April 2022

   Clarifying that this page is about performance data, and adding signposting to guidance about broader uses of data.
2. 19 February 2021

   Removed reference to the Performance Platform as this is being retired.
3. 23 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---