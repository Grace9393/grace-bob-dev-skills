Plan a round of user research - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Plan a round of user research
=============================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Set your research objectives](#set-your-research-objectives)
2. [Find participants](#find-participants)
3. [Plan the session times](#plan-the-session-times)
4. [Arrange recording and note-taking](#arrange-recording-and-note-taking)
5. [Prepare the prototype or beta service](#prepare-the-prototype-or-beta-service)
6. [Run a practice session](#run-a-practice-session)
7. [Invite people to watch the sessions](#invite-people-to-watch-the-sessions)
8. [Get the team to help out](#get-the-team-to-help-out)
9. [Plan time for analysis](#plan-time-for-analysis)
10. [Related guides](#related-guides)

You can only plan specific rounds of research when you’ve created a [research plan for your service](service-manual_user-research_plan-user-research-for-your-service.md).

Set your research objectives
----------------------------

Each round of user research should have clear objectives. Keep your objectives actionable and to the point.

Work with your team to agree what you want to learn from a round of research. Before starting any research, you should understand:

* what you’re trying to achieve (do you want to understand your users’ behaviour, try out new features or both?)
* which problems you’re trying to solve
* which assumptions or beliefs about your users or service you want to test
* what you need to know now to be able to make an informed decision about what to do next

Once you’ve agreed on your objectives, discuss and agree on which [research methods](https://www.gov.uk/service-manual/user-research#user-research-methods) you’ll use to meet these.

You should use your objectives as topics for your research sessions when you write a discussion guide.

Find participants
-----------------

You’ll need to think about:

* which kinds of participants you need to include
* how you’ll cater for any access needs
* how you’ll find them within your budget
* how you’ll collect their informed consent

Start recruiting participants at least a week before a research session.

Learn more about [finding participants](service-manual_user-research_find-user-research-participants.md) and how to [write a recruitment brief](service-manual_user-research_write-a-recruitment-brief.md).

Plan the session times
----------------------

For lab research:

* plan for no more than 6 one-hour sessions a day
* allow at least 15 minutes between sessions
* allow time for people to eat lunch

For research where you visit participants at home or work:

* plan for no more than 4 one-hour sessions a day
* allow at least 30 minutes between sessions, plus travelling time between them
* allow yourself a break for lunch

Arrange recording and note-taking
---------------------------------

Think about whether you’ll:

* record the sessions and how you’ll do it (video and audio recordings are valuable but can get in the way of research as they take time to set up and make some people self-conscious)
* take notes or a full transcript, and who will do this (you can use a service to create a transcript from a recording)

Prepare the prototype or beta service
-------------------------------------

Your prototype or beta service needs to work from end-to-end and be usable and accessible from the research venue. Run through the test tasks on the day before the research.

If you are visiting participants or using their devices, check firewall restrictions, screen resolutions and browser compatibility.

Run a practice session
----------------------

To make sure your research goes smoothly, consider running through the session with a team member.

This is particularly useful if the sessions include unusual or complicated activities, or the team has made significant changes to your prototype or beta service.

Invite people to watch the sessions
-----------------------------------

For lab-based sessions, think about who needs to attend and who would benefit from observing the sessions (eg product manager, designers, content designers, agency or departmental stakeholders).

Use a spreadsheet to record who is turning up and when so you don’t have too many people in the observation room at once.

Get the team to help out
------------------------

For lab-based sessions, you’ll generally need 2 people to help out in the roles of:

* observation room manager
* participant host

Anyone who understands the aims of the research and is willing to help can do these roles - it doesn’t need to be another researcher or member of the team. For internal or specialist participants, an experienced user researcher can perform both roles.

When you visit participants, bring along a team member as an observer and research assistant.

### Appoint an observation room manager

Your observation room manager is in charge of:

* making sure observers are comfortable and understand what’s happening
* making sure that observers are paying attention and taking notes
* answering observers’ questions
* coordinating discussion and analysis immediately after sessions

Your observation manager needs to be familiar with your objectives and the structure of the sessions.

### Appoint a participant host

If you’re using an agency to recruit participants, you can ask them to provide a host.

The host is responsible for:

* greeting participants when they arrive
* escorting participants to the research room
* contacting participants if they are late

### Appoint a research assistant

You need to have a research assistant with you when you visit participants. They are responsible for:

* taking notes and photographs
* managing recordings
* asking additional questions

Plan time for analysis
----------------------

Make sure you also plan enough time for everyone who was at the sessions to take part in analysis. You should try to do this on the same day or as soon as possible afterwards.

For every 2 hours of research, you should do 1 hour of analysis.

Related guides
--------------

You may find the following guide useful:

* [Plan user research for your service](service-manual_user-research_plan-user-research-for-your-service.md)

Updates to this page
--------------------

Published 16 March 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---