Making your frontend accessible - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Making your frontend accessible
===============================

[Give feedback about this page](/contact/govuk)

From:
:   [Accessibility community](service-manual_communities_accessibility-community.md)

Contents
--------

1. [Using the GOV.UK Design System](#using-the-govuk-design-system)
2. [Building accessible services](#building-accessible-services)
3. [Testing your service’s accessibility](#testing-your-services-accessibility)
4. [Getting help](#getting-help)
5. [Further reading](#further-reading)

You must build your service so it’s accessible to everyone who needs to use it. As a developer you must design and build interfaces that do not introduce [barriers for disabled people](https://www.gov.uk/service-manual/helping-people-to-use-your-service/making-your-service-accessible-an-introduction) and users of assistive technology.

Building in an accessible way helps to future-proof your service, as this will protect it against any changes in technology or your users’ accessibility requirements.

This also helps your service:

* meet the [success criteria of the Web Content Accessibility Guidelines (WCAG) 2.2 design principles](https://www.gov.uk/service-manual/helping-people-to-use-your-service/understanding-wcag#wcag-22-design-principles)
* meet [public sector accessibility requirements](https://www.gov.uk/guidance/accessibility-requirements-for-public-sector-websites-and-apps)
* not breach the [Equality Act 2010](https://www.gov.uk/guidance/equality-act-2010-guidance)

Using the GOV.UK Design System
------------------------------

You should use the [GOV.UK Design System](https://design-system.service.gov.uk/) to build your service wherever possible. The GOV.UK Design System provides accessible styles, components and patterns consistent with other GOV.UK services.

Building your service with components from the GOV.UK Design System helps your service be accessible and responsive. The GOV.UK Design System is regularly tested against the most commonly used [assistive technology and browser combinations](https://www.gov.uk/service-manual/technology/testing-with-assistive-technologies). It also meets level AA of WCAG 2.2.

It’s possible that your service needs to use something not available in the GOV.UK Design System. If that’s the case you should make sure anything you add to your service is accessible. You can also [propose a component or pattern for the GOV.UK Design System](https://design-system.service.gov.uk/community/propose-a-component-or-pattern/).

It’s easy to accidentally introduce accessibility barriers into the HTML, Cascading Style Sheets (CSS) and JavaScript layers of code. This is true even if you use the GOV.UK Design System.

[Use progressive enhancement](https://www.gov.uk/service-manual/technology/using-progressive-enhancement) to make sure your service is still usable if any of the layers above the HTML, such as CSS or JavaScript, fail or if the user switches them off.

Building accessible services
----------------------------

Code that does not follow accessibility best practice may exclude people from using your service. This could mean that:

* users relying on a keyboard cannot access or control the user interface or certain elements
* users cannot customise the appearance of the interface
* screen readers read the content out in the wrong order, or not at all
* screen reader users cannot build a mental model of the page or navigate to relevant content
* screen reader users cannot tell that visual-only content has updated
* speech recognition software users cannot interact with the interface, for example not being able to activate links, buttons or form fields

Before turning a design or prototype into production code you should check if there are any accessibility issues in the design. These can include:

* a confusing layout
* poor colour contrast
* non-obvious interactive elements

There could also be issues with the content, such as:

* [links that aren’t descriptive](https://www.gov.uk/guidance/content-design/links)
* [images that don’t have alt text](https://www.gov.uk/guidance/content-design/image-copyright-standards-for-gov-uk)
* descriptions that rely on the user’s ability to see the page, like ‘click the button on the left’
* page titles on the service that are not unique

Work with your content designer or technical writer to fix these issues.

Some users may need to extend time limits, for example how long they’re logged in to your service before being automatically signed out. Make sure users are able to [extend these time limits](https://www.w3.org/TR/UNDERSTANDING-WCAG20/time-limits-required-behaviors.html) if they need to.

### Writing accessible HTML

You should follow the [principles of Semantic HTML](https://html.com/semantic-markup/). Using the correct HTML elements and attributes to mark up the content means the right information is available to assistive technology. It also means assistive technology users can interact with the content or interface as they would expect.

Using the correct elements in your HTML helps users of assistive technologies navigate through your pages, including letting them jump to relevant sections. For example, make sure you use `header`, `main` and `footer` elements to outline the [page structure](https://www.w3.org/WAI/tutorials/page-structure/).

Using appropriate HTML elements allows assistive technologies to understand and operate your interface more easily. For example, buttons should always use `button`, not `div`.

Always make sure the content of a page is in a logical order and does not rely on CSS or JavaScript to reorder content after the page loads. This means [screen readers read out the content in the right order](https://alistapart.com/article/semantics-to-screen-readers/).

Use heading elements in your content. [Headings](https://www.w3.org/WAI/tutorials/page-structure/headings/) tell screen readers how the content on the page is organised, giving users an overview of the content. Avoid skipping heading elements, such as from `h1` to `h3`, as this can confuse screen readers.

Other common accessibility errors introduced when writing HTML can include:

* not providing labels for [form fields](https://www.w3.org/WAI/tutorials/forms/) or associating labels with form fields correctly
* not using the correct [list type](https://www.w3.org/WAI/tutorials/page-structure/content/#lists)
* using a [table](https://www.w3.org/WAI/tutorials/tables/) to build page layout - you should only use tables to display tabular data

### Writing accessible CSS

Take care when writing CSS as it’s easy to accidentally introduce accessibility barriers.

You should make sure you:

* do not use `display:none` to hide [content that screen readers need to announce](https://cloudfour.com/thinks/see-no-evil-hidden-content-and-accessibility/)
* set text and background [colour contrast](https://webaim.org/articles/contrast/) to an acceptable level
* add a focus state to any [interactive or focusable element](https://www.washington.edu/accessibility/checklist/focus/)
* avoid interface elements that have a small touch area

Some users customise the appearance of web pages to suit their needs. To support these users you should make sure:

* all content is still readable if the user increases the font size
* users can change the colours on the page, without [essential elements becoming invisible](https://accessibility.blog.gov.uk/2018/08/01/supporting-users-who-change-colours-on-gov-uk/)

If possible, you should avoid using CSS to [reorder content](http://adrianroselli.com/2015/09/source-order-matters.html) on a page as this could cause issues for keyboard and screen reader users.

### Writing accessible JavaScript

You must tell your users if content dynamically changes. For example, screen readers cannot pick up search results that update in real time. You can use [ARIA live regions](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/ARIA_Live_Regions) to announce dynamic content changes as they happen.

[WAI-ARIA](https://www.w3.org/WAI/standards-guidelines/aria/) can be easy to implement incorrectly, which can result in disabled people being unable to use your service. You must follow the [correct specifications and recommended approaches for WAI-ARIA](https://www.w3.org/TR/wai-aria-practices-1.1/).

When using WAI-ARIA, make sure you:

* add interaction-specific WAI-ARIA attributes such as `aria-controls` using JavaScript, so that users without JavaScript are not confused
* update WAI-ARIA attributes as JavaScript changes occur on the page, for example set `aria-expanded` to `true` once a user expands an element

Testing your service’s accessibility
------------------------------------

You should perform a manual check against WCAG 2.2 and test with the most common [assistive technology and browser combinations](https://www.gov.uk/service-manual/technology/testing-with-assistive-technologies).

Your [manual tests](https://www.gov.uk/service-manual/helping-people-to-use-your-service/testing-for-accessibility#manual-testing) should cover common accessibility issues, for example testing that:

* your service works with a keyboard
* users can adapt the interface, such as by increasing font size or changing colour in the browser

You must [test for accessibility](https://www.gov.uk/service-manual/technology/testing-for-accessibility) regularly when you’re writing production code. Once your service is in public beta, you must test for accessibility each time you add a new feature.

You can test your service with an [automated accessibility testing tool](https://www.gov.uk/service-manual/helping-people-to-use-your-service/testing-for-accessibility#automated-testing). However, [accessibility tools will not catch all errors](https://accessibility.blog.gov.uk/2017/02/24/what-we-found-when-we-tested-tools-on-the-worlds-least-accessible-webpage/), so you must carry out manual tests as well.

### Using accessibility criteria

[Accessibility acceptance criteria](https://insidegovuk.blog.gov.uk/2018/01/24/improving-accessibility-with-accessibility-acceptance-criteria/) are specific rules you can apply to service components to help with accessibility testing. Accessibility criteria help you decide what you need to test.

For example, a link does not need an associated label, but it does need clear text to describe where the link goes. Acceptance criteria like this can help maintain the accessibility of a service as you add or update features.

Getting help
------------

Contact the [accessibility community](https://www.gov.uk/service-manual/communities/accessibility-community) to:

* discuss how to build accessible services and meet accessibility requirements
* share ideas across government
* find support from teams that have worked on similar services or faced similar challenges

Further reading
---------------

You might find the following things useful:

* Google’s [Web Fundamentals on accessibility](https://developers.google.com/web/fundamentals/accessibility/)
* [A11ycasts](https://www.youtube.com/playlist?list=PLNYkxOF6rcICWx0C9LVWWVqvHlYJyqw7g) accessibility videos
* [Accessibility Developer Guide](https://www.accessibility-developer-guide.com/) to accessible web design
* Manuel Matuzovic’s series on writing [HTML](https://medium.com/alistapart/writing-html-with-accessibility-in-mind-a62026493412), [CSS](https://medium.com/@matuzo/writing-css-with-accessibility-in-mind-8514a0007939) and [JavaScript](https://medium.com/@matuzo/writing-javascript-with-accessibility-in-mind-a1f6a5f467b9) with accessibility in mind
* Mozilla’s guidance on using an [accessibility inspector](https://developer.mozilla.org/en-US/docs/Tools/Accessibility_inspector)

Updates to this page
--------------------

Published 22 November 2017

Last updated 28 June 2019
[+ show all updates](#full-history)

1. 28 June 2019

   Added more information to the guidance, as well as links to resources for developers to help build accessible services.
2. 22 November 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---