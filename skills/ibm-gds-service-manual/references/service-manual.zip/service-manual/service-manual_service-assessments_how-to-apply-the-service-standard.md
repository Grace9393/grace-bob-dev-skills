How to apply the Service Standard - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

How to apply the Service Standard
=================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Applying the Service Standard](#applying-the-service-standard)
2. [Get help if you work in UK central government](#get-help-if-you-work-in-uk-central-government)
3. [Get help if you work in UK local government](#get-help-if-you-work-in-uk-local-government)
4. [Useful links](#useful-links)

Government services are often trying to solve complex problems. And the environment in which they’re created is complex, too. For example, it often involves dealing with legacy technology, or with working practices that take time to change because they’re based on contractual commitments.

You cannot solve a complex problem in one go. You have to start small with something that’s just complex enough to learn from - then put it in front of users, and iterate based on what you learn.

This approach allows you to release new or improved services quickly and regularly. Which is great, because that’s when they start making a difference to users.

Applying the Service Standard
-----------------------------

Whether a service has done enough to meet [the Service Standard](service-manual_service-standard.md) is a matter of judgement. But bear in mind that there are problems you can iterate your way out of, and problems you cannot.

For example, it may not make sense to hold up release of a new transaction because the user experience is not perfect. As long as you’re carrying out the right user research, you can generally iterate your way out of that sort of problem.

On the other hand, there are some problems you cannot iterate your way out of. For example, by the time it’s at the stage when it’s going to be used by real users, a service should always:

* meet [accessibility standards](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [be secure](service-manual_technology_securing-your-information.md), and not put government or user data at risk

And the service team should avoid locking in a solution that cannot be iterated because of choices they make about contracts or technology.

### Making transactional services work as part of a wider user journey

If a service team is [bringing transactions together as part of a wider service](service-manual_design_scoping-your-service.md), it’s unlikely that they’ll be able to fix everything at once.

For example, it might make sense to fix the content on GOV.UK as a first step. And use that as an opportunity to carry out research and learn more about what users need from the transactions.

But service teams should be able to demonstrate that they’re doing what makes sense from a strategic point of view, with the aim of providing the best possible experience for users. Rather than being limited by [organisational boundaries](service-manual_agile-delivery_working-across-organisational-boundaries.md), for example.

Get help if you work in UK central government
---------------------------------------------

If you have a UK central government email address, you can join the [#standards-assessments Slack channel](https://ukgovernmentdigital.slack.com/messages/C0M4H0GVB/).

Or you can contact your department’s assessment team.

Get help if you work in UK local government
-------------------------------------------

If you’re working in local government you can [use the localgov digital Slack channel](https://localgovdigital.slack.com/?redir=%2Fmessages%2Fgeneral) to ask questions.

Useful links
------------

* [Download a Service Standard poster](https://github.com/alphagov/govdesign/blob/master/Poster-new-service-standard.pdf)
* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [Apply the Service Standard in the alpha phase](service-manual_agile-delivery_how-the-alpha-phase-works#meeting-the-standard-at-alpha.md)
* [Apply the Service Standard in the beta phase](service-manual_agile-delivery_how-the-beta-phase-works#meeting-the-service-standard-at-beta.md)
* [Meet the standard to go live](service-manual_agile-delivery_how-the-live-phase-works#meeting-the-standard-to-move-into-live.md)

Updates to this page
--------------------

Published 8 May 2019

Last updated 10 June 2021
[+ show all updates](#full-history)

1. 10 June 2021

   Updated information about which version of the standard to use.
2. 8 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---