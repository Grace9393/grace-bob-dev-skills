What a service is - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

What a service is
=================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [What an outcome is](#what-an-outcome-is)
2. [What government provides to deliver an outcome](#what-government-provides-to-deliver-an-outcome)
3. [Services which work across different parts of government](#services-which-work-across-different-parts-of-government)

A service is all the things that government collectively provides to deliver an outcome for all of its users, through any path they take to reach their goal.

Some things that form part of users’ overall journey may not be within government’s control. It’s important to be aware of those parts and to try to influence their improvement.

Learn about [users and their needs](https://www.gov.uk/service-manual/user-research/start-by-learning-user-needs).

What an outcome is
------------------

An outcome is made up of 2 elements:

* a user need
* something government intends to deliver, like a new policy

There are 3 levels of outcome. These are:

* the outcome delivered as part of a specific process or step in a journey - for example, the user understands that their application for a driving licence has been processed
* the wider outcome for government - for example, the government is sufficiently confident that the user has passed a driving test
* the overall outcome government and users need - for example, the user can legally and safely drive a car

An overall service outcome is often part of an even wider user journey. For example, a user’s need to drive a car on the road could be part of caring for a relative who has become ill.

When government delivers an outcome, a user usually gets something along the way that has a policy intent behind it. For example, users could get:

* permission to do something - by registering to vote
* money - through a benefits claim
* confirmation of a payment - when paying taxes
* an artefact of some kind - a driving licence
* information - when checking for flood alerts

Some services deliver multiple different outcomes at different times.

What government provides to deliver an outcome
----------------------------------------------

To deliver an outcome for users, a service usually includes a number of different things:

* public-facing and staff-facing systems, including their products and processes
* people and the tasks they carry out to run those systems
* the buildings and infrastructure which house them

Users of services may also be government staff, using the service as part of their work. For example, they could be applying for a training course, claiming expenses or booking travel.

For users of a service this includes all the things they encounter when using it, for example:

* the search functions, navigation, and guidance they use to find information
* the people they contact by email or telephone for help
* the channel they choose
* the digital or non-digital steps they need to complete
* all the relevant checks, casework and processing after the transaction
* support if they ask for help or an update, or if they complain
* the outcome they get

For the service to work for everyone it has to work across all the channels users need, for example:

* websites
* apps
* text
* post
* phone
* face-to-face
* promotional material
* advertising

A service also includes all the technology and data that supports its operation from start to finish. This could include technology and data provided by third parties, for example:

* third party products or services that have been procured from private sector companies
* the technology a bank might use to process a payment

Read more about [providing a joined up service across channels](https://www.gov.uk/service-manual/service-standard/point-3-join-up-across-channels).

Services which work across different parts of government
--------------------------------------------------------

It usually takes more than one part of government to deliver a whole service. Users are likely to interact with things provided by several different organisations, functions and professions. For example:

* ministerial departments like the Ministry of Justice
* [public bodies](https://www.gov.uk/guidance/public-bodies-reform) like the Driver and Vehicle Licencing Agency
* the [Government Digital and Data function](https://www.civil-service-careers.gov.uk/professions/working-in-digital-data-and-technology/)
* the [Operational Delivery profession](https://www.gov.uk/government/organisations/civil-service-operational-delivery-profession)
* third-party suppliers

Read more about [working across organisational boundaries](https://www.gov.uk/service-manual/design/working-across-organisational-boundaries).

Updates to this page
--------------------

Published 10 March 2025

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---