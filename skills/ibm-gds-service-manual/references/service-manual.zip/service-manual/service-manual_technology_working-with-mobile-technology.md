Making sure your service works well on mobile - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Making sure your service works well on mobile
=============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (frontend development)](service-manual_communities_technology-community-frontend-development.md)

Contents
--------

1. [Finding the right approach for your service](#finding-the-right-approach-for-your-service)
2. [Building a responsive website](#building-a-responsive-website)
3. [Building an app](#building-an-app)
4. [Progressive Web Apps](#progressive-web-apps)
5. [Native apps](#native-apps)
6. [Related guides](#related-guides)

Your service should work well on all mobile devices. Evaluate your options carefully to find the most suitable solution for your users.

Finding the right approach for your service
-------------------------------------------

Users expect government services to work on whatever device or browser they choose to use.

A responsive website is usually the best way to do this. Compared to native apps, responsive websites:

* do not require the user to download anything, making them easier for the user to find and use - and saving on the user’s data allowance
* are usually easier and less expensive to develop, maintain and iterate because they do not need different versions for different operating systems
* make it easier to measure how the service is used, compared to measuring how an app is used after it’s been downloaded

Building a responsive website
-----------------------------

Building a responsive website (or a responsive service that’s part of GOV.UK) means using:

* [responsive design](https://alistapart.com/article/responsive-web-design) to make sure your website works on [different browsers and devices](https://www.gov.uk/service-manual/technology/designing-for-different-browsers-and-devices)
* [progressive enhancement](https://www.gov.uk/service-manual/technology/using-progressive-enhancement), which will also make your service reliable

Building your service in this way means users get the same content and functionality, regardless of how they access your service. And it will help you to meet [government accessibility requirements](https://www.gov.uk/service-manual/helping-people-to-use-your-service/making-your-service-accessible-an-introduction#meeting-government-accessibility-requirements).

Building an app
---------------

An app may be the right solution in some circumstances. For example:

* the service only works if it has a persistent presence on the user’s device - for example, some apps designed to help the user live a healthier lifestyle
* the service needs to interface with specific features of the user’s device
* the user needs to collect and store data, but will not have consistent internet access

If you think an app is the right option for your service, you’ll need to show clear evidence as part of your [spend request](https://www.gov.uk/service-manual/agile-delivery/spend-controls-check-if-you-need-approval-to-spend-money-on-a-service) or internal pipeline process.

You’ll show that the need cannot be met by opening up your data via an Application Programming Interface (API) and letting the market meet any need for an app. For instance when Transport for London opened up its APIs, it resulted in the creation of Citymapper - a popular travel app.

Progressive Web Apps
--------------------

Advances in browser technology have made it possible to do things on the mobile web that you could previously only do with native apps. Services that take advantage of these modern browser enhancements are often called mobile web apps or [Progressive Web Apps (PWAs)](https://technology.blog.gov.uk/2018/03/26/progressive-web-apps-bring-us-new-mobile-opportunities/). You should use your [alpha discovery](https://www.gov.uk/service-manual/agile-delivery/how-the-alpha-phase-works) and prototyping sessions to explore how they might help you.

The user experience of PWAs on a handset is almost identical to a native app. But, unlike native apps, PWAs have a single codebase that works on the web like any normal website.

A benefit of PWAs over native apps for the government is that there’s no need to maintain lots of different operating system versions of the same app. This makes them relatively inexpensive to develop compared to native apps. It’s also important to remember that you may still need to tailor your PWA to suit specific device features.

If your user research is leading you to consider a native app, you should first look to see if PWAs might solve the problem.

### PWA functionality

With PWAs, users can access the following native APIs through their browser:

* offline mode
* push notifications
* Bluetooth
* speech recognition
* file access
* geolocation
* camera and sound recording
* device motion

The site [What Web Can Do](https://whatwebcando.today/) is a good place to check for the current features available on the web platform.

Users can choose to install PWAs on any device that supports the technology. If a user chooses to install a PWA, they typically take up less space than the equivalent native app.

PWAs cost less than native apps, since they only need to be developed once for different platforms. They are also forward-compatible with future upgrades to operating systems.

[Google Chrome](https://developers.google.com/web/progressive-web-apps/), [Mozilla Firefox](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps), [Microsoft Edge](https://blogs.windows.com/msedgedev/2018/02/06/welcoming-progressive-web-apps-edge-windows-10/), [Apple Safari and iOS Safari](https://developer.apple.com/library/archive/releasenotes/General/WhatsNewInSafari/Articles/Safari_11_1.html#//apple_ref/doc/uid/TP40014305-CH14-SW1), and [Samsung Internet](https://developer.samsung.com/internet/android/releases) support PWA functionality, which equates to [90% of global browser use](https://caniuse.com/#search=service%20worker) as of April 2019.

PWAs for government services are still in their early stages, and you’ll need to do user research and examine your data to check if they are the best option for your use case. As with any technology, PWAs do have their own drawbacks and constraints - for example, storage on a device can be a limiting factor. For this reason, it’s important to consider how using a PWA will impact your service and users on a case by case basis.

### Things to consider before developing a PWA

Before you develop a PWA, you need to be sure you know:

* who your users are
* what platforms they use to access your app
* how your users use any existing websites or native apps for your service
* what kind of connectivity your users have
* how much data your intended PWA will use
* if your analytics data shows adequate support for service workers and the [web app manifest](https://caniuse.com/#feat=web-app-manifest)

Native apps
-----------

Native apps are apps for specific operating systems that users download onto their devices.
Sometimes an app may need access to wider functionality than any web app can currently provide. In this case, you may decide a native app is the best solution. For example, if the offline user data needs to be encrypted - this is currently easier and more secure to do in a native app.

If you’re developing a native app, where possible you’ll need to make sure it works the same way on a variety of operating systems - such as Android and iOS.

If you have a small, closed user group who all have the same device, you’ll only need to ensure it works for one operating system. You’ll still need to understand the implications of being tied to one vendor, and support any updates to the operating system.

### What to do if you’re limited by device functionality

If your native app requires functionality that’s only available on a certain number of devices, you’ll need to treat the app as an enhancement to your service.

This means offering it to users who’ve got those devices as the easiest way for them to complete their task. However, you’ll need to provide a way for other users with different devices to complete their task too - and take reasonable steps to make it as simple as possible for them to do so.

Related guides
--------------

You may also find these guides useful:

* [How user research improves service design](service-manual_user-research_how-user-research-improves-service-design.md)
* [Making prototypes](service-manual_design_making-prototypes.md)
* [Using, adapting and creating patterns](https://www.gov.uk/service-manual/design/using-adapting-and-creating-patterns)

Updates to this page
--------------------

Published 27 October 2016

Last updated 10 May 2019
[+ show all updates](#full-history)

1. 10 May 2019

   Updated guidance to include information on progressive web apps (PWAs)
2. 13 June 2018

   Updated guidance around native and hybrid apps.
3. 27 October 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---