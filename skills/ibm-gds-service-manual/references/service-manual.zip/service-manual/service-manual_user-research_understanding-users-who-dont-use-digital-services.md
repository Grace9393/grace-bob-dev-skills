Understanding users who do not use digital services - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Understanding users who do not use digital services
===================================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Find out why people do not use your digital service](#find-out-why-people-do-not-use-your-digital-service)
2. [Doing research with users who do not use digital services](#doing-research-with-users-who-do-not-use-digital-services)
3. [Defining your assisted digital users](#defining-your-assisted-digital-users)
4. [Related guides](#related-guides)

You need to do research to find out why some of your users may avoid using digital services or choose non-digital alternatives.

This will help you to:

* design a digital service that works for as many users as possible
* provide the best support for all users who need help using the digital service (this is called [‘assisted digital support’](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md))

Find out why people do not use your digital service
---------------------------------------------------

There are many reasons why people may be unwilling or unable to use a digital service, for example:

* they prefer non-digital channels and are reluctant to switch to the digital service
* they cannot access or afford the technology to go online
* they lack, or believe they lack, the digital skills required to use the service
* they lack the confidence to try
* they lack language or literacy skills
* they have mental health issues or learning difficulties that stop them from using a digital service
* the service is not designed in a way that makes it easy for people with physical or cognitive disabilities to use (see [Making your service accessible](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md))

You need to find out which of these issues are stopping your users from using your digital service. It could be one issue or a combination. Understanding this will allow you to provide the best type of support for your users.

For example:

* if you’re working with the Personal Independence Payment (PIP), you need to consider that many of your users have disabilities that make it difficult for them to go online
* if you’re working with UK visa services, you need to consider that many of your users will have a low level of English literacy
* if you’re providing services to people in rural areas, your users are less likely to have access to broadband internet

See: [Plan user research for your service](service-manual_user-research_plan-user-research-for-your-service.md)

Doing research with users who do not use digital services
---------------------------------------------------------

### Who to include in your research

When you’re researching with users who do not use digital services (and therefore may need assisted digital support), you should include:

* only people who are current users of your service or who are likely to use it in future
* users with the lowest levels of digital skill, confidence and internet access - this helps you understand people whose support needs are the most difficult to meet, for example they may be housebound or have no computer
* users who get assisted digital support from third parties
* users with high levels of digital skill, confidence and internet access - they may still need help with an online service, for example if the service is complex or they do not trust it

### How to do your research

When carrying out your research, you should:

* talk directly to users
* specifically address users’ assisted digital support needs, as opposed to their general support needs or merely testing on-screen elements of your service
* hold the research in places where users use the service, for example if they need to go to the post office to get support, do it there
* make sure users’ digital skills are assessed by an expert user researcher and not by users themselves - people often misjudge their own skill levels
* show the on-screen service to all users, including those with low levels of digital skills and confidence, so they can give you accurate feedback on the support they would need
* research with third parties that support users, including contact centres, libraries, friends and family, trade bodies, paid intermediaries, charities or colleagues

You could also use things like [Citizens Advice data](https://www.citizensadvice.org.uk/about-us/our-work/advice-trends/) to understand users’ circumstances.

Defining your assisted digital users
------------------------------------

The following tools may help you get a better understanding of your users who may need assisted digital support:

* the digital inclusion scale
* assisted digital personas

### The digital inclusion scale

The digital inclusion scale is a graph that helps you understand the digital skills and attitudes of your users. It describes 9 typical users based on their digital skills level, from those who cannot or will not use the internet to experts with advanced digital skills.

Read a [detailed explanation of all the points in the digital inclusion scale](https://www.gov.uk/government/publications/government-digital-inclusion-strategy/government-digital-inclusion-strategy#annex-2-digital-inclusion-scale-for-individuals).

Point 7 on the scale represents users with ‘basic digital skill’ - this is the minimum ability that people need to have in order to use the internet effectively. Users with basic digital skill can manage their information, communicate online, carry out transactions, create things and problem solve.

Read a [detailed explanation of basic digital skills](https://www.gov.uk/government/publications/essential-digital-skills-framework/).

You can use the scale to:

* show what level of digital skill users need to transact with your service
* plot the digital skill levels of your users

You must provide assisted digital support to users who are below the level required to complete the digital service.

Plot users onto the scale to get a useful snapshot of the types of challenges they face. You can use this as a starting point for planning how to move users up the scale so they can eventually use the service independently.

Read [how the MoJ used the digital inclusion scale](https://assisteddigital.blog.gov.uk/2016/02/23/getting-the-balance-rightmapping-users-on-the-digital-inclusion-scale-mapping-your-users-against-the-digital-inclusion-scale/) to understand users of the Help with fees service.

### Assisted digital personas

From your data and research you can write user personas. These are descriptions of typical users which you make up to represent people who’ll need assisted digital support to use your service.

You should use these personas to help you to understand how people interact with your service, including the parts of your service they find difficult or impossible to complete and why.

The Government Digital Service (GDS) has created 8 personas which represent users who are likely to need assisted digital support. You can use these as a starting point for creating your own personas.

Download the [GDS assisted digital user personas document (ODT, 57kb)](https://assets.publishing.service.gov.uk/media/586cd69440f0b60e4c00010b/ad-personas-march-2015.odt).

Accurate personas will help you to [write user stories](service-manual_agile-delivery_writing-user-stories.md) that show what your users need and why, including their support needs.

Related guides
--------------

* [Assisted digital support: an introduction](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)
* [Designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md)
* [How user research improves service design](service-manual_user-research_how-user-research-improves-service-design.md)
* [Start with user needs](service-manual_user-research_start-by-learning-user-needs.md)

Updates to this page
--------------------

Published 8 April 2016

Last updated 28 June 2016
[+ show all updates](#full-history)

1. 12 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---