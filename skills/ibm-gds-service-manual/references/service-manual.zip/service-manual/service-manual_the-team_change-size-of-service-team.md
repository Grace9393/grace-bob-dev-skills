Change the size of a service team - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

Change the size of a service team
=================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [When to scale up](#when-to-scale-up)
2. [How to scale up](#how-to-scale-up)
3. [Managing productivity and pace](#managing-productivity-and-pace)
4. [Get the right people](#get-the-right-people)
5. [How to reduce the size of your team](#how-to-reduce-the-size-of-your-team)
6. [Examples and case studies](#examples-and-case-studies)
7. [Related guides](#related-guides)

It’s normal for a team’s size to increase and decrease over the life of a service as the amount and type of work changes. Increasing or decreasing your team size is known as ‘scaling up’ or scaling down’.

Read more about [the team size you’ll need in each service phase](service-manual_the-team_set-up-a-service-team.md).

When to scale up
----------------

You should only consider scaling up when everyone is already working well together. You should talk to your team about when it thinks scaling up would be a good option.

You may need to scale up if there’s too much work for the team. However, [adding more people to a late digital project can often make it later.](https://en.wikipedia.org/wiki/Brooks%E2%80%99_law)

If your project is behind schedule and you won’t be able to finish what you promised on time, you might need to redefine your [minimum viable product (MVP).](https://en.wikipedia.org/wiki/Minimum_viable_product)

Before hiring more people, check if the [work backlog](service-manual_agile-delivery_agile-tools-techniques.md) is as big as you think, eg whether everything in it needs to be completed by a fixed date.

How to scale up
---------------

You can scale up by adding people to existing teams or by creating new teams. Only consider creating a new team if you feel it’s impractical to increase the size of an existing one.

Add team members when you need them instead of hiring as many people as you can at the very beginning of your project.

Read the following guides to learn more about recruiting your team:

* [Recruit your team](service-manual_the-team_recruit-your-team.md)
* [Working with contractors or third parties](service-manual_the-team_working-contractors-third-parties.md)

### Splitting into 2 or more teams

If your team becomes too big to work effectively, [split it into smaller teams](service-manual_the-team_running-more-than-one-team.md).

Your team might be too big if:

* the daily standup meeting lasts more than 15 minutes
* team members’ updates aren’t relevant to everyone
* smaller standups start happening after the main standup so people who are working together can plan better

It can also make sense to split a big team when certain features of your service need a different mix of skills. Having smaller teams can make communication easier, but teams working on particular features should still be multidisciplinary.

Managing productivity and pace
------------------------------

Adding more people can sometimes slow down the pace of work. Prepare for a drop in productivity while new people are brought up to speed and integrated into the team.

If you hire too many people at once, it could lead to a permanent drop in productivity due to communication and coordination difficulties.

When creating new teams, there’s also a risk that you could lose your [agile delivery culture](service-manual_agile-delivery_create-agile-working-environment.md). Try to put existing team members who know how your culture works into new teams - this can help to provide continuity.

Get the right people
--------------------

Only add more people when you’re confident they’re a good fit for your team and have the right skills and experience. If you can’t immediately find the right people to work on the service, change your scope or delivery deadlines instead of hiring people who aren’t suitable.

How to reduce the size of your team
-----------------------------------

When your service moves from beta to live, you’ll usually have met more user needs and have less work left to do. This means you’ll need to plan how and when to reduce the size of your team.

To work out when and how to do this, you should review your service’s roadmap, release plans and product backlog with your team.

You should consider whether to merge teams and bear in mind that remaining team members will need time to reorganise their work.

Examples and case studies
-------------------------

Learn how government departments and agencies changed their service teams:

* [Creating a winning team](https://mojdigital.blog.gov.uk/2014/05/28/creating-a-winning-team-at-ds/) - Ministry of Justice blog post about splitting the team for their court finder and tribunal decisions services
* [What we’ve learnt about scaling agile](https://gds.blog.gov.uk/2012/10/26/what-weve-learnt-about-scaling-agile/) - Government Digital Service blog post about going from a single team of 12 people to 14 teams in 18 months

Related guides
--------------

You may also find the following guides useful:

* [Recruit your team](service-manual_the-team_recruit-your-team.md)
* [Running more than one service team](service-manual_the-team_running-more-than-one-team.md)
* [Working with contractors or third parties](service-manual_the-team_working-contractors-third-parties.md)

Updates to this page
--------------------

Published 3 March 2016

Last updated 3 March 2016
[+ show all updates](#full-history)

1. 6 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---