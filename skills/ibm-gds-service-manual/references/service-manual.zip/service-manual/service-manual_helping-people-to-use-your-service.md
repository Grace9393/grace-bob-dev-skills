Accessibility and assisted digital - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Accessibility and assisted digital
==================================

Help and encourage people to use your service: accessibility, assisted digital, user support.

Meeting accessibility requirements
----------------------------------

Getting an audit, understanding WCAG 2.2, preparing for assessment.

* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Understanding WCAG 2.2](service-manual_helping-people-to-use-your-service_understanding-wcag.md)
* [Getting an accessibility audit](service-manual_helping-people-to-use-your-service_getting-an-accessibility-audit.md)
* [Testing for accessibility](service-manual_helping-people-to-use-your-service_testing-for-accessibility.md)

Providing assisted digital support
----------------------------------

Helping people who don’t have the skills or access to use a service.

* [Assisted digital support: an introduction](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)
* [Designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md)
* [Encouraging people to use your service online](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md)
* [How your assisted digital support will be assessed](service-manual_helping-people-to-use-your-service_how-your-assisted-digital-support-will-be-assessed.md)

Managing user support
---------------------

Estimating demand, setting target levels, measuring support performance.

* [Set up and manage user support](service-manual_helping-people-to-use-your-service_set-up-and-manage-user-support.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [Accessibility community](service-manual_communities_accessibility-community.md)
* [Assisted digital and digital take-up community](service-manual_communities_assisted-digital-and-digital-take-up-community.md)
* [User support community](service-manual_communities_user-support-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/helping-people-to-use-your-service)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---