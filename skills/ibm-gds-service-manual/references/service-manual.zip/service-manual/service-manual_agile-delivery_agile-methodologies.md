Agile methods: an introduction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Agile methods: an introduction
==============================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Popular agile methods explained](#popular-agile-methods-explained)
2. [Working with multiple agile methods](#working-with-multiple-agile-methods)
3. [Deciding which methods to work with](#deciding-which-methods-to-work-with)
4. [Related guides](#related-guides)

There are many agile methods you can use when building your service, each has its own set of tools and techniques.

This guide introduces the 3 most popular agile methods:

* Scrum
* Kanban
* Lean

Popular agile methods explained
-------------------------------

### Scrum

Scrum is the most commonly used agile method.

It allows a highly structured model with clearly defined roles and responsibilities. This can be particularly useful for traditionally structured organisations that are moving to agile.

Learn more about the features of Scrum in the [Scrum Guide](http://www.scrumguides.org/scrum-guide.html), written by the developers of Scrum, Ken Schwaber and Jeff Sutherland.

### Kanban

Kanban as a development method was inspired by production systems that focus on reducing waste and improving quality, like those created by Toyota.

Kanban is a way of visualising and improving your current working practices so that work flows through a system quickly.

A fast and smooth flow of work means you can:

* deliver value quickly and predictably
* get early feedback to find out whether your product or service is meeting user needs

Read [a brief introduction to Kanban](https://www.atlassian.com/agile/kanban/).

### Lean

Lean software development, like Kanban, is adapted from lean manufacturing principles like the Toyota Production System.

The principles of Lean aim to help your team focus on:

* reducing waste
* delivering quickly
* learning and improving
* using evidence and data to make decisions

Read the following to learn more about Lean:

* [The Lean Mindset](http://www.poppendieck.com/)
* [The Lean Startup](http://theleanstartup.com/)

Working with multiple agile methods
-----------------------------------

You don’t have to work with just one method, you can choose tools and techniques from several to meet your team’s needs.

Each method has its own language for describing basic tools and techniques, the important thing is to understand:

* why you’ve chosen a tool or technique
* its agile objective

[Find other agile methods you can use.](https://en.wikipedia.org/wiki/Agile_software_development#Agile_methods)

Deciding which methods to work with
-----------------------------------

### Scrum

Scrum is a good starting point if your team is new to agile working.

Your team will generally find Scrum most useful when you’re:

* building a new product or service
* enhancing existing features
* adding new features in each ‘sprint’ (a fixed period of time)

When you’re running your live service and have urgent requests you may find sprints constraining and want to move to a flow-based method like Kanban.

But you can still keep using many of the activities associated with Scrum, like daily standup meetings, retrospectives and regular reviews of progress.

### Kanban

Kanban helps your team to:

* find the bottlenecks in your processes
* control the amount of work you’re doing
* predict your output based on actual delivery

It’s particularly useful at times when your team needs to react quickly to changing priorities.

### Lean

Lean allows your team to focus on learning as quickly as possible.

Lean’s tools and techniques are particularly useful when your team is first discovering what your users’ needs are and deciding how to address those needs.

Related guides
--------------

You may also find these guides useful:

* [Agile and government services: an introduction](service-manual_agile-delivery_agile-government-services-introduction.md)
* [Core principles of agile](service-manual_agile-delivery_core-principles-agile.md)
* [Agile tools and techniques](service-manual_agile-delivery_agile-tools-techniques.md)

Updates to this page
--------------------

Published 16 February 2016

Last updated 27 July 2016
[+ show all updates](#full-history)

1. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---