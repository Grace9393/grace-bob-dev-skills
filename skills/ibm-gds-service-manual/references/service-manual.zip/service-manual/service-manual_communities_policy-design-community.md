Policy design community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Policy design community
=======================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Getting involved](#getting-involved)
3. [Policy design events and meetups](#policy-design-events-and-meetups)
4. [Community resources](#community-resources)

The policy design community is a place where you can:

* discover tools and methodologies that could support your work
* discuss specific challenges, for example in recruitment
* celebrate successes and learn from failures
* help shape what future policymaking might look like
* learn from and network with like-minded people

Who the community is for
------------------------

You might be interested in this community if:

* your work involves designing policy in new and innovative ways
* you want to learn more about policy design
* you want to work together on policy issues with other members of the community

You do not have to be in a specific profession to join. However, you must be working in central or local government.

Getting involved
----------------

If you’re interested in discussing policy issues, you can:

* join the [policy design mailing list](https://forms.office.com/r/sxe4JBVqQ6) using your government email address
* join the [policy design channel](https://ukgovernmentdigital.slack.com/messages/policydesign) on the UK government Slack - you can create a Slack account using your government email address
* write posts for the [public policy design blog](https://publicpolicydesign.blog.gov.uk/)

Policy design events and meetups
--------------------------------

The policy design community runs [events and meetups](https://www.eventbrite.co.uk/o/patrick-gallagher-32986733017)
to help support research and policy practitioners across government.

Community resources
-------------------

You may find these resources useful:

* the [public policy design blog](https://publicpolicydesign.blog.gov.uk/)
* the [Open Policy-Making Toolkit](https://www.gov.uk/guidance/open-policy-making-toolkit) to help guide your work
* the [Delivery Book](https://www.deliverybook.uk/) for making services and policy in challenging circumstances
* the [DIY Toolkit](https://diytoolkit.org/download-diy-toolkit/) to help you develop ideas and innovate
* the [Policy Lab blog](https://openpolicy.blog.gov.uk/)
* the [Open Innovation blog](https://openinnovation.blog.gov.uk/)

Some blog posts worth reading:

* [Are you making a bid for design?](https://publicpolicydesign.blog.gov.uk/2021/08/05/are-you-making-a-bid-for-design/)
* [Commissioning public policy and services differently](https://publicpolicydesign.blog.gov.uk/2021/07/29/commissioning-public-policy-and-services-differently/)
* [What does it mean to transform policymaking?](https://publicpolicydesign.blog.gov.uk/2021/05/27/what-does-it-mean-to-transform-policy-making/)
* [Introducing a ‘Government as a System’ toolkit](https://openpolicy.blog.gov.uk/2020/03/06/introducing-a-government-as-a-system-toolkit/)
* [Lab Long Read: Human-centred policy? Blending ‘big data’ and ‘thick data’ in national policy](https://openpolicy.blog.gov.uk/2020/01/17/lab-long-read-human-centred-policy-blending-big-data-and-thick-data-in-national-policy/)

Updates to this page
--------------------

Published 21 October 2021

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---