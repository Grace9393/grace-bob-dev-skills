Data science community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Data science community
======================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community events](#community-events)
4. [Training](#training)
5. [Areas of special interest](#areas-of-special-interest)
6. [Community resources](#community-resources)

The data science community exists to:

* bring together data scientists and improve data science capability across government
* develop and share data science best practice
* help digital and other analytical teams work effectively with data scientists
* discuss and share examples of ethical, fair and good practices in data science and artificial intelligence

Who the community is for
------------------------

You might be interested in this community if your work involves:

* making sure decisions are based on evidence
* presenting insights in an understandable way to both technical and non-technical audiences
* building statistical models from data and using coding best practices to generate reproducible work
* commissioning data science projects
* working with policy and operations to understand where data science can improve services for users
* exploring new data science technologies, tools and algorithms
* deploying data science at scale

If you work in the public sector and are a data scientist, or have an interest in data science, you are welcome to join.

Get involved
------------

You can use the following online spaces to discuss data science related issues:

* the [cross-government data science Slack](https://govdatascience.slack.com/) - you’ll need a public sector email address to join
* the [data in government blog](https://dataingovernment.blog.gov.uk/) - to contribute a blog post send an email to [dataingovernment\_submissions@digital.cabinet-office.gov.uk](mailto:dataingovernment_submissions@digital.cabinet-office.gov.uk)
* the [UK Government Data Science GitHub](https://github.com/ukgovdatascience) - where you can find repositories for code related to data science in the public sector

If you have any questions you can email the community at: [gdsp@digital.cabinet-office.gov.uk](mailto:gdsp@digital.cabinet-office.gov.uk)

Community events
----------------

The [Government Data Science Partnership (GDSP)](https://gds.blog.gov.uk/2017/07/20/building-capability-and-community-through-the-government-data-science-partnership/) brings public servants together to share their knowledge about data science.

The [Government Data Science Festival Knowledge Hub](https://khub.net/group/government-data-science-festival/group-library) includes presentations from meetups and the annual conference. You’ll need a public sector email address to join.

To find out more about future events you can:

* join the [community mailing list](https://ons.us1.list-manage.com/subscribe?u=0f8869b47a9fed86f0fa1dc17&id=998edd3774)
* join the [#community\_of\_interest Slack channel](https://govdatascience.slack.com/?redir=%2Fmessages%2FC1LJKK292%2F)
* check the [events calendar on Knowledge Hub](https://khub.net/group/government-data-science-festival/group-events)

### Data Science Community of Interest meetups

Meetups take place every 2 to 3 months. Previous meetups have covered topics such as machine learning, geospatial data science and project delivery in the public sector. The meetups are hosted online.

### Annual community conference

The annual Data Science Community Conference focuses on themes such as “Building Data Science capability, partnerships, skills and pipelines”. You can read a [blog post about the 2020 Government Data Science Festival](https://dataingovernment.blog.gov.uk/2020/12/07/all-in-lessons-from-the-first-virtual-government-data-science-festival/).

### Data Science Exchange

A fortnightly data science standup for public sector colleagues to share what they’re working on. Join the [#ds\_exchange Slack channel](https://govdatascience.slack.com/archives/CMY8SN7EX) for more details.

Training
--------

There are a variety of data science courses available in the public sector. Join the [#training Slack channel](https://govdatascience.slack.com/archives/C0NJY4XCZ) for more information about training opportunities.

### Data Science Accelerator programme

The [Data Science Accelerator](https://www.gov.uk/government/publications/data-science-accelerator-programme/introduction-to-the-data-science-accelerator) is a programme for analysts and aspiring data scientists from across the public sector to develop their data science skills. Participants propose and work on a data science project for 3 months under the guidance of a mentor.

You can [read a blog post with testimonials from recent graduates](https://dataingovernment.blog.gov.uk/2021/01/18/data-science-accelerator-programme-2021-applications-now-open/).

### GDS Academy

The GDS Academy runs an [introduction to artificial intelligence course](https://www.gov.uk/guidance/introduction-to-artificial-intelligence-in-government). Many of their other courses also include introductory analytics. You can [view a list of all the GDS Academy courses](https://www.gov.uk/government/collections/gds-academy-course-descriptions).

### The Data Science Campus

The [Data Science Campus](https://datasciencecampus.ons.gov.uk/capability/) runs:

* the [Data Science Graduate Programme](https://datasciencecampus.ons.gov.uk/capability/data-science-graduate-programme/)
* the [Degree Data Science Apprenticeship](https://datasciencecampus.ons.gov.uk/capability/degree-data-science-apprenticeship/)
* the [MSc in Data Analytics for Government](https://datasciencecampus.ons.gov.uk/capability/msc-in-data-analytics-for-government/)
* [individual modules from the MSc in Data Analytics for Government](https://datasciencecampus.ons.gov.uk/individual-modules-from-the-msc-in-data-analytics-for-government-mdatagov-programme/)
* the [Data Science Campus Seminar Series](https://datasciencecampus.ons.gov.uk/capability/data-science-seminar-series/)
* [courses on topics such as R, Python, natural language processing and machine learning](https://datasciencecampus.ons.gov.uk/capability/data-science-campus-faculty/)

### Government Analysis Function

[The Analysis Function Learning Curriculum](https://www.gov.uk/guidance/af-learning-curriculum-technical) lists technical learning and development opportunities for government analysts.

### Government Statistical Service

You might find some of the [courses run by the Government Statistical Service](https://gss.civilservice.gov.uk/training-courses/) useful.

Areas of special interest
-------------------------

These groups focus on specific data science topics or on data science in specific sectors or areas.

If you’d like advice about setting up a new area of special interest you can email [gdsp@digital.cabinet-office.gov.uk](mailto:gdsp@digital.cabinet-office.gov.uk) and read [the community development handbook](https://www.gov.uk/government/publications/community-development-handbook/community-development-handbook).

### Text analysis and natural language processing

[Join the #nlp Slack channel](https://govdatascience.slack.com/?redir=%2Fmessages%2FC0NF51LE4%2F) if you’re particularly interested in text analytics and natural language processing.

### Reproducible analytical pipelines

If you’re interested in reproducible analytical pipelines (RAP) - a method for automating the production of statistical publications - you can:

* visit [the Government Statistical Service’s page about RAP champions](https://gss.civilservice.gov.uk/about-us/champion-networks/reproducible-analytical-pipeline-rap-champions/)
* join the [#rap-collaboration Slack channel](https://govdatascience.slack.com/?redir=%2Fmessages%2FC6H22U3H9%2F)

### Data Ethics and Society Reading Group

[The Data Ethics and Society Reading Group](https://github.com/ukgovdatascience/data-ethics-and-society-reading-group) is a space for public sector colleagues to reflect on the ethical implication of their work in response to current research. [Join the #ethics Slack channel](https://govdatascience.slack.com/archives/C61SCQP8V) to get access to these sessions.

### NHS-R Community

[The NHS-R community](https://nhsrcommunity.com/) supports the learning, application and exploitation of R in the NHS.

### NHS Python Community

[The NHS Python Community for Healthcare](https://nhs-pycom.net/) champions the use of Python and open code in the NHS and healthcare sector.

### London data science network

The LOTI Data Science Network is for data scientists and analysts learning to code from London boroughs. It’s supported by the London Office for Technology and Innovation and Greater London Authority. You can [sign up to one of their monthly meetups on Eventbrite](https://www.eventbrite.co.uk/e/loti-data-science-network-meet-ups-tickets-117972493905).

### Data science for galleries, libraries, archives and museums

[The GLAM (galleries, libraries, archives, museums) Data Science Network](https://glamdatasci.network/) supports members to develop confidence, understanding and skills in statistics and data science.

### Police Rewired data community

Police Rewired is a community connecting volunteer professionals and technologists to tackle public safety challenges. There is also a [Police Rewired data community](https://www.policecoders.org/home/data-community) specifically aimed at data-scientists, analysts, and enthusiasts.

Community resources
-------------------

Use these resources to learn more about data science in government:

* [data scientist role requirements](https://www.gov.uk/government/collections/digital-data-and-technology-profession-capability-framework#data:-data-scientist) - explains the skills you’ll need to be a data scientist in government
* [data in government blog](https://dataingovernment.blog.gov.uk/) - discusses the tools and techniques used in government for data analysis and data science
* [Data Ethics Framework](https://www.gov.uk/government/publications/data-ethics-framework/data-ethics-framework) - guidance for public sector organisations about how to use data appropriately and responsibly
* [Govcookiecutter](https://github.com/ukgovdatascience/govcookiecutter) - a GitHub cookiecutter template for data science projects in government
* [Quality Assurance of Code for Analysis and Research](https://best-practice-and-impact.github.io/qa-of-code-guidance/intro.html) - guidance for analysts in government who use coding in their work
* [The Biscuit Book](https://www.gov.uk/government/publications/the-dstl-biscuit-book) - a guide to artificial intelligence, data science and machine learning made by the Defence Science And Technology Laboratory

Updates to this page
--------------------

Published 26 June 2019

Last updated 10 May 2021
[+ show all updates](#full-history)

1. 10 May 2021

   Added informations about additional events, training, groups and resources.
2. 26 June 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---