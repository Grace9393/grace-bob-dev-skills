Spend controls: apply for approval to spend money on a service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Spend controls: apply for approval to spend money on a service
==============================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Why some services must get spend approval](#why-some-services-must-get-spend-approval)
2. [Before you apply](#before-you-apply)
3. [When to apply](#when-to-apply)
4. [How to apply](#how-to-apply)

Before you start building your service, you may need to apply to the Central Digital and Data Office (CDDO) for approval to spend money on it.

This process is known as ‘spend controls’.

Before you apply, [check if you need approval to spend money on your service](service-manual_spending-money-on-your-service_check-if-you-need-approval-to-spend-money-on-a-service.md).

You’ll need to follow different guidance if your department has signed up to the new [pipeline process](service-manual_agile-delivery_spend-controls-pipeline-process.md). Check with your digital or technology lead to find out.

Why some services must get spend approval
-----------------------------------------

CDDO requires services to get spending approval to make sure they’re built in line with the [Technology Code of Practice](/government/publications/technology-code-of-practice/technology-code-of-practice).

You should read the code before starting work on your service and use it when making decisions about technology.

The spend controls process exists to make sure:

* you’ve considered the needs of the people who’ll use the service
* you get the best value
* you only spend on programmes and projects that meet government digital and technology strategies
* members of the public or private businesses can see how government makes decisions about spending money on digital projects or technology
* you discover and solve any problems with your service before you spend money
* you develop services using [agile methods](service-manual_agile-delivery.md)

Before you apply
----------------

Before you apply you must get your project signed off by either:

* your digital leader (if it’s a digital service) - [check if your service is a digital service](service-manual_spending-money-on-your-service_check-if-you-need-approval-to-spend-money-on-a-service#When-your-service-is-considered-a%20digital-service.md)
* your technology leader (if it’s a technology service) - [check if your service is a technology service](service-manual_spending-money-on-your-service_check-if-you-need-approval-to-spend-money-on-a-service#When-your-service-is-considered-a%20technology-service.md)

You must also contact CDDO on [cddoassurance@digital.cabinet-office.gov.uk](mailto:cddoassurance@digital.cabinet-office.gov.uk) to discuss your idea

### Major projects

If your project costs more than your organisation’s expenditure limit, you need to [get assurance from the Major Projects Authority](https://www.gov.uk/government/groups/major-projects-authority).

When to apply
-------------

If your service requires spend approval, you need to apply to CDDO both:

* before your service goes into discovery phase
* before your service goes into live phase

How to apply
------------

### Complete a spend control form

To apply for approval, you must:

1. [Download a spend control form template](https://www.gov.uk/guidance/digital-and-technology-spend-controls-non-pipeline-process-version-4).
2. Complete the spend control form.
3. Send the completed form to [gdsassurance@digital.cabinet-office.gov.uk](mailto:gdsassurance@digital.cabinet-office.gov.uk).

### Share your business case

If you have not shared your business case with CDDO at the time you’re sending your spend control form, you must send either one of the following with the form:

* a programme business case, if you have one for your service and you’re using agile methods
* a traditional business case, if you’re using public sector OJEU (Official Journal of the European Union) procurement processes

Your spend control form will explain the detail your business case needs to include.

Find out more about [making programme business cases](https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-governent/agile-digital-and-it-projects-clarification-of-business-case-guidance) for agile projects.

Updates to this page
--------------------

Published 13 May 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---