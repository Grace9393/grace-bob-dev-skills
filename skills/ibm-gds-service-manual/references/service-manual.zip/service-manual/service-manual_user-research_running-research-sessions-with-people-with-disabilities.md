Running research sessions with disabled people - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Running research sessions with disabled people
==============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Accessibility community](service-manual_communities_accessibility-community.md)

Contents
--------

1. [Steps to follow](#steps-to-follow)
2. [Examples and case studies](#examples-and-case-studies)
3. [Posters](#posters)
4. [Related guides](#related-guides)

When you do research with disabled people, it’s important to plan your sessions carefully, treat participants with respect and take account of their individual needs.

Steps to follow
---------------

Think about what you need to do to make sessions easy and comfortable for participants, both before they start and when they are underway.

### Before a session

If you’re running a session at a research lab or other venue:

* meet the participant at reception (or arrange for someone else to)
* bring them to the lab or research room - find out [how to guide a blind or partially sighted person](http://www.rnib.org.uk/information-everyday-living-family-friends-and-carers/guiding-blind-or-partially-sighted-person)
* ask if they need you to set up any equipment they’ve brought - this can take time so make sure you plan for it
* explain where the nearest toilets are, including the accessible one
* explain what will happen if the fire alarm goes off

If your participants need to use assistive technology, ask them to bring it with them. This is because it’s hard to recreate someone’s personal settings on a different device. If a participant cannot bring their technology, it’s best to visit them instead.

Do not pet a participant’s assistance dog, unless they say you can.

Before you start the session:

* introduce yourself and explain who else is with you (like observers or notetakers) and what their role is
* make sure they can use and understand the consent form so you [get their informed consent](service-manual_user-research_getting-users-consent-for-research#getting-consent-from-disabled-people.md)

### During a session

Regardless of what you’re researching and which [user research method](service-manual_user-research#user-research-methods.md) you’re using:

* talk directly to the participant, not to their interpreter or helper
* speak clearly and use everyday language without worrying about causing offence - for example, people who are blind or partially sighted use common phrases like ‘see you later’ and ‘see what I mean’
* check if they need you to speak up or slow down
* do not guess what the participant is saying if their speech is not clear - ask them to write things down if you need to
* do not guess or make assumptions about what they can or cannot do - ask before you help them with something
* do not guess or make assumptions about how they feel or why they did something - if you want to know, ask
* if you’re unsure how to refer to the participant’s disability or impairment, ask them what terminology they prefer
* ask how their condition affects their use of technology, if this is not clear

### After a session

When the research session is finished, thank the participant for taking part.

If you’re at a research lab or other venue:

* make sure the participant packs up any assistive technology they’ve brought
* check if they need you to book them a taxi or arrange for someone to meet them
* take them back to reception (or ask someone else to)

Examples and case studies
-------------------------

Read a blog post about [how the passport service was tested with visually impaired users](https://userresearch.blog.gov.uk/2016/01/22/research-with-visually-impaired-users/).

[Learn more about interacting with disabled people](http://www.uiaccess.com/accessucd/interact.html) in the book ‘Just Ask: Integrating accessibility throughout design’.

Posters
-------

[Researching access needs: who to include when](https://github.com/UKHomeOffice/posters/blob/master/accessibility/researching-access-needs/Research-who_to_include_when%3F.pdf), made by the Home Office

Related guides
--------------

You may also find these guides useful:

* [User research for government services: an introduction](https://www.gov.uk/service-manual/user-research/how-user-research-improves-service-design)
* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Choose a location for user research](service-manual_user-research_choose-a-location-for-user-research.md)
* [Using moderated usability testing](https://www.gov.uk/service-manual/user-research/using-moderated-usability-testing)

Updates to this page
--------------------

Published 3 October 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---