Deciding on priorities - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Deciding on priorities
======================

[Give feedback about this page](/contact/govuk)

From:
:   [Product and service community](service-manual_communities_product-and-service-community.md)

Contents
--------

1. [Prioritisation methods](#prioritisation-methods)
2. [Prioritising tasks during the different development phases](#prioritising-tasks-during-the-different-development-phases)

There’s always a long list of things you could work on when developing a product or service. But you’ll usually have a limited amount of time, materials or skills available.

Prioritising what you should work on and in what order is an important part of delivering good products and services.

Decisions about what to prioritise should be made regularly - for example, weekly to prioritise the sprint backlog, or quarterly to organise the service [roadmap](service-manual_agile-delivery_developing-a-roadmap.md). They should be based on performance analysis, user research and input from stakeholders.

The person leading the exercise should use a clear prioritisation method and involve the delivery team and stakeholders.

It’s much easier to prioritise work if you developed a good [understanding of the problem you’re trying to solve](https://www.gov.uk/service-manual/measuring-success/measuring-service-benefits#discovery-spot-problems-and-estimate-how-much-theyre-costing) during your discovery.

Prioritisation methods
----------------------

There are lots of [prioritisation methods](https://foldingburritos.com/product-prioritization-techniques/). Choosing the right method will depend on the capacity of your team and what stage your product or service is at in the delivery lifecycle.

You’ll probably need to try out a few methods before deciding which one best suits the needs of the thing you’re working on.

### Making sure you focus on more than just new features

As well as user stories for new features, your backlog is likely to contain other types of work, like support tickets or tasks to address technical debt.

It’s important to prioritise more than just work on new features. You could use something like a prioritisation quadrant to make sure you’re prioritising enough different types of work.

### Building consensus within your team

It’s important to involve the rest of your team in prioritisation decisions when you can. They’ll find it easier to challenge decisions if they understand the process you use.

The [MoSCoW method](https://en.wikipedia.org/wiki/MoSCoW_method) is useful if you’re trying to build consensus within your team. It involves breaking down the items in your backlog and roadmap into:

* ‘must haves’ - essential things that your product cannot function without
* ‘should haves’ - things that can greatly improve the product, but are not crucial to making it function
* ‘could haves’ - things that can improve the service, but will not have too negative an impact if left out at this stage
* ‘will not haves’ - low priority things that the team has agreed not to do

Prioritising tasks during the different development phases
----------------------------------------------------------

What you consider high priority should change as your service develops.

For example, during the [beta phase](https://www.gov.uk/service-manual/agile-delivery/how-the-beta-phase-works) you’ll be able to prioritise improvements as you test and iterate the service.

During the [live phase](https://www.gov.uk/service-manual/agile-delivery/how-the-live-phase-works), users will be using your service so you’ll need to prioritise support work alongside continuous improvements.

Updates to this page
--------------------

Published 16 November 2017

Last updated 6 December 2018
[+ show all updates](#full-history)

1. 6 December 2018

   Updated and expanded section about prioritisation methods.
2. 16 November 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---