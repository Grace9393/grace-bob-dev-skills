User research - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

User research
=============

Understand user needs: plan research, prepare for sessions, share and analyse findings.

Understanding user research
---------------------------

Introduction, user needs, users who need help online.

* [User research for government services: an introduction](service-manual_user-research_how-user-research-improves-service-design.md)
* [Learning about users and their needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Understanding users who do not use digital services](service-manual_user-research_understanding-users-who-dont-use-digital-services.md)

User research in the different design phases
--------------------------------------------

Discovery, alpha, beta, live.

* [User research in discovery](service-manual_user-research_user-research-in-discovery.md)
* [User research in alpha](service-manual_user-research_user-research-in-alpha.md)
* [User research in beta](service-manual_user-research_user-research-in-beta.md)
* [User research in live](service-manual_user-research_user-research-in-live.md)

Preparing for user research
---------------------------

Planning, participants, locations, recruitment.

* [Plan user research for your service](service-manual_user-research_plan-user-research-for-your-service.md)
* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Choose a location for user research](service-manual_user-research_choose-a-location-for-user-research.md)
* [Finding participants for user research](service-manual_user-research_find-user-research-participants.md)
* [Write a recruitment brief](service-manual_user-research_write-a-recruitment-brief.md)
* [Getting informed consent for user research](service-manual_user-research_getting-users-consent-for-research.md)
* [Running research sessions with disabled people](service-manual_user-research_running-research-sessions-with-people-with-disabilities.md)
* [Managing user research data and participant privacy](service-manual_user-research_managing-user-research-data-participant-privacy.md)
* [Researching emotionally sensitive subjects](service-manual_user-research_researching-emotionally-sensitive-subjects.md)
* [Doing user research during coronavirus (COVID-19): choosing face to face or remote research](service-manual_user-research_doing-user-research-during-coronavirus-covid-19-choosing-face-to-face-or-remote-research.md)
* [Researching contentious subjects or during pre-election periods](service-manual_user-research_researching-contentious-subjects-or-during-pre-election-periods.md)

User research methods
---------------------

Common methods and techniques.

* [Capturing research questions](service-manual_user-research_capturing-research-questions.md)
* [Contextual research and observation](service-manual_user-research_contextual-research-and-observation.md)
* [Researching user experiences](service-manual_user-research_researching-user-experiences.md)
* [Creating an experience map](service-manual_user-research_creating-an-experience-map.md)
* [Researching in small group workshops](service-manual_user-research_research-small-group-workshops.md)
* [Using in-depth interviews](service-manual_user-research_using-in-depth-interviews.md)
* [Using moderated usability testing](service-manual_user-research_using-moderated-usability-testing.md)
* [Taking notes and recording user research sessions](service-manual_user-research_taking-notes-and-recording-user-research-sessions.md)
* [Doing pop-up research](service-manual_user-research_doing-pop-up-research.md)
* [Doing user research remotely by phone or video call](service-manual_user-research_remote-user-research-phone-video-call.md)

Analysing and sharing findings
------------------------------

Doing analysis, sharing what you've learned.

* [Analyse a research session](service-manual_user-research_analyse-a-research-session.md)
* [Sharing user research findings](service-manual_user-research_sharing-user-research-findings.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [User research community](service-manual_communities_user-research-community.md)
* [Accessibility community](service-manual_communities_accessibility-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/user-research)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---