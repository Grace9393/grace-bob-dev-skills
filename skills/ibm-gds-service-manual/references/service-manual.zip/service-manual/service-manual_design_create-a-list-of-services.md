Create a list of services - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Create a list of services
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Build your list of services](#build-your-list-of-services)
2. [What to do with your list of services](#what-to-do-with-your-list-of-services)

Creating a list of the services your organisation provides to citizens, or provides a part of, can be helpful for a number of reasons.

Firstly, it provides you with a backlog of services to map out from start to finish. These maps are useful because they help individual delivery teams understand the wider context around the thing they’re working on.

It also gives you a better view across services. It can help you spot big things you won’t see if you’re only looking at services individually - things like there being 30 different ways of applying for something, or no services at all for a given policy area, which might indicate a gap.

It can also bring a user-centred perspective to the writing of business cases. By asking people to explain which service their project is linked to, you get them thinking about the relationship of say, technology or databases, to outcomes for users.

Because it requires a broad view, it’s probably best that a head of a user centred design profession (or someone in a similar role) owns and maintains the list.

You can see the [Home Office’s list of services](https://ukhomeoffice.github.io/coe/service-list/) (requires secure login to Github).

Build your list of services
---------------------------

Putting together your list means taking themes like ‘visas’, ‘childcare’ or ‘social care’ and reframing them in a way that end users would understand or search for online.

Aim to reflect the big things that users are trying to achieve. Some examples are ‘learn to drive’, ‘start a business’ or ‘foster a child’.

Don’t think of lower level tasks like ‘applying’ or ‘booking a test’ as services - users usually only do those things as part of trying to achieve a bigger goal. For example, you only apply for a UK visa because you want to do something bigger like work in the UK. And you only book a theory test because you want to learn to drive. So keep the user’s overall goal in mind when defining what your services are.

Where services are delivered by multiple organisations, you can list out the different organisations. This gives you an idea of who you might need to collaborate with.

For example, ‘work in the UK’ involves both UK Visas and Immigration (UKVI) and Border Force. ‘Foster a child’ involves the Department for Education (DfE) and local authorities, while ‘starting a business’ involves several organisations.

If you’re not sure how to frame the services, you can:

* read our [guidance on mapping and understanding whole problems](service-manual_design_map-a-users-whole-problem.md)
* listen to how users talk or think about them in research sessions
* review service content on GOV.UK to see how that’s been framed

### Who to involve

The Home Office list was made by a small number of representatives from each different internal area, facilitated by someone with a user centred design background. They then invited a wider variety of stakeholders to give input on their list, from senior management to people from the operations and delivery professions.

Creating the list together is important. If only one person makes the list, it’s less likely that others will use it, understand why it’s important or agree with the contents.

Read more about [how the Home Office collaborated on their list of services](https://hodigital.blog.gov.uk/2018/06/07/creating-a-list-of-services/).

What to do with your list of services
-------------------------------------

Once you’ve built your list and understand the services you’re responsible for, you can do a few useful things. You can start mapping them to [understand how the component parts of the service join up](service-manual_design_map-a-users-whole-problem.md) and who’s involved in delivering them.

This is a big job, so it’s something you’ll want to do in stages. Start with any particularly high priority areas or things you know delivery or operational teams will be working on soon.

If you’re not sure which of your services are most important, look at which are the most used or most expensive to run.

Updates to this page
--------------------

Published 1 May 2019

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---