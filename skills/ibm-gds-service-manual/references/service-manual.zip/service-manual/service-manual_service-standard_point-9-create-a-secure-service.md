9. Create a secure service which protects users’ privacy - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service Standard](service-manual_service-standard.md)

Service Standard

9. Create a secure service which protects users’ privacy
========================================================

Establish the security risks, threats and legal responsibilities associated with the service.

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Why it's important](#why-its-important)
2. [What it means](#what-it-means)
3. [Related guidance](#related-guidance)
4. [Service standard points](#service-standard-points)

Understand how to manage risks throughout the delivery lifecycle and put robust security measures in place to protect against potential threats.

Why it’s important
------------------

Government services often hold personal data about users and sensitive information about operational activities. Government has an obligation to protect this information and minimise disruption to services. If we fail in that duty, we could put people and critical national infrastructure at risk, and undermine public trust.

What it means
-------------

Service teams must follow the [Secure By Design principles](https://www.security.gov.uk/guidance/secure-by-design/principles/) and:

* ensure senior leaders who are accountable for security are aware of risks
* have a plan and budget to manage security during the life of the service, including responding to changes in requirements or new threats
* perform due diligence on the security of third-party software
* perform user research to create security processes that are fit for purpose and easy to understand
* collect, process and store data securely and in a way which respects users’ privacy
* maintain an assessment of security risks and mitigate threats with appropriate protections
* work with business and information risk teams to make sure the service meets security requirements
* anticipate and manage vulnerabilities, limiting opportunities for cyber attacks
* regularly test security controls

Related guidance
----------------

[Secure by Design](https://www.security.gov.uk/guidance/secure-by-design/)

[Securing your information](https://www.gov.uk/service-manual/technology/securing-your-information)

[Protecting your service against fraud](https://www.gov.uk/service-manual/technology/protecting-your-service-against-fraud)

[Collecting personal information from users](https://www.gov.uk/service-manual/design/collecting-personal-information-from-users)

[Working with cookies or similar technologies](https://www.gov.uk/service-manual/technology/working-with-cookies-and-similar-technologies)

[Vulnerability and penetration testing](https://www.gov.uk/service-manual/technology/vulnerability-and-penetration-testing)

Service standard points
-----------------------

[1. Understand users and their needs](https://www.gov.uk/service-manual/service-standard/point-1-understand-user-needs)

[2. Solve a whole problem for users](https://www.gov.uk/service-manual/service-standard/point-2-solve-a-whole-problem)

[3. Provide a joined up experience across all channels](https://www.gov.uk/service-manual/service-standard/point-3-join-up-across-channels)

[4. Make the service simple to use](https://www.gov.uk/service-manual/service-standard/point-4-make-the-service-simple-to-use)

[5. Make sure everyone can use the service](https://www.gov.uk/service-manual/service-standard/point-5-make-sure-everyone-can-use-the-service)

[6. Have a multidisciplinary team](https://www.gov.uk/service-manual/service-standard/point-6-have-a-multidisciplinary-team)

[7. Use agile ways of working](https://www.gov.uk/service-manual/service-standard/point-7-use-agile-ways-of-working)

[8. Iterate and improve frequently](https://www.gov.uk/service-manual/service-standard/point-8-iterate-and-improve-frequently)

[9. Create a secure service which protects users’ privacy](https://www.gov.uk/service-manual/service-standard/point-9-create-a-secure-service)

[10. Define what success looks like and publish performance data](https://www.gov.uk/service-manual/service-standard/point-10-define-success-publish-performance-data)

[11. Choose the right tools and technology](https://www.gov.uk/service-manual/service-standard/point-11-choose-the-right-tools-and-technology)

[12. Make new source code open](https://www.gov.uk/service-manual/service-standard/point-12-make-new-source-code-open)

[13. Use and contribute to open standards, common components and patterns](https://www.gov.uk/service-manual/service-standard/point-13-use-common-standards-components-patterns)

[14. Operate a reliable service](https://www.gov.uk/service-manual/service-standard/point-14-operate-a-reliable-service)

Updates to this page
--------------------

Published 8 May 2019

Last updated 12 December 2024
[+ show all updates](#full-history)

1. 12 December 2024

   This page has been updated to reflect the broader role that security has within service delivery beyond user privacy. Protecting users’ data is retained as a core element of effective security, and including activities such as risk management and mitigation throughout delivery also helps guard against potential threats to government systems and infrastructure.
   Changes reflect updates to government policy, for example considering security earlier on in the delivery lifecycle, ensuring accountability for security, and having long term plans. Read more at https://www.security.gov.uk/policy-and-guidance/secure-by-design/.
   Third party software is included, encouraging teams to check integrations or extensions to service architecture. This encompasses previous guidance on cookies.
   Guidance on collecting and processing data securely has been expanded to cover storage. Guidance on front-end security has been updated to clarify that protection and authentication can facilitate rather than block user journeys.
   References to specific roles within this point have been removed to encourage teams to seek the most suitable support and expertise for their needs, regardless of job titles.
2. 30 May 2022

   Added links to related guidance and other standard points. There is no change to the content of the standard point itself.
3. 20 August 2021

   Added a link to guidance about using cookies.
4. 8 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---