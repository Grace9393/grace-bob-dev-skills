Retiring your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Retiring your service
=====================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Consider user needs](#consider-user-needs)
2. [Telling your users](#telling-your-users)
3. [Make a plan to redirect traffic](#make-a-plan-to-redirect-traffic)
4. [Protecting information](#protecting-information)
5. [Related guides](#related-guides)

Your service may eventually need to be retired, for example if policies change or if there’s evidence that users’ needs have changed.

When retiring a service you should consider user needs in the same way you did when you built the service.

Consider user needs
-------------------

You need to consider how the user need your service met will be met after your service is retired.

It might be the case that:

* the user need no longer exists
* a new government service will meet the user need
* the user need will no longer be met by government

### If a user need no longer exists

In some cases, policy could change to mean that your service is obsolete, for example when Universal Credit replaced 6 other benefits.

### If a new service will meet the need

If a new government service or services will meet the user need then you should work with those services’ teams.

Share your experiences, findings and knowledge of the user with them so that they can learn from them.

This means you can understand how you’ll support your users through the transition, for example by:

* making sure the new service meets proven user needs
* helping users to find out about the new services in the best way

### If the need will no longer be met by government

If the needs will no longer be met by government but by the private or voluntary sectors then you must:

* share knowledge and insight with these organisations, like open source elements
* help the private or voluntary team use the knowledge or information you share
* make sure that users who would normally go to GOV.UK are sent to the new service in the best way possible

Telling your users
------------------

### Users who access your service on GOV.UK

The vast majority of people who use your service will begin and end their journeys on GOV.UK.

As soon as you know that your service is likely to be retired you should email the GOV.UK team at [govuk-enquiries@dsit.gov.uk](mailto:govuk-enquiries@dsit.gov.uk) to make sure that those journeys are amended and appropriate information is supplied.

You need to tell the GOV.UK team why you’re retiring the service and how its user needs will be met, so that they can help users with information and links.

### Users who access your service directly

Retiring the service means a significant change for users, but you should try to minimise it by telling them:

* what’s changing and why
* what they’ll have to do to continue to have their needs met in future
* what will happen to their data, whether you’re passing it on to another service and the rights they have under your organisation’s data protection policy

You can tell people using a notification system if your service has one, otherwise use a GOV.UK content page.

### Users who access your service using APIs

You need to give users who access your service via an application programming interface (API) the time to update their software to use the replacement service’s APIs or make other adjustments.

Contact these users as soon as possible. Keep in mind that they may have significant lead times for making and distributing changes.

### Users who access your service with assisted digital support

You must tell users who don’t use the digital service or use it with assisted digital support that the service is being retired.

To do this, use your service’s assisted digital channel and assisted digital support organisations.

You may need to carry out user research to decide the best way to tell users the service is retiring.

You could use existing research or talk to teams who’ve retired other services that have similar users and use their research.

You may need to make sure that contact centres used by your users tell them the service has been retired and about any replacement service.

You could also put up posters in places that users are likely to visit (for example, in airports for visa or passport services).

Make a plan to redirect traffic
-------------------------------

Once the GOV.UK content team updates GOV.UK to say that your service has retired, the majority of users will be directed to the new service.

Some users will still try to access the service at the retired web address.

You should have a plan for redirecting those users to the new service, or telling them that the service that has permanently retired.

### Make sure your subdomain continues to work

After your service is retired, you must help users by:

* continuing to use SSL
* serving a redirect from your service to the GOV.UK start page

If your service has been live for less than 6 months, you must do this until a year after your service went live.

If your service has been live for longer than 6 months, you must do this for a year after the time it retired or until the current SSL certificate expires, whichever comes first.

Your GOV.UK start page will be changed to explain that the service is no longer running, and the start button will be removed.

Protecting information
----------------------

You should have a plan for [securing the information](service-manual_technology_securing-your-information.md) you’ve got about your users.

You should already have policies in place to manage that data responsibly, including details of how long it’ll be retained.

You must make sure that there’s support in place to maintain these policies and protect information.

If you’re giving data to a new service owner, you must:

* do so in line with your organisation’s data protection policies
* tell your users

Related guides
--------------

You may also find these guides useful:

* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [How the alpha phase works](service-manual_agile-delivery_how-the-alpha-phase-works.md)
* [How the beta phase works](service-manual_agile-delivery_how-the-beta-phase-works.md)
* [How the live phase works](service-manual_agile-delivery_how-the-live-phase-works.md)

Updates to this page
--------------------

Published 4 August 2016

Last updated 26 August 2025
[+ show all updates](#full-history)

1. 26 August 2025

   Changed GOV.UK contact email FROM govuk-enquiries@digital.cabinet-office.gov.uk TO govuk-enquiries@dsit.gov.uk
2. 4 August 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---