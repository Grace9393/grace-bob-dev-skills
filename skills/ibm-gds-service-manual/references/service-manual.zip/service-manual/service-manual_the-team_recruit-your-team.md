Recruit your team - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

Recruit your team
=================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Find out how long recruitment takes](#find-out-how-long-recruitment-takes)
2. [Who can recruit](#who-can-recruit)
3. [Identify the skills you need](#identify-the-skills-you-need)
4. [Work with HR](#work-with-hr)
5. [Hiring a senior civil servant](#hiring-a-senior-civil-servant)
6. [Related guides](#related-guides)

To run a successful service team, you need to understand how your organisation’s recruitment process works.

Find out how long recruitment takes
-----------------------------------

It’s important to find out how quickly you can hire someone in your department, so you can organise your team and plan your work.

It can take up to 4 weeks to hire a civil servant or contractor, depending on the department. Security checks, references and notice periods may add even more time to the process.

Contact your organisation’s HR department to find out what the recruitment process is.

Who can recruit
---------------

Only civil servants can chair (lead) recruitment campaigns and interview panels. If you’re not a civil servant, you must work with someone who is.

You can still be on the interview panel and help with recruitment if you’re not a civil servant.

Whoever leads the recruitment will need to work with your organisation’s human resources (HR) department to manage the process. They should also complete the [Civil Service Learning recruitment and unconscious bias](https://civilservicelearning.civilservice.gov.uk/) training courses.

Identify the skills you need
----------------------------

When you have an idea about the service you’re going to create, talk to your team about the skills you need.

Before [working with contractors or third parties](service-manual_the-team_working-contractors-third-parties.md), see if you have any team members who can develop these skills.

For any longer-term roles, you could hire civil servants on either a permanent or fixed-term (eg 2 year) basis.

### Get help with what roles you need

If you have any questions about the roles in service teams, email the Government Digital and Data profession at: [digitalanddataprofession@digital.cabinet-office.gov.uk](mailto:digitalanddataprofession@digital.cabinet-office.gov.uk)

### Check job descriptions

If your organisation has job descriptions, make sure these are up-to-date and tailored to the [roles in a service delivery team](service-manual_the-team_what-each-role-does-in-service-team.md).

If you do not have any, or the ones you have do not reflect what you need, write new ones based on discussions with your team.

Learn more about [reviewing and writing job descriptions](https://digitalpeople.blog.gov.uk/2015/02/23/turning-vacancies-into-opportunities-2/).

Work with HR
------------

Recruitment and selection are usually carried out by one of the following:

* HR or a specialist recruitment team
* line managers, with advice from HR
* an external provider (eg recruitment agency)

Talk to HR to find out who carries out recruitment in your department and how much involvement you can have, or need to have.

Hiring a senior civil servant
-----------------------------

If you want to hire someone to an SCS-level digital, data or technology role, you need to follow your department’s SCS recruitment process.

Talk to your HR team or senior digital data technology leader to find out what this involves and how long it usually takes.

### Before you advertise the role

The Government Digital and Data function supports the designing, building and running of government technology, data and digital services. Their recruitment team can advise you on recruiting to an SCS role.

You must tell the Government Digital and Data SCS recruitment team before you advertise the position - send an email to [ddatrecruitmenthub@digital.cabinet-office.gov.uk](mailto:ddatrecruitmenthub@digital.cabinet-office.gov.uk) with:

* the job title
* who the person will report to
* what their main responsibilities (‘accountabilities’) will be
* a draft job description for the role (if available)

The team will tell you if you need to tell any senior leaders in government that you’re advertising the position.

### Get help with your campaign

You can also contact the SCS recruitment team for help with:

* writing the job description
* keeping grading and salary in line with other departments
* fitting the new role into your department (organisational design)
* attracting the best candidates
* reviewing applications, shortlisting candidates and carrying out interviews

The SCS recruitment team will work with your HR team and recruiting line manager, who will continue to lead the campaign.

Related guides
--------------

You may also find the following guides useful:

* [Set up a service team at each phase](https://www.gov.uk/service-manual/the-team/set-up-a-service-team)
* [What each role does in a service delivery team](https://www.gov.uk/service-manual/the-team/what-each-role-does-in-service-team)
* [Change the size of a service team](https://www.gov.uk/service-manual/the-team/change-size-of-service-team)
* [Create an agile working environment](https://www.gov.uk/service-manual/agile-delivery/create-agile-working-environment)

Updates to this page
--------------------

Published 3 March 2016

Last updated 12 February 2021
[+ show all updates](#full-history)

1. 12 February 2021

   Added contact details for DDaT profession team.
2. 6 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---