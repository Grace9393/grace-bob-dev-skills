Designing good questions - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Designing good questions
========================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Ask questions that users understand](#ask-questions-that-users-understand)
2. [Change the questions until you find what works](#change-the-questions-until-you-find-what-works)
3. [Add help text where necessary](#add-help-text-where-necessary)
4. [Help users give you the right information](#help-users-give-you-the-right-information)
5. [Related guides](#related-guides)

Designing good questions makes it easy for users to provide the right information and understand why they need to provide it.

If they need it, you can add help text and error messages to nudge them in the right direction.

Before you start, make sure you [know why you’re asking every question](service-manual_design_form-structure.md).

You can see [how a question page should look](https://design-system.service.gov.uk/patterns/question-pages/) in the GOV.UK Design System.

Ask questions that users understand
-----------------------------------

Closed questions are easier to answer than open questions. Especially in government services, where users are often afraid of being caught out.

An example of a closed question might be ‘Do you live at more than one address?’An open version of this question would be ‘Tell us about your living arrangements’.

A series of simple questions can be easier to answer than one complex question. Especially if parts of it aren’t relevant to all users.

Let users answer with ‘I’m not sure’ or ‘I don’t know’ if these are valid answers.

Change the questions until you find what works
----------------------------------------------

If people are struggling to understand a form, think about re-framing the question or changing the [form structure](https://www.gov.uk/service-manual/design/form-structure) as well as the language.

For example, try reversing the question so the user is invited to say ‘no’ rather than ‘yes’ (or the other way round). Sometimes users make assumptions about what the ‘right’ answer is.

Or try more descriptive labels for radio buttons or checkboxes.

For example, an early version of the register to vote service asked users whether they also lived at a second address. User research showed that some people found it difficult to answer ‘yes’ or ‘no’ to this question because they weren’t sure what ‘counted’ as a second address.

![ ](https://assets.publishing.service.gov.uk/media/59dcbef8e5274a5be9d13224/Register_to_vote_1.png)

It became much easier to answer when the team replaced the ’Yes’ option with two radio buttons - one labelled ‘Yes, I spend time living at two homes’ and the other ‘Yes, I’m a student with home and term-time addresses’.

![ ](https://assets.publishing.service.gov.uk/media/59dcbf0340f0b63115586ed4/Register_to_vote_2.png)

If some radio button or checkbox labels are phrased differently from the others, it may make the page more readable if you separate the options that are different with an ‘or’.

![ ](https://assets.publishing.service.gov.uk/media/59dcbf21e5274a5becce36e2/Register_to_vote_4.png)

Add help text where necessary
-----------------------------

Sometimes it’s useful to provide help text to explain things like:

* legal jargon
* where to find obscure information
* what format the information should be given in
* what you’ll do with a user’s personal information
* the consequences of making one choice over another

Only do this if you see in research that your users need it.

### How to add help text

You can do this by:

* adding hint text inline, immediately next to the part of the page it relates to
* using the ‘details’ component to reveal expanding help text - this is useful if the text is only relevant to a subset of users

See examples of [hint text](https://design-system.service.gov.uk/components/text-input/) and [the details component](https://design-system.service.gov.uk/components/details/) in the GOV.UK Design System.

You might occasionally need to add more detailed text to help users make particularly complex or difficult decisions.

But bear in mind they’re unlikely to read anything longer than 3 lines, so try to keep any text brief and action-focused.

Don’t use help text to explain the interface. If you have to do that, you’ve made your service too complicated.

Help users give you the right information
-----------------------------------------

Do what you can to help users avoid failing validation and getting an error message. Set up your validation so it’s as tolerant as possible of users entering information in different ways.

So, for example, if you’re asking for the user’s National Insurance number the input field should accept either ‘QQ123456C’ or ‘QQ 12 34 56 C’ - stripping out the spaces before it passes the number through to the back end.

You’ll probably need to create multiple error messages per field, so they’re as specific to the problem as possible. Focus on telling the user how to fix the problem rather than describing what’s gone wrong.

The Design System shows [how to style and write good error messages](https://design-system.service.gov.uk/components/error-message/).

Related guides
--------------

You might find the following guides useful:

* [writing for user interfaces](https://www.gov.uk/service-manual/design/writing-for-user-interfaces)
* [structuring forms](https://www.gov.uk/service-manual/design/form-structure)

Updates to this page
--------------------

Published 22 June 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---