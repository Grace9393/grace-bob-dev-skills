Data and artificial intelligence ethics community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Data and artificial intelligence ethics community
=================================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [The data and artificial intelligence ethics community exists to:](#the-data-and-artificial-intelligence-ethics-community-exists-to)
2. [Who the community is for](#who-the-community-is-for)
3. [Get involved](#get-involved)

The data and artificial intelligence ethics community exists to:
----------------------------------------------------------------

* provide a forum and safe space for people across the public sector
* explore and discuss data ethics topics and issues
* raise awareness and encourage people to consider how data ethics relate to their work
* share real-world case studies, learnings and best practices
* convene existing expertise and grow the community across the public sector
* facilitate collaboration and knowledge exchange
* help to embed data ethics across public sector operations and practices

Who the community is for
------------------------

The data and artificial intelligence ethics community is for people working in the public sector who are interested in discussing and exploring ethics in data and technology.

Get involved
------------

The community meets every other month to discuss and debate ethical issues in data and technology.

Meeting topics include:

* the Algorithmic Transparency Recording Standard (ATRS)
* data ethics guidance for local authorities
* the ethics of using AI to analyse user research

The community welcomes contributions from guest speakers who want to share insights, best practices and case studies in the data ethics space.

To join, sign up to [the community mailing list](https://dataandaiethicscommunity.substack.com/).

Updates to this page
--------------------

Published 18 June 2024

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---