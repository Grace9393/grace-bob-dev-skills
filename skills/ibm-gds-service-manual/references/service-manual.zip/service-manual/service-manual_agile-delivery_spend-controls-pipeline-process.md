Spend controls: the pipeline process - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Spend controls: the pipeline process
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Why services need spend approval](#why-services-need-spend-approval)
2. [How to get approval](#how-to-get-approval)
3. [Help with the pipeline process](#help-with-the-pipeline-process)

This guidance is about the [digital and technology spend controls pipeline process (version 5)](https://www.gov.uk/guidance/digital-and-technology-spend-controls-version-5). Follow the [older spend control process (version 4)](https://www.gov.uk/service-manual/agile-delivery/spend-controls-check-if-you-need-approval-to-spend-money-on-a-service) if your department is still using it.

The spend controls process requires you to get approval for any:

* spend on a digital service that’s over £100,000
* spend on a technology service that’s over £1 million
* spend of any amount on something that might be considered ‘novel’ or contentious

A digital service is something that’s online and used by people who are not part of central government, for example citizens. This includes things like transactional services, websites and mobile apps.

Your service might not be considered a digital service if you’re creating content on an existing site, intranet or area listed under the [advertising, marketing and communications control](https://www.gov.uk/government/collections/cabinet-office-controls#advertising,-marketing-and-communications-spend-controls). Check this with the senior technology adviser assigned to your department.

A technology service is an internal-facing service used by people in government, for example civil servants.

Why services need spend approval
--------------------------------

Spend controls exist to help you:

* make sure the thing you’re planning to build or procure will meet the [Service Standard](https://www.gov.uk/service-manual/service-standard) and [Technology Code of Practice](https://www.gov.uk/government/publications/technology-code-of-practice/technology-code-of-practice)
* plan your spending
* be transparent about what you’re spending money on
* get early support on issues you might need help with

How to get approval
-------------------

If you’re a service owner and need approval for the thing you’re planning to build or buy, follow your department’s usual project creation process.

The spend will then go through the following approval process.

1. It’ll be added to a list (known as a ‘[pipeline](https://www.gov.uk/guidance/set-up-a-commercial-or-digital-and-technology-spend-controls-pipeline)’), along with all of your organisation’s ongoing and planned digital or technology activity.
2. The person in your organisation in charge of maintaining the pipeline will then assess each spend with help from your senior technology adviser to make sure it meets the [pipeline assessment criteria](https://www.gov.uk/guidance/gds-spend-controls-pipeline-assessment-criteria). You might be asked to provide information to help with the evaluation.
3. The pipeline will then need to be signed off internally, usually by the assurance board responsible for digital and technology spending in your organisation. Someone from the Cabinet Office will have been involved in the internal approval process.
4. The final step is to get your spend activity approved by the joint assurance review. Senior leaders from your organisation and the Cabinet Office oversee the joint assurance review. If your spend is over £10 million, GDS and the Cabinet Office Central Commercial Team will also attend the review.

A project should be added to the pipeline as soon as the idea starts being developed, even if it’s not clear exactly how much it will cost. The pipeline must include digital and technology activity covering the next 5 quarters. GDS recommends adding spend activity to the pipeline 15 months before the start of your project as good practice.

The pipeline will usually be signed off at least once a quarter.

### How to assess spend activity on a pipeline

The person in your organisation in charge of the pipeline will need to assess each planned spend against the [pipeline assessment criteria](https://www.gov.uk/guidance/gds-spend-controls-pipeline-assessment-criteria) and mark it as one of the following:

* ‘assured’ - if the spend will meet the standards
* ‘monitor’ - if the spend does not yet meet the standards, but is unlikely to be novel or contentious
* ‘control’ - if the spend is unlikely to ever meet the standards or is likely to be novel or contentious

If it’s not possible to assess a particular spend due to a lack of information, it’ll be marked as ‘pending’.

An activity might be considered novel or contentious if it’s unusual or of political interest. Examples of novel or contentious spend include:

* contracts that are over £100 million
* automatic contract extensions
* new hosting contracts over 2 years
* investments in emerging technologies like artificial intelligence, machine learning, blockchain and quantum computing

### Getting approval from the Cabinet Office

The Cabinet Office will assess your department’s pipeline once it’s been approved internally.

Your spend will be approved if the Cabinet Office agrees with how it’s been assessed and one of the following applies:

* the spend was marked ‘assured’
* the spend was marked ‘monitor’ and there’s a plan in place to address the issues currently stopping the spend from meeting the standard

The [Minister for the Cabinet Office](/government/ministers/minister-for-the-cabinet-office) will need to approve anything marked ‘control’.

The Cabinet Office will write to your department to confirm the assessment outcome.

Help with the pipeline process
------------------------------

Email [gdsassurance@digital.cabinet-office.gov.uk](mailto:gdsassurance@digital.cabinet-office.gov.uk) for any questions about the digital and technology spend controls.

Updates to this page
--------------------

Published 4 May 2018

Last updated 29 July 2021
[+ show all updates](#full-history)

1. 29 July 2021

   Updated the amount of technology spend that needs approval from over £5 million to over £1 million.
2. 4 May 2018

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---