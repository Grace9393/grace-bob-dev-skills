Technology - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Technology
==========

Choosing technology, development, integration, hosting, testing, security and maintenance.

Technology strategy for services
--------------------------------

Choosing your technology and approach.

* [Choosing technology: an introduction](service-manual_technology_choosing-technology-an-introduction.md)
* [Using common platforms](service-manual_technology_using-common-components.md)
* [Using commercial-off-the-shelf (COTS) products and services](service-manual_technology_commercial-off-the-shelf-products-and-services.md)

Software development processes
------------------------------

Configuration, version control, pre-production environments, dependencies.

* [Managing software dependencies](service-manual_technology_managing-software-dependencies.md)
* [Maintaining version control in coding](service-manual_technology_maintaining-version-control-in-coding.md)
* [Deploying software regularly](service-manual_technology_deploying-software-regularly.md)
* [Working in pre-production environments](service-manual_technology_working-in-pre-production-environments.md)
* [Manage your software configuration](service-manual_technology_manage-your-software-configuration.md)
* [Making source code open and reusable](service-manual_technology_making-source-code-open-and-reusable.md)

Building your service: the frontend
-----------------------------------

Device and browser requirements, progressive enhancement, HTTPS.

* [Using HTTPS](service-manual_technology_using-https.md)
* [Building a robust frontend using progressive enhancement](service-manual_technology_using-progressive-enhancement.md)
* [Designing for different browsers and devices](service-manual_technology_designing-for-different-browsers-and-devices.md)
* [Making sure your service works well on mobile](service-manual_technology_working-with-mobile-technology.md)
* [Using CAPTCHAs](service-manual_technology_using-captchas.md)
* [Making your frontend accessible](service-manual_technology_accessibility-for-developers-an-introduction.md)

Testing your service
--------------------

Quality assurance, performance testing, vulnerability and penetration testing, exploratory testing.

* [Exploratory testing](service-manual_technology_exploratory-testing.md)
* [Quality assurance: testing your service regularly](service-manual_technology_quality-assurance-testing-your-service-regularly.md)
* [Vulnerability and penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md)
* [Test your service's performance](service-manual_technology_test-your-services-performance.md)
* [Testing with assistive technologies](service-manual_technology_testing-with-assistive-technologies.md)
* [How to test frontend performance](service-manual_technology_how-to-test-frontend-performance.md)

Managing a live service
-----------------------

Uptime, availability, monitoring.

* [Uptime and availability: keeping your service online](service-manual_technology_uptime-and-availability-keeping-your-service-online.md)
* [Monitoring the status of your service](service-manual_technology_monitoring-the-status-of-your-service.md)

Integrating with external software and data
-------------------------------------------

Open standards, moving away from legacy systems, using APIs.

* [Moving away from legacy systems](service-manual_technology_moving-away-from-legacy-systems.md)
* [Working with open standards](service-manual_technology_working-with-open-standards.md)
* [Application programming interfaces (APIs)](service-manual_technology_application-programming-interfaces-apis.md)

Hosting your service
--------------------

Suppliers and domain names.

* [Get a service domain name](service-manual_technology_get-a-domain-name.md)
* [Managing service domains](service-manual_technology_managing-domain-names.md)
* [Deciding how to host your service](service-manual_technology_deciding-how-to-host-your-service.md)

Protecting user information
---------------------------

Security, the cloud, fraud, cookies, user logins and sending email.

* [Protecting your service against fraud](service-manual_technology_protecting-your-service-against-fraud.md)
* [Sending emails from your service](service-manual_technology_how-to-email-your-users.md)
* [Working with cookies and similar technologies](service-manual_technology_working-with-cookies-and-similar-technologies.md)
* [Securing your information](service-manual_technology_securing-your-information.md)
* [Securing your cloud environment for services](service-manual_technology_securing-your-cloud-environment.md)
* [Sending text messages securely](service-manual_technology_sending-text-messages-securely.md)

Join the community
------------------

Find out what the cross-government community does and how to get involved.

* [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)
* [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)
* [Design community](service-manual_communities_design-community.md)
* [Technology community (backend development)](service-manual_communities_technology-community-backend-development.md)
* [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)
* [Buying digital community](service-manual_communities_digital-buying-community.md)
* [Technology community (frontend development)](service-manual_communities_technology-community-frontend-development.md)
* [Accessibility community](service-manual_communities_accessibility-community.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/technology)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---