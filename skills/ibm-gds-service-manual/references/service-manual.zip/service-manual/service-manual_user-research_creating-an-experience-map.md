Creating an experience map - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Creating an experience map
==========================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to use experience mapping](#when-to-use-experience-mapping)
2. [Steps to follow](#steps-to-follow)
3. [Examples of experience maps](#examples-of-experience-maps)
4. [Related guides](#related-guides)

Experience maps provide a visual representation of what users do, think and feel over time, from the point they start needing a service to when they stop using it.

Speaking to a range of users will help you understand all the events, transactions and related services they may experience throughout their journey. Consolidating these into a single map will help you to understand:

* how users experience the current service
* how things work (or don’t)
* interdependencies - for example, between different departments or services
* pain points and where things are broken

When to use experience mapping
------------------------------

Experience mapping works best for services that take place over several weeks or months (for example, applying to become a UK citizen or setting up a business) and involve:

* lots of separate steps or events
* more than one location - for example home, a departmental office, the post office
* different people or teams
* several related services or service touchpoints

Steps to follow
---------------

Create experience maps with your team so that everyone can learn more about your users.

### Preparation

You need to [capture the experience of several users](service-manual_user-research_researching-user-experiences.md) before you create an experience map. Once you’ve done this:

* choose a quiet location with a wall (or table) large enough for you to arrange your cards and create a map
* invite your team to help - reviewing users’ experiences will help them make decisions about how to design and build the service
* gather the event cards you used to capture users’ experiences and stacks of different coloured sticky notes or index cards
* decide a colour-coding scheme for your sticky notes - for example, blue for journey stages, yellow for steps in a process, green and red for emotional high and lows

### Identify common stages

Start by:

* laying out event cards for each participant in a row
* line up common events
* break the rows into stages
* name each stage you’ve identified - use your colour-coded sticky notes to remind people that your aim at this point is to create a simple map - it’s ok to start with only a few stages and iterate as you understand more

Once you’ve laid out your users’ journeys, decide how many maps to create. You should:

* create one consolidated map if all your research participants went through the same stages and similar steps
* create separate maps for different user groups if participants went through different stages and significantly different steps

### Build up the experience

Once you’ve established the stages you want to include, you need to add the steps involved in each. Together, these will form the ‘spine’ of the experience.

You can add to this by extracting important information from event cards. Look for evidence of:

* emotional highs and lows - record these on different coloured sticky notes and add relevant quotes
* people’s reactions and thought processes
* service touchpoints
* which channels the service is delivered through
* user needs at specific stages

You can also add photos and artefacts collected during your research.

### Live with the map

Once you’ve created a draft map, move it to your team area. Over the next few days or week:

* talk it over with your team
* show it to lots of people - for example, people who observed your research with users, teams who deliver parts of your service, other researchers
* review, rearrange, rename and reword things until you’re happy the map is both clear and accurately reflects your users’ experience

### Draw a detailed map

Once you’re happy with your draft map:

* draw it in your preferred graphics application
* print it at large scale and stick it on a wall in your team area

Your map can be based on a simple grid design that shows the stages, steps and activities your users experience over time.

![ ](https://assets.publishing.service.gov.uk/media/5bc49d0040f0b6386354ac8f/experiencemap.svg)

Use your map to structure discussions about your users’ experience and how you’re working to improve it.

### Share a summary map

Most people outside your team won’t be interested in detail, so make a summary map that you can share. This should:

* just show stages and key findings for each stage
* include a few images and quotes
* be self-explanatory - you shouldn’t have to explain it further
* be easy to read on both screen and paper

Examples of experience maps
---------------------------

You might find the following blog posts about experience mapping useful:

* [why we use journey maps in government](https://designnotes.blog.gov.uk/2016/03/30/why-we-use-user-journey-maps-in-government/)
* [mapping services for the Ministry of Justice](https://mojdigital.blog.gov.uk/2014/06/19/mapping-services-for-the-ministry-of-justice/)

Related guides
--------------

You may also find the [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md) guide useful.

Updates to this page
--------------------

Published 21 February 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---