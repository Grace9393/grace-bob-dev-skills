Maintaining version control in coding - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Maintaining version control in coding
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (backend development)](service-manual_communities_technology-community-backend-development.md)

Contents
--------

1. [Making commits](#making-commits)
2. [Writing commit messages](#writing-commit-messages)
3. [Using distributed version control systems](#using-distributed-version-control-systems)
4. [Other uses for version control](#other-uses-for-version-control)
5. [Related guides](#related-guides)

You must have a way to maintain version control for your code.

Version control means keeping track of changes to your code over time.

It allows you to:

* revert to an earlier version whenever you want to
* record your changes and the reasons why you made them, to help future developers understand the process
* work on changes in parallel as a team before merging them together

Making commits
--------------

Making a commit means making a set of changes permanent. You should:

* write clear commit messages
* group changes according to their purpose
* review new changes

Writing commit messages
-----------------------

You should commit any changes with a clear message explaining the change. Clear commit messages help new or future developers and the public to see the changes you’ve made.

Your commit messages should:

* describe what you’ve changed and why
* link to any supporting information like development stories, bug reports, or third party documentation

For example, if the change is helping to fix a bug in a certain browser, your commit message could be:

`Set cache headers`   
  
`Browser-name was doing foo, so we need to do X.`   
`See http://example.com/why-is-this-broken for more details.`

### Grouping changes

When updating code, you should make small separate commits of changes and group the changes according to their purpose.

For example, if you make several commits in order to fix a bug, you should group those changes together.

### Reviewing changes

Whenever possible, you should review each others’ code. The process for this could change between teams, but make sure:

* every code change is reviewed by someone who did not write it
* the process does not stop you from [deploying software regularly](https://www.gov.uk/service-manual/technology/deploying-software-regularly) or making quick bug fixes

Using distributed version control systems
-----------------------------------------

You should use a distributed version control system so that:

* everyone involved in the process has a full copy of the code and its history
* it’s easier for developers to create ‘branches’ in their code to explore new features or approaches without encroaching on other work
* developers can continue to work when the network is unavailable, making small incremental commits, merging their changes back with everyone else’s at a later date

The Government Digital Service (GDS) and many other government teams use a distributed version control system called Git.

You can read:

* [a blog post about how GDS uses Git](https://gdstechnology.blog.gov.uk/2014/01/27/how-we-use-github/)
* [internal guidance for GDS teams about using Git](https://gds-way.digital.cabinet-office.gov.uk/standards/source-code/working-with-git.html)

Other uses for version control
------------------------------

You can also use version control in other parts of the work you’re doing to build your service.

For example, [see how the World Wide Web Consortium (W3C) is using Git and GitHub](https://github.com/w3c/html) to manage its specifications.

Related guides
--------------

You may also find the [Deploying software regularly](https://www.gov.uk/service-manual/technology/deploying-software-regularly) guide useful.

Updates to this page
--------------------

Published 23 May 2016

Last updated 2 December 2016
[+ show all updates](#full-history)

1. 2 December 2016

   Grouping changes and reviewing sub-sections added.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---