Assisted digital and digital take-up community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Assisted digital and digital take-up community
==============================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [Assisted digital and digital take-up in the Service Manual](#assisted-digital-and-digital-take-up-in-the-service-manual)

The assisted digital and digital take-up community exists to develop knowledge and awareness across government of how to:

* design assisted digital support
* encourage digital take-up

Who the community is for
------------------------

You might be interested in this community if your work involves:

* procuring, designing or managing assisted digital support
* working on channel shift strategies to increase the percentage of people using your digital service

Get involved
------------

### Online

Join these groups to discuss particular aspects of assisted digital and digital take-up, depending on your area of interest:

* user needs and user research - [user research Google group](https://groups.google.com/a/digital.cabinet-office.gov.uk/forum/#!forum/digital-user-research)
* building and designing services - [digital service designers Google group](https://groups.google.com/a/digital.cabinet-office.gov.uk/forum/#!forum/digital-service-designers)
* measuring effectiveness - [cross-government performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Post any other questions in the [assisted digital and digital take-up Google group](https://groups.google.com/a/digital.cabinet-office.gov.uk/forum/?hl=en-GB#!forum/ad-and-dtu-interest-group).

If you cannot access one of these discussion spaces, email [adteam@digital.cabinet-office.gov.uk](mailto:adteam@digital.cabinet-office.gov.uk).

### Training and events

GDS Academy’s 6-day [service owner course](https://www.gov.uk/guidance/service-owner-course-description) includes a module on assisted digital.

Community resources
-------------------

Use these resources to learn more about assisted digital and digital take-up in government:

* [GDS blog – assisted digital](https://gds.blog.gov.uk/tag/assisted-digital/) - stories from GDS about the assisted digital and digital take-up programme

Assisted digital and digital take-up in the Service Manual
----------------------------------------------------------

These guides show what we currently believe is best practice in assisted digital and digital take-up for government services:

* [Assisted digital support: an introduction](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)
* [Designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md)
* [How your assisted digital support will be assessed](service-manual_helping-people-to-use-your-service_how-your-assisted-digital-support-will-be-assessed.md)
* [Encouraging people to use your digital service](service-manual_helping-people-to-use-your-service_encouraging-people-to-use-your-digital-service.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Updates to this page
--------------------

Published 7 April 2016

Last updated 8 April 2016
[+ show all updates](#full-history)

1. 7 April 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---