Designing for different browsers and devices - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Designing for different browsers and devices
============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (frontend development)](service-manual_communities_technology-community-frontend-development.md)

Contents
--------

1. [Test for compatibility](#test-for-compatibility)
2. [Browsers to test in (from September 2024)](#browsers-to-test-in-from-september-2024)
3. [Testing with assistive technologies](#testing-with-assistive-technologies)
4. [Design for your audience](#design-for-your-audience)
5. [Adapt to changing behaviour](#adapt-to-changing-behaviour)
6. [Related guides](#related-guides)

Your service must be universally accessible. This means building it to work on every browser or device that your users access it on.

Test for compatibility
----------------------

Technology is always changing, so users’ experience of your service will vary according to the technical capabilities of their browsers and devices.

Different browsers handle technologies like CSS, HTML and JavaScript in slightly different ways. It’s fine if there are small, visible differences in how a page renders - as long as it doesn’t make it harder for the user to understand the content or interact with the page.

Services do not have to look perfect in every browser but users must be able to access and use all the information and features they need, regardless of which browser they use.

Use [progressive enhancement](service-manual_technology_using-progressive-enhancement.md) to give your service the best possible chance of working for the majority of your users.

Browsers to test in (from September 2024)
-----------------------------------------

You should test your service in these browsers:

| Operating system | Browser |
| --- | --- |
| **Windows** | Edge (latest versions) |
|  | Google Chrome (latest stable version) |
|  | Mozilla Firefox (latest stable version) |
| **macOS** | Safari 15.6 and later |
|  | Google Chrome (latest stable version) |
|  | Mozilla Firefox (latest stable version) |
| **iOS** | Safari for iOS 15.6 and later |
|  | Google Chrome (latest stable version) |
| **Android** | Google Chrome (latest stable version) |
|  | Samsung Internet (latest stable version) |

You will still need to support Internet Explorer 11 if your analytics data shows at least 2% of your users arriving at the service’s start page are using it.

Consider the impact on users. For example, they may be required to use a particular browser. Consider doing some user research to learn more.

### Understanding the table

Users must be able to access the information they need or be able to complete their task without layout issues causing any problems, for example vital information or form fields becoming difficult to access.

This list in the table is based on usage statistics for GOV.UK and represents approximately 95% of the most popular browsers. It’s updated in September every year.

### Testing for services that are for government use

If your service is aimed at internal users rather than the general public you should look at your analytics data and check which browsers your users are using. Then you can then make an informed decision about which browsers to test with.

Testing with assistive technologies
-----------------------------------

You’ll also need to [make sure your service works with assistive technologies](https://www.gov.uk/service-manual/technology/testing-with-assistive-technologies).

Design for your audience
------------------------

When designing your service, you should analyse your users’ choice of:

* operating systems
* browsers
* browser versions
* screen size/resolutions
* choice of mobile device

If evidence shows that your users have specific needs or extra support requirements, you can use this to make a case for not meeting these browser requirements.

For example, the trade tariff team chose not to tailor their tool to smaller screens as it’s largely used by office workers working during office hours.
Equally, if your audience is likely to include those working in the public sector, there may be higher use of older, more limited browsers.

As your digital service develops, you should encourage more people to use it (this is called ‘channel shift’). You should also consider how this may affect future usage patterns. Channel shift means you must also consider your potential future audience.

Adapt to changing behaviour
---------------------------

Decisions about compatibility cannot be something you specify at the start of your project and then forget about. Digital services need to reflect and adapt to the changing digital behaviour of their users.

Do this by researching your users and checking statistics on a regular basis. You must also make sure there’s an obvious way for users to report problems so you can carry out additional testing and make adjustments to your service.

New products and platforms might not appear in any data, but it makes sense for you to test against them if they’re likely to be popular.

You also have to work out when to stop supporting a product or system if its popularity is declining.

Related guides
--------------

You may also find these guides useful:

* [Progressive enhancement](service-manual_technology_using-progressive-enhancement.md)
* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Testing for accessibility](service-manual_technology_testing-for-accessibility.md)

Updates to this page
--------------------

Published 23 May 2016

Last updated 18 September 2024
[+ show all updates](#full-history)

1. 18 September 2024

   List of browsers to test in updated. Commitment to update browser list updated to annual.
2. 16 June 2022

   Updated the list of browsers to support, removing Internet Explorer. Added some information on circumstances when it should still be supported.
3. 6 August 2021

   Reviewed list of browsers to make sure it's still current, based on recent usage figures for GOV.UK. No change from the January 2021 version of the list.
4. 4 February 2021

   Reviewed list of browsers to make sure it's still current, based on recent usage figures for GOV.UK. No change from the June 2020 version of the list.
5. 30 June 2020

   Reviewed list of browsers to make sure it's still current, based on recent usage figures for GOV.UK. No change from the January 2020 version of the list.
6. 20 December 2019

   Updated list of browsers to test in: earliest version of iOS Safari is now 12.1 rather than 10.3.
7. 25 June 2019

   Updated the requirement to test in Safari for iOS from 9.3 to 10.3 to reflect usage statistics.
8. 11 January 2019

   Removed requirement to test with Safari 11 and earlier versions, as they fall outside of the 95% most popular browsers.
9. 26 June 2018

   Removed Internet Explorer versions 8 to 10 from the list of browsers to test your service with.
10. 4 May 2018

    Removed requirement to test on Windows phone, as it falls outside of the 95% most common browser/device combinations.
11. 16 March 2018

    Added links to Microsoft virtual machines for testing services in IE 8 to 10.
12. 12 January 2018

    Samsung Internet added to list of browsers you must test with.
13. 3 October 2017

    Added guidance on how to test with different assistive technologies, including which software to test with.
14. 6 April 2017

    Updated browser requirements table based on usage statistics:
    \* Internet Explorer 8 (functional) to Internet Explorer 8-10 (functional)
    \* Internet Explorer 9+ (compliant) to Internet Explorer 11 (compliant)
    \* Safari 9+ (compliant) to Safari 9.3+ (compliant)
15. 16 November 2016

    The list of browsers to test in has been updated.
16. 5 September 2016

    Updated the list of browsers to test in for public-facing and government-only services.
17. 23 May 2016

    Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---