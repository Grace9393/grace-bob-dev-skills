Securing your information - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Securing your information
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Security for 'secret' or 'top secret' information](#security-for-secret-or-top-secret-information)
2. [Before you start assessing security](#before-you-start-assessing-security)
3. [When to start considering information security](#when-to-start-considering-information-security)
4. [How to assess information security](#how-to-assess-information-security)
5. [Carrying out a risk assessment](#carrying-out-a-risk-assessment)
6. [Protecting information](#protecting-information)
7. [Getting an IT Health Check](#getting-an-it-health-check)
8. [Further reading](#further-reading)

Information security is the technologies, policies and practices you choose to help you keep data secure.

It’s important because government has a duty to protect service users’ data. Without this protection, users could lose trust in public services.

The government’s [Cloud First policy](https://www.gov.uk/guidance/government-cloud-first-policy) means you’ll most likely be building your system in the cloud. Find out more about [securing your cloud environment](service-manual_technology_securing-your-cloud-environment.md).

Security for ‘secret’ or ‘top secret’ information
-------------------------------------------------

This guidance is for services holding information that’s classified by the government as ‘official’.

If your service handles information that’s classified as ‘secret’ or ‘top secret’, then you should ask for specialist advice from your department or agency security team.

Before you start assessing security
-----------------------------------

### Accept your service will have information risk

It’s unrealistic to aim for a service with no information risk.

You should [document your service assets](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/documenting-service-assets/) and identify the risk to your service posed by your technology choices, processes, staffing and data aggregation.

When you understand this risk, you can [work out your project’s risk appetite](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/working-out-the-projects-security-risk-appetite/) then [agree on appropriate security controls](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/agreeing-a-security-controls-set-for-your-service/) to mitigate risks.

### Talk to risk professionals

You need to discuss your security decisions with your organisation’s risk owner. Do this as early as possible when starting to develop your service.

Your risk owner is responsible for dealing with risk in all your organisation’s services.

They can help you decide the risks you can accept and put a plan in place to mitigate against those you can’t.

When to start considering information security
----------------------------------------------

The government [Secure by Design approach](https://www.security.gov.uk/policy-and-guidance/secure-by-design/) is to start thinking about the security of your service in the discovery phase.

[Government security policy](/government/publications/security-policy-framework/hmg-security-policy-framework) means your security measures must be proportionate to the risk and still allow user needs to be met while maintaining the appropriate level of security.

How to assess information security
----------------------------------

When you’re assessing the security of your service and the data you hold, you should consider it under the following general categories:

* confidentiality: information should only be seen by people who are authorised to access it
* integrity: information should only be modified by people who are authorised to do so
* availability: information should be available when needed. Problems or attacks shouldn’t stop you getting information from the system
* non-repudiation: nothing should happen in a system that can’t be traced back to a responsible person

Also consider any relevant privacy legislation and talk to your data protection officer about this.

Carrying out a risk assessment
------------------------------

The [recommended approach for risk assessments](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/performing-a-security-risk-assessment/) suggests that you should:

1. Consider threats to your system and the information and assets you store.
2. Record any risks you believe are possible even if you don’t have a solution.
3. Prioritise the risks you identify as most likely and the risks that would have the biggest effect on your service and your users.

### Learn more about risk assessment

Read these articles to see how other digital organisations manage risk:

* [Risk management introduction](https://www.ncsc.gov.uk/collection/risk-management-collection) (The National Cyber Security Centre)
* [The Security Development Lifecycle](https://www.microsoft.com/en-us/sdl/) (Microsoft)

### Risk assessment techniques

Throughout your service’s development, you can assess how well you’re managing risks by using techniques like third-party code audits and [penetration testing](service-manual_technology_vulnerability-and-penetration-testing.md).

You should [run red team exercises and game days](https://gdstechnology.blog.gov.uk/2015/02/06/running-a-game-day-for-gov-uk/) to rehearse incident management practices.

If an actual incident occurs, you can [use a blameless post mortem](https://codeascraft.com/2012/05/22/blameless-postmortems/) to identify whether there are actions that would improve the team’s ability to respond in future.

Protecting information
----------------------

Once you’ve identified the risks to your information, you can consider how to reduce them, for example by using:

* physical controls like walls, locked doors or guards
* procedural controls like making a manager responsible for access, training staff or putting emergency response processes in place
* regulatory controls like legislation, policy or rules for staff
* technical controls like cryptographic software, authentication and authorisation systems or secure protocols

### Choosing which controls to use

To choose controls, you need to assess the risk of information disclosure or modification then decide which risks you’re willing to take.

Many controls come with drawbacks and you may find some don’t suit your service.

Learn about [agreeing a security controls set for your service](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/agreeing-a-security-controls-set-for-your-service/).

### On-demand or reactive protection

The controls explained in this guide help to prevent incidents occurring but it is also important for your organisation to detect incidents and react to them.

For example, it is possible to arrange Distributed Denial of Service (DDOS) protection that comes into effect when an attack takes place. This may seem like an unnecessary expense, however the cost needs to be weighed up against the resources it would take to identify and resolve this issue without protection in place.

Getting an IT Health Check
--------------------------

[An IT Health Check](/government/publications/it-health-check-ithc-supporting-guidance/it-health-check-ithc-supporting-guidance#choosing-a-testing-partner) provides assurance that your organisation’s external systems are protected from unauthorised access or change.

The check will be a penetration test carried out by a National Cyber Security Centre (NCSC) supplier. Read more about [penetration tests](service-manual_technology_vulnerability-and-penetration-testing.md).

Further reading
---------------

Read about [Secure by Design](https://www.security.gov.uk/policy-and-guidance/secure-by-design/) and the [NCSC guidance on building secure services](https://www.ncsc.gov.uk/collection/developers-collection).

For projects using artificial intelligence, read the [AI Playbook](https://www.gov.uk/government/publications/ai-playbook-for-the-uk-government).

Updates to this page
--------------------

Published 20 October 2016

Last updated 17 October 2024
[+ show all updates](#full-history)

1. 17 October 2024

   Integrated guidance on Assessing the importance of service assets, Performing threat modelling, Performing a security risk assessment, Agreeing a security controls set for your service, Responding to and mitigating security risks and Retiring service components securely.
2. 21 May 2018

   Removed references to Data Protection Act 1998.
3. 20 October 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---