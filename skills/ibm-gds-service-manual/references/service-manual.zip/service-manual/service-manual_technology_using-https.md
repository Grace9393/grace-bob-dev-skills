Using HTTPS - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Using HTTPS
===========

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Configuring HSTS](#configuring-hsts)
2. [Serving your assets efficiently](#serving-your-assets-efficiently)
3. [Further reading](#further-reading)
4. [Related guides](#related-guides)

Many services collect personal information from users or present information to them which they then use to make important decisions.

It’s important that you build a service that does not allow this information to be intercepted or modified by malicious third parties as it travels over the internet.

This means you must make sure your service (including APIs) is only accessible through secure connections. For web-based services this means [HTTPS](https://en.wikipedia.org/wiki/HTTPS) only, with an HTTP Strict Transport Security (HSTS) configuration as explained in this guide.

(HTTPS describes the use of TLS, a lower level protocol previously known as SSL, to secure HTTP requests.)

Configuring HSTS
----------------

HSTS is an extension to the HTTPS protocol that tells web browsers that subsequent connections to a site must use HTTPS, and not an insecure protocol.

This helps defend users from attacks on subsequent visits to a site. Browser vendors can also preload this configuration in their browsers to defend users on their first connection to the site.

You should use this HSTS header which the Central Digital and Data Office (CDDO) recommends:

`Strict-Transport-Security: max-age=31536000, includeSubDomains; preload;`

Read National Cyber Security Centre (NCSC) guidance on [using TLS for external-facing services](https://www.ncsc.gov.uk/guidance/tls-external-facing-services).

Serving your assets efficiently
-------------------------------

The way your users’ browsers access your service’s assets (for example stylesheets, JavaScript, images) may change their opinion of the service, and this can affect its success.

In particular, how and where they’re hosted can have a dramatic impact on perceived and actual page-load times.

Do not link to assets hosted by another service, like GOV.UK, as their location may change without notice and break your service.

Historically, limitations in HTTP/1.1 have resulted in practices designed to work around these limitations. In response to many of these limitations, HTTP/2 has been developed which does not require these workarounds, and which will provide better performance once deployed.

HTTP/1.1 and HTTP/2 can be concurrently supported by web server software, and if HTTP/2 is not supported by the browser, HTTP/1.1 will be used.

In early 2016, support for HTTP/2 in web browsers in use was [measured at around 56%](https://blog.cloudflare.com/cloudflares-impact-on-the-http-2-universe/), and rising rapidly.

Depending on the browsers in use by your users, you may decide to optimise for HTTP/1.1 users. In this case, common practice is to serve assets from a separate hostname (this avoids sending bulky cookies in requests for assets).

For example, if your service is at www.servicename.service.gov.uk, you should serve your assets from assets.servicename.service.gov.uk.

Further reading
---------------

The following videos explain how HTTPS works:

* [Public Key Cryptography: Diffie-Hellman Key Exchange, from the Art of the Problem channel](http://bit.ly/SM086t)
* [Secure web browsing, from the Computerphile channel](http://bit.ly/2mOSKM0)

For more detailed information about optimising web application performance and particularly for optimising for HTTP/1.1 or HTTP/2, see [Chapter 13 of High Performance Browser Networking](https://hpbn.co/optimizing-application-delivery/).

Related guides
--------------

You may also find the following guides useful:

* [Using progressive enhancement](service-manual_technology_using-progressive-enhancement.md)
* [Designing for different browsers and devices](service-manual_technology_designing-for-different-browsers-and-devices.md)

Updates to this page
--------------------

Published 23 May 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---