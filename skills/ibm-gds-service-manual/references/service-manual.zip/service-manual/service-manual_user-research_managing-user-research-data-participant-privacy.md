Managing user research data and participant privacy - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Managing user research data and participant privacy
===================================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [User research and the General Data Protection Regulation (GDPR)](#user-research-and-the-general-data-protection-regulation-gdpr)
2. [Managing participants’ personal data during recruitment](#managing-participants-personal-data-during-recruitment)
3. [Managing the research data you collect and use](#managing-the-research-data-you-collect-and-use)
4. [Protecting privacy when sharing research outputs](#protecting-privacy-when-sharing-research-outputs)
5. [Making sure colleagues protect participant privacy](#making-sure-colleagues-protect-participant-privacy)
6. [Working with service providers, contractors and third-party staff](#working-with-service-providers-contractors-and-third-party-staff)
7. [Protecting participant privacy when reporting findings publicly](#protecting-participant-privacy-when-reporting-findings-publicly)

You must manage the user research data and participant details you collect so that you protect participants’ privacy and comply with the law.

User research data includes:

* your notes from research sessions
* photos, audio and video recordings
* information that participants enter into prototypes or test versions of services
* paperwork that participants refer or respond to

Participant details include:

* contact details like names and addresses
* data collected when you recruit participants, for example responses to screening questions

User research and the General Data Protection Regulation (GDPR)
---------------------------------------------------------------

GDPR came into effect in May 2018. For user research, the important things to note about GDPR are:

* it defines [personal data](https://ico.org.uk/for-organisations/guide-to-the-general-data-protection-regulation-gdpr/key-definitions/what-is-personal-data/) broadly, so that it can include data like online identification markers and location data
* rules around evidence of informed consent and withdrawal of consent are strict
* it sets out stronger requirements for documenting and auditing your practices

To make sure your research data management and privacy practices comply with the law, we recommend having them reviewed by the data protection expert or legal adviser in your organisation. This might include completing a data privacy impact assessment (DPIA).

Managing participants’ personal data during recruitment
-------------------------------------------------------

### Be clear about personal data during recruitment

However you [recruit participants](https://www.gov.uk/service-manual/user-research/find-user-research-participants), make sure that they know what data you plan to collect and how you’ll use it. Do this as early in the recruitment process as you can.

We recommend providing participants with [an information sheet](service-manual_user-research_getting-users-consent-for-research#getting-informed-consent.md) that allows participants to give their informed consent.

### Take care of participants’ contact details and other data

Collect and use the minimum information you need to manage their participation. For example, if you are using a participant recruitment agency you may only need to know the participant’s name so that you can book them in with your building reception.

Store participants’ details securely and share them only with colleagues who need to use those details to manage participation in the research. For example, during private beta a colleague might need to send participants information about follow up interviews.

Take particular care of any sensitive personal information that participants give in response to screening questions. For example, personal information about children, or information relating to ethnicity, health, genetics or biometrics. You can check with your organisation’s data protection expert or legal adviser for help.

Delete participants’ contact and other details as soon as you no longer need them to manage their participation in your research.

#### Get informed consent for any data you collect and use

You must get [informed consent](https://www.gov.uk/service-manual/user-research/getting-users-consent-for-research) from all participants for all user research activities.

This consent must cover the data you’ll collect, how you’ll store and use it, and who you’ll share it with.

You must then use the research data only within the consent you have.

Managing the research data you collect and use
----------------------------------------------

### Treat all research data as personal data

You should treat as personal data all the notes, recordings and other data you collect during your research.

Take particular care of any sensitive personal information that you collect. For example, personal information about children, or information relating to ethnicity, health, genetics or biometrics. You can check with your organisation’s data protection expert or legal adviser for help.

### Collect only the data you need

When [planning your research](https://www.gov.uk/service-manual/user-research/plan-user-research-for-your-service) and [choosing your approach to note taking and recording](https://www.gov.uk/service-manual/user-research/taking-notes-and-recording-user-research-sessions), design your research activities to collect only the data that you need to answer your research questions.

As well as saving time and effort, this will make it easier for you to:

* manage the research data
* protect the participants’ privacy
* collect informed consent and stay within the consent you get

### Agree a retention period

You should agree a reasonable retention period for your research data.

While broad user research findings can be valuable for a long time, most raw user research data loses its value quite quickly.

We suggest 2 or 3 years as reasonable retention periods for user research data - but delete it sooner if it’s no longer needed.

### Store research data securely at all times

You should collect and transport research data only on devices that your organisation has approved for storing and processing personal data. Take particular care when using smartphones that can backup notes, photos and recordings to cloud data storage.

Move research data from devices like cameras and voice recorders to more secure storage as soon as possible. For example, at the end of a set of research sessions you might transfer the sound files from a voice recorder to an encrypted storage device, and then use a data deletion utility to securely delete the data from the SD card in the recorder.

Keep your research data only in places that your organisation has approved for storing personal data. For example, GDS user researchers use Google Team Drive and researchers in other government organisations use Microsoft OneDrive.

Restrict access to the data to those who specifically need to use it. Where the technology allows, prevent colleagues from copying and downloading the data.

### Name and organise your research data clearly

Under GDPR, research participants have the right to access the personal data you hold about them. They can also ask you to delete their data.

You must name and organise your research data so that you can find the specific data you collected about a participant, and delete it if necessary. For example, you might have a folder structure based on service teams or product areas, with individual research data file names that include the date it was collected, the research round number and the participant number.

If a participant makes a request about their data, you can ask them additional questions to help you find their data. For example, you might ask them what the research was about, and when and where the research happened.

### Keep a record of the consent with the data you collect

You must keep a record of the consent you collected from each participant, and what they agreed to.

You can do this by:

* scanning and keeping a copy of a signed paper consent form - you should shred the paper version
* downloading and keeping copies of emails confirming consent
* if you use a survey, including a positive confirmation of consent as the first step and keeping the response

Keep the record of consent with the research data it covers. And make sure you can match the record to the data. For example, by using the date collected, the research round number and the participant number to name the scan of a consent form.

### Use and share data only within the purpose and consent you have

It is important that you use your research data only for the purpose the participants gave consent for.

For most user research in government, the purpose is to improve a government service. If you want to use the research data for any other purpose, make sure you clearly explain that purpose to the participants so you have their informed consent.

Different government organisations often work together to build and improve services. If staff from other organisations will be involved in analysing research data or reviewing research data, make sure you tell participants about those organisations.

If you use third-party suppliers to process any research data, for example creating transcripts of interviews, include this in your [consent materials](service-manual_user-research_getting-users-consent-for-research#getting-informed-consent.md).

### Delete research data when no longer needed

You must establish a process for deleting research data when you no longer need it, or when it reaches the end of its retention period.

You must also delete any research data where you do not have clear evidence of consent.

Protecting privacy when sharing research outputs
------------------------------------------------

### Use fully anonymised extracts whenever possible

It’s normal to illustrate user research outputs with extracts from user research data - such as quotes, photos, screenshots, sound and video clips.

Whenever you can, you should fully anonymise the extracts you use so that the participants cannot be identified.

With anonymised extracts, there are no concerns with sharing the outputs widely - including making them public. And there’s also nothing you need to do with the research outputs if a participant requests access to their personal data or withdraws their consent.

For example, you might want to use screenshots from usability tests to illustrate a blog post about changes you are making to a service. If you choose screenshots that include no personal data, or blur any personal data that does appear, then you can use the screenshots in the blog post.

The UK Data Service have useful guidance on [anonymising both quantitative and qualitative research data](https://www.ukdataservice.ac.uk/manage-data/legal-ethical/anonymisation).

### Always remove direct personal identifiers

Some extracts from user research can be difficult to fully anonymise, or can lose much of their value when they are fully anonymised.

Whether or not you fully anonymise an extract, we recommend that you always remove or obscure:

* direct personal identifiers - such as names or badge numbers
* contact details - such as addresses and phone numbers
* other confidential information - such as bank account details

For example, you have a video clip of a colleague describing how they review and approve an application. Given the context it is impossible to fully anonymise the clip and still show the important activity. So you blur the confidential information that appears on the screen and on the paperwork, and ‘bleep’ out the names from the soundtrack.

### Limit the sharing of outputs where participants can be identified

If a research output is not fully anonymised, restrict access to those who specifically need to use it. Where the technology allows, prevent colleagues from copying and downloading the material.

Only share non-anonymised research outputs with the third parties you told participants their data would be shared with.

It’s best not to make public any non-anonymised research outputs. Once others have downloaded and copied the outputs, it is difficult to find and destroy the personal data if a participant withdraws their consent.

For example, you have a compelling clip of a member of the public experiencing a problem with a service. You decide to restrict access to the clip and show it only to members of your team at closed show and tell sessions.

Making sure colleagues protect participant privacy
--------------------------------------------------

You may have non-research colleagues taking part in user research activities - for example, by [coming on research visits](https://www.gov.uk/service-manual/user-research/contextual-research-and-observation), [taking notes](https://www.gov.uk/service-manual/user-research/taking-notes-and-recording-user-research-sessions) and [joining in analysis sessions](https://www.gov.uk/service-manual/user-research/analyse-a-research-session). Or perhaps you share the findings from user research in show and tells.

Make sure that everyone involved understands their responsibilities for protecting the privacy of research participants. For example, by briefing observers before research sessions, and reminding show and tell attendees to be careful about what they share on social media.

The Home Office have produced a useful poster of [observation room do’s and don’ts](https://github.com/UKHomeOffice/posters/blob/master/research/dos-donts-user-research/research-lab-dos-donts.pdf).

Working with service providers, contractors and third-party staff
-----------------------------------------------------------------

### Have appropriate contracts with service providers

During user research it is normal to use third-party services like recruitment agencies, research labs, survey tools and transcription services.

This usually means that participants’ personal data is shared between you and these third parties, so make sure your contracts with them meet data privacy requirements.

This means including things like:

* being clear what the personal data can be used for - and prohibiting any use apart from this (for example, sharing it with another organisation)
* making sure data is deleted when it’s no longer needed
* saying which organisation is responsible for the data collected (known as the ‘data controller’)

Work with your data protection expert or legal adviser to make sure your organisation’s contracts follow the rules.

### Make sure contractors and third-party staff follow your practices

If you have interim staff or staff from suppliers working on your team, they should follow your data privacy practices. Your contract with them should make it clear what you expect.

For example, if an interim user researcher uses their own laptop during visits to participants, you should make it clear that they must follow your general IT procedures about acceptable use, bringing your own device and information management, as well as specific procedures for user research data.

Protecting participant privacy when reporting findings publicly
---------------------------------------------------------------

Government recognises the value of [making research open where possible](https://www.gov.uk/government/publications/open-access-to-research-independent-advice-response). And one of the government design principles is to [make things open, it makes things better](https://www.gov.uk/guidance/government-design-principles#make-things-open-it-makes-things-better).

So government organisations can publish research reports and blog posts about their findings and [share research findings](https://www.gov.uk/service-manual/user-research/sharing-user-research-findings) in response to Freedom of Information requests.

If you do make user research findings public, make sure that you remove participants’ personal data and fully anonymise any research data you use to illustrate your findings.

Updates to this page
--------------------

Published 5 November 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---