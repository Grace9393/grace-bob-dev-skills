Planning and writing text messages and emails - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Planning and writing text messages and emails
=============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [When to send emails and text messages](#when-to-send-emails-and-text-messages)
2. [Transactional messages](#transactional-messages)
3. [Subscription messages](#subscription-messages)
4. [Choosing email or text message](#choosing-email-or-text-message)
5. [Protect your users from spam and phishing](#protect-your-users-from-spam-and-phishing)
6. [How to write emails and text messages](#how-to-write-emails-and-text-messages)
7. [Related guides](#related-guides)

This guide explains when to send emails and text messages to your users and how to write them.

When to send emails and text messages
-------------------------------------

Always consider whether you can send an email or text message instead of a letter. If a user doesn’t respond, you may still be able to follow up with a letter.

Some information is too sensitive to be sent by email or text. You should consider this and discuss anything you’re not sure about with your information assurance team.

Only send email or text messages when it meets a user need. Two types of message that meet a user need are transactional messages and subscription messages.

Transactional messages
----------------------

Transactional messages relate directly to something a user has done. For example:

* they completed a transaction, and you’re sending them a confirmation email
* they paid for an annual service a year ago, and you’re reminding them that it’s about to expire
* their application has been approved, and you’re sending them a text message to let them know

Transactional messages reassure the user that the service is working as they expect it to. They reduce anxiety and stop users contacting your service needlessly.

Look at your service end to end and find the points where users are likely to get anxious. Talk to your contact centre staff to find out why people are contacting you.

If you’re sending an email or text message because the user has completed an action, automate the sending so that the user gets it straight away. That way they will know they’ve been successful.

If a message doesn’t need to be sent immediately, consider sending it during business hours as it’s more likely to be read. If possible, avoid sending text messages late at night.

You don’t need to ask permission to send transactional messages. Make it clear to users when you collect any details that you may use them for sending messages.

### Example of a transactional message

Transport for London’s Dial-a-Ride service sends users the following text message to confirm the details of a booking:

Dial-a-Ride: Your vehicle will arrive in approximately [number of minutes] at [time of day] on [date]. Your driver today is [driver name].

Subscription messages
---------------------

Subscription messages relate to something a user has asked to be updated about - for example, the publication of new information or changes to government guidance.

Never send subscription messages unless the user has explicitly asked for them - for example, by signing up for alerts. Always give users a way to unsubscribe.

### Example of a subscription message

Users who sign up to be notified when their MOT is about to expire receive the following email:

From: MOT Remind me <mot-remind-me@notifications.service.gov.uk>

Subject: You’ve signed up for an MOT reminder for [vehicle details]

Body of email:

You’ve signed up for MOT reminders.

The MOT for [vehicle details] [is due or expires] on [date].

You’ll get an annual reminder a month before your MOT is due, and again 2 weeks later if you don’t have your MOT yet.

DVSA (Driver and Vehicle Standards Agency)

Unsubscribe from MOT reminders: [link to unsubscribe]

Choosing email or text message
------------------------------

When choosing whether to send an email or text message, consider:

* which contact details you hold and have permission to use
* what individual users have said about how they prefer to be contacted
* the length of your message

It’s a good idea to use a mix of emails and text messages, especially if the contact details you have are old and might be out of date. For example, you could send an email asking a user to do something. If they haven’t done it after a week, follow it up with a text message.

You should avoid sending emails and text messages at the same time, unless there’s a very good reason to do this.

Protect your users from spam and phishing
-----------------------------------------

When contacting your users, you must:

* leave out sensitive information, like bank details
* avoid making requests for personal information, like a user’s date of birth
* only send links which point to the GOV.UK domain
* spell out any web addresses (URLs) in full to show the user where links are going - for example, https://www.gov.uk/exampleservice
* avoid including redirects in any links - for example, tracking
* avoid sending attachments with emails
* include the user’s first name and surname in the body of the email to make phishing more difficult

You must also follow [technical standards for emails](service-manual_technology_how-to-email-your-users.md).

How to write emails and text messages
-------------------------------------

Follow the [Government Digital Service (GDS) style guide](https://www.gov.uk/guidance/content-design/writing-for-gov-uk) and [write clearly using plain English](https://www.gov.uk/guidance/content-design/writing-for-gov-uk#how-people-read).

### Personalise your messages

Users are more likely to trust information that’s relevant and clearly meant for them. You should:

* say who the message is from - consider that the name of your service might mean more to the user than your department or agency name
* tailor your message - for example, use ‘visa application’ for the email subject line rather than something generic like ‘application’
* start emails with ‘Dear [firstname lastname]’ not ‘Hi’ (you don’t need to do either for texts)
* include a reference number and contact details for your service if the user might need to contact you

### Be concise

Keep email and text messages short and to the point. Say only one important thing in each message. If you have several important things to say, send more than one message.

Get the most important information across in the first sentence, so it’s more likely to be read (and to appear in the preview). Remember that email subject lines are often shortened.

Don’t use jargon or acronyms without explanation.

### Give clear instructions

Don’t explain back-end processes or policy. Give the user just enough information so they know what to do next:

* make it clear what you need the user to do and include any deadlines - for example, ‘Complete this form and send it back to us by 20 May’
* say what will happen if they don’t do what you’re asking - for example, ‘If you don’t pay by 20 May, you’ll have to apply for a new licence’
* explain what you’ll do next and when they’ll hear from you - if you won’t be contacting them again, make it clear that it’s the end of the process

### Example of a personalised message

The Help with Prison Visits service sends users the following message:

From: Help with Prison Visits <help-with-prison-visits@notifications.service.gov.uk>

Subject: Your reference number

Body of message:

Dear [firstname lastname]

You asked for a reminder of your reference number.

Your reference number is:

[reference]

Check progress or start a new claim at [service URL].

Regards,
APVU (Assisted Prison Visit Unit)

Related guides
--------------

You may also find these guides useful:

* [Using, adapting and creating patterns](service-manual_design_using-adapting-and-creating-patterns.md)
* [Confirmation pages](service-manual_design_confirmation-pages.md)

Updates to this page
--------------------

Published 21 June 2017

Last updated 3 October 2017
[+ show all updates](#full-history)

1. 3 October 2017

   Added examples of subscription, transactional and personalised messages.
2. 21 June 2017

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---