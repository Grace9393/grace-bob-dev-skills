Protecting your service against fraud - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Protecting your service against fraud
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Types of fraud](#types-of-fraud)
2. [Protecting your service against fraud](#protecting-your-service-against-fraud)
3. [Monitoring your service for fraud](#monitoring-your-service-for-fraud)
4. [Further reading](#further-reading)
5. [Related guides](#related-guides)

When you’re designing and managing your digital service, you must:

* consider how it could be targeted by fraudsters, starting at the [discovery stage](https://www.gov.uk/service-manual/agile-delivery/how-the-discovery-phase-works) and the impact this could have
* take proportionate measures to protect your users and your service from fraud
* meet relevant [cyber security obligations](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/understanding-cyber-security-obligations/) related to user data

This guide covers the basics of fraud. If you need to know more, talk to:

* a counter fraud expert in your organisation, if there is one
* the Counter Fraud Function in the Cabinet Office, if there’s no expert in your organisation

The government [Secure by Design](https://www.security.gov.uk/policy-and-guidance/secure-by-design/) approach outlines what delivery teams and security professionals need to do to include effective cyber security practices to reduce risks, such as fraud, while building digital services.

Types of fraud
--------------

Fraudsters that target online services usually try to:

* take money from a service
* pretend they’re eligible for a service
* extract information to target other services
* use a service for money laundering

Some types of fraud are more severe than others. For example, high-level fraud would be organised criminals targeting multiple services to get money. Lower-level fraud could be one member of your staff taking advantage of a vulnerability in a system.

Some small-scale fraud may lead to more serious consequences beyond your service or organisation. For example, if someone faked a claim for one service, they could use that fake eligibility to defraud another service.

### Consider the weaknesses of online services

If you’re moving an offline service online, you should consider any new weaknesses that may be introduced in the process.

Online services are more open to fraud and fraudsters can try multiple attempts in a short space of time.

Do not assume any security processes you’re following offline will fully protect your service from fraud when the service moves online.

Learn about [discovering vulnerabilities](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/discovering-vulnerabilities/) during service design, development and deployment to address security weaknesses and prevent fraud.

### Consider non-financial fraud

Even if your service does not pay out money to users, fraudsters may still try to attack it to get information which they could use to commit fraud.

For example, they could use your users’ personal details to access money or other benefits from other government services, the private sector or individuals.

Protecting your service against fraud
-------------------------------------

Follow these steps to protect your service against fraud.

1. Analyse the risk.
2. Reduce the risk.
3. Respond to changing threats.
4. Check information against independent sources.
5. Make your team aware of fraud risks.
6. Have an incident response plan.

### Assess the risk

You must start considering fraud risks during your service’s [discovery phase](https://www.gov.uk/service-manual/agile-delivery/how-the-discovery-phase-works) and [include security in your business case](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/considering-security-within-the-business-case/).

Check if an Initial Fraud Impact Assessment (IFIA) or a Full Fraud Risk Assessment (FRA) or [threat assessment](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/sourcing-a-threat-assessment/) has been completed.

An IFIA gives an overview of some of the main ways fraud could affect a policy, project or programme.

A Full FRA is a thorough assessment of the risks within specific processes and programmes. It explains how the controls in place reduce them and what the remaining vulnerabilities are.

If you do not have an IFIA or Full FRA, contact a counter fraud expert.

As you build your first prototypes, you should review the potential areas of your service that could be left vulnerable to fraud.

For example, focus on parts of your service where users have to share personal information. Widgets or forms may ask users for information that’s attractive to fraudsters, particularly if a user is prompted to change their address or bank details.

Once you’ve found how your service gathers sensitive information, check how individuals or systems store, transport or access this data. This will help you to [manage third-party product security risks](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-third-party-product-security-risks/).

### Reduce the risk

You must attempt to reduce the fraud risks that you’ve identified. Use your IFIA or Full FRA to support your approach to [risk mitigation](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/responding-to-and-mitigating-security-risks/).

The way to reduce these risks depends on your service and the type of fraud that it could be affected by.

For example, if your service is only open to UK users, you could set up a system to check any non-UK requests and review them in detail.

If you know that certain payment mechanisms have higher fraud rates, you should treat them as higher risk.

You could also check that a user’s browser and IP address matches their usual browser and IP address. Sudden changes might be a sign of fraudulent activity and you may wish to treat them as higher risk.

You do not need to automatically prevent a transaction because of a change in browser or IP address. This may occur frequently if your users work from home or use virtual private networks (VPNs). Depending on your service and what it does, you could delay or record it, or require extra layers of verification to process the request.

### Preventing identity fraud

Identity theft and fraud are growing problems with fraudsters sharing stolen personal details online. To protect your users, follow guidance on [how to prove and verify someone’s identity](https://www.gov.uk/government/publications/identity-proofing-and-verification-of-an-individual/how-to-prove-and-verify-someones-identity). This sets out how to check the identity of a customer, an employee or someone acting on behalf of a business.

### Respond to changing threats

Fraudsters regularly change the nature and frequency of their fraud attempts, so you must make sure your service is flexible enough to respond to changing threats.

For example, if you’ve set rules to limit fraudulent activity, make sure you can change them easily and that they aren’t ‘hard-baked’ into your system.

Your organisation may use security classifications to label security risks. If you apply these classifications to fraud attempts, make sure you can change them according to the severity of new threats that appear.

Learn how to [assess the effectiveness of security controls](https://www.security.gov.uk/guidance/secure-by-design/activities/assessing-the-effectiveness-of-security-controls).

### Check user information against independent sources

You should check the information users give you against authoritative lists. For example, you can reference lists of authorised bank accounts, addresses and other personal details to identify any false information.

Be aware that not every incorrect entry means fraudulent activity. Users can make genuine errors and you should take these into account when checking against reliable and independent sources.

### Make your team aware of fraud risks

You must make sure every member of your team understands the risk of fraud to your service so that they don’t add vulnerabilities by mistake.

While designing and maintaining your service, follow the [Secure by Design principles](https://www.security.gov.uk/policy-and-guidance/secure-by-design/principles/) and talk to counter fraud experts regularly to help reduce the risk and impact of fraud.

Monitoring your service for fraud
---------------------------------

Monitor your service for suspicious behaviour to help you identify fraudulent activity.

You can use ‘transaction monitoring systems’ to track user behaviour and spot suspicious activity.

Use the information you find to:

* detect fraud stop fraudsters from accessing your service
* identify fraudulent activity after it’s been completed
* trace fraudsters and take appropriate action such as recovering money that has been fraudulently claimed or legal action

Learn about ways to [track the security health of your service](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-observability/).

### Keep a record of fraudulent activity

Keep track of all fraud attempts in your security and risk log. Note the time, date and type of attempt as well as whether it was successful.

Fraudsters will often try to commit fraud, change tactics and try again. Wherever possible, you should share information about fraud attempts with other government agencies and departments to raise awareness.

The [Cyber-security Information Sharing Partnership](https://www.gov.uk/government/speeches/cyber-security-information-sharing-programme) can help you exchange this information with others. Check with your counter fraud expert if you are unsure if it’s safe to share information about fraud attempts.

Further reading
---------------

You might find this guidance useful:

* [National Cyber Security Centre guidance on secure development and deployment](https://www.ncsc.gov.uk/collection/developers-collection)
* [Professional standards and guidance for fraud risk assessment in government](https://www.gov.uk/government/publications/professional-standards-and-guidance-for-fraud-risk-assessment-in-government)

Related guides
--------------

You may also find these guides useful:

* [Information security](service-manual_making-software_information-security.html.md)
* [Cloud security](service-manual_operations_cloud-security.html.md)
* [Secure By Design](https://www.security.gov.uk/policy-and-guidance/secure-by-design/)

Updates to this page
--------------------

Published 25 August 2016

Last updated 22 October 2024
[+ show all updates](#full-history)

1. 22 October 2024

   Integrated guidance on Responding to and mitigating security risks, Assessing the effectiveness of security controls, and Managing observability.
2. 31 May 2022

   Added information about Initial Fraud Impact Assessments and Full Fraud Risk Assessments.
3. 21 May 2018

   Removed reference to Data Protection Act (1998).
4. 17 October 2017

   Added guidance to explain that National Insurance numbers shouldn't be used to verify a user's identity.
5. 25 August 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---