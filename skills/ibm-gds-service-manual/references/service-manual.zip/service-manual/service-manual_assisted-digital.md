Assisted digital support: an introduction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Accessibility and assisted digital](service-manual_helping-people-to-use-your-service.md)

Accessibility and assisted digital

Assisted digital support: an introduction
=========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Assisted digital and digital take-up community](service-manual_communities_assisted-digital-and-digital-take-up-community.md)

Contents
--------

1. [How to provide assisted digital support](#how-to-provide-assisted-digital-support)
2. [Researching users’ assisted digital needs](#researching-users-assisted-digital-needs)
3. [Users you don’t have to support](#users-you-dont-have-to-support)
4. [Services where no users need support](#services-where-no-users-need-support)

You must make sure everyone who needs your service can use it.

Sometimes users will need help to use your service online. This is known as ‘assisted digital support’.

Any user may need assisted digital support, if they lack:

* trust in your service or the internet
* confidence to use an online service themselves
* access to the internet
* digital skills
* motivation to overcome these barriers on their own

You can provide this support over the phone or in person. Sometimes webchat will be appropriate too.

How to provide assisted digital support
---------------------------------------

You can use existing capacity in your organisation or hire private, voluntary or other public sector organisations to provide support for you.

Decide this when you [design your assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md).

Researching users’ assisted digital needs
-----------------------------------------

You must do user research to [understand what help people need to use your service online](service-manual_user-research_understanding-users-who-dont-use-digital-services.md).

Users you don’t have to support
-------------------------------

You don’t have to provide assisted digital support for users who:

* work in the public sector and use your service as part of their work (including contractors)
* are overseas and not British citizens
* are not the end user (for example accountants helping end users with a tax service, or a car sales business helping end users pay road tax)

Services where no users need support
------------------------------------

If you think your service has no users who need assisted digital support, you need to be able to explain how your user research and testing support this.

Updates to this page
--------------------

Published 8 April 2016

Last updated 30 August 2018
[+ show all updates](#full-history)

1. 30 August 2018

   Added low trust, self-confidence and motivation to list of reasons users may need assisted digital support.
2. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---