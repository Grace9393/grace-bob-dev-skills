Getting informed consent for user research - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Getting informed consent for user research
==========================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [What informed consent is](#what-informed-consent-is)
2. [Getting informed consent](#getting-informed-consent)
3. [Managing user research data](#managing-user-research-data)
4. [Collecting and keeping evidence of consent](#collecting-and-keeping-evidence-of-consent)
5. [Withdrawing consent](#withdrawing-consent)
6. [Related guides](#related-guides)

Whenever you do user research, you must get the participant’s ‘informed consent’. This means getting a record from them to show they understand your research and agree to take part.

By getting informed consent, you’ll help make sure that:

* participants understand what they’re signing up to, making your sessions more effective
* your research is ethical
* you comply with data protection law

You need to get consent from all research participants, even if they work for your organisation.

What informed consent is
------------------------

For consent to be informed, participants must understand:

* who is doing the research
* the purpose of the research
* what data you’re collecting
* what will happen during the research
* how you will use the results of the research, and who you’ll share them with
* that their participation is voluntary, and that they can stop or [withdraw their consent](#withdrawing-consent) at any time
* how long their data will be kept
* what their rights are and how they can complain

You must also let participants know:

* whether the session is being observed (and who’s watching)
* whether and how [the session is being recorded](https://www.gov.uk/service-manual/user-research/taking-notes-and-recording-user-research-sessions)

You must also tell participants how you’ll handle their personal data, including:

* which organisation is responsible for their data (known as the ‘data controller’) so the participant knows who to contact if they want to stop taking part in the research or make a complaint
* any other organisations that will be processing the data, for example transcription services, or staff from a design agency working in your team

Getting informed consent
------------------------

We recommend that you provide participants with an ‘information sheet’ during recruitment.

This is a document that gives them the information they need to give their informed consent, and tells them about their rights.

Information sheets also help to ensure that participants:

* are prepared and not surprised by the research activities they will be involved in - make sure you give them the sheet before the research session
* know how you will be recording the sessions and any data you want to collect
* do not feel pressured to agree to things they’re not comfortable with

### Designing your information sheet

Write your information sheet in language your participants can understand.

Check with your organisation’s data protection expert or legal adviser that your document complies with the law.

When you provide the information sheet to participants, make sure it’s in a format they can use. For example, you can send a printed information sheet by post, attach it to an email, or offer to read it aloud during a phone call.

Managing user research data
---------------------------

When running your sessions, you’ll collect research data like:

* notes, photos, audio or video recordings
* responses from any questionnaires you receive
* copies of paperwork

You must carefully [manage the research data you collect](service-manual_user-research_managing-user-research-data-participant-privacy.md). This includes using it only within the consent you get and deleting it when you no longer need it.

Collecting and keeping evidence of consent
------------------------------------------

Write your consent form in language your participants can understand, and provide it in a format they can use.

For face-to-face research sessions, the simplest way to collect evidence of consent is to have the participant sign a paper consent form. You can scan and keep a copy of this consent, and then shred the paper version.

For remote research sessions, you can send the participant the consent form by email or post, and ask them to reply confirming their consent. You can then keep a copy of the correspondence.

You could also get verbal consent on the recording, as long as the participant has read the consent form you’ve sent them.

For online surveys, you can provide information and collect positive confirmation of consent as the first step.

You can also collect and record verbal consent from a participant. You can then keep a copy of the consent script and the part of the recording which provides evidence of consent.

You must keep evidence of the consent you get from each participant, and what they have consented to.

Keep the record of consent with the research data it covers. And make sure you can match the record to the data. For example, by using the date it was collected, the research round number and the participant number to name the scan of a consent form.

### Getting consent from disabled people

If you’re doing a research session with a disabled person, make sure they can use and understand the information sheet and consent form. This is important to make sure you get their informed consent.

If someone has a visual or cognitive impairment, you can offer to read the form aloud and ask if they need help signing it. You can also check before the session whether they need a digital version so they can read it using assistive technology.

If someone has a motor impairment they might not be able to sign the form themselves. You can record them giving you verbal consent instead.

### Getting consent for children or vulnerable adults

If you want to do research with children or vulnerable adults (people who are unable to take care of themselves or are at risk of harm or exploitation), you need to get informed consent both from the participant and from a parent, guardian, carer or other responsible adult.

If you have any concerns about this, find out what’s best practice in your department or organisation.

Withdrawing consent
-------------------

Participants’ participation is voluntary and they can stop or withdraw their consent at any time.

As well as making this clear during recruitment, you should remind participants at the beginning and end of their research session, and at any point during a session if you’re not certain you have the participant’s continued consent. For example, if they seem uncomfortable with a research activity or confused about how you will use the data you’re collecting.

If a participant withdraws their consent during a research session, you must stop and delete any research data you’ve collected.

Dispose of paper notes in confidential waste and securely delete relevant recordings, files and database entries.

You must do the same if the participant withdraws their consent after the session, or if you find you have some research data without any associated consent.

You must [name and organise the research data](service-manual_user-research_managing-user-research-data-participant-privacy.md) you collect in a way that allows you to respond if a participant withdraws their consent.

Related guides
--------------

You may also find these guides useful:

* [Finding participants for user research](https://www.gov.uk/service-manual/user-research/find-user-research-participants)
* [Managing user research data and participant privacy](service-manual_user-research_managing-user-research-data-participant-privacy.md)

You might also want to read about the:

* [Nuremberg Code 1947](https://en.wikipedia.org/wiki/Nuremberg_Code)
* [Helsinki Declaration 1964](https://en.wikipedia.org/wiki/Declaration_of_Helsinki)
* [Economic and Social Research Council framework for research ethics](https://esrc.ukri.org/funding/guidance-for-applicants/research-ethics/)

Updates to this page
--------------------

Published 24 May 2016

Last updated 5 November 2018
[+ show all updates](#full-history)

1. 5 November 2018

   Added extra information on withdrawing consent.
2. 3 October 2017

   Added guidance on getting consent from people with disabilities.
3. 24 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---