3. Provide a joined up experience across all channels - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service Standard](service-manual_service-standard.md)

Service Standard

3. Provide a joined up experience across all channels
=====================================================

Work towards creating a service that meets users’ needs across all channels, including online, phone, paper and face to face.

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Why it's important](#why-its-important)
2. [What it means](#what-it-means)
3. [Related guidance](#related-guidance)
4. [Related blog posts](#related-blog-posts)
5. [Service standard points](#service-standard-points)

Why it’s important
------------------

Bringing different channels together means you can design an experience that makes sense to the user, however they use the service. Users should not be excluded or have an inferior experience because they lack access to technology or the skills to use it.

People working on the service are empowered to fix problems in whatever channel they crop up, instead of having to create work-arounds. They can spend less time dealing with failure demand, and more time with users who need their help.

What it means
-------------

Service teams should be able to show that:

* the service team is empowered to find the best way of solving the problem
* front line operations staff and policy people are invited to attend user research and to contribute to prioritisation decisions
* designers and user researchers are working with front line operations staff
* they are testing and can make changes to users’ experience of both online and offline channels (for example, call centre scripts and letters)
* data and user research on the online part of the service is used to improve offline channels, and the other way around
* front line operations staff who are responsible for answering users’ questions know how the online service works, and there’s a process for keeping them up to date with changes
* they’re working with colleagues in operations to understand how changes to the online part of the service will affect offline channels, and vice versa
* plans to increase digital take up do not involve making it more difficult to find details of phone, paper or face to face channels

Service teams should be able to identify any problems with internal processes, systems or structures that make it more difficult than it needs to be to design and operate a joined up service.

And show that there’s a plan to fix them - for example, by having an agreed procedure for resolving issues with the online service that are causing problems for the offline channels. Or the other way around.

Related guidance
----------------

[Assisted digital support: an introduction](https://www.gov.uk/service-manual/helping-people-to-use-your-service/assisted-digital-support-introduction)

[Encouraging people to use your digital service](https://www.gov.uk/service-manual/helping-people-to-use-your-service/encouraging-people-to-use-your-digital-service)

[Sending emails and text messages](https://www.gov.uk/service-manual/design/sending-emails-and-text-messages)

[Making your service more inclusive](https://www.gov.uk/service-manual/design/making-your-service-more-inclusive)

Related blog posts
------------------

[Helping people with court fees](https://mojdigital.blog.gov.uk/2015/07/29/helping-people-with-court-fees/)

Service standard points
-----------------------

[1. Understand users and their needs](https://www.gov.uk/service-manual/service-standard/point-1-understand-user-needs)

[2. Solve a whole problem for users](https://www.gov.uk/service-manual/service-standard/point-2-solve-a-whole-problem)

[3. Provide a joined up experience across all channels](https://www.gov.uk/service-manual/service-standard/point-3-join-up-across-channels)

[4. Make the service simple to use](https://www.gov.uk/service-manual/service-standard/point-4-make-the-service-simple-to-use)

[5. Make sure everyone can use the service](https://www.gov.uk/service-manual/service-standard/point-5-make-sure-everyone-can-use-the-service)

[6. Have a multidisciplinary team](https://www.gov.uk/service-manual/service-standard/point-6-have-a-multidisciplinary-team)

[7. Use agile ways of working](https://www.gov.uk/service-manual/service-standard/point-7-use-agile-ways-of-working)

[8. Iterate and improve frequently](https://www.gov.uk/service-manual/service-standard/point-8-iterate-and-improve-frequently)

[9. Create a secure service which protects users’ privacy](https://www.gov.uk/service-manual/service-standard/point-9-create-a-secure-service)

[10. Define what success looks like and publish performance data](https://www.gov.uk/service-manual/service-standard/point-10-define-success-publish-performance-data)

[11. Choose the right tools and technology](https://www.gov.uk/service-manual/service-standard/point-11-choose-the-right-tools-and-technology)

[12. Make new source code open](https://www.gov.uk/service-manual/service-standard/point-12-make-new-source-code-open)

[13. Use and contribute to open standards, common components and patterns](https://www.gov.uk/service-manual/service-standard/point-13-use-common-standards-components-patterns)

[14. Operate a reliable service](https://www.gov.uk/service-manual/service-standard/point-14-operate-a-reliable-service)

Updates to this page
--------------------

Published 8 May 2019

Last updated 30 May 2022
[+ show all updates](#full-history)

1. 30 May 2022

   Added links to related guidance and other standard points. There is no change to the content of the standard point itself.
2. 8 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---