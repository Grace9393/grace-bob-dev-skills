Agile delivery community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Agile delivery community
========================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [Agile in the Service Manual](#agile-in-the-service-manual)

The agile community exists to:

* share information about how to use agile ways of working in government
* give agile practitioners the opportunity to share experiences, observed behaviours and best practice
* give people a space to discuss and challenge the way agile methods are used to deliver government projects and products

Who the community is for
------------------------

You might be interested in the community if you use (or want to use) agile methods to deliver government projects or products.

You don’t have to be in a software development role to join.

Get involved
------------

[Join the cross-government #deliverymgmt Slack channel](https://ukgovernmentdigital.slack.com/messages/C07CMTQKC/).

Community resources
-------------------

Use these resources to learn more about agile in government:

* [GDS blog](https://gds.blog.gov.uk/?s=agile) - includes stories, lessons and case studies about agile from across government
* [MOJ Digital blog](https://mojdigital.blog.gov.uk/category/agile/) - posts from the Ministry of Justice about their experience of using agile
* [Home Office Digital blog](https://hodigital.blog.gov.uk/category/agile/) - posts from Home Office staff about what they’ve learnt about using agile

Agile in the Service Manual
---------------------------

These guides show what we currently believe to be best practice for delivering government services in an agile way:

* [Agile and government services: an introduction](service-manual_agile-delivery_agile-government-services-introduction.md)
* [Agile methods: an introduction](service-manual_agile-delivery_agile-methodologies.md)
* [Core principles of agile](service-manual_agile-delivery_core-principles-agile.md)
* [Creating an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md)
* [Agile tools and techniques](service-manual_agile-delivery_agile-tools-techniques.md)
* [Set up a team wall](service-manual_agile-delivery_team-wall.md)
* [Writing user stories](service-manual_agile-delivery_writing-user-stories.md)
* [Planning in agile](service-manual_agile-delivery_planning-agile.md)
* [Governance principles for agile service delivery](service-manual_agile-delivery_governance-principles-for-agile-service-delivery.md)
* [Measuring and reporting progress](service-manual_agile-delivery_measuring-reporting-progress.md)
* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [How the alpha phase works](service-manual_agile-delivery_how-the-alpha-phase-works.md)
* [How the beta phase works](service-manual_agile-delivery_how-the-beta-phase-works.md)
* [How the live phase works](service-manual_agile-delivery_how-the-live-phase-works.md)
* [Retiring your service](service-manual_agile-delivery_retiring-your-service.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Updates to this page
--------------------

Published 2 March 2016

Last updated 5 August 2016
[+ show all updates](#full-history)

1. 5 August 2016

   Added guides to how the discovery, alpha, beta and live phases work, and 'Retiring your service'.
2. 2 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---