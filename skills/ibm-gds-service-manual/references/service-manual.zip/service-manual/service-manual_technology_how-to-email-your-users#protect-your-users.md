Sending emails from your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Sending emails from your service
================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Use a specialist service provider](#use-a-specialist-service-provider)
2. [Create an email address](#create-an-email-address)
3. [Protect your users](#protect-your-users)
4. [Dealing with delivery errors](#dealing-with-delivery-errors)
5. [Testing your email delivery](#testing-your-email-delivery)
6. [Checking the format and content of your email](#checking-the-format-and-content-of-your-email)
7. [How and when to write emails](#how-and-when-to-write-emails)

If you need to email your users, you must do it in a way that is reliable and protects them from spam and phishing.

Use a specialist service provider
---------------------------------

You should use a specialist service provider for sending emails, and consider using [GOV.UK Notify](/notify). Your service provider should:

* send and receive email using [Transport Layer Security (TLS)](https://www.gov.uk/government/publications/email-security-standards/transport-layer-security-tls), where available
* use [DomainKeys Identified Mail (DKIM)](https://www.gov.uk/government/publications/email-security-standards/domainkeys-identified-mail-dkim) to sign outbound email
* provide a hostname or IP range for you to include in your [Sender Policy Framework (SPF)](https://www.gov.uk/government/publications/email-security-standards/sender-policy-framework-spf) record

Create an email address
-----------------------

To email users, you must set up an email address on the service.gov.uk domain, for example:

* info@servicename.service.gov.uk
* servicename@notifications.service.gov.uk

Talk to your department IT team or service provider to set up an email address on the service.gov.uk domain.

You must only email your users from this email address and not from your department, agency or any other domain.

### Allow users to reply to you

You must create an email address that your users can reply to, and you must read their messages.

You can receive user replies by either:

* allowing users to reply directly
* setting a reply-to address

Protect your users
------------------

When contacting your users, you must:

* leave out sensitive information, like bank details
* avoid making requests for personal information, like a user’s date of birth
* show the URL in full, and use URLs that are easy to read
* only use shortened URLs if they have been [created by the Government Digital Service](https://www.gov.uk/guidance/contact-the-government-digital-service/request-a-thing#short-url) or your IT department
* avoid sending attachments with emails
* include the user’s first name and surname in the body of the email to make phishing more difficult
* enable [Domain-based Message Authentication, Reporting and Conformance (DMARC)](https://www.gov.uk/government/publications/email-security-standards/domain-based-message-authentication-reporting-and-conformance-dmarc) to stop someone spoofing your domain
* follow the [guidance on securing government email](https://www.gov.uk/guidance/set-up-government-email-services-securely#configure-other-email-sending-services) to set up DMARC and TLS on your service.gov.uk domains

Read more information about handling [links and URLs in emails](https://www.notifications.service.gov.uk/using-notify/links-and-URLs).

Dealing with delivery errors
----------------------------

Do not keep sending mail to email addresses that you know are broken or do not exist.

Testing your email delivery
---------------------------

You must implement automated testing and monitoring to make sure your email sending is reliable.

The level of reliability you need depends on:

* what your service does and how critical email is to the service
* the development phase you’re in - in alpha you will not need as much reliability as when the service is live

### Types of checks you need

The types of checks you need to achieve your chosen level of reliability depend on how you’re sending emails.

If you’re using GOV.UK Notify or another managed email service provider, it may be enough to carry out a combination of:

* monitoring checks on your integration with the external services
* automated tests that verify the integration with the third-party application programming interface (API)

If you need to be more confident of reliability, you can set up full end-to-end tests which check both the integration of your service and the eventual delivery to the recipient.

Checking the format and content of your email
---------------------------------------------

You should periodically use tools to manually check:

* email looks normal and is easy to read in all email and webmail clients
* email successfully delivers to popular email clients

There are a variety of commercial tools you can use to manually check emails.

How and when to write emails
----------------------------

There’s a separate guide to [planning and writing emails](https://www.gov.uk/service-manual/design/sending-emails-and-text-messages).

Updates to this page
--------------------

Published 9 September 2016

Last updated 16 April 2025
[+ show all updates](#full-history)

1. 16 April 2025

   Updated advice about links within emails in line with Notify.
2. 18 January 2017

   Included more detailed advice on protecting users, including guidance on DMARC and SPF records.
3. 9 September 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---