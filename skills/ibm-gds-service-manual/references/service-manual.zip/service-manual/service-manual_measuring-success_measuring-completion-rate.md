Measuring completion rate - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Measuring success](service-manual_measuring-success.md)

Measuring success

Measuring completion rate
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Performance analysis community](service-manual_communities_performance-and-data-analysis-community.md)

Contents
--------

1. [Calculating completion rate](#calculating-completion-rate)
2. [Configure your service to measure completion rate](#configure-your-service-to-measure-completion-rate)
3. [Counting users who are ineligible for a service](#counting-users-who-are-ineligible-for-a-service)
4. [Measuring completion rates for assisted digital support](#measuring-completion-rates-for-assisted-digital-support)
5. [Completion rate through each service phase](#completion-rate-through-each-service-phase)
6. [Publish data](#publish-data)
7. [Related guides](#related-guides)

Your service’s completion rate is the number of digital transactions that your users complete as a percentage of all digital transactions that your users start.

This includes transactions where the user receives support from someone to use the digital service (called [‘assisted digital support’](service-manual_helping-people-to-use-your-service_assisted-digital-support-introduction.md)).

Calculating completion rate
---------------------------

To calculate your completion rate:

1. Count the number of completed transactions - the numerator.
2. Divide it by the total number of transactions (including partially completed or failed ones) - the denominator.
3. Show the result as a percentage.

Make sure you count only genuine users, ie set up your analytics tools to exclude internal users, test users and web robots from your data.

### What to include as a transaction

A transaction is an exchange of:

* money
* information
* permission
* goods or services

Transactions on your service will have clearly defined start and end points. They will also result in a change to a government system, eg someone’s personal information or the details of an interaction are stored in a register or database.

The following activities do not have clearly defined start and end points and are not recorded in a government system, so they are not transactions:

* general advice or enquiries
* informal complaints
* visits to websites

### When a transaction is completed

A transaction is completed when someone finishes the task that your digital service provides. For example, when a user:

* submits an application
* makes a payment
* makes a booking

The service should tell the user that the transaction is complete with a confirmation or ‘thank you’ message.

A user’s application does not have to be successful for you to consider the transaction complete.

For example, the Apply for a patent transaction is considered complete when the user has submitted an application, regardless of whether the application is successful.

### When a transaction has failed

A failed transaction is when a user gives up before reaching a defined end page (often called a [‘confirmation page’](service-manual_design_confirmation-pages.md)). This includes when a user abandons the service from an error page.

Configure your service to measure completion rate
-------------------------------------------------

To make it easier to analyse user behaviour give each step in your service a unique URL so you can identify them in your analytics tool.

### Measure from the start of a transaction

Most services will have a [start page](https://www.gov.uk/service-manual/user-centred-design/resources/patterns/start-pages.html) on GOV.UK, which should be the only way to access the service. You should usually only consider a transaction to have started when the user continues from your service’s start page.

Make sure users are not able to bypass the start page via links or search engine results.

Some services do not have a start page. In these cases it helps to understand the whole user journey so you can identify the exact points at which the user starts the service. This is usually another page on GOV.UK.

For example, there is no start page if someone wants to book an appointment at a UK consular office. There are links to this service from other pages on GOV.UK, such as the information page on getting married in France. In this case, the page on getting married in France is effectively the start page for booking an appointment at a UK consular office.

### Know when a service ends

Services often have multiple end points. You must have appropriate end pages at each of them.

For example, the ‘Check if you can get legal aid’ service has two main end points:

* one for those who are eligible (that tells them what to do next)
* one for those who are not eligible (that suggests other forms of support)

When a user reaches one of these end pages, you must consider the transaction to have finished.

You’ll have to list all of your end pages in your [service assessments](service-manual_service-assessments_how-service-assessments-work.md).

### Counting users who ‘save and return’

If your service allows users to save a transaction and finish it later, make sure you can match transaction starts to their subsequent completions.

For example, in Google Analytics you can use cohort analysis and custom dimensions to track the number of times a user returns to complete a transaction on your service.

### Services with both digital and non-digital steps

For legal reasons, some services require users to carry out steps digitally and non-digitally, for example starting and finishing a transaction online, but sending a paper copy of a form in the middle.

To measure the 2 parts of the service as a whole is complicated. Users complete the second part of the service much later, which can lead to misleading completion rates. You can resolve this by using cohort analysis and custom dimensions.

However, if your service does not need to match the 2 digital parts of the user journey, you can treat them as separate transactions and measure completion rates for each.

Counting users who are ineligible for a service
-----------------------------------------------

Some services have complex eligibility criteria. It can be helpful to include a series of questions - [a smart answer](https://gds.blog.gov.uk/2012/02/16/smart-answers-are-smart/) - to test eligibility.

If a user continues to use a service after failing an eligibility test, count them as having started the transaction. For example, people can still apply for Carer’s Allowance even if the eligibility test tells them they’re not entitled to it.

You should not consider users who abandon a service after failing an eligibility test as users who have started a transaction.

Measuring completion rates for assisted digital support
-------------------------------------------------------

Some users will require help using the digital service, and it’s useful to keep a separate measure of how your assisted digital support is performing.

For completion rates:

* count the number of successful assisted digital transactions
* divide it by the total assisted digital transactions
* express the result as a percentage

Find out more about [designing assisted digital support](service-manual_helping-people-to-use-your-service_designing-assisted-digital.md).

Completion rate through each service phase
------------------------------------------

### Discovery

In discovery, explore any data from legacy and offline systems.

You should consider:

* the data that’s available
* where you can get the data, eg an existing online service, a digital database that supports an existing offline service, contact centre data, search terms in web analytics
* whether you can calculate completion rates from these to use as a baseline

### Alpha

In alpha, start work on your [performance framework](https://www.gov.uk/design-principles/performanceframework). In the framework, specify the user journeys you’ll measure, including start and end points for them.

### Beta

In beta, map all possible user journeys through your service. You will not be able to measure completion rates until your service goes into public beta.

Publish data
------------

You must measure your completion rate data every month and [publish it](service-manual_measuring-success_data-you-must-publish.md).

Related guides
--------------

You may also find these guides useful:

* [Measuring cost per transaction](service-manual_measuring-success_measuring-cost-per-transaction.md)
* [Measuring digital take-up](service-manual_measuring-success_measuring-digital-take-up.md)
* [Measuring user satisfaction](service-manual_measuring-success_measuring-user-satisfaction.md)
* [Data you must publish](service-manual_measuring-success_data-you-must-publish.md)
* [Choosing digital analytics tools](service-manual_measuring-success_choosing-digital-analytics-tools.md)

Updates to this page
--------------------

Published 31 March 2016

Last updated 19 February 2021
[+ show all updates](#full-history)

1. 19 February 2021

   Removed reference to Performance Platform as this is being retired.
2. 31 March 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---