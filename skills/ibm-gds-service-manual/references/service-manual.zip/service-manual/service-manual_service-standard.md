Service Standard - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)

Service Standard
================

The Service Standard helps teams to create and run great public services.

Check whether you need to use  [the previous version of the Service Standard](service-manual_service-assessments_pre-july-2019-digital-service-standard.md).

1. 1.
   Understand users and their needs
   -----------------------------------

   [Read more about point 1](service-manual_service-standard_point-1-understand-user-needs.md)
2. 2.
   Solve a whole problem for users
   ----------------------------------

   [Read more about point 2](service-manual_service-standard_point-2-solve-a-whole-problem.md)
3. 3.
   Provide a joined up experience across all channels
   -----------------------------------------------------

   [Read more about point 3](service-manual_service-standard_point-3-join-up-across-channels.md)
4. 4.
   Make the service simple to use
   ---------------------------------

   [Read more about point 4](service-manual_service-standard_point-4-make-the-service-simple-to-use.md)
5. 5.
   Make sure everyone can use the service
   -----------------------------------------

   [Read more about point 5](service-manual_service-standard_point-5-make-sure-everyone-can-use-the-service.md)
6. 6.
   Have a multidisciplinary team
   --------------------------------

   [Read more about point 6](service-manual_service-standard_point-6-have-a-multidisciplinary-team.md)
7. 7.
   Use agile ways of working
   ----------------------------

   [Read more about point 7](service-manual_service-standard_point-7-use-agile-ways-of-working.md)
8. 8.
   Iterate and improve frequently
   ---------------------------------

   [Read more about point 8](service-manual_service-standard_point-8-iterate-and-improve-frequently.md)
9. 9.
   Create a secure service which protects users’ privacy
   --------------------------------------------------------

   [Read more about point 9](service-manual_service-standard_point-9-create-a-secure-service.md)
10. 10.
    Define what success looks like and publish performance data
    ---------------------------------------------------------------

    [Read more about point 10](service-manual_service-standard_point-10-define-success-publish-performance-data.md)
11. 11.
    Choose the right tools and technology
    -----------------------------------------

    [Read more about point 11](service-manual_service-standard_point-11-choose-the-right-tools-and-technology.md)
12. 12.
    Make new source code open
    -----------------------------

    [Read more about point 12](service-manual_service-standard_point-12-make-new-source-code-open.md)
13. 13.
    Use and contribute to open standards, common components and patterns
    ------------------------------------------------------------------------

    [Read more about point 13](service-manual_service-standard_point-13-use-common-standards-components-patterns.md)
14. 14.
    Operate a reliable service
    ------------------------------

    [Read more about point 14](service-manual_service-standard_point-14-operate-a-reliable-service.md)

Get notifications
-----------------

* [Get emails when any guidance within this topic is updated](/email-signup?link=/service-manual/service-standard)

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---