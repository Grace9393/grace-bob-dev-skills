Planning in agile - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Planning in agile
=================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Differences between agile and waterfall planning](#differences-between-agile-and-waterfall-planning)
2. [How to make an agile plan](#how-to-make-an-agile-plan)
3. [Hold planning meetings](#hold-planning-meetings)
4. [Further reading](#further-reading)
5. [Related guides](#related-guides)

Planning is vital to the success of agile working. Planning allows everyone to understand:

* what your vision and objectives are
* what you need to do to achieve your objectives
* how you know when you’ve achieved them

Differences between agile and waterfall planning
------------------------------------------------

In waterfall projects you typically do detailed planning early on in a project, before the development stage.

After planning it’s rare that you go back and make changes.

You hold plans in requirement documents and Gantt charts that may not be accessible to everyone.

In agile, you change your plans as you do more work and learn more about your users.

You should focus your efforts on planning at the right level at the right time. Plan work you don’t expect to do for a while at a high level. Make a more detailed plan for work you are just about to do.

In agile, you should make your planning visible to the rest of your organisation.

Use your [team wall](service-manual_agile-delivery_team-wall.md) to display your vision, goals, roadmap and [user stories](service-manual_agile-delivery_writing-user-stories.md).

You should also allow anyone in your organisation to see any planning you do using online tools.

How to make an agile plan
-------------------------

Follow these 3 steps to make an agile plan.

1. Decide on a vision.
2. Make objectives.
3. Make a roadmap.

### Decide on a vision

Every product or service benefits from a vision - a simple statement explaining what you’re trying to achieve.

It’s important that people working on your service and its stakeholders understand the vision and are involved in writing it. This creates a collective sense of ownership.

### Make objectives

You should define some objectives that you want to achieve and have a system for checking when you’ve achieved these objectives.

One way you can do this is by tracking results you can measure for each objective. For example:

1. Start by defining 3 to 5 main objectives.
2. For each objective, define 3 to 4 results you can measure using quantitative data.

You should also:

* set your objectives a year in advance, although you can change them
* change how you’re measuring results as you learn more about the service

### Make a roadmap

You should make and keep a roadmap of the main features you need to build to achieve your objectives. Your team must have the authority to develop and own the roadmap.

Your roadmap should typically set out your plans 6 to 12 months in advance. If you have fixed deadlines, for example ministerial deadlines, you should focus your roadmap planning around what you can achieve within that deadline.

Revisit your roadmap regularly to re-prioritise what you’ll be working on in the near future. In large programmes of work with many dependencies, you may want to look at your roadmap weekly.

Make your roadmap visible by displaying it on your team wall or board.

If you have more than one team or organisation working towards a common goal, you should put the roadmaps for separate streams of work together on a wall.

This allows you to see cross-team or cross-organisation dependencies, including what any external third parties are doing.

Hold planning meetings
----------------------

You should hold a meeting with your whole team to make detailed plans of the work you’ll be carrying out in the next iteration or sprint.

Use this meeting to:

* make sure that the whole team understands the work they’re about to do
* talk about possible approaches, issues and dependencies based on [user stories](service-manual_agile-delivery_writing-user-stories.md) from your backlog
* keep up collaboration between the different disciplines in your team
* include members of other teams or external teams if there are cross-team or cross-organisation dependencies

Further reading
---------------

Read a GOV.UK Verify blog post about [making clear goals for complex agile programmes](https://identityassurance.blog.gov.uk/2016/03/11/goals-cycles-and-people-running-an-agile-complex-programme-in-government/).

Related guides
--------------

You may also find these guides useful:

* [Governance principles for agile service delivery](service-manual_agile-delivery_governance-principles-for-agile-service-delivery.md)
* [Measuring and reporting progress](service-manual_agile-delivery_measuring-reporting-progress.md)

Updates to this page
--------------------

Published 16 February 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 16 March 2016

   Added further reading blog on making clear goals for complex agile programmes.
2. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---