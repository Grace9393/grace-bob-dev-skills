What each role does in a service team - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [The team](service-manual_the-team.md)

The team

What each role does in a service team
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Roles your team must have](#roles-your-team-must-have)
2. [Other roles you may need](#other-roles-you-may-need)
3. [Get help with what roles you need](#get-help-with-what-roles-you-need)
4. [Related guides](#related-guides)

Your service team must include people doing a variety of different roles (this type of team is called a multidisciplinary team). You may need to include other roles depending on the size of your service.

Roles your team must have
-------------------------

A team building a government service needs to have people with the following roles or skills either in the team or available to it:

* product manager
* service owner
* delivery manager
* user researcher
* content designer
* designer
* developer

The skills you need will change throughout the lifecycle of your service. Read more about [the roles you’ll need at each service phase](service-manual_the-team_set-up-a-service-team.md).

Your whole team, and in particular your designers, user researchers, content designers and developers, must work together to design, build and iterate a service based on the [user needs](service-manual_agile-delivery_core-principles-agile#focus-on-user-needs.md) of the people your service is aimed at.

### Product manager

Your product manager works with the delivery team to:

* makes sure your service fits in with your organisation’s priorities
* define what the future goal of the service is (often called the ‘product vision’ in [agile project management](service-manual_agile-delivery.md))
* make sure your service will meet user needs
* make sure your service is [accessible](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md) to everyone, including disabled people
* prioritise [user stories](service-manual_agile-delivery_writing-user-stories.md) for each work sprint
* comment on technical, content and design solutions
* accept user stories when complete

Download a job description to find out more:

* [product manager job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf80491ed915d17eadacf66/Product_manager__job_description_template.odt)

### Service owner

Your service owner must have the decision-making authority to deliver on all aspects of a project. They also:

* have overall responsibility for developing, operating and continually improving your service
* represent the service during service assessments
* make sure the necessary project and approval processes are followed
* identify and mitigate risks to your project
* encourage the maximum possible take-up of your digital service
* have responsibility for your service’s assisted digital support

Download a job description to find out more:

* [service owner job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf80513e5274a2ac236775e/Service_owner__job_description_template.odt)

### Delivery manager

Your delivery manager is responsible for:

* [setting up the agile environment](service-manual_agile-delivery_create-agile-working-environment.md) your team needs to build and iterate a user-centred service
* removing obstacles or ‘blockers’ to progress
* helping your service team become better at autonomously organising their own work
* making sure accessibility is factored into each feature or activity the team’s working on

Download a job description to find out more:

* [delivery manager job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf80532ed915d17d51eb8cd/Delivery_manager__job_description_template_.odt)

You can also find more resources and link up with digital professionals on the [agile delivery community page](service-manual_agile-delivery-community.md).

### User researcher

Your user researcher helps your team learn about the people who will use your service. This will help you design and build a service that works well for all your users, including disabled people and those who need support.

On your team, they will:

* plan and carry out research using a range of methods
* involve the team in user research to help everyone develop a deep understanding of your users
* create clear findings that help your team continuously improve your service, based on data and evidence

Download a job description to find out more:

* [user researcher job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf80561e5274a2adb757530/User_researcher_job_description_template.odt)

### Content designer

A content designer is responsible for the content in your service. They
contribute to service design by:

* developing content plans and strategies based on [user needs](service-manual_user-centred-design_user-needs.html.md)
* writing clear, usable and [accessible content](https://www.gov.uk/service-manual/design/writing-for-user-interfaces#make-content-accessible) in [plain English](/guidance/content-design/writing-for-gov-uk#plain-english)
* reviewing content to make sure it’s accurate, relevant, accessible and written in line with [GOV.UK style](/topic/government-digital-guidance/content-publishing)
* communicating the principles of [content design](/guidance/content-design/what-is-content-design) to your service team and others across your organisation
* advocating for users of your service by challenging requests that do not support their needs

Download a job description to find out more:

* [content designer job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf80580e5274a2aefa09774/Content_designer__job_description_template_.odt)

### Designer

Designers help your team create user-focused, accessible services and a consistent user experience.

Depending on the type of service you’re building, you may need a team of designers with a range of different skills, for example interaction, content, service or graphic designers. However, in discovery it’s often best to hire an interaction designer as the first member of your team.

Download a job description to find out more:

* [interaction designer job description (.odt)](https://assets.publishing.service.gov.uk/media/5c069fb6e5274a6a6a534277/Interaction_designer__job_description_template.odt)
* [service designer job description (.odt)](https://assets.publishing.service.gov.uk/media/5c069fa3ed915d7475317c84/Service_designer__job_description_template.odt)
* [graphic designer (.odt)](https://assets.publishing.service.gov.uk/media/5bf8287b40f0b637ae62900a/Graphic_designer__job_description_template.odt)

### Developer and frontend developer

You need developers on your team to:

* build accessible software with a focus on what users need from your service and how they’ll use it
* advise on the technical feasibility of designs
* write, adapt, maintain and support code
* continually improve the service with new tools and techniques
* solve technical problems

Download a job description to find out more:

* [developer job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf8062240f0b637cbd1e7e0/Software_developer__job_description_template.odt)
* [frontend developer job description (.odt)](https://assets.publishing.service.gov.uk/media/5de1317b40f0b650e2545c4d/Frontend_developer__job_description_template.odt)

Other roles you may need
------------------------

Depending on a service’s size and complexity, your team might also need these roles:

* performance analyst
* technical architect
* DevOps engineer
* business analyst
* quality assurers and testers
* technical writers

### Performance analyst

Performance analysts help your team understand and improve your service’s performance by:

* collecting and presenting key performance data and analysis for your service
* working with your service owner to make sure their service meets the performance requirements set out in the Service Standard
* helping your service team understand user needs by providing quantitative and qualitative evidence from web analytics, financial data and user feedback

Download a job description to find out more:

* [performance analyst job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf8063de5274a2add0d1c50/Performance_analyst_description_template.odt)

### Technical architect

Technical architects need to:

* work with delivery teams and third parties to decide on technical requirements and improvements for software development and web operation
* make sure that new and updated platforms, products, transactions and system architectures are robust, scalable, open and secure

Download a job description to find out more:

* [technical architect job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf8065740f0b637cf729b67/Technical_architect__job_description_template.odt)

### DevOps engineer

DevOps engineers help your service team by:

* running your production systems
* helping the development team build software that’s easy to use
* working with developers to optimise existing applications and design new ones
* encouraging everyone (developers, delivery managers, product managers) to think about how new applications will be run and maintained

Download a job description to find out more:

* [DevOps job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf8069b40f0b637bfcda99b/DevOps__job_description_template.odt)

### Business analyst

A business analyst will:

* define the business context, problem or opportunity
* undertake research and analysis to understand how a business area works
* elaborate user needs, business needs and constraints into user stories to enable effective design, development, testing and adoption of services
* identify areas for improvement, explore feasible options, analyse the effects of change and define success measures
* ensure new products and services meet business and user needs, and are aligned with organisational goals

Download a job description to find out more:

* [business analyst job description (.odt)](https://assets.publishing.service.gov.uk/media/654502a859b9f5000d85a23e/Business_analyst_job_description_template.odt)

### Quality assurers and testers

The quality of any digital service is the responsibility of the entire team, and the final responsibility lies with the service owner.

Employing specialist skills from outside of the service is a good way to make sure this is tested thoroughly. You may find this particularly helpful for [penetration testing](service-manual_making-software_testing-in-agile.html#penetration-testing.md) and [quality assurance](https://www.gov.uk/service-manual/technology/quality-assurance-testing-your-service-regularly).

A quality assurer can work on a short-term basis with your team to build quality into everything they do. They should leave your team capable of managing quality as part of their standard development and iteration of the service.

Download a job description to find out more:

* [quality assurer and tester job description (.odt)](https://assets.publishing.service.gov.uk/media/5bf8070140f0b637abbee9a9/QAT_analyst__job_description_template_.odt)

### Technical writer

A technical writer is responsible for your service’s technical content, for example API documentation or architecture documentation.

On your team a technical writer will:

* develop documentation plans and strategies based on internal and external technologists’ user needs
* write clear, usable and accessible documentation in plain English
* review documentation to make sure it’s accurate, relevant, accessible and written in line with GOV.UK style
* advocate for technologist users who need to integrate with your service, and challenge requests that do not support their needs
* bring a user-centred approach to your team’s technology development, for example working with developers on a design-first approach to API design

Download a job description to find out more:

* [technical writer job description (.odt)](https://assets.publishing.service.gov.uk/media/62416799d3bf7f32a7c010fd/Technical_writer__job_description_template.odt)

Get help with what roles you need
---------------------------------

If you have any questions about the roles in service teams, email the DDaT Profession at: ddatprofession@digital.cabinet-office.gov.uk

Related guides
--------------

You may also find the following guides useful:

* [Set up a service team](service-manual_the-team_set-up-a-service-team.md)
* [How to recruit to a service team](service-manual_the-team_recruit-your-team.md)
* [Working with contractors or third parties](service-manual_the-team_working-contractors-third-parties.md)

Updates to this page
--------------------

Published 3 March 2016

Last updated 6 November 2023
[+ show all updates](#full-history)

1. 6 November 2023

   Updated the business analyst job description odt attachment.
2. 7 June 2023

   Updated the business analyst role.
3. 25 March 2022

   Added technical writer to the list of roles needed.
4. 12 February 2021

   Added contact details for DDaT profession team.
5. 29 November 2019

   Added job description for frontend developers
6. 23 November 2018

   Updated job descriptions
7. 27 October 2017

   Updated to clarify the accessibility responsibilities that some roles have.
8. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---