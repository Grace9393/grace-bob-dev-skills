Check if you need to meet the Service Standard or get an assessment - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

Check if you need to meet the Service Standard or get an assessment
===================================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [What has to be assessed](#what-has-to-be-assessed)
2. [Exception if you’re using an assured form building platform](#exception-if-youre-using-an-assured-form-building-platform)
3. [Who will assess your service](#who-will-assess-your-service)
4. [Services which do not meet the criteria for being assessed](#services-which-do-not-meet-the-criteria-for-being-assessed)
5. [Adapting the Service Standard](#adapting-the-service-standard)
6. [Related guides](#related-guides)

What has to be assessed
-----------------------

If you’re developing a transactional service for central government, you must get it assessed. This applies even if your service is internal and will only be used by civil servants.

A service is transactional if it allows users to either:

* exchange information, money, permission, goods or services
* submit personal information that results in a change to a government record

### Scope of the assessment

The Service Standard requires you to think about the user’s wider journey. But that doesn’t mean the entire journey will be assessed.

The things that get assessed are:

* the transaction you’ve been working on
* your understanding of the user’s wider journey - and the work you’ve done to [make sure the transaction you’re building joins up with that wider journey](service-manual_design_scoping-your-service.md)

The service could still meet the standard if there are problems with the user’s wider journey, as long as you’re taking reasonable steps to make things better and fix the journey in increments.

Exception if you’re using an assured form building platform
-----------------------------------------------------------

You won’t need an assessment if you’re:

* using an [assured form building platform](https://www.gov.uk/service-manual/technology/using-common-components) to create a form, and
* expecting to get fewer than 10,000 transactions per year

This reflects the fact that forms created using an assured form building platform have government standards ‘built in’. And it allows organisations to make cost savings and accessibility improvements by delivering digital versions of document-based forms quickly.

Even if you’re using an assured form building platform, you may find that your department has an assurance process for forms with a higher degree of reputational or financial risk. This will be a lighter touch process than a service assessment - for example, it might be an expert review carried out by a design or content professional. Contact your department’s assessment team if you’re not sure.

Who will assess your service
----------------------------

Your service will be assessed by a cross-government panel if either:

* your service is likely to handle more than 100,000 transactions per year
* civil servants in more than one organisation will use your service

Otherwise, your service will be assessed by a panel from your department. If your department doesn’t have an assessment team, you can ask for help in the [#standard-assessments channel on cross-government Slack](https://ukgovernmentdigital.slack.com).

You can check when and how to [book an assessment](https://www.gov.uk/service-manual/service-assessments/book-a-service-assessment).

Services which do not meet the criteria for being assessed
----------------------------------------------------------

Even if your service doesn’t need an assessment, you can arrange one to check you’re building it in a way that meets the Service Standard. Contact your department’s assessment team to ask about a voluntary assessment.

If getting an assessment is a condition of your spend control approval, you must get the service assessed - even if it does not meet the usual criteria.

### Assessments in local government

If you’re working in local government you can [use the localgov digital Slack channel](https://localgovdigital.slack.com/?redir=%2Fmessages%2Fgeneral) to ask for a peer review of your work.

Adapting the Service Standard
-----------------------------

You can adapt the Service Standard to suit different contexts.

For example, you might be building something that’s non-transactional, like a website or calculator. You won’t need to publish data on [the mandatory KPIs](service-manual_measuring-success_sharing-your-data-with-the-performance-platform#what-data-you-have-to-report.md), but you should still know what your users are trying to do and collect data that helps you work out whether they’re able to do that or not.

Or if you’re [creating a service for people who work in government](service-manual_design_services-for-government-users.md) you could take a more relaxed view of things like uptime, as the service is unlikely to be needed 24 hours a day. But make sure to schedule any downtime outside office hours.

If you’re creating a service that’s not for GOV.UK, you can still use the patterns in the [GOV.UK Design System](https://design-system.service.gov.uk/). But [it won’t be appropriate to make your service look like GOV.UK](https://www.gov.uk/service-manual/design/making-your-service-look-like-govuk).

Related guides
--------------

You may find the following guides useful:

* [Book a service assessment](service-manual_service-assessments_book-a-service-assessment.md)
* [What happens at a service assessment](service-manual_service-assessments_how-service-assessments-work.md)

Updates to this page
--------------------

Published 8 May 2019

Last updated 3 September 2024
[+ show all updates](#full-history)

1. 3 September 2024

   Updated information on how using a form-building platform affects assurance - you won’t usually need an assessment if you’re using an assured form building platform and expecting a lower number of transactions.
2. 10 May 2024

   Page updated to align with policy around assessment responsibilities and contact details for voluntary assessments.
3. 1 July 2022

   Added information about when online forms made using form building tools do not need to have a service assessment.
4. 8 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---