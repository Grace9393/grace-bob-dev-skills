Analyse a research session - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Analyse a research session
==========================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Plan analysis sessions](#plan-analysis-sessions)
2. [Extract observations](#extract-observations)
3. [Sort observations](#sort-observations)
4. [Determine findings](#determine-findings)
5. [Decide actions](#decide-actions)
6. [Share your findings](#share-your-findings)
7. [Case studies and examples](#case-studies-and-examples)
8. [Related guides](#related-guides)

User research activities produce a lot of raw data, for example:

* written and digital notes
* sketches and photos
* audio and video recordings

You need to filter, organise and interpret this data so you can produce useful insights that will help you design and deliver your service.

Plan analysis sessions
----------------------

Invite anyone who observed the user research to take part in the analysis session. You should do analysis as soon as you can after each round of research, while it is still fresh in people’s minds.

Involving lots of people helps your team make better decisions. It reduces the risk of researcher bias and limits the influence of individual team members or stakeholders. It also means you can decide as a group what the next most important thing to work on should be.

Aim to spend 1 hour analysing every 2 hours of research.

Extract observations
--------------------

Follow these steps to gather observations:

1. Hand out sticky notes (use just one colour).
2. Ask people to review their notes and write down anything interesting or relevant that they saw or heard during the session.
3. If you have recordings, make them available so people can confirm their observations and get verbatim quotes.
4. Tell the group to use a single note for each observation and write exactly what they saw or heard (eg verbatim quotes or observed behaviour), not what they think it means. This way, the notes will be unbiased and can represent the voice of the user.

### Capturing observations during research sessions

If your team is experienced and you’re doing research in a lab, they may be able to capture their observations on sticky notes during the session itself.

This only works for lab-based sessions because it’s difficult with most research methods to know which observations are important until you’ve reviewed all the data.

Sort observations
-----------------

Once they’ve written down their observations, ask your team members to place their sticky notes on a wall and start sorting them into similar themes, for example:

* common topics (eg identity, delivery, payment)
* stages in a user journey (eg ‘provide photo’, attend interview’, ‘pay’)
* individual pages or steps in a transaction
* types of user (eg personas)

Allow people to move notes placed by other people. The idea is to look for patterns or clusters, and to keep moving the notes until clear groups emerge. This is often called ‘affinity diagramming’ or ‘affinity sorting’.

### Name your groups

Once you have your groups, agree a title for each. At this stage, you can discard irrelevant or isolated notes. You should also check if you can break any large groups into smaller themes based on matching observations.

For example, if users have to provide a photo to use your service, you might have a ‘photos’ group that could broken down into:

* photo rules and requirements
* using a photo booth or high street photographer
* taking a photo at home
* reasons a photo might be rejected

Determine findings
------------------

The final part of analysis involves reviewing the notes in each group to determine what the observations are telling you.

When you agree on what you’ve learned, write it as a finding or ‘insight’ on a different coloured sticky note and add it to the relevant group.

You should write findings as short statements that summarise what you’ve learned, for example:

* ‘the legal declaration is threatening and difficult to understand’
* ‘people think they can click the progress bar to navigate’
* ‘users are confused about what’s required because so many questions are optional’

Decide actions
--------------

You can use your findings to make decisions about what to work on, change or research next. This supports the [agile method of planning continuously](service-manual_agile-delivery_core-principles-agile.md) based on new facts or requirements.

As a group, discuss if there are any obvious actions you want to take. Write these on a third colour sticky note and add it to the relevant group.

These might include:

* new design ideas to work on
* new questions to include in user research
* things you want to change in a prototype and test in another research session
* new user stories to add to the product backlog
* new details you need to add to an existing story
* strategic insights you can use to develop your user needs, proposition or product roadmap

Share your findings
-------------------

After analysing your research, you should write up your findings so you can share them with the wider team and stakeholders.

[Learn more about sharing user research](service-manual_user-research_sharing-user-research-findings.md).

Case studies and examples
-------------------------

To learn more about analysing user research sessions:

* [find out how GDS does research analysis in agile](https://userresearch.blog.gov.uk/2014/06/05/how-we-do-research-analysis-in-agile/)
* [see how to use sticky notes effectively when analysing research](https://userresearch.blog.gov.uk/2014/10/29/anatomy-of-a-good-sticky-note/)
* [find out why user researchers at the Department for Work and Pensions rely on insights](https://digitaldwp.blog.gov.uk/2015/03/26/digital-academy-the-importance-of-insights/)
* [find out how to do large-scale group analysis of user research data](https://userresearch.blog.gov.uk/2017/12/20/how-we-did-a-large-scale-group-analysis-of-user-research-data/)
* [find out how to create an empathy map and why they can be useful](https://www.nngroup.com/articles/empathy-mapping/)

Related guides
--------------

* [Find user research participants](service-manual_user-research_find-user-research-participants.md)
* [Write a recruitment brief](service-manual_user-research_write-a-recruitment-brief.md)

Updates to this page
--------------------

Published 24 May 2016

Last updated 24 May 2016
[+ show all updates](#full-history)

1. 24 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---