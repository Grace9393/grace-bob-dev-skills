Technical cloud community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Technical cloud community
=========================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Events](#events)
4. [Training](#training)
5. [Areas of special interest](#areas-of-special-interest)

The technical cloud community aims to:

* build a skilled and active community of technical expertise in using cloud technologies in government
* share knowledge, information, patterns, best practices and code
* improve the efficiency and speed of using cloud technologies in government

The community is part of the [One Government Cloud Strategy](https://www.gov.uk/government/publications/cloud-guide-for-the-public-sector), which aims to promote cloud adoption and best practice within government.

Who the community is for
------------------------

This community is for anyone with a technical interest in using cloud technology in government.

You might be interested in this community if you’re a technical architect, engineer, DevOps engineer, developer, designer or business analyst.

Anyone with an interest in cloud computing and a government email address can join.

Get involved
------------

To get involved with the community you can:

* join the [#cloud channel on the UK Government Digital Slack](https://ukgovernmentdigital.slack.com/messages/cloud) - create a Slack account using your government email address
* get the latest updates on [the technical cloud community page](https://onegovcloud.kahootz.com/OGCS/view?objectID=40167952) on the One Government Cloud Strategy website
* email us at [govtechcloudco@digital.cabinet-office.gov.uk](mailto:govtechcloudco@digital.cabinet-office.gov.uk) if you have any questions

Events
------

We’ll announce periodic events and meetups on the [#cloud Slack channel](https://ukgovernmentdigital.slack.com/messages/cloud).

Training
--------

We aim to offer opportunities to learn and share knowledge about cloud computing across government. We can also recommend, and put you in touch with, training providers and cloud suppliers.

Areas of special interest
-------------------------

We cover a diverse range of topics such as:

* new and emerging cloud technologies and trends
* cloud native platforms and solutions
* common and unique challenges in the cloud
* sovereign cloud, edge cloud, multi cloud and hybrid cloud
* cloud networking
* developing reusable and open code
* building proof of concepts

Updates to this page
--------------------

Published 9 March 2023

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---