Researching in small group workshops - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Researching in small group workshops
====================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to do research in small group workshops](#when-to-do-research-in-small-group-workshops)
2. [Steps to follow](#steps-to-follow)
3. [Further reading](#further-reading)

Running interactive workshops with small groups can be an effective method for user research.

They can help you learn more about the things that actual or likely users do, how they do them, how they think and make decisions, and how they feel about their experiences.

When to do research in small group workshops
--------------------------------------------

Doing research in small group workshops is most useful in the discovery phase when you want to:

* learn how people, such as colleagues or family members, work together to make a decision or to get something done
* get a more detailed understanding of people who’ve had a similar experience

You can also do workshops with stakeholders as a good first step to get an overview of a new area and build trust in preparation for more detailed research.

Working in small groups can help participants, as they can:

* feel more comfortable as part of a group
* learn about and build on others’ contributions

However, working in groups means that:

* you have to get everyone in the same room at the same time
* strong characters can dominate the discussion
* participants may not feel comfortable speaking openly in front of others - especially in groups with different levels of seniority

Bear in mind that you don’t get twice as many findings by inviting twice as many people to a session.

If there’s nothing to gain from having several participants together, you should run individual research sessions using methods such as [in-depth interviews](https://www.gov.uk/service-manual/user-research/using-in-depth-interviews), [contextual observation](https://www.gov.uk/service-manual/user-research/contextual-research-and-observation) or [experience mapping](https://www.gov.uk/service-manual/user-research/researching-user-experiences).

Research in small group workshops is not the same as focus groups. Focus groups are good for learning about opinions, attitudes and likely reactions. In user research we want to learn about [what works for users, not what’s popular](https://www.gov.uk/service-manual/user-research/how-user-research-improves-service-design#find-what-works-not-whats-popular).

Steps to follow
---------------

Plan your small group workshops carefully so you make the most of having the participants together. You’ll need to be flexible as you never know exactly what will happen when you bring people together.

### Design the workshop

Start by agreeing with your team the questions, issues or topics you want to learn more about. This will help you create the best workshop structure and activities.

Small group workshops are best with between 3 and 8 participants. Larger groups are more difficult to manage and give less time for detailed, individual contributions. If you need to run larger workshops, you’ll also need more facilitators.

An effective workshop can run from 1 to 3 hours. For longer workshops, factor in regular breaks. Book additional time before and after for set up and clear up.

A good default structure is to divide the workshop into 3 main parts.

1. Start by letting the participants explore the subject and open up their thinking.
2. Continue with activities that help the participants focus in more detail on particular topics, decisions, tasks or experiences.
3. Finish with participants comparing, consolidating and reflecting on the ideas and issues that have emerged.

To open the workshop use activities like:

* [carousel](http://gamestorming.com/caroussel/) - to gather thoughts from all participants
* [1-2-4-All](http://www.liberatingstructures.com/1-1-2-4-all/) - to quickly explore a question or topic

To explore topics in more detail use activities like:

* [empathy mapping](https://www.uxpin.com/studio/blog/the-practical-guide-to-empathy-maps-creating-a-10-minute-persona/) - to learn about a users’ actions, thoughts and feelings in a given situation
* [experience mapping](https://www.gov.uk/service-manual/user-research/creating-an-experience-map) - to learn more about specific steps in a common experience
* [force field analysis](https://www.mindtools.com/pages/article/newTED_06.htm) - to understand reasons for and against change
* [card sorting](https://www.usability.gov/how-to-and-tools/methods/card-sorting.html) - to understand how people think about words and related concepts
* question sorting - asking people to group and order questions to understand how people think about the information they’re providing
* 2 by 2 grids - asking people to place concepts on a matrix to understand things like categories, sizes, [priorities](https://www.nngroup.com/articles/prioritization-matrices/) or the [impact and effort](http://gamestorming.com/impact-effort-matrix-2/) of actions
* typical day or week mapping - asking people to map out a typical day or week to understand living or working patterns

To finish a workshop you can use activities like:

* [KJ-Technique](https://articles.uie.com/kj_technique/) - to group and prioritise topics
* [What, So What, Now What](http://www.liberatingstructures.com/9-what-so-what-now-what-w) - to encourage the whole group to reflect on what has happened in the session and what it means
* [five-fingered consensus](http://gamestorming.com/five-fingered-consensus/) - to quickly gauge consensus

With many of these activities you can choose whether to split the group or have the whole group work together. For example, if the group are all colleagues from the same team, you might have them work together to create a joint experience map. Whereas if the group are individual members of the public, you might ask them each to create an empathy map, then bring the group together to compare the results.

Make sure that the workshop will produce the research data you need. Ideally, this will simply be the outputs of the various activities. But you may also want to have a colleague [take notes or record the session](https://www.gov.uk/service-manual/user-research/taking-notes-and-recording-user-research-sessions) in other ways.

Once you’re happy with the structure and the activities, create a workshop plan. This should include:

* your introduction script - this tells the participants who you are, explains the workshop and reminds them about things like recording
* descriptions of each workshop activity, along with instructions and expected timings
* a planning checklist to make sure you’ll have everything you need - such as source material, sticky notes, pens, templates, cards, printouts and worksheets

You can use your workshop plan to:

* try out the activities and instructions with some colleagues
* stay on track during the workshop
* make sure participants are given the activities in a consistent way
* maintain a record of what you do in this round of research

### Prepare for the workshop

You should [recruit participants](https://www.gov.uk/service-manual/user-research/find-user-research-participants) who will help you build a full picture of what you’re trying to understand.

[Choose an appropriate room](https://www.gov.uk/service-manual/user-research/choose-a-location-for-user-research) with the right amount of floor and wall space, tables and chairs, and other equipment you need for the workshop activities. Check that you’re allowed to put worksheets and sticky notes on the walls.

Make sure the room is [accessible for the participants](https://www.gov.uk/service-manual/user-research/running-research-sessions-with-people-with-disabilities) and anyone who will be supporting them.

Arrange to have at least 2 people to facilitate the session - you may need 3 or more for larger groups with more complex activities. You may also want to invite other colleagues to observe.

Make sure all the facilitators understand the structure of the session and the parts they are responsible for - such as taking photos of outputs. Think about potential problems and agree how you might deal with them - for example, cutting an activity short if you are running over time.

### Run the workshop

Before the workshop:

* prepare and print all the materials you need for the workshop activities (use your planning checklist)
* set participants’ expectations so they are ready for the workshop when they arrive - this is especially important when researching people who work together

At the start of the workshop:

* [get all the participants’ informed consent](https://www.gov.uk/service-manual/user-research/getting-users-consent-for-research)
* give everyone a few moments to relax and get comfortable
* run through your introduction script to explain what’s going to happen and set any ground rules
* show everyone the workshop agenda - and keep it visible throughout

During the activities:

* show clear instructions for each activity on a single slide or poster - without this people quickly forget what they’re supposed to be doing
* regularly check how the participants are doing, and provide any support and guidance they need
* make sure everyone has the chance to contribute - use techniques like [talking chips](http://gamestorming.com/talking-chips/)
* don’t put people on the spot - give people the time they need to think
* be flexible - some things may go quicker and work better than you expect, while others can take longer or be less effective
* use breaks to help maintain energy levels
* be sure to end on time

Reserve some time at the end of the activities to:

* ask follow-up questions about any contributions you didn’t clearly understand
* check if the participants have any final thoughts about the things they’ve discussed

At the end of the workshop:

* spend 5 to 10 minutes asking participants about the session - what went well and what could be improved
* thank everyone for their time and what they’ve helped you learn
* explain what will happen with your research

When the participants have left:

* make sure any personal data you’ve collected (on paper or in recordings) is stored securely
* pack away your equipment (use your planning checklist)

### Use the results

After the session, go through the notes and outputs with your team to [generate findings](https://www.gov.uk/service-manual/user-research/analyse-a-research-session) they can use.

If the workshop produced visual outputs such as experience maps, empathy maps or grids, share them with others to prompt discussion and ideas. For example, post them on your team wall space, or email copies to anyone based remotely.

Further reading
---------------

Find about more in these examples and case studies:

* [getting the best from workshops](https://gds.blog.gov.uk/2017/12/18/ten-tips-for-getting-the-best-from-workshops/)
* [how we ran collaborative user research for a collaborative standard](https://userresearch.blog.gov.uk/2018/05/08/how-we-ran-collaborative-user-research-for-a-collaborative-standard/)
* [building a phone for older people](http://videos.theconference.se/clara-gaggero-westaway-merging-physical-and) (video)

You can find more techniques to use in small workshops:

* [Gamestorming](http://gamestorming.com/) - lots of resources on different workshop exercises and when to use them.
* [Liberating structures](http://www.liberatingstructures.com/) - lots of resources on different workshop exercises and when to use them.

You can also download a [poster to encourage inclusive meetings](https://assets.publishing.service.gov.uk/media/5b3373e340f0b67f6dea2bf9/2018-03-15_Inclusive_meetings_poster.jpg), created by the GDS Introverts Network.

Updates to this page
--------------------

Published 28 June 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---