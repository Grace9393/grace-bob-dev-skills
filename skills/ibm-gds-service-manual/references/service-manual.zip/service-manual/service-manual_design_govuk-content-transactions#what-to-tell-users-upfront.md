Designing how GOV.UK content and transactions work together - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Designing how GOV.UK content and transactions work together
===========================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [What to tell users upfront](#what-to-tell-users-upfront)
2. [What to deal with inside your transaction](#what-to-deal-with-inside-your-transaction)
3. [Related reading](#related-reading)

Services often include multiple GOV.UK guidance pages and transactions, as well as offline channels.

These elements perform different functions to help a user navigate and complete a service. Use each of these elements for what they’re best for.

For example, GOV.UK guidance pages are good for explaining information in a simple way and nudging users towards the transactional elements of a service, where they carry out their task.

But guidance pages are not usually the place to handle the more complex elements of your service, like eligibility criteria.

Instead of asking the user to read and understand complicated eligibility criteria on a GOV.UK guidance page or start page, you can ask them some simple questions within your transaction.

Asking these questions once the user’s clicked the link on the GOV.UK start point into your service helps you build a picture of whether or not they’re eligible. If they are, you can let them complete the transaction. If they’re not, you can tell them what they need to do instead.

This means the user does not need to work out their eligibility themselves, which minimises [cognitive load](https://www.nngroup.com/articles/minimize-cognitive-load/) and makes it easier for them to complete their task.

It’s important to strike the right balance between what you handle inside and outside your transaction.

What to tell users upfront
--------------------------

Give users an idea of whether they can use your service. This might mean including some high-level eligibility information on the GOV.UK start page or guidance page that links to your service - for example if users need to be a certain age or live in a certain area to use the service.

It’s okay to include broad statements like ‘this service is for businesses, not individuals’.

You could also give users information about the wider context of the task they’re doing - for example, some information about dealing with the estate of someone who’s died on the start page of a transaction about Inheritance Tax.

[Discuss these issues with the GDS content team](https://www.gov.uk/service-manual/service-assessments/get-your-service-on-govuk) when you get in touch to talk about how the user journey to your service might work. Aim to do this midway through the alpha phase.

Once you’ve worked out the details with the GDS content team, it’s a good idea to include a draft of the start page or guidance page that will link to your service in your prototype. This is so you can research what works for users and what does not. You can get a [template start page](https://design-system.service.gov.uk/patterns/start-pages/) to use in your prototypes in the GOV.UK Design System.

What to deal with inside your transaction
-----------------------------------------

### Complex eligibility

Handle more complex eligibility through routing questions within your transaction. For example, if someone lives abroad and their [eligibility depends on which part of the UK they used to live in](https://www.registertovote.service.gov.uk/register-to-vote/exit/northern-ireland-overseas).

This approach means you:

* only show information to the people it’s relevant to
* give advice tailored to the user’s situation
* reduce time and money spent processing queries from users confused about whether they can use your service

You can use the [Check a service is suitable](https://design-system.service.gov.uk/patterns/check-a-service-is-suitable/) design pattern to ask users questions to help them work out if they can or should use your service.

### Routing users to the right service

Routing questions also work well for sending users to the right service. The team at HM Revenue and Customs working on the ‘File your company accounts and tax return’ service found this approach useful.

The team were building a new service to replace a legacy version. For a period while they were adding functionality to the new one, both services needed to be live at the same time.

The team originally planned to link to the services from separate start pages.

However, this would have meant users working out their own eligibility and potentially using the wrong version of the service.

Instead, the team used a single start page and built routing questions which took users to the version of the service they needed.

### Give users information at the point they need it

If the user needs information to complete a certain step in their task, it’s better to provide it at that point in the transaction.

That’s because if you link users out to a content item elsewhere on GOV.UK, they may not find their way back to the transaction.

It’s okay to duplicate small amounts of information already on GOV.UK if it means keeping the user inside the transaction. But if you need to do this a lot then [your service is probably too complicated](service-manual_design_scoping-your-service.md).

Unless users need a piece of information to complete a step in your transaction, it’s best not to include it. Content inside a transaction is not indexed by search engines and users will not be able to find it when browsing GOV.UK.

If users need information outside of the transaction, talk to your department’s publishing team about getting guidance on to GOV.UK.

Related reading
---------------

* [‘Check before you start’ design pattern](https://design-system.service.gov.uk/patterns/check-a-service-is-suitable/)
* [Building end-to-end services into GOV.UK](https://gds.blog.gov.uk/2017/11/30/building-end-to-end-services-into-gov-uk/)

Updates to this page
--------------------

Published 30 April 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---