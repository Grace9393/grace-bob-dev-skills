Artificial Intelligence community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Artificial Intelligence community
=================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Resources](#resources)

The cross-government artificial intelligence (AI) community exists to:

* share information about what other departments are doing in the field of AI
* enable people using AI tools in the workplace to share their experiences and best practices
* host talks on topics including AI ethics, security and emerging uses of AI technology, from speakers both inside and outside government

Who the community is for
------------------------

You don’t have to be in an AI role to join, but you might want to join this community if you are interested in:

* how the AI field is developing
* learning about existing and emerging AI tools
* understanding how to use AI ethically and safely

Get involved
------------

Please sign up using [our form](https://www.us14.list-manage.com/subscribe?u=751cf84762295209ed8291813&id=db38e5da8d) or email [ai@dsit.gov.uk](mailto:ai@dsit.gov.uk).

As a member of the AI community you will be able to:

* attend our monthly AI talks
* join the mailing list
* read and contribute to the monthly AI Community newsletter, which includes relevant news and events
* connect with colleagues from across the public sector in the [AI Community KHub group](https://khub.net/group/ai-community)

### Events

The community meets on a monthly basis on Teams.

Resources
---------

You can use these resources to learn about using AI in government:

* [a guide to using AI in the public sector](https://www.gov.uk/government/collections/artificial-intelligence-resources-for-the-public-sector)
* [AI regulation: a pro-innovation approach - white paper](https://www.gov.uk/government/publications/ai-regulation-a-pro-innovation-approach)
* [a blog about generative AI from the Chief Technology Officer for UK government](https://cddo.blog.gov.uk/2023/06/30/the-use-of-generative-ai-in-government/)
* [AI Playbook for UK government](https://www.gov.uk/government/publications/ai-playbook-for-the-uk-government)
* [first findings of GDS’s experiment with an AI chatbot on GOV.UK](https://insidegovuk.blog.gov.uk/2024/01/18/the-findings-of-our-first-generative-ai-experiment-gov-uk-chat/)

Updates to this page
--------------------

Published 15 March 2024

Last updated 25 June 2025
[+ show all updates](#full-history)

1. 25 June 2025

   Edited email address and added link to KHub group.
2. 15 March 2024

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---