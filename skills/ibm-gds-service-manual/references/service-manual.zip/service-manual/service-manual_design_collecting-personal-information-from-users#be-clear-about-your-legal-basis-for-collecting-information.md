Collecting personal information from users - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Collecting personal information from users
==========================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Do not collect information you do not need](#do-not-collect-information-you-do-not-need)
2. [Do not store information any longer than you need to](#do-not-store-information-any-longer-than-you-need-to)
3. [Be clear about your legal basis for collecting information](#be-clear-about-your-legal-basis-for-collecting-information)
4. [Tell users what information you’re collecting and what you’ll do with it](#tell-users-what-information-youre-collecting-and-what-youll-do-with-it)
5. [Especially sensitive personal information](#especially-sensitive-personal-information)

Minimise the personal information you collect from users - and make sure you’re only collecting personal information when it’s a proportionate way of solving the problem you’re trying to solve.

Talk to your data protection expert or legal adviser to make sure what you’re planning to do is proportionate in the circumstances.

Make it as easy as possible for users to understand how you’ll use any personal information you do collect.

If your service uses cookies or similar technologies to store information on a user’s device, you must [follow the guidance about using cookies](service-manual_technology_working-with-cookies-and-similar-technologies.md).

Do not collect information you do not need
------------------------------------------

The first thing to do is [remove any questions that you do not need to ask](https://www.gov.uk/service-manual/design/form-structure). As well as minimising the personal information you’re collecting, that will make your service simpler to use.

Make sure you do not accidentally collect personal information by [setting up your digital analytics tools correctly](https://www.gov.uk/service-manual/measuring-success/choosing-digital-analytics-tools), and avoid putting personally identifiable information [into page titles or H1s](https://design.tax.service.gov.uk/hmrc-design-patterns/page-title/#personally-identifiable-information).

Do not store information any longer than you need to
----------------------------------------------------

You do not always need to store personal information at all. For example, let’s say you need to know if someone is getting a particular benefit so you can tell whether they’re eligible to use your service.

You may be able to use an [application programming interface (API)](https://www.gov.uk/service-manual/technology/application-programming-interfaces-apis) or [something similar to an API](https://gdstechnology.blog.gov.uk/2014/07/10/under-the-hood-of-ier/) so you can just record whether they were eligible or not. And avoid storing the raw personal information they supplied (for example, a scan of the benefit letter that proved their eligibility).

Do not store personal information you do collect for longer than you need to given the purpose you collected it for. This will reduce opportunities for attackers to exploit security vulnerabilities in your service.

Be clear about your legal basis for collecting information
----------------------------------------------------------

[The Data Protection Act 2018](https://www.gov.uk/data-protection) is the UK’s implementation of the General Data Protection Regulation (GDPR). These rules state that you need to be clear about your legal basis for collecting personal information.

Getting consent from the user is one basis.

But if the information you’re collecting is an essential part of providing a public service, think carefully about whether it could be better to rely on a different basis, for example, the ‘public task’ basis.

For example if you’re running a government service that involves issuing an official document in someone’s name, it’s probably not meaningful to ask for consent to collect their name. Because it’s not possible to provide the service without collecting that information.

Aside from consent, the [legal bases for collecting and processing personal information](https://ico.org.uk/for-organisations/guide-to-the-general-data-protection-regulation-gdpr/lawful-basis-for-processing/) are:

* ‘public task’ - you need to collect or process the information to carry out a task in the public interest, or for an official function
* ‘contract’ - you need to collect or process the information to fulfil a contract you’ve entered into with the user - or because they have asked you to do something before entering into a contract (for example, provide a quote)
* ‘legal obligation’ - you need to collect or process the information to comply with the law (this does not include contractual obligations)
* ‘legitimate interests’ - you need to collect or process the information to protect your interests, or those of a third party (and it’s reasonable to do so when balanced against the user’s interests)
* ‘vital interests’ - you need to collect or process the information to protect someone’s life

If you’re a public body you cannot rely on ‘legitimate interests’ for personal information you’re collecting or processing as part of a public task - only for things that are outside the scope of a public task.

Your data protection expert or legal adviser will be able to advise you what legal basis to rely on. Learn how to identify [cyber security obligations](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/understanding-cyber-security-obligations/) relevant to your service.

### How to ask for consent

If you are relying on consent as the basis for collecting and processing personal information, it has to be meaningful consent. If a user refuses their consent, they must still be able to use the service.

Consent means the user has to explicitly agree to you using their information in a specific way, not just failing to say they disagree. Ask a direct question rather than relying on the user ticking or unticking a check box.

Make it clear what the user is agreeing to. It’s not consent if the user does not understand what they’re consenting to.

And be equally clear about what the user should do if they want to withdraw their consent.

For example if you wanted consent to send emails that are not directly related to providing the service, you might:

* ask a direct question like ‘Can we send you emails about [X subject]?’
* tell the user how often you usually send the emails, so they can make an informed decision
* tell the user that they can stop the emails at any time, with details of how to do it

![ ](https://assets.publishing.service.gov.uk/media/5b69afece5274a14f45342dc/Sample-question-GDPR-guidance.jpg)

Consent must be specific. If you’re asking users to consent to different things, ask for consent to each thing in a separate question.

Tell users what information you’re collecting and what you’ll do with it
------------------------------------------------------------------------

Use plain language to explain what personal information you’re collecting and what you’ll do with it.

Put things in terms that will be familiar to your users. For example, you may need to explain things in a different way if your service is aimed at children.

If you’re doing something that has an especially significant consequence for the user, or it’s something that the user might not expect to happen, do not rely on them reading the privacy notice to find out about it.

For example, if you’re collecting information that’s going to be put on a public register, tell the user in the main flow of the service.

### Privacy notices

Create a privacy notice that’s specific to the service. In an online service, the privacy notice should be available to the user at any point, via a ‘privacy’ link in the [footer](https://www.gov.uk/service-manual/design/add-the-govuk-header-and-footer). Do not bury it in a terms and conditions page. Serve the privacy notice as part of the service, not as a page on GOV.UK.

Privacy notices and other ‘legal’ content must be written in plain English and to [GOV.UK style](https://www.gov.uk/guidance/content-design/writing-for-gov-uk), just like any other content.

Explain, clearly and concisely:

* step by step, what you’ll do with the personal information once you’ve collected it
* why you’re collecting their personal information
* which of the legal bases you’re using for collecting and processing personal information
* how long you’ll keep the personal information - or, if there’s no set period, how you’ll decide how long to keep it

If you’re collecting and storing personal information on the basis of a legitimate interest, you’ll need to explain how you balanced those interests against the user’s interests.

In the privacy notice, you’ll also need to:

* say who the ‘data controller’ for the service is (usually your department or agency)
* explain in what circumstances you’ll share the information outside your organisation, and who with (including any ‘data processors’ - organisations processing personal information on your behalf)
* provide contact details for any data processors who will be processing personal information on your behalf

If the personal information will be transferred outside the UK as part of the processing, make that clear. And say what you’re doing to make sure the personal information gets the same level of protection as it would within the UK.

If the service uses an automated decision making process (for example, a computer algorithm), explain clearly how it works.

The Digital Marketplace has [an example of a clearly written privacy notice](https://www.digitalmarketplace.service.gov.uk/privacy-notice).

This is not necessarily a complete list of what should go into a privacy notice. Check the privacy notice with your organisation’s data protection expert or legal adviser.

### Personal information charters

Do not go into detail about the standards your organisation follows when dealing with personal information in the privacy notice - link to your organisation’s official personal information charter instead.

The personal information charter should include information on how to get in touch with your Data Protection Officer.

It should also explain users’ rights - including their rights if they want to see personal information you’re holding about them.

Or if they want you to erase or restrict processing of personal information you’re holding about them.

The Cabinet Office has [an example of a clearly written personal information charter](https://www.gov.uk/government/organisations/cabinet-office/about/personal-information-charter).

Especially sensitive personal information
-----------------------------------------

There may be additional things to consider if you’re collecting especially sensitive types of personal information. For example personal information about children, or information relating to ethnicity, health, genetics or biometrics.

Check with your organisation’s data protection expert or legal adviser.

Updates to this page
--------------------

Published 21 May 2018

Last updated 25 March 2025
[+ show all updates](#full-history)

1. 25 March 2025

   Adding explicit guidance about excluding personally identifiable information from page titles and H1s.
2. 25 November 2024

   Integrated guidance about understanding business objectives and user needs, understanding cyber security obligations, and sourcing a threat assessment.
3. 28 September 2021

   Updated reference to EEA legislation.
4. 21 May 2018

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---