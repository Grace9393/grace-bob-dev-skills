Researching contentious subjects or during pre-election periods - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Researching contentious subjects or during pre-election periods
===============================================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Services related to Brexit](#services-related-to-brexit)
2. [Confidential subjects](#confidential-subjects)
3. [During pre-election periods](#during-pre-election-periods)
4. [Working with certain user groups](#working-with-certain-user-groups)
5. [Working with commercial suppliers](#working-with-commercial-suppliers)
6. [Tell us about your experiences](#tell-us-about-your-experiences)

It’s usually fine to do user research on contentious subjects, or during times like the pre-election period.

You might need to take a few more precautions than you usually would depending on the research you’re doing.

Services related to Brexit
--------------------------

Sometimes the service you’re working on will be linked to something that’s politically sensitive or confidential. For example because it has not been announced or the policy has not been set.

But you should still do user research because:

* you’re working out how well a service works, not opinion polling
* a bad service could damage the department’s reputation and lead to expensive failure demand

Make sure not to imply a particular policy outcome if the outcome is still being negotiated, as with Brexit. You can avoid this by explaining that you’re testing a range of outcomes.

Confidential subjects
---------------------

You can minimise the risk of information leaks by:

* using more robust [non-disclosure agreements](https://www.gov.uk/government/publications/non-disclosure-agreements) (NDAs) - for example covering use of social media, or mentioning the Official Secrets Act
* changing login details after each session, or putting any sensitive information on paper and collecting it at the end of each session

If your service is linked to something particularly sensitive or confidential, you will not be able to carry out user research as planned. But you might still be able to:

* research any non-sensitive parts of the service
* find representative end users within your organisation, if you cannot talk to members of the public
* research with people who are not end users but who know about them, for example by doing [contextual research](https://www.gov.uk/service-manual/user-research/contextual-research-and-observation) of call centre staff

### Example

A team working on a Brexit related service found ways to lower the risk of carrying out user research.

Their service featured several interactions - like document uploading - that they could test in isolation, outside of the political context of the service.

Removing the sensitive context meant the team could test the interactions with a wider range of participants, while still getting useful data.

The team kept these prototypes separate from their main prototype, so there was no risk of users accessing sensitive information.

During pre-election periods
---------------------------

Teams often think they cannot do any user research whatsoever during a pre-election period. This is not the case.

Even during these periods, you can:

* recruit members of the public through recruitment agencies, as long as initial adverts and screeners do not mention or imply that the research is for a government service
* invite participants from existing user research panels like the [GOV.UK panel](https://userresearch.blog.gov.uk/2017/03/27/launching-a-user-research-panel-for-gov-uk/) - this is a good tactic for any sensitive research you’re doing
* use internal channels to recruit colleagues for user research on internal aspects of services

You will not be able to:

* do research on themes or issues that might be raised by politicians, or could be seen to have an impact on the outcome of the election
* recruit participants directly online, for example through government or personal social media accounts
* do pop-up research, where you recruit members of the public at a venue on the day
* promote user research activities or publish results on blogs or other public channels

Working with certain user groups
--------------------------------

There are things you can do to mitigate any additional risks or challenges of doing research with certain groups.

### Groups with a negative public perception

Some services are for groups of people that might have a negative public perception, for example offenders.

It’s important you still carry out user research because a better service for users leads to better outcomes for everyone. For example, an improved service for offenders might reduce reoffending, improve safety for public, staff and prisoners, and lead to faster and fairer decisions.

You can help mitigate the risk of how your research might be perceived by considering things like the incentives you give to participants.

### Groups with a higher risk of information leaks

Some services are for groups of people that might be more likely to share negative information. For example, members of advocacy groups.

You can do user research safely with these groups as long as you:

* do not consult them about government policy
* minimise the risk of leaks, for example by using NDAs

You might also not want the public to know that you’re talking to these groups. If so, ask your recruitment agency to ensure initial adverts and screeners do not mention or imply that the research is for a government service.

If you think there might be particular sensitivities for your service or department, speak to your communications team.

### Disabled people and people with low digital skills

There’s sometimes a perception that you need to apply risk assessment and safeguarding processes to all disabled people and people with low digital skills.

The vast majority of participants should be able to take part without this.

Just make sure you ask what they need so that you can [plan sessions that are easy and comfortable for them](service-manual_user-research_running-research-sessions-with-people-with-disabilities.md).

Working with commercial suppliers
---------------------------------

It’s important not to be seen to be favouring one supplier over another.

The [Digital Marketplace](https://www.gov.uk/government/collections/digital-marketplace-buyers-and-suppliers-information) team sometimes faces this issue when doing research.

They handle this by blogging or tweeting that they are doing research, for example on the opening of a new framework. This openness allows people to raise any objections, or volunteer to take part in research sessions. It also builds trust.

Tell us about your experiences
------------------------------

If you’ve done user research of this nature, we’d love to hear how you did it. [Get in touch with us](https://www.gov.uk/service-manual/communities/contact-the-service-manual-and-service-standard-team).

Updates to this page
--------------------

Published 24 October 2024

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---