Testing for accessibility - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Accessibility and assisted digital](service-manual_helping-people-to-use-your-service.md)

Accessibility and assisted digital

Testing for accessibility
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Accessibility community](service-manual_communities_accessibility-community.md)

Contents
--------

1. [Think about accessibility from the start](#think-about-accessibility-from-the-start)
2. [Testing your code](#testing-your-code)
3. [Automated testing](#automated-testing)
4. [Manual testing](#manual-testing)
5. [Testing with assistive technologies](#testing-with-assistive-technologies)
6. [Getting an accessibility audit](#getting-an-accessibility-audit)
7. [Useful resources](#useful-resources)
8. [Related guides](#related-guides)

You need to make sure your service meets level AA of the [Web Content Accessibility Guidelines 2.2](https://www.gov.uk/service-manual/helping-people-to-use-your-service/understanding-wcag) (WCAG 2.2) as a minimum.

If the service does not meet WCAG 2.2 AA, you may be breaking the law.

If you’re working to meet the [Service Standard](https://www.gov.uk/service-manual/service-standard), you’ll also need to:

* make sure the service works with the most common [assistive technologies](https://www.gov.uk/service-manual/technology/testing-with-assistive-technologies) - screen readers or speech recognition software, for example
* [test the service with disabled users](https://www.gov.uk/service-manual/user-research/running-research-sessions-with-people-with-disabilities) and with older users

The best way to meet accessibility requirements is to:

* think about accessibility from the start
* run your own accessibility tests regularly throughout development
* get a formal accessibility audit before you go into public beta

Think about accessibility from the start
----------------------------------------

Consider accessibility at every stage. You might find these [accessibility user profiles](https://www.gov.uk/government/publications/understanding-disabilities-and-impairments-user-profiles) useful.

Start thinking about technical accessibility from alpha. When you’re discussing ideas and developing concepts, consider:

* whether what you’re thinking about meets the [WCAG design principles](https://www.gov.uk/service-manual/helping-people-to-use-your-service/understanding-wcag-20#wcag-20-design-principles)
* how people with impairments to their sight, hearing, movement, memory or thinking might use it

You should run regular tests as soon as you start writing production code. Once your service moves into public beta, run tests every time you add a new feature.

When you’re working on rough prototypes, you do not need to worry about your code being accessible. But it’s useful to check that things like the colour contrasts you’re using are accessible.

Working in this way helps you identify and fix issues early. It’s much more expensive to unpick and fix them at a later stage.

Testing your code
-----------------

Test your code regularly, using both automated testing and manual testing. These tests will also uncover issues with design and content.

It’s important to do both types of testing - you’ll miss some issues if you only do automated testing.

Automated testing
-----------------

There are a range of tools for automated testing including:

* [Axe](https://www.deque.com/axe/)
* [WAVE](http://wave.webaim.org/extension/)
* [ARC Toolkit](https://www.tpgi.com/arc-platform/arc-toolkit/)
* [SiteImprove](https://www.siteimprove.com/integrations/browser-extensions/)

Manual testing
--------------

[Doing a basic accessibility check if you cannot do a detailed one](https://www.gov.uk/government/publications/doing-a-basic-accessibility-check-if-you-cant-do-a-detailed-one/doing-a-basic-accessibility-check-if-you-cant-do-a-detailed-one) is guidance to help you test for common accessibility problems, including:

* lack of keyboard accessibility (important because some people rely on using a keyboard to navigate websites)
* link text that’s not descriptive (for example,‘click here’ links)
* lack of colour contrast for text and important graphics and controls
* images not having meaningful alt text (where alt text is needed)
* [online forms](https://design-system.service.gov.uk/components/) not being marked up correctly, so the right control is associated with the right label

Some browsers have tools that make it easier to find accessibility problems in the Document Object Model (DOM). For example, the [Accessibility Inspector for Mozilla Firefox](https://developer.mozilla.org/en-US/docs/Tools/Accessibility_inspector) and the [accessibility features in Chrome DevTools](https://developers.google.com/web/tools/chrome-devtools/accessibility/reference).

There are also tools like [Microsoft’s Accessibility Insights](https://accessibilityinsights.io/) which help going through manual checks.

Testing with assistive technologies
-----------------------------------

Your service needs to work on the [most common browsers and devices](https://www.gov.uk/service-manual/technology/designing-for-different-browsers-and-devices) people will use to access your service.

You must also make sure your service works with [common assistive technologies](https://www.gov.uk/service-manual/technology/testing-with-assistive-technologies).

This means:

* where possible, doing some testing with assistive technology yourself
* [finding user research participants](service-manual_user-research_find-user-research-participants.md) who use assistive technology
* asking for assistive technology testing to be included in your accessibility audit

Getting an accessibility audit
------------------------------

You must get an [accessibility audit](service-manual_helping-people-to-use-your-service_getting-an-accessibility-audit.md) - and fix any issues - before your service moves into public beta.

Useful resources
----------------

You can start some simple tests with:

* [Doing a basic accessibility test if you cannot do a detailed one](https://www.gov.uk/government/publications/doing-a-basic-accessibility-check-if-you-cant-do-a-detailed-one/doing-a-basic-accessibility-check-if-you-cant-do-a-detailed-one)
* [W3C Easy Checks](https://www.w3.org/WAI/test-evaluate/preliminary/) - a few quick things to help you start to assess how accessible a web page is
* [Basic screen reader commands for accessibility testing](https://developer.paciellogroup.com/blog/2015/01/basic-screen-reader-commands-for-accessibility-testing/), from TPGi
* [WCAG report generator](https://www.w3.org/WAI/eval/report-tool/#/)

You can also read some blog posts on:

* [Assistive technology tools you can test with at no cost](https://accessibility.blog.gov.uk/2018/09/27/assistive-technology-tools-you-can-use-at-no-cost/)
* [Why accessibility testing with real users is so important](https://accessibility.blog.gov.uk/2018/03/20/why-accessibility-testing-with-real-users-is-so-important/)
* [Using persona profiles to test accessibility](https://accessibility.blog.gov.uk/2019/02/11/using-persona-profiles-to-test-accessibility/)
* [Remote accessibility persona testing](https://accessibility.blog.gov.uk/2021/03/30/remote-accessibility-persona-testing/)
* [What we found when we tested tools on the world’s least-accessible webpage](https://accessibility.blog.gov.uk/2017/02/24/what-we-found-when-we-tested-tools-on-the-worlds-least-accessible-webpage/)

Related guides
--------------

You may also find these guides useful:

* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)
* [Using, adapting and creating patterns](service-manual_design_using-adapting-and-creating-patterns.md)
* [Using progressive enhancement](https://www.gov.uk/service-manual/technology/using-progressive-enhancement)

Updates to this page
--------------------

Published 6 March 2019

Last updated 29 October 2024
[+ show all updates](#full-history)

1. 29 October 2024

   Section about when GDS is monitoring the new success criteria in WCAG 2.2 has been removed.
2. 5 October 2023

   Added information about WCAG 2.2 and what GDS is doing as a result of the new success criteria in WCAG 2.2.
3. 24 May 2022

   Page reviewed and updated.
4. 6 March 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---