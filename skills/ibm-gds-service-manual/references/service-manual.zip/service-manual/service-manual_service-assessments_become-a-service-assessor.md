Become a service assessor - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service assessments and applying the Service Standard](service-manual_service-assessments.md)

Service assessments and applying the Service Standard

Become a service assessor
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Standards and assurance community](service-manual_communities_standards-and-assurance-community.md)

Contents
--------

1. [Who sits on an assessment panel](#who-sits-on-an-assessment-panel)
2. [What being an assessor involves](#what-being-an-assessor-involves)
3. [Why it’s good to be an assessor](#why-its-good-to-be-an-assessor)
4. [How to become an assessor](#how-to-become-an-assessor)

Becoming a service assessor is an opportunity to help service teams across government create and run great public services by meeting the Service Standard. It also helps your professional development and is a great way to learn about other government departments and services.

Who sits on an assessment panel
-------------------------------

Assessment panels are made up of:

* lead assessor
* user researcher
* designer - any type of designer with the relevant experience can be a design assessor, including service, interaction and content designers
* technologist
* analyst

A lead assessor is a very experienced specialist assessor, or a product or service manager who is confident assessing all aspects of [multidisciplinary team working](https://www.gov.uk/service-manual/service-standard/point-6-have-a-multidisciplinary-team) (with input from specialists in those disciplines).

The lead assessor is responsible for:

* setting a supportive tone for the assessment
* keeping things moving and making sure the assessment finishes on time
* managing discussions, including any areas of disagreement
* working with the department’s assessment team to finalise the assessment report

If the panel is undecided on the outcome of an assessment, the lead assessor has the deciding vote.

What being an assessor involves
-------------------------------

Most people who take part in service assessments do so alongside their day job. So you’ll need to decide whether you’ve got the capacity to do it.

A typical assessment lasts about 4 hours. Usually the service team presents and demonstrates their service, then the assessors ask questions to establish how it meets the Service Standard.

You can read more about [what usually happens at a service assessment](https://www.gov.uk/service-manual/service-assessments/how-service-assessments-work).

As well as making time for the assessment itself, you’ll need to spend a few hours:

* reading the briefing documents and familiarising yourself with the service ahead of the assessment
* attending the pre-assessment meeting
* attending the pre-assessment tech call (for technologists)
* writing up your section of the assessment report

Being an assessor is a skill that takes time to develop, so we encourage assessors to commit to being involved on a regular basis. Most assessors do roughly one assessment a month.

These things mean that being an assessor is a significant commitment. One way to make sure you can allocate enough time to it is to make assessments part of your corporate objectives. This allows you to set aside time each month for assessments.

Why it’s good to be an assessor
-------------------------------

As an assessor you’ll be part of the wider digital government community. You’ll have come into contact with practitioners from outside your department, get inspired by what others are doing and take away ideas to inform your own practice.

You’ll also be sharing your knowledge with the community. Being an assessor involves more than just pointing out what teams have done well - it’s also about coaching them through the things they need to improve.

It’s important for the teams being assessed to know they’re being assessed by one of their peers - someone who understands the sort of environment they’re working in and the constraints they’re likely to be facing.

How to become an assessor
-------------------------

To become an internal assessor within your department contact the person or team in charge of service assessments or assurance at your department (or your agency’s parent department). They will usually have a process for working out whether you’ve got the right amount of experience and can set you up as an internal assessor within your department.

If you want to assess services across government, you’ll also need to contact the service assessments team at CDDO at [dbd-assessments@digital.cabinet-office.gov.uk](mailto:dbd-assessments@digital.cabinet-office.gov.uk). Copy in the person or team in charge of assurance at your parent department (or your agency’s parent department).

CDDO will email you about what happens next. If you’re invited to become an assessor for services across government, you’ll be asked:

* how long you’ve been in your role
* why you’d make a good assessor
* whether you want to be a lead, user researcher, designer, technologist or analyst assessor
* to provide an endorsement from your department’s head of community or profession, or your line manager

You’ll then do assessor training and observe 2 assessments before taking part in an assessment. The process takes between 1 and 3 months.

In the meantime, familiarise yourself with the [Service Standard](https://www.gov.uk/service-manual/service-standard) and [what happens at an assessment](https://www.gov.uk/service-manual/service-assessments/how-service-assessments-work).

Updates to this page
--------------------

Published 10 May 2019

Last updated 9 May 2024
[+ show all updates](#full-history)

1. 9 May 2024

   Added information about benefits of becoming a service assessor
2. 10 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---