Working with open standards - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Working with open standards
===========================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Open standards you must use](#open-standards-you-must-use)
2. [Finding technical standards outside government](#finding-technical-standards-outside-government)
3. [Getting an exemption](#getting-an-exemption)

Open standards are technical specifications developed outside of government.

You must use open standards when designing and building your service unless you’ve been granted an exemption.

Using open standards means you can:

* share data between services and systems more easily
* avoid getting ‘locked in’ to a specific piece of technology or supplier
* reuse software components built by others, including open source components
* reduce the overall cost of your digital service
* benefit from global cyber threat intelligence
* change your service’s design over time more easily

Open standards you must use
---------------------------

The [Open Standards Board](https://www.gov.uk/government/groups/open-standards-board) has approved a list of [open standards that all of government must use](/government/publications/open-standards-for-government).

### If no approved open standard meets your needs

If you believe the approved list has no available standard that meets your needs, email the open standards team: [openstandards@digital.cabinet-office.gov.uk](mailto:%20openstandards@digital.cabinet-office.gov.uk).

They’ll tell you if another government project has a similar standard you could use.

If there’s no suitable standard in use elsewhere in government, you must find a standard from outside government.

Finding technical standards outside government
----------------------------------------------

When looking for a standard outside government, you must follow these open standard principles.

1. Start with user needs.
2. Choose standards that make it possible for suppliers to compete on an equal basis.
3. Choose standards that support flexibility and change.
4. Choose standards that support sustainable cost.
5. Make well-informed decisions about your standards.
6. Use fair and transparent selection processes when choosing your standards.
7. Be fair and transparent in how you specify and implement your chosen open standards.

Find out more about [following open standards principles](/government/publications/open-standards-principles/open-standards-principles).

If you find a standard that you think could be useful across government, you should [submit a suggestion to the open standards team](https://www.gov.uk/guidance/propose-an-open-standards-challenge) at the Central Digital and Data Office (CDDO).

### Services with multiple technical specifications

If you’re building a service which uses multiple technical specifications, for example an [application programming interface (API)](service-manual_making-software_apis.html.md) used for interfacing between pieces of software, you’re likely to be using multiple technical standards.

In these cases, you must make sure that as many standards as possible meet open standards principles.

Getting an exemption
--------------------

In exceptional circumstances the Open Standards Board may give you permission to use a standard that:

* does not meet the open standards principles and has an open alternative
* performs the same function as one of the government’s approved open standards

To ask for an exemption, you need to explain why you want to use a different standard when you [apply for spend control approval](service-manual_agile-delivery_spend-controls-check-if-you-need-approval-to-spend-money-on-a-service.md).

In your spend controls application you should include:

* a description of how you selected your proposed standard
* an analysis of your proposed standard against [the Cabinet Office definition of an open standard](/government/publications/open-standards-principles/open-standards-principles#open-standard-definition)

You can use the Standards Hub’s [core assessment questions for proposed standards](https://www.gov.uk/guidance/how-an-open-standards-proposal-is-assessed) to help you decide what information to include.

The Open Standards Board will decide whether you can use your proposed standard.

If your service does not need [spend controls approval](service-manual_agile-delivery_spend-controls-check-if-you-need-approval-to-spend-money-on-a-service.md), ask your organisation’s accounting officer for an exemption to use a standard that does not meet normal rules.

### If you get an exemption

If you get an exemption, the open standards team will publish this information on the [Standards Hub](https://www.gov.uk/government/collections/open-standards-for-government-data-and-technology) as long as it does not pose a threat to national security.

You can also contact the open standards team at CDDO for advice. Email [openstandards@digital.cabinet-office.gov.uk](mailto:%20openstandards@digital.cabinet-office.gov.uk).

Updates to this page
--------------------

Published 15 September 2016

Last updated 17 October 2024
[+ show all updates](#full-history)

1. 17 October 2024

   Integrated guidance on Managing third-party product security risks.
2. 15 September 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---