Securing your cloud environment for services - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Securing your cloud environment for services
============================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (technical architecture)](service-manual_communities_technology-community-technical-architecture.md)

Contents
--------

1. [Deciding whether to use the cloud](#deciding-whether-to-use-the-cloud)
2. [Finding a secure cloud provider](#finding-a-secure-cloud-provider)
3. [Configure your cloud environment for security](#configure-your-cloud-environment-for-security)
4. [Auditing the cloud environment](#auditing-the-cloud-environment)
5. [Related guides](#related-guides)

You must follow the government’s [Cloud First policy](https://www.gov.uk/guidance/government-cloud-first-policy) when considering cloud purchases.

You can only choose an alternative to the cloud if you can show it’s better value for money in your service assessments or departmental spending assurance process.

Deciding whether to use the cloud
---------------------------------

It’s government policy to use the public cloud first for almost all information classed as official and some sensitive data.

Follow the [Creating and implementing a cloud hosting strategy](https://www.gov.uk/guidance/creating-and-implementing-a-cloud-hosting-strategy) and the [National Cyber Security Centre (NCSC) cloud security guidance](https://www.ncsc.gov.uk/collection/cloud-security) to decide if cloud security meets your needs.

To better analyse your service’s security risks, make sure you understand:

* your business requirements
* the information you want to store and where you want to store it
* if the cloud provider can give you enough assurance of their security measures
* what user and administrator security your organisations uses
* how you will monitor your security processes to make sure they are working

You must still do a risk analysis and mitigation exercise if you choose to use the public cloud.

Learn about government [Secure by Design principles](https://www.security.gov.uk/policy-and-guidance/secure-by-design/principles/) and [managing third-party product security risks](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-third-party-product-security-risks/).

Finding a secure cloud provider
-------------------------------

Use the government’s [Cloud Security Principles](https://www.ncsc.gov.uk/collection/cloud-security?curPage=/collection/cloud-security/implementing-the-cloud-security-principles) to help you evaluate cloud providers.

You will need to identify which of the principles your service needs and find a supplier who meets those needs. If your chosen cloud provider can not meet a principle, check if your team can meet it instead.

You should also choose your provider from a trusted place such as the [Digital Marketplace](https://www.digitalmarketplace.service.gov.uk/buyers/direct-award/g-cloud/start) or the [Crown Commercial Service](https://www.crowncommercial.gov.uk/products-and-services/technology).

As you identify your needs, you might find you have to balance several factors along with security. For example, balancing the risk of [technical lock-in](https://www.gov.uk/guidance/managing-technical-lock-in-in-the-cloud) and contract flexibility with the provider can mean that you need to do less security work to get the service up and running as they have done it for you.

Configure your cloud environment for security
---------------------------------------------

As well as checking that your provider’s security meets your requirements, you will need to make sure that your environment is configured properly.

Check things such as:

* access control
* asset encryption
* locking down external access
* how you keep data such as secret keys or credentials closed
* security logging, monitoring, and alerting procedures (also known as [managing observability](https://beta-dev.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-observability/))

Auditing the cloud environment
------------------------------

Do regular audits of your cloud environment so you can:

* get real-time data about what’s happening in your environment
* create automated alerts or actions if there is unusual or suspicious behaviour
* keep track of your provider’s cloud environment and the access your users and administrators have to your data
* keep track of your use of the cloud, such as any changes your administrators make or who has access to data
* highlight and prioritise actions so that your operations or security team can respond more quickly to the most serious alerts
* see who has copied or shared documents or what administrators have done

Cloud tools do not always provide all of this functionality, but you should make sure you have a way to monitor your environment. You should decide which features you need and which you can implement yourself.

Related guides
--------------

You may also find these guides useful:

* [Securing your information](service-manual_technology_securing-your-information.md)
* [Working with cookies and similar technologies](service-manual_technology_working-with-cookies-and-similar-technologies.md)
* [Cloud guide for the public sector](/government/publications/cloud-guide-for-the-public-sector/cloud-guide-for-the-public-sector)

Updates to this page
--------------------

Published 21 October 2016

Last updated 17 October 2024
[+ show all updates](#full-history)

1. 17 October 2024

   Integrated guidance on Assessing the importance of service assets, Performing threat modelling, Performing a security risk assessment, Agreeing a security controls set for your service, Responding to and mitigating security risks and Retiring service components securely.
2. 15 February 2021

   Page updated and reworded for clarity.
3. 21 October 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---