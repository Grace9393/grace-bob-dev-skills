Technology community (web operations) - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Technology community (web operations)
=====================================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Join the community](#join-the-community)
3. [Resources](#resources)
4. [Web ops in the Service Manual](#web-ops-in-the-service-manual)

The cross-government web operations (web ops) community exists to:

* share information about web ops for government services
* discuss and challenge how web ops work for government services
* bring together people from across government with an interest in web ops

Who the community is for
------------------------

You might be interested in this community if you’re involved in any aspect of web ops, for example:

* setting up hosting for a service
* setting up deployment environments
* managing software configuration
* monitoring the uptime and availability of a live service

You do not need to be in a web ops role to join.

Join the community
------------------

Join the #web-operations channel on the [cross-government Slack](https://ukgovernmentdigital.slack.com/messages/announcements/) to discuss cross-government web ops issues (request access using your government email address).

If you cannot access the channel, email [webops-community-admin@digital.cabinet-office.gov.uk](mailto:%20webops-community-admin@digital.cabinet-office.gov.uk) for help.

Resources
---------

The [technology in government blog](https://technology.blog.gov.uk/) documents how technologists across government are building, assembling and running digital and technology projects.

Web ops in the Service Manual
-----------------------------

These guides show what we currently believe to be best practice in web ops for government services:

* [Deploying software regularly](service-manual_technology_deploying-software-regularly.md)
* [Working in pre-production environments](service-manual_technology_working-in-pre-production-environments.md)
* [Manage your software configuration](service-manual_technology_manage-your-software-configuration.md)
* [Uptime and availability: keeping your service online](service-manual_technology_uptime-and-availability-keeping-your-service-online.md)
* [Monitoring the status of your service](service-manual_technology_monitoring-the-status-of-your-service.md)
* [Deciding how to host your service](service-manual_technology_deciding-how-to-host-your-service.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Updates to this page
--------------------

Published 23 May 2016

Last updated 10 August 2016
[+ show all updates](#full-history)

1. 5 August 2016

   Added guides to 'Deploying software regularly' and 'Deciding how to host your service'.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---