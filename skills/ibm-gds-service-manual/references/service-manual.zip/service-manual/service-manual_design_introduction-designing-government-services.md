Designing good government services: an introduction - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Designing good government services: an introduction
===================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [The characteristics of a good government service](#the-characteristics-of-a-good-government-service)
2. [A user can do what they need to do, from start to finish](#a-user-can-do-what-they-need-to-do-from-start-to-finish)
3. [A user has to do as few things as possible](#a-user-has-to-do-as-few-things-as-possible)
4. [There are no dead ends](#there-are-no-dead-ends)
5. [It's straightforward to get human help](#its-straightforward-to-get-human-help)
6. [Internal structures are not shown to users](#internal-structures-are-not-shown-to-users)
7. [The service is easy to find](#the-service-is-easy-to-find)
8. [What the service is for and what it involves is clear](#what-the-service-is-for-and-what-it-involves-is-clear)
9. [How decisions are made is clear](#how-decisions-are-made-is-clear)
10. [The service is consistent](#the-service-is-consistent)
11. [The service works in a familiar way](#the-service-works-in-a-familiar-way)
12. [Everyone can use and understand the service](#everyone-can-use-and-understand-the-service)
13. [Users and their information are treated with care and respect](#users-and-their-information-are-treated-with-care-and-respect)

To a user, a service is simple. It’s something that helps them to do something, like learn to drive, start a business or become a childminder. To design good services you will need to:

* conduct [user research](https://www.gov.uk/service-manual/user-research)
* work with [data](http://gov.uk/service-manual/design/designing-with-data-an-introduction)
* use the right [technology](https://www.gov.uk/service-manual/technology)
* work with a [multidisciplinary team](https://www.gov.uk/service-manual/the-team)
* be [agile](https://www.gov.uk/service-manual/agile-delivery)
* be able to [measure success](https://www.gov.uk/service-manual/measuring-success)
* follow [Secure by Design principles](https://www.security.gov.uk/policy-and-guidance/secure-by-design/principles/)

The characteristics of a good government service
------------------------------------------------

Government services differ in size, scope and who their users are. But there are certain characteristics that all good services share.

[Good services reflect what a user wants to do](https://gds.blog.gov.uk/2016/04/18/what-we-mean-by-service-design/) and do not need them to have a working knowledge of the inside of government.

Before you can build a new service or improve an existing one, you need to understand how it works. This means thinking about your service:

* from beginning to end: think about every single thing a user needs to do, including anything done by a supplier external to government
* from front to back: this means both the service that users see and the internal processes, software, data and policies behind it
* across every channel: phone, post and face to face as well as digital

A user can do what they need to do, from start to finish
--------------------------------------------------------

A good service enables a user to [complete the thing they set out to do](https://www.gov.uk/service-manual/design/map-a-users-whole-problem) as seamlessly as possible.

It considers everything from the moment a user is considering doing a task to the moment they have completed it. And it accommodates any further steps a user could need to take – or support they might need afterwards.

A user has to do as few things as possible
------------------------------------------

Good services get a user to take the smallest number of steps possible to reach their goal.

Reducing how much data a user has to give reduces how much they have to do. For example, using a postcode lookup to help find an address, rather than asking the user to enter the address manually. Or asking users to review information they provided previously, rather than having them enter it again. This improves accuracy by reducing opportunities for mistakes.

Where there is a risk a user will fail if they act too quickly, a good service slows them down. Like showing a warning screen before people make significant changes to their personal data.

There are no dead ends
----------------------

Every user needs to be led to a clear outcome, even if they are not eligible for the service itself.

If somebody’s needs are outside the [scope of your service](https://www.gov.uk/service-manual/design/scoping-your-service), the service should clearly direct them to what to do next.

No user should be left stranded within a service without knowing how to continue.

It’s straightforward to get human help
--------------------------------------

If people get stuck when they are doing something by themselves, a good service gives them an easy way to communicate with a human being. This might be over phone or email, face to face or online.

Ideally, your service will cater for most users’ needs and people will not need to make unplanned contact.

But there will always be exceptions. Like a technical problem nobody could have predicted, or a user who is unable to provide a particular piece of evidence and so cannot carry on using a service without help.

Internal structures are not shown to users
------------------------------------------

A good service does not [unnecessarily expose a user to internal structures](https://www.gov.uk/service-manual/design/scoping-your-service#dont-let-organisation-structures-or-technical-choices-dictate-service-shape) behind it. Even if the service has to [work across organisational boundaries](https://www.gov.uk/service-manual/agile-delivery/working-across-organisational-boundaries).

For example, if a user needs to access saved information that’s stored in 2 different back-end systems, they do not need or want to know this. What they need is one quick way of accessing their information.

The service is easy to find
---------------------------

A service needs to be easy to find in the first place, because most people will not know exactly how to reach their goal.

For example, someone who searches ‘learn to drive’ needs to be able to find their way to [getting a driving licence](https://www.gov.uk/apply-first-provisional-driving-licence) easily.

So it’s important to [choose a good name for your service](https://www.gov.uk/service-manual/design/naming-your-service).

What the service is for and what it involves is clear
-----------------------------------------------------

The purpose of a good service is clear to a user before they start using it. People understand what it will do for them and [if they are eligible to use it in the first place](https://www.gov.uk/service-manual/design/govuk-content-transactions#what-to-tell-users-upfront).

A useful exercise is to [ask users questions that help them check a service is suitable](https://design-system.service.gov.uk/patterns/check-a-service-is-suitable/).

Be clear about what is needed from a user when they use the service and what they can expect from the service in return. This includes things like:

* how long something will take to complete
* how much it will cost
* when the user can expect a reply or decision

A user should be really clear about what they need to do to get started.

How decisions are made is clear
-------------------------------

When a user receives a decision, a good service makes sure it’s obvious how this decision was made. People must have a way of challenging a decision if they need to.

An algorithm is a sequence of instructions that a computer uses to solve a problem or make a suggestion. If your service uses algorithmic tools, make it clear to users how they are being used. The [Algorithmic Transparency Standard](https://www.gov.uk/government/collections/algorithmic-transparency-standard) helps you outline and publish this information. You may need to give users the option to override an algorithm.

Only use algorithms you know work properly and test them regularly once in use.

This will help build users’ trust and confidence in the service.

The service is consistent
-------------------------

You should make a service look and feel like one service to users. Even if [different organisations are involved](https://www.gov.uk/service-manual/agile-delivery/working-across-organisational-boundaries) or users get information in more than one way, for example an online form followed up with a letter.

How you collect, store and display data should also be consistent. This helps users understand and use the information, and know what is expected of them.

Consistent use of visual styles, data formats and structure, [interaction patterns](https://www.gov.uk/service-manual/design/using-adapting-and-creating-patterns) and the [language in your service](https://www.gov.uk/service-manual/design/writing-for-user-interfaces) are important.

When a user updates their details, they expect to see this change in all parts of a service straightaway. For example, if somebody enters or changes their name or phone number online, they’d expect the service to have a record of this if they phoned up.

The service works in a familiar way
-----------------------------------

People expect services to work in a certain way based on what they have seen or used before.

A good service uses [familiar design conventions](https://www.gov.uk/service-manual/design/using-adapting-and-creating-patterns) to help people use it easily. For example, users who have signed up to a new service often expect an email confirming this.

It takes into consideration changing behaviour or emerging patterns too, like email addresses replacing usernames as the usual way of signing into a service online.

Everyone can use and understand the service
-------------------------------------------

People have different needs at different times and in different circumstances. [A good service is inclusive](https://www.gov.uk/service-manual/design/making-your-service-more-inclusive) so that everyone who needs to can use it as easily as possible.

It [uses the same language](https://www.gov.uk/service-manual/design/writing-for-user-interfaces) as its users to make things easy for anyone to read and understand.

It looks out for places where users might be excluded, like insisting people have to make contact in one particular way or accepting only specific documents as evidence.

Presenting and collecting data in ways that are accessible to everyone helps make sure people can use your service in the way that works for them.

Users and their information are treated with care and respect
-------------------------------------------------------------

A good service does not treat users with unnecessary suspicion or scrutiny, like running identity checks that are not really needed. People working on the service handle users with care.

Part of the government’s Secure by Design approach is to [design usable security controls that reflect business and user needs](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/understanding-business-objectives-and-user-needs/). A good service will minimise friction for users by making sure security processes are fit for purpose and easy to understand.

The service does not put people at risk or do things that are not in users’ best interests. For example, it minimises the [personal data that’s collected from users](https://www.gov.uk/service-manual/design/collecting-personal-information-from-users).

Updates to this page
--------------------

Published 7 November 2016

Last updated 22 October 2024
[+ show all updates](#full-history)

1. 22 October 2024

   Integrated guidance on Understanding business objectives and user needs, Understanding cyber security obligations, and Sourcing a threat assessment.
2. 6 April 2022

   Added extra information and signposting about the role of data.
3. 5 November 2018

   Updated with an explanation of what a good service looks like, following detailed consultation with the service design community.
4. 3 October 2017

   Added information on operating services in line with departmental Welsh language scheme requirements
   (previously in the guide 'Making your service accessible: an introduction').
5. 7 November 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---