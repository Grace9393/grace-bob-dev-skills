13. Use and contribute to open standards, common components and patterns - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Service Standard](service-manual_service-standard.md)

Service Standard

13. Use and contribute to open standards, common components and patterns
========================================================================

Build on open standards and common components and patterns from inside and outside government.

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Why it's important](#why-its-important)
2. [What it means](#what-it-means)
3. [Related guidance](#related-guidance)
4. [Service standard points](#service-standard-points)

If you develop your own patterns or components, share them publicly so others can use them.

Why it’s important
------------------

Using common components and patterns means you do not have to solve problems that have already been solved. By using a component or pattern that’s already been extensively tested, you can provide users with a good experience in a cost effective way. If you develop your own components or patterns, share them so that others can benefit from your work.

Open standards help services to work consistently - so you’ll spend less time trying to make systems “talk” to each other. And they help you to avoid getting locked into a particular supplier or technology - so when things change, you can change your approach.

What it means
-------------

Service teams should:

* use open standards, and propose a new open standard if there is not one that already meets their needs
* use standard government technology components where possible
* maximise flexibility in their use of technology, for example by using and creating application programming interfaces (APIs) and, where possible, authoritative sources of data
* use common components and patterns, and share details of any new components or patterns they create or adapt (for example, by contributing to the GOV.UK Design System)

When services create data that’s potentially useful to others inside or outside government, they should publish them in an open, machine readable format, under an Open Government Licence (unless they have permission from the National Archives to use a different type of licence). This does not apply to data that contains personally identifiable information, information that’s sensitive (for example because it could affect national security), or where publishing the data would infringe the intellectual property rights of someone outside government.

Related guidance
----------------

[Working with open standards](https://www.gov.uk/service-manual/technology/working-with-open-standards)

[Standard government technology components](https://www.gov.uk/service-toolkit#gov-uk-services)

[APIs](https://www.gov.uk/service-manual/technology/application-programming-interfaces-apis)

[GOV.UK Design System](https://design-system.service.gov.uk/)

Service standard points
-----------------------

[1. Understand users and their needs](https://www.gov.uk/service-manual/service-standard/point-1-understand-user-needs)

[2. Solve a whole problem for users](https://www.gov.uk/service-manual/service-standard/point-2-solve-a-whole-problem)

[3. Provide a joined up experience across all channels](https://www.gov.uk/service-manual/service-standard/point-3-join-up-across-channels)

[4. Make the service simple to use](https://www.gov.uk/service-manual/service-standard/point-4-make-the-service-simple-to-use)

[5. Make sure everyone can use the service](https://www.gov.uk/service-manual/service-standard/point-5-make-sure-everyone-can-use-the-service)

[6. Have a multidisciplinary team](https://www.gov.uk/service-manual/service-standard/point-6-have-a-multidisciplinary-team)

[7. Use agile ways of working](https://www.gov.uk/service-manual/service-standard/point-7-use-agile-ways-of-working)

[8. Iterate and improve frequently](https://www.gov.uk/service-manual/service-standard/point-8-iterate-and-improve-frequently)

[9. Create a secure service which protects users’ privacy](https://www.gov.uk/service-manual/service-standard/point-9-create-a-secure-service)

[10. Define what success looks like and publish performance data](https://www.gov.uk/service-manual/service-standard/point-10-define-success-publish-performance-data)

[11. Choose the right tools and technology](https://www.gov.uk/service-manual/service-standard/point-11-choose-the-right-tools-and-technology)

[12. Make new source code open](https://www.gov.uk/service-manual/service-standard/point-12-make-new-source-code-open)

[13. Use and contribute to open standards, common components and patterns](https://www.gov.uk/service-manual/service-standard/point-13-use-common-standards-components-patterns)

[14. Operate a reliable service](https://www.gov.uk/service-manual/service-standard/point-14-operate-a-reliable-service)

Updates to this page
--------------------

Published 8 May 2019

Last updated 30 May 2022
[+ show all updates](#full-history)

1. 30 May 2022

   Added links to related guidance and other standard points. There is no change to the content of the standard point itself.
2. 23 February 2021

   Removed reference and link to GOV.UK Registers as it is closing on on 16 March 2021.
3. 14 June 2019

   Updated this point of the Service Standard to: (1) clarify the position on open standards; and (2) provide a better explanation of the benefits of open standards.
4. 8 May 2019

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---