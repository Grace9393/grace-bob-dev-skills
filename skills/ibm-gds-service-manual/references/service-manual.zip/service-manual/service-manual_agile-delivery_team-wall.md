Set up a team wall - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Set up a team wall
==================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [How team walls work](#how-team-walls-work)
2. [What to put on your team wall](#what-to-put-on-your-team-wall)
3. [How team walls help](#how-team-walls-help)
4. [Related guides](#related-guides)

To help your service team to work in an agile way, you may want to set up a team wall.

In agile working, team walls are a section of wall near where your team sits on which you keep a visual record of the work you’re doing.

How team walls work
-------------------

You record individual pieces of work on a card or piece of paper and stick them to the wall.

You stick other cards on the wall which represent stages of production, you can then move the pieces of work along the wall as they pass through the production stages.

What to put on your team wall
-----------------------------

Most teams fill the wall with paper or post-it notes and various headings, to show everything the team is working on, the stage of production it’s at, and any work that’s upcoming.

Your wall will differ depending on the service you’re building, but most teams include details of:

* work the team is currently doing
* work the team has not started yet
* work that’s done

You should also use the wall to track:

* progress against your goals and key performance indicators (KPIs) – for live data, you could show this on an electronic dashboard
* any risks and issues you’ve found
* major obstacles to delivery, things which are stopping you getting work done (these are sometimes called ‘blockers’)
* important deadlines and dependencies

You can also display information about your service and your team, for example:

* your service vision
* photos or profiles of the people who are on your team
* your working arrangements, eg when you have retrospectives or other meetings

How team walls help
-------------------

Team walls help you to:

* map out problems you’re exploring
* manage work you’ve agreed to do
* share a lot of information quickly and publicly
* put all your work together and see how it’s progressing
* start conversations in your team or with others in your office, eg about your processes or points where work gets blocked
* encourage communication and collaboration in your team, and with the rest of the organisation

An up-to-date wall also allows you to:

* have a physical focal point for the team to look at and comment on during standups and other meetings
* promote transparency and discussion by showing everyone in your organisation the status of your work
* make decisions based on an overview of your work
* manage and measure workflow and spot problems that are delaying you

Example:

A team mapped out the current processes for importing and exporting goods across the UK border, which are currently handled by 26 different government departments and agencies.

[Read about what they learned from mapping the processes in their discovery](https://gds.blog.gov.uk/2015/08/07/mapping-the-border-as-users-see-it/).

### Online tools

As well as your team wall, you may want to record the work your team is doing online, for example using a tool like [Trello](http://www.trello.com).

If you do this you should always post information about current and future work to your wall.

If possible you can display your online tool on a screen in your work area so it is still visible to everyone.

Related guides
--------------

You may also find these guides useful:

* [Creating an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md)
* [Agile tools and techniques](service-manual_agile-delivery_agile-tools-techniques.md)

Updates to this page
--------------------

Published 16 February 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---