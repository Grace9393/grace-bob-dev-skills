Deciding how to host your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Deciding how to host your service
=================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)

Contents
--------

1. [Consider public cloud hosting first](#consider-public-cloud-hosting-first)
2. [Planning your hosting strategy](#planning-your-hosting-strategy)
3. [Choosing a hosting option](#choosing-a-hosting-option)
4. [Crown hosting](#crown-hosting)
5. [Choosing a supplier](#choosing-a-supplier)
6. [Moving to a new supplier](#moving-to-a-new-supplier)
7. [Getting advice](#getting-advice)

You must decide how much control and flexibility you want in hosting your service and then choose a supplier who meets your needs.

This guidance is about hosting for systems and information classified as ‘official’, which covers the vast majority of what government does.

If you’re building a service that involves information classified as ‘secret’ or above, ask your departmental security officer for guidance.

Consider public cloud hosting first
-----------------------------------

You must consider and fully evaluate public cloud solutions before considering other options in line with the government’s [Cloud First policy](/government/news/government-adopts-cloud-first-policy-for-public-sector-it).

The Government Digital Service (GDS) will review your choice when assessing your spend controls application, if your service needs to get spend controls approval.

[Check if your service needs to get spend controls approval](service-manual_agile-delivery_spend-controls-check-if-you-need-approval-to-spend-money-on-a-service.md).

### If you believe you cannot use cloud hosting

If you believe you cannot use cloud hosting, you should email the Assurance team at GDS as soon as possible at [gdsassurance@digital.cabinet-office.gov.uk](mailto:gdsassurance@digital.cabinet-office.gov.uk).

You’ll have to explain why you cannot use cloud hosting and how your alternative will provide value for money. You should consider the operational costs for the expected lifetime of your service and the value of flexibility.

Planning your hosting strategy
------------------------------

You should think about hosting as early as possible when designing the architecture of your service. You may need to design your service in a different way based on the hosting options you choose.

### Set up a team

Start by choosing some people from your team to:

* assess different hosting options
* make a shortlist of suppliers
* interview suppliers about their services
* make a final decision on which supplier to use

You must make sure the people you choose:

* have a technical understanding of hosting and your software
* know the hosting options that are available
* know the range of prices you can afford

Choosing a hosting option
-------------------------

Hosting can be a significant investment for your organisation. Use the [choosing technology guide](service-manual_technology_choosing-technology-an-introduction.md) to help you choose a hosting option. You should choose an option that allows you to adapt your hosting if you want to.

You should consider these options:

* Software as a Service (SaaS)
* Platform as a Service (PaaS)
* Infrastructure as a Service (IaaS)

### Software as a Service

As you develop your understanding of the components of your service, you should consider where SaaS can provide some of the functionality.

If you have SaaS components, you will not need to consider hosting directly, but you should evaluate those components using the [Cloud Security Principles](https://www.ncsc.gov.uk/guidance/cloud-security-collection).

Make sure that you have the connectivity to the component and make backups so that you keep control of your data.

### Platform as a Service

PaaS allows you to rent storage space but also offers a layer on top, which might include:

* operating systems
* databases
* logging infrastructure or other features

Most PaaS suppliers will expect your architecture to meet their specific requirements. For example, they offer limited flexibility for software environments, languages or interfaces, so check the details before you sign an agreement.

### Infrastructure as a Service

IaaS is a system where you can quickly add or remove capacity and the supplier only bills you for what you use.

You’ll need someone in your team with the technical infrastructure skills and time to manage it.

If you’re unsure whether your team could handle IaaS hosting, consider PaaS instead - it’ll allow your team to focus time and effort on the tasks best suited to their skills.

Crown hosting
-------------

If you cannot use a cloud provider, for example because of contractual or complex technical restraints, consider using [Crown Hosting](http://crownhostingdc.co.uk/).

You must migrate to public cloud as soon as possible if you use Crown hosting.

You must never build your own data centre.

If you believe you have a legitimate need to build your own data centre, you should contact GDS to seek advice from the Government Chief Technology Officer (GCTO).

Choosing a supplier
-------------------

When looking for a supplier, you should try to find options that offer value for money and avoid long contracts with a single company.

### Use the Digital Marketplace

You should use the Digital Marketplace to search for and evaluate suppliers and award them contracts.

[Find out how to use the Digital Marketplace](/guidance/digital-marketplace-buyers-guide).

[Search for hosting providers on the Digital Marketplace](https://www.digitalmarketplace.service.gov.uk).

Contact the Digital Marketplace team if you have any questions - email [cloud\_digital@crowncommercial.gov.uk](mailto:cloud_digital@crowncommercial.gov.uk).

### If you cannot find a supplier on the Digital Marketplace

If you cannot find a suitable supplier for your service on the Digital Marketplace, you can use other routes. [Contact Crown Commercial Service](http://ccs-forms.cabinetoffice.gov.uk/contact-us) if you have any questions about procurement.

When you apply for spend controls approval, you’ll have to explain your choice of hosting supplier. You need to show you’ve looked on the Digital Marketplace before deciding to use another route.

### Evaluating a supplier

As well as making sure a supplier offers the type of hosting you need for your service, you should also consider:

* what you’ll need the hosting service to do in the future
* the level of user support the supplier provides, like Service Level Agreements (SLAs)
* reliance and back-up measures, known as ‘redundancy’
* government information security requirements, including the [Cloud Security Principles](/government/publications/cloud-service-security-principles/cloud-service-security-principles)
* whether you need [Public Services compliance](/guidance/public-services-network-psn-compliance)

### Choosing a way to pay

Different suppliers also allow you to pay in different ways.

As well as the overall cost of the hosting service itself, find out if the supplier offers flexible or on-demand billing.

This can save you money if you do not need hosting resources 24 hours a day.

Moving to a new supplier
------------------------

If you’re moving from one supplier to another, you should consider the full cost of the migration.

Be wary of choosing supplier-specific tools or features that could make switching suppliers difficult.

Getting advice
--------------

If you do not think you or your team has the knowledge to choose a hosting supplier, talk to a third party that you trust, for example a technical architect in another government department.

You can find technical architects by [joining the technical architecture community](service-manual_communities_technology-community-technical-architecture#join-the-community.md).

Updates to this page
--------------------

Published 26 August 2016

Last updated 21 July 2022
[+ show all updates](#full-history)

1. 21 July 2022

   Removed references to GOV.UK PaaS because it is being decommissioned and is no longer taking on new tenants.
2. 25 March 2021

   Updated to reflect that GOV.UK PaaS passed its live assessment and is no longer in beta.
3. 28 February 2019

   Updated to reflect the fact that GOV.UK PaaS is no longer in private beta
4. 26 August 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---