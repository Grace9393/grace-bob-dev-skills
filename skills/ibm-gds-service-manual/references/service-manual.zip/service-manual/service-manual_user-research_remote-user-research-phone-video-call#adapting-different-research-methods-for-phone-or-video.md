Doing user research remotely by phone or video call - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Doing user research remotely by phone or video call
===================================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [When to do research remotely](#when-to-do-research-remotely)
2. [Steps to follow](#steps-to-follow)
3. [Adapting different research methods for phone or video](#adapting-different-research-methods-for-phone-or-video)

You can run user research sessions remotely using telephone or video calls.

Most face to face research methods can be adapted to work remotely.

During the coronavirus (COVID-19) pandemic, if you’re thinking about doing some face to research there are steps you must follow to help you [choose between face to face and remote research](service-manual_user-research_doing-user-research-during-coronavirus-covid-19-choosing-face-to-face-or-remote-research.md).

When to do research remotely
----------------------------

Remote research is helpful when you want to:

* reach participants who are spread over long distances
* reach participants who cannot or do not want to meet you in person
* make research sessions more accessible for more observers
* cut down on travel time and cost

However, be aware that:

* you can miss out on significant contextual and non-verbal information
* security and privacy worries can make participants reluctant to share their screen
* technical problems on conference and video calls can frustrate both participants and researchers

A good example of remote research is when the Home Office [researched users living overseas](https://gds.blog.gov.uk/2013/10/09/testing-with-users-around-the-world/) for a visa service. You can also read about [what the NHS App team learned when they switched to remote research](https://digital.nhs.uk/blog/design-matters/2020/nhs-app-conducting-user-research-in-lockdown) and the unexpected benefits they found.

### Remote research and inclusion

Doing research remotely can help to include some participants - for example those who are less mobile or who have social anxiety. But it can also exclude others - for example those who are deaf or have a speech impairment.

Always use a variety of approaches to make sure that your research is inclusive.

Steps to follow
---------------

### Plan the research

Remote sessions can take from 30 to 90 minutes, depending on the methods you’re using and the amount you want to cover. If you’re scheduling many in a day, leave at least 15 minutes between each session to do any preparation for the next session.

Before planning any sessions, work with your team to agree which of your research questions and user groups you want to focus on. You can then decide which research methods to use - for example [in-depth interviews](https://www.gov.uk/service-manual/user-research/using-in-depth-interviews), [moderated usability testing](https://www.gov.uk/service-manual/user-research/using-moderated-usability-testing), [experience mapping](https://www.gov.uk/service-manual/user-research/researching-user-experiences), card sorting or tree testing.

You’ll need to [adapt the methods you’ve chosen for remote research](service-manual_user-research_remote-user-research-phone-video-call#adapting-different-research-methods-for-phone-or-video.md) so that they work effectively over phone or video calls.

When choosing the technology for the calls:

* make sure it’s accessible to disabled participants and any assistive technology they may be using
* if you can, have several technologies available and let the participant choose the one that will work best for them
* decide whether and how you want to [record the calls](https://www.gov.uk/service-manual/user-research/taking-notes-and-recording-user-research-sessions#audio-recordings)

You should book a quiet place with the right equipment to do the sessions. Make sure you have:

* a good internet or phone connection
* a speakerphone or headset so your hands are free
* a comfortable position for sitting and note taking
* if you’re testing a prototype or service, check if any firewall or other technical issues will affect your participants’ ability to see what you’re testing

To involve your team:

* run a pilot session with colleagues as participants and observers
* [arrange a note-taker for each session](https://www.gov.uk/service-manual/user-research/plan-round-of-user-research#arrange-recording-and-note-taking)
* invite other team members to listen or observe
* include the room, call and joining instructions in any calendar invite

Once you know how you’ll run the sessions, you can [recruit research participants](https://www.gov.uk/service-manual/user-research/find-user-research-participants) from the appropriate user groups.

To help participants prepare:

* send them any [consent information](https://www.gov.uk/service-manual/user-research/getting-users-consent-for-research) before the session and ask that they confirm they’ve read it and are willing to take part in the session
* suggest that the participant finds a quiet space with few distractions
* if you’re doing a conference or video call, ask them to try out the technology beforehand

### Do the research

Before the first session of each research day:

* send reminders to participants and team members
* set up the space you’ll use for the sessions
* test all the technology you’ll be using

At the start of each session:

* read out your introduction script - this tells participants who you are, explains the research and reminds them about things like recording
* give the participant the chance to ask any questions about the session
* tell the participant about any other people observing the research
* [confirm that you have the participant’s consent](https://www.gov.uk/service-manual/user-research/getting-users-consent-for-research) - do this at the start of the recording if you’re making one
* open a webchat channel or email loop for your observers to ask questions

When running a remote research session:

* give more time to build rapport
* give the participant more verbal reassurance that you’re still there and actively listening - they may not be able to see you nodding and smiling
* check in with the participant regularly to see how they’re doing - give them a chance to pause, take a breath, take a drink
* leave plenty of time for the debrief at the end of the call - this is particularly important if the research is emotionally sensitive

At the end of the session, make sure you stop and secure any recording.

### Use the results

After the calls, [analyse the research](https://www.gov.uk/service-manual/user-research/analyse-a-research-session) with your team to generate findings they can use. Quotes, screenshots, sound and video clips from remote and telephone research make particularly compelling illustrations for your findings.

Adapting different research methods for phone or video
------------------------------------------------------

### In-depth interviews

You can do [interviews](https://www.gov.uk/service-manual/user-research/using-in-depth-interviews) remotely using a phone or video call.

If you do not plan to record the interview, you can do an interview remotely using either:

* a regular phone call with a headset - so your hands are free to take notes
* a speakerphone in a meeting room - so colleagues can listen in, take notes and ask follow up questions
* a conference call or video call service - so colleagues can also join remotely

To record a remote interview, you can use either:

* a conference call or video call service that supports call recording
* a video call service, and record the video and sound on your computer with an app like QuickTime

### Moderated usability tests

You can run [usability testing](https://www.gov.uk/service-manual/user-research/using-moderated-usability-testing) remotely using a video call.

To run the test you can use a video call service that either:

* gives the participant control of an application on your screen
* allows you to see the participant’s screen

To record the test, you can either:

* use a video call service that supports call recording
* record the video and sound on your computer with an app like QuickTime

At the start of the test:

* make sure the participant can see and control your screen or you can see theirs
* set up or help them navigate to the prototype or service

During the test, as well as asking the participant to think out loud, ask them to describe anything they’re doing that you might not be able to see.

### Experience mapping

If you cannot run the session face to face, it is possible to run an [experience mapping](https://www.gov.uk/service-manual/user-research/researching-user-experiences) session remotely.

To run the session remotely, you can use:

* a card-based collaboration tool like Trello, Airtable or Mural to sketch out the participant’s experience
* a regular phone call, conference call or video call to talk the participant through the session

If you use a collaboration tool, the sketched experience will remain at the end of the session.

### Observing screen based activity

If the activity you want to observe is screen-based, you can do some contextual observation remotely using a video call.

Use a video call service that allows you to see the participant’s screen.

To record what you see, you can either:

* use a video call service that supports call recording
* record the video and sound on your computer with an app like QuickTime

During the observation, ask the participant to describe anything they’re doing that you cannot see on their screen.

### Card sorts and tree tests

You can do card sorts and tree tests remotely.

For card sorting, you can use:

* a specialist card sorting tool like Optimal Sort combined with a video call to view the participant’s screen
* a card-based collaboration tool like Trello, Airtable or Mural combined with a phone call

For tree testing, you can:

* click through your own copy of the test to mirror and ‘see’ what the participant is doing
* use a phone, conference call or video call to talk the participant through the session and have them think aloud during the test

When you do card sorting and tree testing, as well as asking the participant to think out loud, ask them to describe anything they’re doing that you might not be able to see.

Updates to this page
--------------------

Published 31 January 2018

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---