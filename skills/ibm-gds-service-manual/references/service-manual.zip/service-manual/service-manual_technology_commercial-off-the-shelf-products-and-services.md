Using commercial-off-the-shelf (COTS) products and services - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Using commercial-off-the-shelf (COTS) products and services
===========================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Buying digital community](service-manual_communities_digital-buying-community.md)

Sometimes you may decide that it is more cost effective to procure products and services from a commercial supplier. These commercial-off-the-shelf (COTS) products and services are part of [the service as a whole](https://www.gov.uk/service-manual/service-assessments/what-a-service-is) and must meet the [Service Standard](https://www.gov.uk/service-manual/service-standard).

### When to buy commercial-off-the-shelf products and services

You must not commit to using a technology before you go through a discovery phase to determine the problem you’re trying to solve, and have tried out different options during alpha. This ensures that you are spending public money responsibly and using the best tool for the job.

You should only use COTS products when no suitable alternative is available, including existing products and services from other services.

[Read more about alpha](https://www.gov.uk/service-manual/agile-delivery/how-the-alpha-phase-works)

### Accessibility

All COTS products must meet the same requirements as internally-built products, including when it comes to accessibility.

Remember that both public-facing and staff-facing systems must meet accessibility requirements.

Your accessibility assurance must be specific to the service you are creating.

[Read more about accessibility](https://www.gov.uk/service-manual/helping-people-to-use-your-service)

### Sustainability

When asking suppliers to calculate environmental impact, you should consider:

* the running costs of the product or service they are supplying
* the environmental impact of its initial development

[Read more about environmentally sustainable services](https://www.gov.uk/service-manual/design/environmentally-sustainable-services)

### User-centred design

Your service consists of more than the COTS products and services. You must involve designers who understand the broader context of your service and can map the end-to-end service journey. For example, designers will be able to factor in service touchpoints like call centres, forms, letters and emails, and face to face meetings with users.

COTS products and services must be designed to meet the specific needs of the users of your service. You may need to adjust them according to your service users’ needs.

Content designers, interaction designers and user researchers will also help to ensure your service meets accessibility requirements.

[Read more about how to set up a service team at each phase](https://www.gov.uk/service-manual/the-team/set-up-a-service-team)

### Project lifecycle

You should use agile project management with COTS in the same way you would with an internally-developed product or service. This means that you should include an alpha phase to try out different solutions and decide whether COTS is the right approach for your service.

[Read more about agile delivery](https://www.gov.uk/service-manual/agile-delivery)

Updates to this page
--------------------

Published 2 May 2025

Last updated 4 July 2025
[+ show all updates](#full-history)

1. 4 July 2025

   Clarifying that technology choices should not be committed to before the problem is understood and different options have been tested.
2. 2 May 2025

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---