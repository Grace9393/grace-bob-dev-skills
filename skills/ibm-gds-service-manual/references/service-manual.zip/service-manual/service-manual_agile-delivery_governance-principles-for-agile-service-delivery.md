Governance principles for agile service delivery - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Governance principles for agile service delivery
================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Who is involved in governance](#who-is-involved-in-governance)
2. [Don’t slow down delivery](#dont-slow-down-delivery)
3. [Decisions when they’re needed, at the right level](#decisions-when-theyre-needed-at-the-right-level)
4. [Do it with the right people](#do-it-with-the-right-people)
5. [Go see for yourself](#go-see-for-yourself)
6. [Only do it if it adds value](#only-do-it-if-it-adds-value)
7. [Trust and verify](#trust-and-verify)
8. [Examples and case studies](#examples-and-case-studies)

The following 6 principles will help you create an agile culture for your service team and organisation:

1. Don’t slow down delivery
2. Decisions when they’re needed, at the right level
3. Do it with the right people
4. Go see for yourself
5. Only do it if it adds value
6. Trust and verify

Who is involved in governance
-----------------------------

Everyone in the delivery team is responsible for and involved in its governance. [Agile tools and techniques](service-manual_agile-delivery_agile-tools-techniques.md) (daily stand-ups, regular planning meetings and retrospectives) are all ways of governing delivery.

Delivery teams also need help from people who are responsible for supporting an agile team through management and governance activity. These generally are:

* service owners
* delivery managers
* senior responsible officers (SROs)
* auditors and assurers
* digital leaders, chief technology officers and other senior civil servants

Don’t slow down delivery
------------------------

Your service team must build a service that you continually improve to meet user needs. As service owner, you should:

* find a way to get work done when it’s ‘blocked’ and slowing down delivery, especially if your team doesn’t have the authority to do so
* be available and make frequent decisions throughout service delivery
* be mindful of the balance between releasing new features and maintaining quality
* protect the team from, or help them handle, external pressures

You should keep a good pace of delivery by:

* having short, frequent meetings, like standups
* managing risks and issues that will affect the delivery of your service as and when needed
* basing controls (eg on spending) on the balance between costs and benefits

Transition between the phases of service delivery should be seamless, so people who govern must anticipate problems and make timely decisions to allow this.

Decisions when they’re needed, at the right level
-------------------------------------------------

Iterative development is the best way of handling change and improving service quality. Embrace that things change and decisions need to be made frequently. Make sure:

* decision making is evidence-based and focused on meeting user needs
* the service owner and team have the authority to make decisions and only escalate when they need to
* you handle change and improve quality through continuous iterative development

You should also ensure that service teams know:

* that they have the authority to make decisions about the service
* what the boundaries of that decision making are
* who is accountable for helping them when decisions outside the boundaries need to be made

### Risk management

Risks can’t be eliminated and you should highlight and own only the ones that could affect service delivery.

In agile, you need to deal with risks at the right time. Identify the best possible moment to respond to important risks and only then start to plan and carry out your response.

Do it with the right people
---------------------------

As a service owner or SRO you should:

* make sure the people in your team have all the skills they need
* give them the environment, workspace and tools to collaborate, organise and deliver
* have a flat organisation structure so everyone in your team can contribute to the team’s success

You should make sure that everyone involved in redesigning or creating your government service is:

* capable, motivated and empowered
* focused on goals and outcomes including [key performance indicators (KPIs)](service-manual_measuring-success_using-data-to-improve-your-service-an-introduction#what-to-measure.md)
* open and honest about what they do

Find out how to [set up a service team for each phase](service-manual_the-team_set-up-a-service-team.md).

Go see for yourself
-------------------

It’s everyone’s responsibility to stay well informed. Delivery teams talk face to face wherever possible and the best way to measure progress is to ‘see the thing’.

SROs should visit teams regularly and take part in a [delivery team’s meetings](service-manual_agile-delivery_agile-tools-techniques.md), particularly sprint reviews or show and tells. This makes sure they’re fully informed and can make decisions quickly.

If these meetings aren’t happening, find out why.

### Reporting and planning

Going to see for yourself, and looking at data that delivery teams are already using to manage delivery, should give you the information you need to govern.

Walls are an excellent way to track work and show important things, like what the team is doing and how they’re progressing. It helps planning and communication within the team and to other teams.

Read more in the guide [Measuring and reporting progress](service-manual_agile-delivery_measuring-reporting-progress.md).

Only do it if it adds value
---------------------------

In agile delivery management there’s a focus on giving value to users early and continuously. This means your team needs to:

* have a service vision and goals based on user needs
* set out measures of success and communicate these regularly
* value quality and make sure that user needs are met (give the team time to do this)
* explore and develop ideas that could add value - if they don’t work, try something else

To do this the service delivery team should develop a charter (written document, posters etc) that describes:

* their service vision
* quantifiable goals
* key performance indicators (KPIs) that show progress against meeting user needs and organisational goals

Trust and verify
----------------

Governance should be simple and supportive. It should trust individuals and give decision-making authority to teams so they can focus on delivering.

People who govern should regularly speak to the team to help support, steer and assure. To monitor progress use a light touch. This means checking services a little, but often.

Regular reflection on how teams are doing and finding ways to improve is an important part of good governance. At the end of each iteration every delivery team holds a retrospective where it discusses lessons learned - both what went well and what didn’t. This lets you identify actions which are then planned into future iterations. Retrospectives should also be used across programmes of work.

Examples and case studies
-------------------------

Read about [how the Home Office used agile governance](https://digitaltransformation.blog.gov.uk/2014/12/11/doing-the-right-things-in-the-right-way-agile-governance-at-home-office) to help them deliver the Immigration Platform Technologies (IPT) Programme.

Updates to this page
--------------------

Published 22 February 2016

Last updated 23 May 2016
[+ show all updates](#full-history)

1. 6 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---