Writing effective letters - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Writing effective letters
=========================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Decide whether you should send a letter](#decide-whether-you-should-send-a-letter)
2. [How to structure letters](#how-to-structure-letters)
3. [Changing existing letters](#changing-existing-letters)
4. [Making letters accessible to disabled people](#making-letters-accessible-to-disabled-people)

Letters are an important part of how government interacts with users. A letter will often be about a thing the user’s never heard of or did not know they needed to do.

They might be anxious about receiving letters from certain departments - especially if they or someone they know has had a negative experience in the past.

This means it’s crucial the letter is clear and understandable, especially if the user has to act on it or it’s explaining new concepts.

Clear letters are better for government too. If a user can understand a letter, they’re less likely to get in touch to ask questions via another channel and more likely to do the thing the letter is asking them to do (such as pay for or register something).

If you’re not already, you should consider using [GOV.UK Notify](https://www.notifications.service.gov.uk/) to send letters to your users.

Decide whether you should send a letter
---------------------------------------

In general, it’s good to offer your users a choice of how they’d like to be contacted. And if they’ve expressed a preference previously you should stick to that where possible - especially if it’s because that format is more accessible for them.

But all other things being equal, it’s probably better to send a letter if any of the following apply:

* users need a hard copy of the thing you’re sending them - that way, they don’t have to print anything out
* the letter is formatted in a way you can’t replicate accessibly in an email
* research shows your user group overwhelmingly expects or prefers to be contacted via letter

There might also be a security or legislative reason for sending a letter. For example, you might need to send users [sensitive information that you wouldn’t want to put in an email](https://www.gov.uk/service-manual/technology/how-to-email-your-users#protect-your-users), or you might be bound by law to send information in writing.

If those criteria don’t apply and what you’re sending is relatively short and simple, you should probably [send a text message or email instead](https://www.gov.uk/service-manual/design/sending-emails-and-text-messages).

How to structure letters
------------------------

You can adapt the [writing standards that apply to digital content](https://www.gov.uk/guidance/content-design/writing-for-gov-uk) to make sure letters are as simple and concise as possible.

When you’re working on a letter, make sure to:

* start with user needs - know what you want the user to do when they get the letter and
  leave out any information that isn’t directly relevant to that task
* put the most important information at the top - this includes explaining what the letter’s about and any action a user needs to take
* write clearly, in [plain English](https://www.gov.uk/guidance/content-design/writing-for-gov-uk#plain-english)

For example, the Get your state pension service team [redesigned their letters to meet user needs](https://dwpdigital.blog.gov.uk/2019/01/28/designing-letters-as-part-of-the-whole-user-journey/).

Important information includes things like:

* any reference or phone numbers the user needs to know
* a brief summary of why the user’s receiving the letter, perhaps formatted as a headline - for example, “Your tax return is due” or “You need to renew your licence”
* where relevant, an explanation of what happens next if the user does not do the action outlined in the letter

Use short URLs where possible - they’re easier for users to read and type into their browsers.

There’s no reason to strike a more formal tone in a letter, despite the perception that they should be more formal than digital content. This is backed up by [research HM Revenue and Customs (HMRC) did on the letters they send to users filing tax returns](https://www.gov.uk/government/publications/letter-testing-with-hmrc-self-assessment-customers). The research found that legal jargon was particularly confusing for users.

It also revealed that users find it easier to follow short letters than long ones.

And think about things like font sizes and whether you’re relying on colour alone to convey information. If as many as people as possible are able to read the letter you’re likely to get fewer phone calls.

Changing existing letters
-------------------------

Changing existing letters can be harder than writing new ones.

For example, if you’re working with a supplier, there might be a cost associated with every change you make. This can make even small updates very expensive.

Agreeing changes and getting approval from colleagues can take a long time too. A team at HMRC found a way to speed up this process when they were updating letters for childcare-related services.

They invited a range of people, including policy experts, to a meeting. Before reviewing the old letter, they asked everyone to describe its purpose.

They came up with a list of important information, then compared the list with the old letter. What they found was that the most important information was buried near the bottom.

This exercise proved that the old letter needed to change. It also helped the team to reach an agreement about how to rewrite it.

Sometimes convincing people you need to edit a letter is easy. For example, if legislation is changing or something’s out of date.

But even when the changes seem obvious, you should look at their impact. For instance, moving the position of the address could mean changing the type of envelope you use as well, which could be expensive.

As is always the case when you’re challenging an established process, it’s useful to know [how much the current process is costing](https://www.gov.uk/service-manual/measuring-success/measuring-service-benefits#discovery-spot-problems-and-estimate-how-much-theyre-costing), how much it’d cost to change it and how much you think you’d be able to improve it by.

And it’s useful to have evidence that the current letters are not working as well as they could. To understand how well your letters are performing you could:

* include them in your lab research
* run [simple research exercises](https://userresearch.blog.gov.uk/2014/09/02/a-simple-technique-for-evaluating-content/) with users
* ask staff in your department’s contact centre if they get a lot of support calls about letters

This approach worked for the team working on the [pay a DVLA fine service](https://www.gov.uk/pay-dvla-fine). They developed a very close relationship with their contact centre, which helped them build up enough trust to iterate and test three versions of the penalty letter with users.

Making letters accessible to disabled people
--------------------------------------------

The Office for Disability Issues and Department for Work and Pensions have published [guidance on making print publications accessible](/government/publications/inclusive-communication/accessible-communication-formats#accessible-print-publications).

Updates to this page
--------------------

Published 8 April 2019

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---