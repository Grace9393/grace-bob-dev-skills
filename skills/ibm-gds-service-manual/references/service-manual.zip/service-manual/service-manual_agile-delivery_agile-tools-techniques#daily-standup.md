Agile tools and techniques - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Agile delivery](service-manual_agile-delivery.md)

Agile delivery

Agile tools and techniques
==========================

[Give feedback about this page](/contact/govuk)

From:
:   [Agile delivery community](service-manual_communities_agile-delivery-community.md)

Contents
--------

1. [Daily standup](#daily-standup)
2. [Sprint planning meetings](#sprint-planning-meetings)
3. [Team review (show and tell)](#team-review-show-and-tell)
4. [Retrospective meetings](#retrospective-meetings)
5. [End-of-phase retrospectives](#end-of-phase-retrospectives)
6. [User stories](#user-stories)
7. [The backlog](#the-backlog)
8. [Team walls](#team-walls)
9. [Related guides](#related-guides)

Using agile tools and techniques can help your digital service team to:

* self-organise and plan
* communicate (within the team and with the rest of your organisation)
* continuously improve the way you work
* get support from senior responsible officers (SROs) and service managers

You might also hear these tools and techniques called ‘agile ceremonies and artefacts’.

Daily standup
-------------

The standup is a daily meeting for the team to discuss what they’re working on and whether there are any problems or dependencies they need to resolve (for example, needing help from someone else).

Standups should last no longer than 15 minutes. You should hold them at the same time every day. It’s best if you do standups in front of your [team wall](service-manual_agile-delivery_team-wall.md).

[good and bad standups](https://www.youtube.com/watch?v=Uwl-z1QZsLc) - a video presentation by Adam Maddison, Head of Agile Delivery at Government Digital Service (GDS)

See: [standup meetings](https://en.wikipedia.org/wiki/Stand-up_meeting) on Wikipedia

Sprint planning meetings
------------------------

Sprint planning meetings are a feature of [Scrum](service-manual_agile-delivery_agile-methodologies.md). You should hold them at the start of each [sprint.](http://www.scrumguides.org/scrum-guide.html#events-sprint)

At a sprint planning meeting, the team decides what to work on next and how they’ll do it.

The length of the meeting will depend on how long your sprint is.

Read: [sprint planning](http://www.scrumguides.org/scrum-guide.html#sprint-planning) by Ken Schwaber and Jeff Sutherland, the creators of Scrum

Team review (show and tell)
---------------------------

The team review is a regular meeting which gives team members the opportunity to demonstrate their work. It can also be called a sprint review or a show and tell.

You can invite stakeholders like directors or suppliers to this meeting and use it to tell them about the user stories you’ve completed or other work you’ve done.

You’ll need a screen to show your work and enough space for people to join in.

If your service is part of a larger organisation or programme you may want to open up your review to the rest of the organisation every few weeks.

This gives you the opportunity to show the most important work you’ve done, talk about what you’ve learned, explain your plans for the next few weeks and answer questions. It also gives other teams the chance to see how your work relates to theirs.

See: [how a Ministry of Justice team got stakeholders involved in sprint reviews](https://mojdigital.blog.gov.uk/2014/07/28/getting-stakeholders-more-involved-in-sprint-reviews/)

Retrospective meetings
----------------------

Retrospectives, sometimes called ‘retros’, are regular meetings where your whole team talks about what’s going well and what is not.

Teams usually hold retros at the end of an iteration (for example a sprint) and use them to talk about the work from that period of time.

The point of a retro is to fix any problems in the team and to make sure you keep doing the things that are working.

### How to run a retro

One person should host the retro and decide on questions for the team to talk about.

If you’re hosting, pick broad questions that allow the team to set the agenda, rather than strictly setting it yourself.

Retros should have an open atmosphere where every member of the team can speak honestly and feel confident that their colleagues will listen.

Allow 60 to 90 minutes for the meeting and use a private space where you can stick post-it notes to the wall.

A basic retro could follow these steps:

1. The host explains the questions at the beginning and sticks a post-it note to the wall for each question.
2. Each team member writes down one or more answers for each question on post-it notes and sticks them to the right part of the wall.
3. The group discusses issues as they come up, or at the end.
4. The host decides on actions to fix any problems raised, and assigns them to members of the team.

You could choose to cover 3 or 4 of the following topics:

* what went well in the last iteration
* what went badly in the last iteration
* what’s puzzling the team or what the team does not understand
* who the team wants to thank (eg other members of the team)

These topics are just examples, there are many different types of retro. You can [find more in the Retrospective wiki](http://retrospectivewiki.org/index.php?title=Agile_Retrospective_Resource_Wiki).

If you’re hosting the retro, you should pick topics which you think will prompt useful discussions in your team, for example on transparency, team learning or your working process.

### Make a list of actions

You should use the information you get from your retro to improve your work and your working environment.

Make a list of actions that you’ll carry out to fix the problems that your team highlighted and assign them to people in the team.

You should aim to get the actions done before the next retro.

End-of-phase retrospectives
---------------------------

Some teams run a longer retro at the end of discovery, alpha and beta. These usually include people who’ve been involved in the work from outside the team, too, like procurement or policy colleagues.

This type of retro can:

* identify what could be improved in the next phase of the project
* help people from procurement, policy or other disciplines work more effectively with service teams across the wider organisation

[ONS ran an end-of-phase retro](https://digitalblog.ons.gov.uk/2017/04/05/running-the-data-discovery-end-of-alpha-retro/) to identify which ways of working to continue and which to stop in the next phase of their data discovery project.

User stories
------------

User stories are a way for your team to briefly record the things you need to do to build the service. You can use them to prompt discussions about features when you’re ready to start work on them.

See: [writing user stories](service-manual_agile-delivery_writing-user-stories.md)

The backlog
-----------

Your team will have a product backlog where you’ll store the user stories you have not started work on yet in order of priority. If you’re following Scrum methodology you’ll also have a [sprint backlog](http://www.scrumguides.org/scrum-guide.html#artifacts-sprintbacklog) to store the stories the team has agreed to work on in that sprint.

See:

* [Creating an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md) for more information about tools that can help you manage your backlog
* [product backlog](http://www.scrumguides.org/scrum-guide.html#artifacts-productbacklog) by Ken Schwaber and Jeff Sutherland, the creators of Scrum

Team walls
----------

Your team wall is a wall near where you sit on which you keep a visual record of your work.

The wall shows what your team has done, what they’re currently doing and the work still to do.

It helps your team to collaborate and allows other people in the organisation to see what you’re doing.

See:

* [Set up a team wall](service-manual_agile-delivery_team-wall.md)
* [Creating an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md)

Related guides
--------------

You may also find these guides useful:

* [Agile methods: an introduction](service-manual_agile-delivery_agile-methodologies.md)
* [Creating an agile working environment](service-manual_agile-delivery_create-agile-working-environment.md)

Updates to this page
--------------------

Published 16 February 2016

Last updated 18 January 2019
[+ show all updates](#full-history)

1. 18 January 2019

   Added information about running end-of-phase retros.
2. 5 January 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---