Product and service community - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Communities](service-manual_communities.md)

Communities

Product and service community
=============================

[Give feedback about this page](/contact/govuk)

Contents
--------

1. [Who the community is for](#who-the-community-is-for)
2. [Get involved](#get-involved)
3. [Community resources](#community-resources)
4. [Product management in the Service Manual](#product-management-in-the-service-manual)

The product and service community exists to:

* make sure government products and services meet user needs
* create a supportive peer group of product managers and service owners across government
* improve product management skills and techniques through collaboration
* discuss and challenge the way government manages products and services
* help you use shared products and components in your service

Who the community is for
------------------------

You might be interested in the community if you use (or want to use) product management methods to deliver government products and services that meet user needs.

You do not have to be in a product manager or service owner role to join.

Get involved
------------

If you’re interested in discussing product management, you can:

* join the Product People mailing list by [submitting your government email address](https://www.smartsurvey.co.uk/s/665EXY/) - the team will get back to you within a week
* join the [product management channel on the UK government Slack](https://ukgovernmentdigital.slack.com/messages/C06HVTMDH) - you can create a Slack account using your government email address
* come along to one of our monthly and annual community events (announced on the mailing list and Slack).

Your department may have its own product management community. Talk to your head of product to find out.

Community resources
-------------------

Use these resources to learn more about product management in government:

* [GDS blog](https://gds.blog.gov.uk) - includes stories, lessons and case studies about agile from across government
* [product manager roles and skills](https://www.gov.uk/guidance/product-manager) and [service owner role and skills](https://www.gov.uk/guidance/service-owner) - from the government Digital, Data and Technology Profession Capability Framework
* [Government Design Principles](https://www.gov.uk/design-principles) - use these to guide your work

Product management in the Service Manual
----------------------------------------

These guides show what we currently believe to be best practice for managing products and services in government:

* [Core principles of agile](service-manual_agile-delivery_core-principles-agile.md)
* [Designing government services: an introduction](service-manual_design_introduction-designing-government-services.md)
* [Set up a service team at each phase](service-manual_the-team_set-up-a-service-team.md)
* [Writing user stories](service-manual_agile-delivery_writing-user-stories.md)
* [Planning in agile](service-manual_agile-delivery_planning-agile.md)
* [Governance principles for agile service delivery](service-manual_agile-delivery_governance-principles-for-agile-service-delivery.md)
* [Measuring and reporting progress](service-manual_agile-delivery_measuring-reporting-progress.md)
* [Developing a road map](service-manual_agile-delivery_developing-a-roadmap.md)
* [Deciding on priorities](service-manual_agile-delivery_deciding-on-priorities.md)
* [How the discovery phase works](service-manual_agile-delivery_how-the-discovery-phase-works.md)
* [How the alpha phase works](service-manual_agile-delivery_how-the-alpha-phase-works.md)
* [How the beta phase works](service-manual_agile-delivery_how-the-beta-phase-works.md)
* [How the live phase works](service-manual_agile-delivery_how-the-live-phase-works.md)
* [Retiring your service](service-manual_agile-delivery_retiring-your-service.md)

Help us keep the Service Manual up to date by:

* contributing to community discussions
* telling us if something is wrong or out of date using the feedback link at the top of each guide

Updates to this page
--------------------

Published 1 August 2017

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---