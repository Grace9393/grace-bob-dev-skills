Choose a location for user research - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

Choose a location for user research
===================================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [Hiring research studios](#hiring-research-studios)
2. [Using meeting rooms](#using-meeting-rooms)
3. [Going to a participant’s work or home](#going-to-a-participants-work-or-home)
4. [Using public spaces (pop-up research)](#using-public-spaces-pop-up-research)
5. [Make sure venues are accessible](#make-sure-venues-are-accessible)
6. [Doing research remotely](#doing-research-remotely)
7. [Examples and case studies](#examples-and-case-studies)
8. [Related guides](#related-guides)

Choose the location that will work best for each round of user research. You do not always need a full research lab, and many types of research are done best in other locations.

You can run research sessions in:

* research studios or labs
* meeting rooms
* a participant’s home or workplace
* public spaces (pop-up research)
* your office (using a laptop or phone for remote research)

Whatever location you choose, make sure it’s accessible so you do not exclude disabled participants.

If you choose a location away from your office, do not go alone and let your team know where you are. Try not to run research sessions in remote locations with poor phone signal.

During the coronavirus (COVID-19) pandemic, if you’re thinking about doing some face to face research there are steps you must follow to help you [choose between face to face and remote research](https://www.gov.uk/service-manual/user-research/doing-user-research-during-coronavirus-covid-19-choosing-face-to-face-or-remote-research).

Hiring research studios
-----------------------

A research studio (or usability lab) is a dedicated user research space. A studio will support a range of research activities, including:

* [interviews](service-manual_user-research_using-in-depth-interviews.md)
* [experience mapping](service-manual_user-research_creating-an-experience-map.md)
* [usability tests](service-manual_user-research_using-moderated-usability-testing.md)

Most external studios provide reception services to welcome participants, collect consent and handle incentive payments.

Observation and recording facilities are built-in, and facilities often include a way to stream sessions to remote observers. This means your team and stakeholders can watch them even if they’re not in the studio.

However, research studios can be expensive and are rarely available at short notice, so you need to book well in advance.

Participants are also taken out of their normal environment, which means you cannot capture information on their usual behaviour or surroundings. They also need to travel to the studio. If they use assistive technologies (like screen readers or voice recognition software), you may not be able to recreate their home set-up in the lab.

Using meeting rooms
-------------------

A standard meeting room is a good location for many kinds of research, including:

* [interviews](service-manual_user-research_using-in-depth-interviews.md)
* [experience mapping](service-manual_user-research_creating-an-experience-map.md)
* card sorting
* simple [usability tests](service-manual_user-research_using-moderated-usability-testing.md)
* workshops

However, you might need help to welcome participants, collect consent and handle payment for your participants’ time. You may also need to bring your own devices and manage your own recording.

Some venues do not like visitors sticking worksheets or sticky notes on walls, and streaming to remote observers might also be difficult.

If you want team members or stakeholders to watch the session, you can use screen-sharing tools.

Going to a participant’s work or home
-------------------------------------

Your participants’ homes and workplaces are ideal research locations, helping you to understand how your service fits into their lives. This will really help in the design process so it’s important to do this early on (for example, in the discovery phase).

You can ask participants to:

* [show you how they do an activity](https://www.gov.uk/service-manual/user-research/contextual-research-and-observation)
* give feedback on concepts and prototypes
* test a new service

The familiar context will make it easier for them to remember details and provide rich feedback. Being in their normal environment also means you can gather contextual and behavioural information that you cannot get in the lab.

This option is not always available as participants can feel uncomfortable having researchers in their home or at their workplace.

For your own security, always visit people’s homes with a colleague. When your research involves contact with children or vulnerable adults, get advice from your department or organisation before speaking to them.

### Visiting disabled participants

For some disabled people, the best research location is their home or workplace, for example if:

* it’s difficult or stressful for them to travel to your venue
* they use a custom set-up that would be difficult to reproduce in a lab - for example, a screen reader or second monitor with specific settings

It can be difficult finding disabled participants. You’ll get the best research results if you make it easy for them to take part and let them use the technology they’re used to.

Using public spaces (pop-up research)
-------------------------------------

Do [pop-up research](service-manual_user-research_doing-pop-up-research.md) in places where your target users are likely to be so you can reach those with particular needs, for example:

* visit a university if you want to talk to students
* go to a job centre if you need to talk to the unemployed or those on benefits

You can get a lot of participants to take part in pop-up research and there are no costs, except for travel and your time.

If using a public space, you should:

* get permission to use the area
* be prepared to improvise as you often will not know the place
* avoid setting up near entrances, exits and places where people are in groups
* take care of your equipment and bags

Make sure venues are accessible
-------------------------------

When choosing and setting up research venues, check that:

* there’s an accessible route from the street to the research room
* there are no trip hazards
* there’s enough room for a wheelchair, if needed
* there’s a chair for the interpreter or assistant, if needed
* the lighting suits the participant’s needs - for example, someone with autism spectrum disorder may prefer a darker room
* your research environment is quiet
* there’s no food around, if the participant has an assistance dog

Doing research remotely
-----------------------

You can run user research sessions remotely using telephone or video calls.

There’s a separate guide to [doing user research sessions remotely](service-manual_user-research_remote-user-research-phone-video-call.md). The guide explains how to adapt face to face research methods so that they work effectively over phone or video calls.

Examples and case studies
-------------------------

You may find the following blog posts useful:

* [China tourist visas: user research](https://gds.blog.gov.uk/2015/02/16/china-tourist-visas-user-research/)
* [Research with visually impaired users](https://userresearch.blog.gov.uk/2016/01/22/research-with-visually-impaired-users/)

Related guides
--------------

You may also find the following guides useful:

* [Plan a round of user research](service-manual_user-research_plan-round-of-user-research.md)
* [Find user research participants](service-manual_user-research_find-user-research-participants.md)
* [Running research sessions with disabled people](service-manual_user-research_running-research-sessions-with-people-with-disabilities.md)

Updates to this page
--------------------

Published 16 March 2016

Last updated 3 October 2017
[+ show all updates](#full-history)

1. 3 October 2017

   Added guidance on accessibility requirements.
2. 25 February 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---