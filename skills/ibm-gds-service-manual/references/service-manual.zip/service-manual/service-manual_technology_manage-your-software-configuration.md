Manage your software configuration - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Manage your software configuration
==================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)

Contents
--------

1. [Using configuration management tools](#using-configuration-management-tools)
2. [Use infrastructure as code](#use-infrastructure-as-code)
3. [Build for portability](#build-for-portability)
4. [Use the same development and production tools](#use-the-same-development-and-production-tools)
5. [Related guides](#related-guides)

Managing how the pieces of your software and service work together allows you to build a stable, scalable, secure and portable system.

It’s important to do this because your system is likely to be much larger than a single application relying on other supporting infrastructure components.

Even if your system is a simple application, it still probably requires configuration, for example providing database credentials or a web service endpoint.

Using configuration management tools
------------------------------------

Configuration management tools will help you to document and maintain the configuration and dependencies of your software system.

You can do this using handmade software but it’s more common to use existing open source tools, for example:

* [Ansible](https://www.ansible.com/)
* [CFEngine](http://cfengine.com/)
* [Chef](https://www.chef.io/chef/)
* [Puppet](https://puppetlabs.com/)

Use infrastructure as code
--------------------------

One way you can manage configuration is by using code to describe the configuration and software dependencies. Dependencies are the things your software needs in order to work properly.

This approach brings all the advantages of programming in general and allows you to:

* test your code ability
* reuse your code
* document your infrastructure

Once written in code, the infrastructure configuration is then run against the servers, networks and software in question.

When documenting technology components, you should include information on:

* [service vulnerabilities](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/discovering-vulnerabilities/)
* [how you will assess the effectiveness of security controls](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/assessing-the-effectiveness-of-security-controls/)
* [who is responsible for ensuring asset security](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/agreeing-roles-and-responsibilities/)

Build for portability
---------------------

Moving software systems between providers can be difficult and time-consuming. If you don’t consider portability, it’s possible to lock yourself in with a provider.

Configuration management gives you a deep understanding of the configuration of your system. You can use this knowledge to easily move software between providers.

Use the same development and production tools
---------------------------------------------

A common software systems problem is that code which was written by a development team works on their machine or test environment but not in the production environment.

This is often caused by differences in:

* software
* databases
* application servers

Avoid this problem by using the same tools for your development and production environments.

Related guides
--------------

You may also find these guides useful:

* [Managing software dependencies](service-manual_technology_managing-software-dependencies.md)
* [Deploy software regularly](service-manual_making-software_deployment.html.md)
* [Documenting service assets](https://www.security.gov.uk/guidance/secure-by-design/activities/documenting-service-assets)

Updates to this page
--------------------

Published 23 May 2016

Last updated 24 October 2024
[+ show all updates](#full-history)

1. 24 October 2024

   Integrated elements on Documenting service assets and Discovering vulnerabilities.
2. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---