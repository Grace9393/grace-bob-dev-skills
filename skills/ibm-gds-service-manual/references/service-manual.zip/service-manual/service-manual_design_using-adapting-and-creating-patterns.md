Using, adapting and creating patterns - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Design](service-manual_design.md)

Design

Using, adapting and creating patterns
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Where to find design patterns](#where-to-find-design-patterns)
2. [Creating or changing patterns](#creating-or-changing-patterns)

Design patterns are evidence-based solutions to common design problems. You must start using them as soon as you begin [making prototypes](https://www.gov.uk/service-manual/design/making-prototypes).

Following design patterns means you:

* avoid repeating work that’s already been done
* avoid making mistakes that others have already learned from
* build on the research and experience of teams across government
* make your service consistent with other government services

Where to find design patterns
-----------------------------

In the [GOV.UK Design System](https://design-system.service.gov.uk), you’ll find patterns on how to ask users for commonly-needed information like:

* addresses
* dates
* gender or sex
* names
* National Insurance numbers
* passwords

There are also patterns on how to help users do things like:

* check a service is suitable
* check their answers
* confirm an email address
* create a username
* create an account

You’ll also find patterns for common page types like:

* confirmation pages
* question pages
* start pages
* task list pages

Creating or changing patterns
-----------------------------

If research shows that none of the [existing patterns](https://design-system.service.gov.uk/patterns/) meet the needs of your users, you can:

* adapt an existing pattern
* create a new pattern

You must [contribute your findings](https://design-system.service.gov.uk/community/propose-a-component-or-pattern/) back to the GOV.UK Design System.

Updates to this page
--------------------

Published 18 October 2016

Last updated 11 April 2017
[+ show all updates](#full-history)

1. 11 April 2017

   Added guidance on using beta patterns.
2. 18 October 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---