User research in discovery - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [User research](service-manual_user-research.md)

User research

User research in discovery
==========================

[Give feedback about this page](/contact/govuk)

From:
:   [User research community](service-manual_communities_user-research-community.md)

Contents
--------

1. [How to do user research in discovery](#how-to-do-user-research-in-discovery)
2. [Examples and case studies](#examples-and-case-studies)
3. [Related guides](#related-guides)

The aim of user research in the [discovery phase](service-manual_agile-delivery_how-the-discovery-phase-works.md) is to find out:

* who your likely users are and what they’re trying to do
* how they do it currently (for example, what services or channels they use)
* the problems or frustrations they experience
* what users need from your service to achieve their goal

You must do this before you start planning, designing or building your service. What you learn about your users in discovery will also help you to [scope your service](service-manual_design_scoping-your-service.md).

How to do user research in discovery
------------------------------------

You need to think about your service from end to end and consider all the ways that users interact with it (including all tools, transactions, support and offline steps).

### Who to research with

You must do research with a broad range of users, including disabled people and people with low digital skills. It’s also helpful to [learn about the range of abilities that people have](https://accessibility.blog.gov.uk/2016/05/16/consider-the-range-of-people-that-will-use-your-product-or-service/).

You should also find out about the people who provide the service or who support other users (for example, caseworkers, call centre agents and charity workers).

Learn more about [finding user research participants](service-manual_user-research_find-user-research-participants.md).

### Typical user research activities

To learn more about your users and their needs, you can:

* [research the current experience](service-manual_user-research_researching-user-experiences.md) of people who want to do the task your service provides
* observe people to see how they do things now and what problems or barriers they face
* use interviews and visits to explore relevant aspects of their lives and work
* examine existing data (for example analytics, back-office workflow and support logs)
* review previous user research

From these activities you’ll typically get:

* a [detailed map](service-manual_user-research_creating-an-experience-map.md) that presents the current experience of likely users
* descriptions of different types of users (for example, personas)
* sets of needs for different types of users
* an understanding of some of the barriers that disabled users face

You’ll have done enough research when you understand the different kinds of people who use your service and what they need from it, including disabled people and people with support needs.

### Involve the team

Get the whole service team involved in your research during discovery.

Observing and talking to users from the beginning helps everyone understand the problems you’re trying to solve.

Examples and case studies
-------------------------

To find out more about researching a service, read these blog posts:

* [User research for government services: 8 strategies that worked for us](https://userresearch.blog.gov.uk/2015/01/21/user-research-for-government-services-8-strategies-that-worked-for-us/)
* [Digital academy: Understanding the problem](https://dwpdigital.blog.gov.uk/2015/01/20/digital-academy-understanding-the-problem/)
* [Dos and don’ts of designing for accessibility - understanding how to cater for disabled people](https://accessibility.blog.gov.uk/2016/09/02/dos-and-donts-on-designing-for-accessibility/)

Related guides
--------------

You may also find these guides useful:

* [Plan user research for your service](service-manual_user-research_plan-user-research-for-your-service.md)
* [Learning about users and their needs](service-manual_user-research_start-by-learning-user-needs.md)
* [Designing government services: an introduction](service-manual_design_introduction-designing-government-services.md)
* [Making your service accessible: an introduction](service-manual_helping-people-to-use-your-service_making-your-service-accessible-an-introduction.md)

Updates to this page
--------------------

Published 18 November 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---