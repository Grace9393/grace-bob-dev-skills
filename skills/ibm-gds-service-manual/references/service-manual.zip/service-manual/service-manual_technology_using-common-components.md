Using common platforms - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Using common platforms
======================

[Give feedback about this page](/contact/govuk)

From:
:   [Design community](service-manual_communities_design-community.md)

Contents
--------

1. [Common platforms and standards](#common-platforms-and-standards)
2. [Common platforms built and maintained by GDS](#common-platforms-built-and-maintained-by-gds)

Use common platforms where doing so helps you to deliver services which meet user needs faster and more cost-effectively (considering the features and functionality available in the platforms).

Common platforms and standards
------------------------------

Any common platform you use must have been assured and found to produce outputs that meet the relevant government requirements.

For example, only use a form building platform if it’s been assured and found to produce forms which meet the required standards for accessibility, security and compatibility with operating systems and browsers. But assuming it has, you will not need to:

* [test the frontend performance](https://www.gov.uk/service-manual/technology/test-your-services-performance) of individual forms
* [test the frontend code of individual forms for accessibility](https://www.gov.uk/service-manual/helping-people-to-use-your-service/testing-for-accessibility), [test with assistive technologies](https://www.gov.uk/service-manual/technology/testing-with-assistive-technologies) or [commission an accessibility audit](https://www.gov.uk/service-manual/helping-people-to-use-your-service/getting-an-accessibility-audit)
* test individual forms for [compatibility with different browsers and devices](https://www.gov.uk/service-manual/technology/designing-for-different-browsers-and-devices)
* carry out [vulnerability and penetration testing](https://www.gov.uk/service-manual/technology/vulnerability-and-penetration-testing) on individual forms

If you’re using a SaaS-type form building platform, you won’t need to consider hosting, deployment or monitoring uptime and performance - assuming that’s built into the platform.

Common platforms built and maintained by GDS
--------------------------------------------

### GOV.UK Forms

GOV.UK Forms allows users to create an accessible form-type interface without needing to know any code.

[Find out more about GOV.UK Forms](https://www.gov.uk/forms).

### GOV.UK Notify

GOV.UK Notify is a product to keep users updated by helping government service teams to send text messages, emails or letters.

[Find out more about GOV.UK Notify](https://www.notifications.service.gov.uk/).

### GOV.UK Pay

GOV.UK Pay is a product that allows users to make payments to the public sector in the same way, regardless of what service they’re using. Whether they’re applying for a passport or renewing a licence, they’ll be using the same trusted and accessible payment process.

GOV.UK Pay allows service teams to manage payments, including things like reconciliation and refunds.

[Find out more about GOV.UK Pay](https://www.payments.service.gov.uk/).

Updates to this page
--------------------

Published 7 November 2016

Last updated 3 September 2024
[+ show all updates](#full-history)

1. 3 September 2024

   Updated to:
   - reflect fact that these things are generally called 'platforms' rather than 'components'
   - clarify that some testing and auditing won't be required if you're using a platform that have been assured as meeting the relevant requirements
2. 19 April 2024

   This page has been updated to include information about using GOV.UK Forms.
3. 21 July 2022

   Removed references to GOV.UK PaaS because it is being decommissioned and is no longer taking on new tenants.
4. 23 February 2021

   Removed information about GOV.UK Registers as it is closing on on 16 March 2021.
5. 7 November 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---