Monitoring the status of your service - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Monitoring the status of your service
=====================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)

Contents
--------

1. [Plan your monitoring](#plan-your-monitoring)
2. [Metrics to monitor](#metrics-to-monitor)
3. [How to monitor](#how-to-monitor)
4. [Processing and recording issues](#processing-and-recording-issues)
5. [Make data widely available](#make-data-widely-available)
6. [Reviewing your monitoring processes regularly](#reviewing-your-monitoring-processes-regularly)
7. [Related guides](#related-guides)

By the time you reach public beta, you must have monitoring in place for your service to identify any problems that might affect it.

Monitoring with the right tools and processes allows you to:

* discover any problems that users have
* get alerts when technical problems occur so you can fix them
* anticipate problems before they happen or become more serious
* [discover vulnerabilities](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/discovering-vulnerabilities/) or the warning signs of an impending cyber security attack
* improve your service, for example by using performance data to help with [capacity planning](service-manual_technology_test-your-services-performance.md)

Plan your monitoring
--------------------

You should start planning how to monitor your service during alpha.

During alpha, your team should agree:

* what to monitor in your service
* how to monitor your service
* how to process and record issues

Metrics to monitor
------------------

You must track user-related metrics, as well as technical and security metrics. For example, track the percentage of users that can complete a task as well as available disk space, application programming interface (API) performance and memory usage.

How to monitor
--------------

Once you’ve agreed what to monitor, your team should:

* set up internal and external monitoring checks
* write monitoring checks
* write alerts

### Setting up internal and external monitoring checks

You should set up internal and external monitoring checks.

Internal monitoring is the monitoring you should set up inside your infrastructure and will give you real time updates about metrics like memory usage, page load times, and network traffic.

External monitoring is the monitoring you should set up outside of your service which keeps checking your systems even if your infrastructure goes down.

### Writing monitoring checks

You need to decide the type of monitoring checks that are most useful to your service.

A monitoring check is a series of tests that you can run against your systems or overall service to assess their status and tell you if something is wrong.

For example, you might decide you need to see an alert if 1% of users in an hour have problems finishing a transaction. You could also capture access control issues, where excessive levels of login attempts may indicate someone trying to brute force a password.

You should write monitoring checks at the same time as writing code and treat your checks as tests for your live system.

Learn about [managing observability](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/managing-observability/) to track the security health of your service.

### Writing alerts

Make your alert messages clear and concise. They need to be easy to understand for team members who might be woken up in the night to fix a problem.

Consider creating an operations manual or documentation to help your team deal with problems quickly. Make sure every member of your team has a local copy of the documentation in case your cloud-based documentation storage is unavailable.

Processing and recording issues
-------------------------------

You should manage and track errors using a ticketing system that allows you to delegate them to members of your team.

Errors always contain interesting information - they can tell you about:

* a user problem
* attacks on your service
* failing systems
* problems with capacity

Tracking errors helps you to see which ones are recurring and whether they’re part of the overall service or related to a particular application or machine.

You can combine monitoring test results to better understand what to fix in your service. For example, comparing page-loading tests with failed transactions and application errors allows you to:

* find out the parts of your service where more users are having problems
* identify the cause of problems
* discuss how to fix the cause of problems, for example, disk space or slow performance

When fixing problems, always make sure to [evaluate the security impact of changes](https://www.security.gov.uk/policy-and-guidance/secure-by-design/activities/evaluating-the-security-impact-of-changes/) being made.

Make data widely available
--------------------------

Unless it’s not safe to do so, you should make monitoring information and data widely available.

For example, you can share performance reports with other service teams in your department or use a status dashboard, like the operations status page used by [GOV.UK Notify](https://www.gov.uk/government/publications/govuk-notify/govuk-notify), to tell users about any issues.

Reviewing your monitoring processes regularly
---------------------------------------------

You should review your monitoring processes to make sure they align with your support obligations and capabilities.

If someone is called out of hours, you should make sure the issue needs that level of response.

For example, if the issue doesn’t affect users and could wait until the morning, consider changing your alert strategy so that type of error doesn’t prompt an alert in future. It may be possible to implement automated responses to issues that don’t require an immediate human intervention.

Related guides
--------------

You may also find the [Uptime and availability](service-manual_technology_uptime-and-availability-keeping-your-service-online.md) guide useful.

Updates to this page
--------------------

Published 23 May 2016

Last updated 23 October 2024
[+ show all updates](#full-history)

1. 23 October 2024

   Integrated elements on Managing observability and Evaluating the security impact of changes.
2. 9 January 2017

   Guide revised to include more detailed advice on how to set up monitoring, write checks and alerts, and how to process and record issues.
3. 23 May 2016

   Guidance first published

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---