Uptime and availability: keeping your service online - Service Manual - GOV.UK



[Skip to main content](#content)


[GOV.UK](https://www.gov.uk)

Navigation menu
---------------

[Menu](/browse)

Menu

Search GOV.UK





×
[Search GOV.UK](/search)

### Services and information

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

### Government activity

* [Departments](/government/organisations)

  Departments, agencies and public bodies
* [News](/search/news-and-communications)

  News stories, speeches, letters and notices
* [Guidance and regulation](/search/guidance-and-regulation)

  Detailed guidance, regulations and rules
* [Research and statistics](/search/research-and-statistics)

  Reports, analysis and official statistics
* [Policy papers and consultations](/search/policy-papers-and-consultations)

  Consultations and strategy
* [Transparency](/search/transparency-and-freedom-of-information-releases)

  Data, Freedom of Information releases and corporate reports

### Search

Search GOV.UK

Search

[Emergency Alerts](/alerts)

Test on Sunday 7 September, 3pm

1. [Service manual](service-manual.md)
2. [Technology](service-manual_technology.md)

Technology

Uptime and availability: keeping your service online
====================================================

[Give feedback about this page](/contact/govuk)

From:
:   [Technology community (web operations)](service-manual_communities_technology-community-web-operations.md)

Contents
--------

1. [Design to maximise uptime](#design-to-maximise-uptime)
2. [Issues that can affect uptime](#issues-that-can-affect-uptime)
3. [Decide on out-of-hours support](#decide-on-out-of-hours-support)
4. [Tell users about downtime](#tell-users-about-downtime)
5. [Case studies and examples](#case-studies-and-examples)
6. [Related guides](#related-guides)

You must build and run your digital service in a way that means it’ll work for users when they need it.

This could mean you need it to be available 24 hours a day and 365 days a year.

To achieve the level of uptime you need involves good planning and design.

Design to maximise uptime
-------------------------

Your service should have more possible states than simply ‘on’ or ‘off’. For example you can:

* design your components so that they fall back to minimal functions if something goes wrong
* introduce a read-only mode where users can look at information but not change it
* build in redundancy and avoid single points of failure (eg having only one vendor could be a single point of failure)
* use more than one web server and allow load-balancing between servers, to avoid servers failing
* use database systems which spread data and queries across a cluster, to minimise database crashes

If your service relies on a third party service and this goes down, you can queue information and process it later.

Issues that can affect uptime
-----------------------------

### Underlying infrastructure availability

Your service’s availability is dependent on the availability of many systems, potentially with multiple suppliers. You may not have a relationship with all of these suppliers. This can become complicated.

**Example**

Your application is maintained by your development team. The application relies on an application server or database provided by another team in your department. The server or database runs on an infrastructure as a service platform provided via a contract with a commercial supplier. The infrastructure as a service platform relies on network connectivity and power from utilities that you have no direct contract with.

You should understand your dependencies and their dependencies and all the intended uptime expectations.

### Scheduled maintenance

Some services don’t count pre-arranged maintenance periods as downtime.

For example, a service could claim 100% uptime even though it shuts down every Monday evening for maintenance.

You shouldn’t hide uptime problems behind multiple maintenance periods.
You can classify downtime as planned (scheduled maintenance) or unplanned (other problems), if your service genuinely needs scheduled maintenance.

### Suppliers and contracts

You shouldn’t underestimate the impact that contracts you agree with suppliers (of products or services) can have on your service’s availability.

You need to fully understand the terms in any contracts you agree, for example:

* [service level agreements](https://en.wikipedia.org/wiki/Service-level_agreement)
* uptime guarantees

Suppliers may miss uptime guarantees or service level agreement response times.

Although they may offer you money or service credits as compensation, you should consider whether this really offsets the effect of the downtime on your users.

If you’re regularly getting credits for uptime problems, consider whether you’re really getting the offered uptime or service level agreement response from your supplier.

Decide on out-of-hours support
------------------------------

If your service fails outside of normal office hours, like evenings and weekends, it’ll be down for a long time unless you’ve got someone responsible for out-of-hours support.

[Carry out user research](service-manual_user-research.md) to find out whether your users are likely to use your service during these out-of-hours times. If they are you should:

* put someone in your team on call to deal with any problems
* have dedicated 24/7 support

Tell users about downtime
-------------------------

### Deliberate downtime

You may decide that you can’t afford to guarantee your service will be up at all times. If you do this, tell your users when it’ll be down and explain why.

### Unanticipated downtime

You should have a status page that you can update when there’s downtime you didn’t anticipate.

Case studies and examples
-------------------------

Find out [what happens when something goes wrong on GOV.UK](https://insidegovuk.blog.gov.uk/2015/11/18/what-happens-when-things-go-wrong-on-gov-uk/), from the Inside GOV.UK blog.

Related guides
--------------

You may also find the [Monitoring the status of your service](service-manual_technology_monitoring-the-status-of-your-service.md) guide useful.

Updates to this page
--------------------

Published 23 May 2016

Services and information
------------------------

* [Benefits](/browse/benefits)
* [Births, death, marriages and care](/browse/births-deaths-marriages)
* [Business and self-employed](/browse/business)
* [Childcare and parenting](/browse/childcare-parenting)
* [Citizenship and living in the UK](/browse/citizenship)
* [Crime, justice and the law](/browse/justice)
* [Disabled people](/browse/disabilities)
* [Driving and transport](/browse/driving)
* [Education and learning](/browse/education)
* [Employing people](/browse/employing-people)
* [Environment and countryside](/browse/environment-countryside)
* [Housing and local services](/browse/housing-local-services)
* [Money and tax](/browse/tax)
* [Passports, travel and living abroad](/browse/abroad)
* [Visas and immigration](/browse/visas-immigration)
* [Working, jobs and pensions](/browse/working)

Government activity
-------------------

* [Departments](/government/organisations)
* [News](/search/news-and-communications)
* [Guidance and regulation](/search/guidance-and-regulation)
* [Research and statistics](/search/research-and-statistics)
* [Policy papers and consultations](/search/policy-papers-and-consultations)
* [Transparency](/search/transparency-and-freedom-of-information-releases)
* [How government works](/government/how-government-works)
* [Get involved](/government/get-involved)

---