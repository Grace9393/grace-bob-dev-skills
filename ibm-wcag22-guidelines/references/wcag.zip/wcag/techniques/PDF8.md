# PDF8 - Providing definitions for abbreviations via an E entry for a structure element

**Technique ID**: PDF8  
**Technology**: pdf

---

## Description

Description The objective of this technique is to provide an expansion or definition of an abbreviation for the first occurrence of the abbreviation. For example, a reference to an abbreviation, such as "WCAG", should be available as "Web Content Accessibility Guidelines (WCAG)" on its first occurrence in a document. This is done by setting expansion text using an /E entry for a structure element, and is normally accomplished using a tool for authoring PDF. A Span structure element is typically used to tag the abbreviation, but the /E entry is valid with any structure element. This technique is applicable for any abbreviation, including acronyms and initialisms. Note that on the first occurrence of the abbreviation, both the abbreviation and the expansion text must be provided. This will aid recognition of later use of the abbreviation. PDF documents may be enhanced by providing expansions for abbreviations. In fact, such expansions are required for accessibility to ensure understanding by people who have difficulty decoding words; rely on screen magnification (which may obscure context); have limited memory; or who have difficulty using context to aid understanding.

---

## Applicability

When to Use Tagged PDF documents containing abbreviations or acronyms

---

## Procedure

Procedure Verify that the first occurrence of abbreviations that require expansion text have /E entries on an enclosing tag by one of the following and that both the abbreviation and the expansion text are provided: In a PDF editor, locate the tag for the text that is the abbreviation, and check that an expansion or definition is provided for each abbreviation in the Expansion Text field in the corresponding tag's properties. Read the PDF document with a screen reader, listening to hear that on the first occurrence, the abbreviation and expansion are read when the screen reader reads the content line-by-line. Use a tool that is capable of showing the /E entry value, such as aDesigner to open the PDF document and view the GUI summary to read the text expansions for abbreviations. Use a tool that exposes the document through the accessibility API and verify that the text expansion of the abbreviation is properly implemented.

---

## Examples

Examples Adding an /E entry to an abbreviation using Adobe Acrobat Pro's Tags panel This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. In a tagged PDF document: Select View → Show/Hide → Navigation Panes → Accessibility Tags. Select the first instance of the abbreviated text that needs to be expanded. If the selected text is part of a larger tag, use the Accessibility Tags panel's "Create Tag from Selection", and create a new Span tag. In this example, the text "WCAG2.2" (within the LBody tag) has been enclosed in a Span tag. In the Tags panel, access the context menu for the spanned text and select Properties... In the Content tab of the Properties dialog, enter the expansion text, followed by the originally selected text. The following image illustrates this technique: This example is shown in operation in: Working example of Providing definitions for Abbreviations (Word document); Working example of Providing definitions for Abbreviations (OpenOffice document); Working example of Providing definitions for Abbreviations (PDF document). Using a /Span structure element with an /E entry to define an abbreviation The following code fragment illustrates code that is typical for using the /Span structure element to define an abbreviation. This example uses the sentence "Sugar is commonly sold in 5 lb bags." The abbreviation "lb" is tagged as a /Span structure element with an /E entry (typically accomplished by an authoring tool). <code class="no-highlight">1 0 obj % structure element << /Type /StructElemen /S /Span % element type /P ... % Parent in structure hierarchy /K << /Type /MCR /Page 2 0 R % Page containing marked-content sequence /MCID 0 % Marked content identifier for "lb" >> /E (pound, lb) >> endobj</code> Using a /TH structure element with an /E entry to define an abbreviation As noted in the Description, the /E entry is valid with any structure element. The following code fragment illustrates code that is typical for using an /E entry to define an abbreviation. A table that contains columns for each month uses abbreviations as the values of column headers. The expansion for each abbreviation is provided as the /E entry of the /TH structure element (typically accomplished by an authoring tool). <code class="no-highlight">1 0 obj % structure element << /Type /StructElemen /S /TH % element type /P ... % Parent in structure hierarchy /K << /Type /MCR /Page 2 0 R % Page containing marked-content sequence /MCID 0 % Marked content identifier for "Dec" >> /E (December, Dec) >> endobj</code>

---

## Tests

Tests Procedure Verify that the first occurrence of abbreviations that require expansion text have /E entries on an enclosing tag by one of the following and that both the abbreviation and the expansion text are provided: In a PDF editor, locate the tag for the text that is the abbreviation, and check that an expansion or definition is provided for each abbreviation in the Expansion Text field in the corresponding tag's properties. Read the PDF document with a screen reader, listening to hear that on the first occurrence, the abbreviation and expansion are read when the screen reader reads the content line-by-line. Use a tool that is capable of showing the /E entry value, such as aDesigner to open the PDF document and view the GUI summary to read the text expansions for abbreviations. Use a tool that exposes the document through the accessibility API and verify that the text expansion of the abbreviation is properly implemented. Expected Results Check #1 is true.

---

## Resources

Resources Section 14.9.5 (Expansion of Abbreviations and Acronyms) in PDF 1.7 (ISO 32000-1) (PDF) Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf8  
**Last Updated**: 2026-02-10
