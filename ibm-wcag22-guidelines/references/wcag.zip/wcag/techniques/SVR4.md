# SVR4 - Allowing users to provide preferences for the display of conforming alternate versions

**Technique ID**: SVR4  
**Technology**: server-side-script

---

## Description

Description The objective of this technique is to provide a mechanism for users to select a preference for an alternate conforming version of a web page. Providing preferences to allow users to view conforming alternate versions can be accomplished in several ways. One common method is to provide a link which triggers a server-side process that sets a session or persistent cookie that the web server uses to modify the page or redirect the user to the alternate version. Other methods include providing user-specific choices that are stored as part of the user's login information for a system where users sign in to access a web page or service. Users requiring an alternate version will need the mechanism provided in the non-conforming page to be accessible in order to find and use it. The mechanism itself should conform to the accessibility level being claimed.

---

## Applicability

When to Use Content created using server-side scripting to store preferences.

---

## Procedure

Procedure Change a preference for how pages on the site are displayed. Check that the preference itself or a link to that page where it can be set can be reached from each non-conforming page. Check that web pages are displayed according to the selected preference. Check that when the preference(s) are set, the web page conforms as claimed. Verify that the resulting page is a conforming alternate version for the original page.

---

## Examples

Examples Setting a session or persistent cookie to store a user preference A website offers a link to a "preferences" page on pages within the site. On this page, there is an option to view an alternate version of the site. There may be various aspects of the page that are affected, or the user may be opting to view an entirely alternate version of the site. The preference may be to display a version of the site where video included on the site displays captioning, or it may be offered because the primary site contains accessibility conformance issues that are addressed only via the alternative. A web page author may choose to handle this preference via a cookie, which may be handled via a server-side scripting language such as PHP. The preferences page may be offered as follows: <code class="language-html"><!DOCTYPE html> <html lang="en"> <head> <title>Site Preferences</title> </head> <body> <h1>Site Preferences</h1> <form id="form1" name="site_prefs" method="post" action="pref.php"> <fieldset> <legend>Which version of the site do you want to view?</legend> <input type="radio" name="site_pref" id="site_pref_reg" value="reg"> <label for="site_pref_reg">Main version of site</label> <input type="radio" name="site_pref" id="site_pref_axx" value="axx"> <label for="site_pref_axx">Accessibility-conforming version</label> </fieldset> </form> </body> </html></code> The form is submitted to the pref.php file for processing. A cookie is set, and in this simple example the user's browser is directed to the site home page. pref.php <code class="language-php-template"><?php if(isset($site_pref)) { setcookie("site_pref",$site_pref, time() + (86400 * 30)); //set for 30 days header("location: http://www.example.com"); //redirects to home page } ?></code> The home page starts with code that implements the user's preference. index.php <code class="language-php-template"><?php if(isset($site_pref)) { if($site_pref="axx") { header("location: ./accessible/index.php"); } ?> <!DOCTYPE html> <html lang="en"> <head> ...</code> For a login-based system, the preference is stored in the user's database record and referred to by the server-side script generating the pages for the user to view.

---

## Tests

Tests Procedure Change a preference for how pages on the site are displayed. Check that the preference itself or a link to that page where it can be set can be reached from each non-conforming page. Check that web pages are displayed according to the selected preference. Check that when the preference(s) are set, the web page conforms as claimed. Verify that the resulting page is a conforming alternate version for the original page. Expected Results Checks #2 and #3 are true.

---

## Resources

Resources Setting and using cookies in PHP

---

**Keywords**: accessibility, wcag, technique, server-side-script, svr4  
**Last Updated**: 2026-02-10
