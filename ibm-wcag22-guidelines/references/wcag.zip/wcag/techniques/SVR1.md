# SVR1 - Implementing automatic redirects on the server side instead of on the client side

**Technique ID**: SVR1  
**Technology**: server-side-script

---

## Description

Description The objective of this technique is to avoid confusion that may be caused when two new pages are loaded in quick succession because one page (the one requested by the user) redirects to another. Some user agents support the use of the HTML meta element to redirect the user to another page after a specified number of seconds. This makes a page inaccessible to some users, especially users with screen readers. Server-side technologies provide methods to implement redirects in a way that does not confuse users. A server-side script or configuration file can cause the server to send an appropriate HTTP response with a status code in the 3xx range and a Location header with another URL. When the browser receives this response, the location bar changes and the browser makes a request with the new URL.

---

## Applicability

When to Use Server-side technologies, including server-side scripting languages and server configuration files with URLs or URL patterns for redirects.

---

## Procedure

Procedure Find each link or programmatic reference to another page or web page. For each link or programmatic reference to a URI in the set of web pages being evaluated, check if the referenced web page contains code (e.g., meta element or script) that causes a client-side redirect. For each link or programmatic reference to a URI in the set of web pages being evaluated, check if the referenced URI does not cause a redirect OR causes a server-side redirect without a time-out.

---

## Examples

Examples JSP/Servlets In Java Servlets or JavaServer Pages (JSP), developers can use HttpServletResponse.sendRedirect(String url). <code class="language-java">... public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { ... response.sendRedirect("/newUserLogin.do"); }</code> This sends a response with a 302 status code ("Found") and a Location header with the new URL to the user agent. It is also possible to set another status code with response.sendError(int code, String message) with one of the constants defined in the interface javax.servlet.http.HttpServletResponse as status code. <code class="language-java">... public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { ... response.sendError(response.SC_MOVED_PERMANENTLY, "/newUserLogin.do"); }</code> If an application uses HttpServletResponse.encodeURL(String url) for URL rewriting because the application depends on sessions, the method HttpServletResponse.encodeRedirectURL(String url) should be used instead of HttpServletResponse.sendRedirect(String url). It is also possible to rewrite a URL with HttpServletResponse.encodeURL(String url) and then pass this URL to HttpServletResponse.sendRedirect(String url). ASP In Active Server Page (ASP) with VBScript, developers can use Response.Redirect. <code class="language-vbnet">Response.Redirect "newUserLogin.asp"</code> or <code class="language-vbnet">Response.Redirect("newUserLogin.asp")</code> The code below is a more complete example with a specific HTTP status code. <code class="language-vbnet">Response.Clear Response.Status = 301 Response.AddHeader "Location", "newUserLogin.asp" Response.Flush Response.End</code> PHP In PHP, developers can send a raw HTTP header with the header method. The code below sends a 301 status code and a new location. If the status is not explicitly set, the redirect response sends an HTTP status code 302. <code class="language-php"><?php header("HTTP/1.1 301 Moved Permanently"); header("Location: https://www.example.com/newUserLogin.php"); ?></code> Apache Developers can configure the Apache web server to handle redirects, as in the following example. <code class="language-apache">redirect 301 /oldUserLogin.jsp https://www.example.com/newUserLogin.do</code>

---

## Tests

Tests Procedure Find each link or programmatic reference to another page or web page. For each link or programmatic reference to a URI in the set of web pages being evaluated, check if the referenced web page contains code (e.g., meta element or script) that causes a client-side redirect. For each link or programmatic reference to a URI in the set of web pages being evaluated, check if the referenced URI does not cause a redirect OR causes a server-side redirect without a time-out. Expected Results Check #2 is false and check #3 is true.

---

## Resources

Resources Use standard redirects: do not break the back button! (W3C QA Tip). RFC 9110: HTTP Semantics 15.4. Redirection 3xx. Interface javax.servlet.http.HttpServletResponse in the Java Servlets 6 API documentation. PHP header. Apache Module mod_alias in the Apache HTTP Server Version 2.4 Documentation describes how redirects can be specified in Apache 2.4.

---

**Keywords**: accessibility, wcag, technique, server-side-script, svr1  
**Last Updated**: 2026-02-10
