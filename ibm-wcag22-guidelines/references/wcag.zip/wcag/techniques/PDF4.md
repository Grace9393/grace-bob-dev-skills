# PDF4 - Hiding decorative images with the Artifact tag in PDF documents

**Technique ID**: PDF4  
**Technology**: pdf

---

## Description

Description The purpose of this technique is to show how purely decorative images in PDF documents can be marked so that they can be ignored by Assistive Technology by using the /Artifact tag. This is typically accomplished by using a tool for authoring PDF. In PDF, artifacts are generally graphics objects or other markings that are not part of the authored content. Examples of artifacts include page header or footer information, lines or other graphics separating sections of the page, or decorative images.

---

## Applicability

When to Use Tagged PDF documents

---

## Procedure

Procedure For an image that is purely decorative, use one of the following to verify that it is marked as an artifact: Read the PDF document with a screen reader, listening to hear that the decorative image is not announced when reading the content line-by-line. Using a PDF editor, make sure the decorative image is marked as an artifact. Reflow the document and make sure the decorative image does not appear on the page. Use a tool that is capable of showing the /Artifact entry or property list, such as aDesigner, to open the PDF document and verify that decorative images are marked as artifacts. Use a tool that exposes the document through the accessibility API and verify that the decorative image is not exposed through the API.

---

## Examples

Examples Marking an image as an artifact using Acrobat Pro's TouchUp Reading Order Tool This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. The TouchUp Reading Order Tool can be used to mark an image as "Background / Artifact", which removes it from the document tag structure. Open the TouchUp Reading Order Tool in Acrobat Pro: Accessibility → TouchUp Reading Order Select the decorative image in the document In the TouchUp Reading Order Tool, click the Background/Artifact button to remove the selected image from the tag structure This example is shown in operation in the working example of creating a decorative image (Word file) and working example of marking a background image as an artifact (PDF file). Marking an image as an artifact in a PDF document using an /Artifact tag or property list The PDF specification allows images to be marked as "artifacts". An artifact is explicitly distinguished from real content by enclosing it in a marked-content sequence with the /Artifact tag. /Artifact <code class="no-highlight">BMC ... EMC</code> or /Artifact propertyList <code class="no-highlight">BDC ... EMC</code> The first is used to identify a generic artifact; the second is used for artifacts that have an associated property list. Note, to aid in text reflow, artifacts should be defined with property lists whenever possible. Artifacts lacking a specified bounding box are likely to be discarded during reflow. Property list entries for artifacts include Type, BBox, Attached, and Subtype.

---

## Tests

Tests Procedure For an image that is purely decorative, use one of the following to verify that it is marked as an artifact: Read the PDF document with a screen reader, listening to hear that the decorative image is not announced when reading the content line-by-line. Using a PDF editor, make sure the decorative image is marked as an artifact. Reflow the document and make sure the decorative image does not appear on the page. Use a tool that is capable of showing the /Artifact entry or property list, such as aDesigner, to open the PDF document and verify that decorative images are marked as artifacts. Use a tool that exposes the document through the accessibility API and verify that the decorative image is not exposed through the API. Expected Results #1 is true.

---

## Resources

Resources Section 14.8.2.2 (Real Content and Artifacts) in PDF 1.7 (ISO 32000-1) (PDF) Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf4  
**Last Updated**: 2026-02-10
