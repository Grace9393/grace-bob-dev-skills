# SVR2 - Using .htaccess to ensure that the only way to access non-conforming content is from conforming content

**Technique ID**: SVR2  
**Technology**: server-side-script

---

## Description

Description The objective of this technique is to ensure that users can always access an accessible version of the content when non-conforming versions are also available. Whenever content is provided in a format that does not conform to WCAG, the site as a whole can still conform if alternate versions of the inaccessible content are provided. Conformance Requirement 4 requires that alternate versions can be derived from the nonconforming content or from its URI. Since it is not always possible to provide an accessible link from within non-conforming content, this technique describes how authors can use Apache's Module "mod_access" to ensure that non-conforming content can only be accessed from URIs that serve as alternate versions to the non-conforming content or from pages that include links to both the non-conforming version and the alternative version.

---

## Applicability

When to Use Content residing on a web server that supports .htaccess (typically Apache) where a conforming version of content is provided as an alternative to a non-conforming version.

---

## Procedure

Procedure Identify pages that do not conform to WCAG at the conformance Level claimed where accessible alternatives are served based on the use of .htaccess files. Visit the URI of the non-conforming content. Verify that the resulting page is one of the following: a conforming alternate version for the non-conforming content a page that includes a link to both the conforming alternate version and the non-conforming content

---

## Examples

Examples Using Apache's mod_redirect module to redirect requests The following .htaccess file uses Apache's mod_redirect module to redirect requests for "inaccessible.html" to "accessible.html" unless the request comes from "accessible.html". <code class="language-apache"># If the request for inaccessible content comes from a file # called accessible.html, then set an environment variable that # allows the inaccessible version to be displayed. SetEnvIf Referer .*(accessible.html)$ let_me_in <FilesMatch ^(inaccessible.html)$> Order Deny,Allow Deny from all Allow from env=let_me_in </FilesMatch> # If the request comes from anyplace but accessible.html, then # redirect the error condition to a location where the accessible # version resides ErrorDocument 403 /example_directory/accessible.html</code> Redirecting direct requests for files This example assumes a directory structure where documents are available in multiple formats. One of the formats does not meet WCAG at the level claimed and uses the file extension "jna" (Just Not Accessible). All of these files are stored in a folder called "jna" with an .htaccess file which ensures that any direct request for a file with the .jna extension from pages where inaccessible versions are not already available is redirected to an index page that lists all of the available formats. <code class="language-apache"># If the request for inaccessible content comes from a file at # https://example.com/documents/index.html, then set an environment # variable that allows the inaccessible version to be displayed. SetEnvIf Referer ^https://example.com/documents/index.html$ let_me_in <FilesMatch ^(.*\.jna)$> Order Deny,Allow Deny from all Allow from env=let_me_in </FilesMatch> # If the request comes from anyplace but https://example.com/documents/index.html, then # redirect the error condition to a location where a link the accessible # version resides ErrorDocument 403 https://example.com/documents/index.html</code>

---

## Tests

Tests Procedure Identify pages that do not conform to WCAG at the conformance Level claimed where accessible alternatives are served based on the use of .htaccess files. Visit the URI of the non-conforming content. Verify that the resulting page is one of the following: a conforming alternate version for the non-conforming content a page that includes a link to both the conforming alternate version and the non-conforming content Expected Results Check #3.1 or #3.2 is true.

---

## Resources

Resources Apache Module mod_env Authentication, Authorization and Access Control Apache Tutorial: .htaccess files

---

**Keywords**: accessibility, wcag, technique, server-side-script, svr2  
**Last Updated**: 2026-02-10
