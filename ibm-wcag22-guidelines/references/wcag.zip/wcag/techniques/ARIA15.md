# ARIA15 - Using aria-describedby to provide descriptions of images

**Technique ID**: ARIA15  
**Technology**: aria

---

## Description

Description The objective of this technique is to provide descriptions of images when a short text alternative does not adequately convey the function or information provided in the object. A feature of WAI-ARIA is the ability to associate descriptive text with a section, drawing, form element, picture, and so on using the aria-describedby property. Descriptive text provided using aria-describedby is separate from the short name provided using the alt attribute in HTML. An advantage of providing long descriptions using content from the same page as the image is that the alternative is available to all, including sighted people who do not have assistive technology. Like aria-labelledby, aria-describedby can accept multiple ids to point to other regions of the page using a space separated list. It is also limited to ids for defining these sets.

---

## Applicability

When to Use Technologies that support Accessible Rich Internet Applications (WAI-ARIA).

---

## Procedure

Procedure Examine each image element where a aria-describedby attribute is present. Examine whether the aria-describedby attribute programmatically associates an element with its text description, via the id attribute on the element where the text to be used as the description is found. Examine whether the combined text equivalent and associated text description accurately describe or provide the equivalent purpose to the object.

---

## Examples

Examples Describing an image The following example shows how aria-describedby can be applied to an image to provide a long description, where that text description is on the same page as the image. <code class="language-html"><img src="ladymacbeth.jpg" alt="Lady MacBeth" aria-describedby="p1"> <p id="p1">This painting dates back to 1889 and is oil on canvas. It was created by John Singer Sargent, and represents ...</p></code>

---

## Tests

Tests Procedure Examine each image element where a aria-describedby attribute is present. Examine whether the aria-describedby attribute programmatically associates an element with its text description, via the id attribute on the element where the text to be used as the description is found. Examine whether the combined text equivalent and associated text description accurately describe or provide the equivalent purpose to the object. Expected Results #1, #2, and #3 are true.

---

## Resources

Resources WAI-ARIA Authoring Practices Guide HTML to Platform Accessibility APIs Implementation Guide: Accessible Name and Description Calculation

---

**Keywords**: accessibility, wcag, technique, aria, aria15  
**Last Updated**: 2026-02-10
