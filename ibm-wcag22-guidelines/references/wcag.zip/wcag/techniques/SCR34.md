# SCR34 - Calculating size and position in a way that scales with text size

**Technique ID**: SCR34  
**Technology**: client-side-script

---

## Description

Description The objective of this technique is to calculate the size and position of elements in a way that will scale appropriately as the text size is scaled. There are four properties in JavaScript that help determine the size and position of elements: offsetHeight (the height of the element in pixels) offsetWidth (the width of the element in pixels) offsetLeft (the distance of the element from the left of its parent (offsetParent) in pixels) offsetTop (the distance of the element from the top of its parent (offsetParent) in pixels) Calculating the height and width using offsetHeight and offsetWidth is straightforward, but when calculating an object's left and top position as absolute values, we need to consider the parent element. The calculatePosition function below iterates through all of an element's parent nodes to give a final value. The function takes two parameters: objElement (the name of the element in question), and the offset property (offsetLeft or offsetTop):

---

## Applicability

When to Use Client-side scripting.

---

## Procedure

Procedure Open a page that is designed to adjust container sizes as text size changes. Increase the text size up to 200% using the browser's text size adjustment (not the zoom feature). Examine the text to ensure the text container size is adjusted to accommodate the size of the text. Ensure that no text is "clipped" or has disappeared as a result of the increase in text size.

---

## Examples

Examples Calculating the size and position of elements in a way that will scale appropriately as the text size is scaled <code class="language-javascript">function calculatePosition(objElement, strOffset { var iOffset = 0; if (objElement.offsetParent) { do { iOffset += objElement[strOffset]; objElement = objElement.offsetParent; } while (objElement); } return iOffset; }</code> The following example illustrates using the function above by aligning an object beneath a reference object, the same distance from the left: <code class="language-javascript">// Get a reference object var objReference = document.getElementById('refobject'); // Get the object to be aligned var objAlign = document.getElementById('lineup'); objAlign.style.position = 'absolute'; objAlign.style.left = calculatePosition(objReference, 'offsetLeft') + 'px'; objAlign.style.top = calculatePosition(objReference, 'offsetTop') + objReference.offsetHeight + 'px'; </code>

---

## Tests

Tests Procedure Open a page that is designed to adjust container sizes as text size changes. Increase the text size up to 200% using the browser's text size adjustment (not the zoom feature). Examine the text to ensure the text container size is adjusted to accommodate the size of the text. Ensure that no text is "clipped" or has disappeared as a result of the increase in text size. Expected Results Checks #3 and #4 are true.

---

## Resources

No additional resources.

---

**Keywords**: accessibility, wcag, technique, client-side-script, scr34  
**Last Updated**: 2026-02-10
