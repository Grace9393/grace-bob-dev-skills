# W## - Using role=log to identify sequential information updates

**Technique ID**: W##  
**Technology**: aria

---

## Description

Description The purpose of this technique is to notify Assistive Technologies (AT) when content has been appended to sequential information concerning the application's history or logs. The aria live region role of log has an implicit aria-live value of polite and aria-atomic value of false, which allows a user to be notified via AT (such as a screen reader) when log messages are added. The new content within the aria-live region is automatically read by the AT, without the AT having to focus on the place where the text is displayed. See WAI-ARIA 1.1 log (role) for more details.

---

## Applicability

When to Use

---

## Procedure

Procedure On a page that contains sequentially updating information: Check that the container for the information is given a role of log.

---

## Examples

Examples Updating the contents of a chat conversation Comments that users type into a chat input field are appended to the end of the chat history region. The region is marked with role="log" so that new additions are announced by ATs. When each new chat message appears, a screen reader should announce its content (depending on AT/browser compatibility). <code class="language-html"><div id="chatRegion" role="log" aria-labelledby="chatHeading"> <h4 id="chatHeading">Chat History</h4> <ul id="conversation"> <li>The latest chat message</li> </ul> </div></code> Working example: using role="log" with chat conversation Updating the log of a server An application log records time-stamped activities. The log is exposed in the app as a view, with the region marked with role="log" so that the new additions are announced by the ATs. (The default value for the aria-relevant attribute is "additions", so the removal of the old top entries due to log size limitations will not be announced.) When each new log entry is added, a screen reader announces it. <code class="language-html"><div id="activityLog" role="log"> <h4 id="logHeading">Recent activity</h4> <ul id="logentries""> <li>08:03 UserX logged off</li> </ul> </div></code> Working example: using role="log" with server log

---

## Tests

Tests Procedure On a page that contains sequentially updating information: Check that the container for the information is given a role of log. Expected Results #1 is true.

---

## Resources

No additional resources.

---

**Keywords**: accessibility, wcag, technique, aria, w##  
**Last Updated**: 2026-02-10
