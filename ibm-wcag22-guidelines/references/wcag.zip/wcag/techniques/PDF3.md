# PDF3 - Ensuring correct tab and reading order in PDF documents

**Technique ID**: PDF3  
**Technology**: pdf

---

## Description

Description The intent of this technique is to ensure that users can navigate through content in a logical order that is consistent with the meaning of the content. Correct tab and reading order is typically accomplished using a tool for authoring PDF. For sighted users, the logical order of PDF content is also the visual order on the screen. For keyboard and assistive technology users, the tab order through content, including interactive elements (form fields and links), determines the order in which these users can navigate the content. The tab order must reflect the logical order of the document. Logical structure is created when a document is saved as tagged PDF. The reading order of a PDF document is determined primarily by the tag order of document elements, including interactive elements, but the order of content within individual tags is determined by the PDF document's content tree structure. If the reading order is not correct, keyboard and assistive technology users may not be able to understand the content. For example, some documents use multiple columns, and the reading order is clear visually to sighted users as flowing from the top to the bottom of the first column, then to the top of the next column. But if the document is not properly tagged, a screen reader may read the document from top to bottom, across both columns, interpreting them as one column. The simplest way to ensure correct reading order is to structure the document correctly in the authoring tool used to create the document, before conversion to tagged PDF. Note, however, that pages with complex layouts with graphics, tables, footnotes, side-bars, form fields, and other elements may not convert to tagged PDF in the correct reading order. These inconsistencies must then be corrected with repair tools such as Acrobat Pro. When a PDF document containing form fields has a correct reading order, all form fields are contained in the tab order in the appropriate order, and in the correct order relative to other content in the PDF. Common tab-order errors include: Form fields missing from the tagged content. Form fields in the wrong location in the PDF content; e.g., at the end of non-interactive content.

---

## Applicability

When to Use Tagged PDF documents

---

## Procedure

Procedure Verify that the content is in the correct reading order by one of the following: Read the PDF document with a screen reader or a tool that reads aloud, listening to hear that each element is read in the correct order. Use a tool that exposes the document through the accessibility API, and verify that the reading order is correct. Verify that the tab order is correct for focusable content by one of the following: Use the tab key to traverse the focus order in the document. Use a tool that is capable of showing the page object entry that specifies the tab order setting to open the PDF document and view the setting.

---

## Examples

Examples Creating a 2-column document using Microsoft Word This example is shown with Microsoft Word. There are other software tools that perform similar functions. Multi-column documents created using Word's Layout → Columns tool typically are in the correct reading order when converted to tagged PDF. The following image shows Word's Columns tool. This example is shown in operation in the working example of 2-column document (Word file) and working example of 2-column document using Word (PDF file). Creating a 2-column document using OpenOffice Writer This example is shown with OpenOffice Writer. There are other software tools that perform similar functions. Multi-column documents created using OpenOffice Writer's Columns tool typically are in the correct reading order when converted to tagged PDF. The image below shows Writer's Columns tool. The Columns tool can be found under Format. This example is shown in operation in the working example of 2-column document using OpenOffice Writer (OpenOffice file) and working example of 2-column document using OpenOffice Writer (PDF file). Setting the tab order for one or more pages using Adobe Acrobat Pro In a tagged PDF document: Open Organize Pages tool. Select one or more page thumbnails. Right-click to access the context menu for the selected thumbnail(s) and select Page Properties. Select the Tab Order tab in the Page Properties dialog. If needed, select a tab order option: Option Description Use Row Order Tabs from the upper left field, moving first left to right and then down, one table row at a time. Use Column Order Tabs from the upper left field, moving first from top to bottom and then across from left to right, one table column at a time. Use Document Structure For tagged documents, moves in the tag order specified by the authoring application. This is usually the correct reading order and will be selected by default for tagged documents. Unspecified If the document was created using an earlier version of Acrobat Pro, the tab order is Unspecified by default. With this setting, form fields are tabbed through first, followed by links and then comments ordered by row. This may not be correct reading order. This example is shown in operation in the working example of setting the tab order (Word file) and working example of setting the tab order (PDF file). Repairing the reading order using the Tags panel in Adobe Acrobat Pro This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. Use the Tags panel to correct the reading order. Either: Drag and drop a tag to its required position, or Cut a tag and paste it to its required position.

---

## Tests

Tests Procedure Verify that the content is in the correct reading order by one of the following: Read the PDF document with a screen reader or a tool that reads aloud, listening to hear that each element is read in the correct order. Use a tool that exposes the document through the accessibility API, and verify that the reading order is correct. Verify that the tab order is correct for focusable content by one of the following: Use the tab key to traverse the focus order in the document. Use a tool that is capable of showing the page object entry that specifies the tab order setting to open the PDF document and view the setting. Expected Results #1 and Check #2 are true.

---

## Resources

Resources Section 14.8 (Tagged PDF) in PDF 1.7 (ISO 32000-1) (PDF) Acrobat and Accessibility Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf3  
**Last Updated**: 2026-02-10
