# PDF16 - Setting the default language using the /Lang entry in the document catalog of a PDF document

**Technique ID**: PDF16  
**Technology**: pdf

---

## Description

Description The objective of this technique is to specify a document's default language by setting the /Lang entry in the document catalog. This is normally accomplished using a tool for authoring PDF. Both assistive technologies and conventional user agents can render text more accurately when the language of the document is identified. Screen readers can load the correct pronunciation rules. Visual browsers can display characters and scripts correctly. Media players can show captions correctly. As a result, users with disabilities are better able to understand the content.

---

## Applicability

When to Use Tagged PDF documents

---

## Procedure

Procedure Verify that the default language for the document is correctly specified by applying one of the following: Read the PDF document with a screen reader, listening to hear that the text is read in the correct natural language. Using a PDF editor, check that the language is set to the default document language. Use a tool which is capable of showing the /Lang entry value in the document catalog to open the PDF document and view the language settings. Use a tool that exposes the document through the accessibility API and verify that the language is set to the default language.

---

## Examples

Examples Adding a /Lang entry to specify the default document language using Adobe Acrobat Pro This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. Open the document in Adobe Acrobat Pro From the File menu, select "Properties..." In the "Properties" dialog, select the "Advanced" tab In the "Reading Options" field, select the default language from the "Language" combo box Acrobat includes numerous preset language selections. If you need to specify a language that is not on the list, such as Russian, you must type the ISO 639-2 code for the language, not its name. Specifying the default document language in a PDF document using a /Lang entry The natural language used for text in a document is determined in a hierarchical fashion, based on whether an optional /Lang entry is present in any of several possible locations. At the highest level, the document's default language may be specified by a /Lang entry in the document catalog. The following code fragment illustrates code that is typical for using the /Lang entry in the document catalog for a document's default language (in this case English). (This is typically accomplished by an authoring tool.) <code class="no-highlight">1 0 obj << /Type /Catalog ... /Lang (en) ... >> endobj</code>

---

## Tests

Tests Procedure Verify that the default language for the document is correctly specified by applying one of the following: Read the PDF document with a screen reader, listening to hear that the text is read in the correct natural language. Using a PDF editor, check that the language is set to the default document language. Use a tool which is capable of showing the /Lang entry value in the document catalog to open the PDF document and view the language settings. Use a tool that exposes the document through the accessibility API and verify that the language is set to the default language. Expected Results #1 is true.

---

## Resources

Resources Section 14.9.2 (Natural Language Specification) in PDF 1.7 (ISO 32000-1) (PDF) ISO 639-2 Codes Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf16  
**Last Updated**: 2026-02-10
