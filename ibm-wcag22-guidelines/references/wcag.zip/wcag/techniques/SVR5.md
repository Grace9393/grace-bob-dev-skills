# SVR5 - Specifying the default language in the HTTP header

**Technique ID**: SVR5  
**Technology**: server-side-script

---

## Description

Description The objective of this technique is to provide information on the primary language or languages in a web page, in order to identify the audience of the content. The Content-Language HTTP header can contain a list of one or more language codes, which can be used for language negotiation between a user agent and a server. If the language preferences in a user agent are set correctly, language negotiation can help the user to find a language version of the content that suits their preferences. Note that the Content-Language HTTP header does not serve to identify the language used for processing the content. The content processing language can be identified by means of other techniques, such as the attributes lang and xml:lang in markup languages. This technique ensures that the primary language of the document, as specified for example in the lang or xml:lang attribute, is listed in the Content-Language HTTP header.

---

## Applicability

When to Use Server-side technologies, including server-side scripting languages and server configuration files for setting HTTP headers.

---

## Procedure

Procedure Use a Live HTTP Header viewer to find the value of the Content-Language header. Check that this value matches the default language of the web page.

---

## Examples

Examples Setting content language in Java Servlet and JSP In Java Servlet or JavaServer Pages (JSP), developers can use response.setHeader("Content-Language", lang), in which "lang" stands for a language tag (for example, "en" for English): <code class="language-java">... public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { ... response.setHeader("Content-Language", "en"); PrintWriter out = response.getWriter(); ... }</code> Setting content language in PHP In PHP, developers can send a raw HTTP header with the header method. The following example sets the language to French: <code class="language-php"><?php header('Content-language: fr'); ... ?></code>

---

## Tests

Tests Procedure Use a Live HTTP Header viewer to find the value of the Content-Language header. Check that this value matches the default language of the web page. Expected Results Step #2 is true.

---

## Resources

Resources W3C Internationalization FAQ: HTTP and meta for language information Declaring metadata about the language(s) of the intended audience in Authoring HTML: Language declarations - W3C Working Group Note 3 June 2014. RFC 9110, 8.5. Content-Language PHP header.

---

**Keywords**: accessibility, wcag, technique, server-side-script, svr5  
**Last Updated**: 2026-02-10
