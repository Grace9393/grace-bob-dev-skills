# SCR35 - Making actions keyboard accessible by using the onclick event of anchors and buttons

**Technique ID**: SCR35  
**Technology**: client-side-script

---

## Description

Description The objective of this technique is to demonstrate how to invoke a scripting function in a way that is keyboard accessible by attaching it to a keyboard-accessible control. In order to ensure that scripted actions can be invoked from the keyboard, they are associated with "natively actionable" HTML elements (links and buttons). The onclick event of these elements is device independent. While "onclick" sounds like it is tied to the mouse, the onclick event is actually mapped to the default action of a link or button. The default action occurs when the user clicks the element with a mouse, but it also occurs when the user focuses the element and hits enter or space, and when the element is triggered via the accessibility API. This technique relies on client-side scripting. However, it is beneficial to provide a backup implementation or explanation for environments in which scripting is not available. When using anchor elements to invoke a JavaScript action, a backup implementation or explanation is provided via the href attribute. When using buttons, it is provided via a form post.

---

## Applicability

When to Use Script used with HTML.

---

## Procedure

Procedure For all script actions associated with a, button, or input elements: In a user agent that supports Scripting Click on the control with the mouse. Check that the scripting action executes properly. If the control is an anchor element, check that the URI in the href attribute of the anchor element is not invoked. Check that it is possible to navigate to and give focus to the control via the keyboard. Set keyboard focus to the control. Check that pressing ENTER invokes the scripting action. If the control is an anchor element, check that the URI in the href attribute of the anchor element is not invoked. In a user agent that does not support Scripting Click on the control with the mouse. If the control is an anchor element, check that the URI in the href attribute of the anchor element is invoked. Check that it is possible to navigate to and give focus to the control via the keyboard. Set keyboard focus to the control. If the control is an anchor element, check that pressing ENTER invokes the URI of the anchor element's href attribute.

---

## Examples

Examples Link that runs a script and has no fallback for non-scripted browsers This approach should only be used when script is relied upon as an Accessibility Supported Technology. Even though we do not want to navigate from this link, we must use the href attribute on the a element in order to make this a true link and get the proper eventing. In this case, we're using href="#" as the link target, but you could use anything. This link will never be navigated. The "return false;" at the end of the doStuff() event handling function tells the browser not to navigate to the URI. Without it, the page would refresh after the script ran. <code class="language-html"><script> function doStuff() { //do stuff return false; } </script> <a href="#" onclick="return doStuff();">do stuff</a></code> Link that runs script, but navigates to another page when script is not available This approach can be used to create sites that don't rely on script, if and only if the navigation target provides the same functionality as the script. This example is identical to the example 1, except that its href is now set to a real page, dostuff.html. The dostuff.html page must provide the same functionality as the script. The "return false;" at the end of the doStuff() event handling function tells the browser not to navigate to the URI. Without it, the browser would navigate to dostuff.html after the script ran. <code class="language-html"><script> function doStuff() { //do stuff return false; } </script> <a href="dostuff.html" onclick="return doStuff();">do stuff</a></code> A working example of this code is available. Refer to Creating Action Links using JavaScript. Button that runs a script and falls back to a form post for users without script This approach can be used by sites that do not rely on script, if and only if the form post provides the same functionality as the script. The onsubmit="return false;" prevents the form from submitting. <code class="language-html"><script> function doStuff() { //do stuff } </script> <form action="doStuff.aspx" onsubmit="return false;"> <input type="submit" value="Do Stuff" onclick="doStuff();"> </form></code> A working example of this code is available. Refer to Creating Action Buttons using JavaScript. Button that runs a script, implemented with input type="image" Note that an alt attribute must be added to the input to provide a text equivalent for the image. This approach should only be used when script is relied upon. <code class="language-html"><script> function doStuff() { //do stuff return false; } </script> <input type="image" src="stuff.gif" alt="Do stuff" onclick="return doStuff();"></code> Button that runs a script, implemented with input type="submit", input type="reset" or input type="button" This approach should only be used when script is relied upon. <code class="language-html"><input type="submit" onclick="return doStuff();" value="Do Stuff"></code> Button that runs a script, implemented with button This is valuable when you want more control over the look of your button. In this particular example, the button contains both an icon and some text. This approach should only be used when script is relied upon. <code class="language-html"><button onclick="return doStuff();"> <img src="stuff.gif" alt="stuff icon"> Do Stuff </button></code>

---

## Tests

Tests Procedure For all script actions associated with a, button, or input elements: In a user agent that supports Scripting Click on the control with the mouse. Check that the scripting action executes properly. If the control is an anchor element, check that the URI in the href attribute of the anchor element is not invoked. Check that it is possible to navigate to and give focus to the control via the keyboard. Set keyboard focus to the control. Check that pressing ENTER invokes the scripting action. If the control is an anchor element, check that the URI in the href attribute of the anchor element is not invoked. In a user agent that does not support Scripting Click on the control with the mouse. If the control is an anchor element, check that the URI in the href attribute of the anchor element is invoked. Check that it is possible to navigate to and give focus to the control via the keyboard. Set keyboard focus to the control. If the control is an anchor element, check that pressing ENTER invokes the URI of the anchor element's href attribute. Expected Results All of the above checks are true.

---

## Resources

Resources HTML - the script element HTML - Forms HTML - the a element

---

**Keywords**: accessibility, wcag, technique, client-side-script, scr35  
**Last Updated**: 2026-02-10
