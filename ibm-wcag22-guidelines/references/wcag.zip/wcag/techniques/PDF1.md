# PDF1 - Applying text alternatives to images with the Alt entry in PDF documents

**Technique ID**: PDF1  
**Technology**: pdf

---

## Description

Description The objective of this technique is to provide text alternatives for images via an /Alt entry in the property list for a Tag. This is normally accomplished using a tool for authoring PDF. PDF documents may be enhanced by providing alternative descriptions for images, formulas, and other items that do not translate naturally into text. In fact, such text alternatives are required for accessibility: alternate descriptions are human-readable text that can be vocalized by text-to-speech technology for the benefit of users with vision disabilities. When an image contains words that are important to understanding the content, the text alternative should include those words. This will allow the alternative to accurately represent the image. Note that it does not necessarily describe the visual characteristics of the image itself but must convey the same meaning as the image.

---

## Applicability

When to Use Tagged PDF documents with images

---

## Procedure

Procedure For all images which need equivalents: Verify the images have /Alt entries on an enclosing tag by one of the following: Read the PDF document with a screen reader, listening to hear that the equivalent text is read when tabbing to the non-text object (if it is tabbable) or hearing the alternative text read when reading the content line-by-line. Using a PDF editor, check that a text alternative is displayed for each image. Use a tool which is capable of showing the /Alt entry value, such as aDesigner, to open the PDF document and view the GUI summary to read the text alternatives for images. Use a tool that exposes the document through the accessibility API and verify that images have required text equivalents.

---

## Examples

Examples Adding alt text to an image in Adobe Acrobat DC Pro This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. Open the Accessibility panel via the Tools → Accessibility options. Select the image in the document and select the "Set Alternative Text" option in the Accessibility tools panel. In the Set Alternative Text dialog that appears, type in your alternative text, then press the Save & Close button. This example is shown in operation in the working example of Adding an /Alt entry to an image. Adding alt text to an image in Microsoft Word Right-click on the image and choose View Alt Text Type the alternative text into the text box provided. Adding alt text to an image in OpenOffice with the Writer add-on This example is shown with Open Office Writer. There are other software tools that perform similar functions. Select "Insert" then "picture", select the image to be inserted Right click on the mouse Select "Description" Enter a text title and a good text description Click OK. Adding a text alternative to an image in a PDF document using an /Alt entry The /Alt property used on an image of mountains with a moon and trees typically would be used like this (typically accomplished by an authoring tool): <code class="no-highlight">/Figure <</Alt (Sketch of Mountains with moon rising over trees)>></code> The image might also be represented by a tag with a different name. A different name might be used because the tag name is written in a language other than English or because a specific tool uses a different name for some other reason. In this situation, it is also necessary that the RoleMap contained within the StructTreeRoot for the PDF document contain an entry which explicitly maps the name of the tag used for the image with the standard structure type used in PDF documents (in this case, Figure). If the RoleMap contains only an entry mapping Shape tags to Figure tags, the rolemap information would appear as follows: <code class="no-highlight">/RoleMap << /Shape /Figure >></code> In this case, the usage of the /Alt entry as follows would also be correct: <code class="no-highlight">/Shape <</Alt (Crater Lake in the summer, with the blue sky, clouds and crater walls perfectly reflected in the lake) >></code> Note that the /Alt entry in property lists can be combined with other entries.

---

## Tests

Tests Procedure For all images which need equivalents: Verify the images have /Alt entries on an enclosing tag by one of the following: Read the PDF document with a screen reader, listening to hear that the equivalent text is read when tabbing to the non-text object (if it is tabbable) or hearing the alternative text read when reading the content line-by-line. Using a PDF editor, check that a text alternative is displayed for each image. Use a tool which is capable of showing the /Alt entry value, such as aDesigner, to open the PDF document and view the GUI summary to read the text alternatives for images. Use a tool that exposes the document through the accessibility API and verify that images have required text equivalents. Expected Results Check #1 is true.

---

## Resources

Resources Section 14.9.4 (Replacement Text) in PDF 1.7 (ISO 32000-1) (PDF) Acrobat and Accessibility Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf1  
**Last Updated**: 2026-02-10
