# SCR28 - Using an expandable and collapsible menu to bypass block of content

**Technique ID**: SCR28  
**Technology**: client-side-script

---

## Description

Description This technique allows users to skip repeated material by placing that material in a menu that can be expanded or collapsed under user control. The user can skip the repeated material by collapsing the menu. The user invokes a user interface control to hide or remove the elements of the menu. The resources section lists several techniques for menus, toolbars and trees, any of which can be used to provide a mechanism for skipping navigation. Similar approaches can be implemented using server-side scripting and reloading a modified version of the web page.

---

## Applicability

When to Use Technologies that provide client side scripting.

---

## Procedure

Procedure Check that some user interface control allows the repeated content to be expanded or collapsed. Check that when the content is expanded, it is included in the programmatically determined content at a logical place in the reading order. Check that when the content is collapsed, it is not part of the programmatically determined content.

---

## Examples

Examples Toggling a table of contents The table of contents for a set of web pages is repeated near the beginning of each web page. A button at the beginning of the table of contents lets the user remove or restore it on the page. <code class="language-html">... <script> let tocToggle = document.querySelector(".toc-toggle"); let toc = document.querySelector("#toc"); tocToggle.addEventListener("click", toggle, false); function toggle(e){ let elm = e.currentTarget; if(elm.getAttribute("aria-expanded") === "false"){ elm.setAttribute("aria-expanded", "true"); } else{ elm.setAttribute("aria-expanded", "false"); } } </script> ... <button aria-controls="toc" aria-expanded="true" class="toc-toggle" type="button"> Toggle Table Of Contents </button> <nav aria-labelledby="toc-header" id="toc"> <h2 id="toc-header">Table of Contents</h2> <ul> <li><a href="#sec1">Section 1</a></li> <li><a href="#sec2">Section 2</a></li> <li><a href="#sec3">Section 3</a></li> <li><a href="#sec4">Section 4</a></li> </ul> </nav> ...</code> Working example of this code: Toggle table of contents with a button.

---

## Tests

Tests Procedure Check that some user interface control allows the repeated content to be expanded or collapsed. Check that when the content is expanded, it is included in the programmatically determined content at a logical place in the reading order. Check that when the content is collapsed, it is not part of the programmatically determined content. Expected Results All checks above are true.

---

## Resources

Resources ARIA - Disclosure (Show/Hide) pattern.

---

**Keywords**: accessibility, wcag, technique, client-side-script, scr28  
**Last Updated**: 2026-02-10
