# PDF21 - Using List tags for lists in PDF documents

**Technique ID**: PDF21  
**Technology**: pdf

---

## Description

Description The intent of this technique is to create lists of related items using list elements appropriate for their purposes. PDF files containing lists are normally created or repaired using a tool for authoring PDF. When markup is used that visually formats items as a list but does not indicate the list relationship, users may have difficulty navigating the information. An example of such visual formatting is simply using line-breaks to separate list items. Some assistive technologies allow users to navigate from list to list or item to item. If the lists are not correctly formatted with list tags, these users will have difficulty understanding the list content. The easiest way to create lists in PDF content is to format them properly using list markup in the authoring tool, for example, Microsoft Word or OpenOffice Writer. However, if you do not have access to the source file and authoring tool, you can use Acrobat Pro's Reading Order tool and the Tags panel. The structure types for lists in PDF documents are: L - the List tag, which contains one or more LI tags. LI - the List Item tag. List item tags can contain Lbl and LBody tags. Lbl - the list item label. Contains distinguishing information such as a item number or bullet character. LBody - the list item body. Contains list item content, or in the case of a nested list, it may contain additional List tag trees.

---

## Applicability

When to Use Tagged PDF documents with lists.

---

## Procedure

Procedure For a list in a PDF document, verify in one of the following ways: Read the PDF document with a screen reader, listening to hear that list is read correctly when reading the content line-by-line. Use a tool that is capable of showing lists to open the PDF document and view the list to check that it is correctly structured. Inspect the tag tree to verify that the list is structured according to the PDF specification. Use a tool that exposes the document through the accessibility API and verify that the list is correctly structured.

---

## Examples

Examples Adding lists to Microsoft Word documents This example is shown with Microsoft Word. There are other software tools that perform similar functions. On the Home ribbon, use the lists tools to create or repair lists in Word documents. This is the easiest way to ensure that lists are formatted correctly when they are converted to PDF. Adding lists to OpenOffice Writer documents This example is shown with OpenOffice Writer. There are other software tools that perform similar functions. Use the Bullets and Numbering tool to create or repair lists in OpenOffice Writer documents. This is the easiest way to ensure that lists are formatted correctly when they are converted to PDF. Ensuring that lists are correctly formatted using Adobe Acrobat Pro This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. View → Navigation Panels... → Accessibility Tags Inspect the lists in the document to determine which, if any, are not formatted properly. In the following image, the third list is formatted as text. The list items are separated only by line-breaks. Assistive technology may not be able to render the list intelligibly for users. To repair the list, use the Tags panel to create list tags in the content. The following image shows the resulting first list item correctly formatted. This example, with two list items not nested inside the list element, is shown in the working example of ensuring lists are properly formatted.

---

## Tests

Tests Procedure For a list in a PDF document, verify in one of the following ways: Read the PDF document with a screen reader, listening to hear that list is read correctly when reading the content line-by-line. Use a tool that is capable of showing lists to open the PDF document and view the list to check that it is correctly structured. Inspect the tag tree to verify that the list is structured according to the PDF specification. Use a tool that exposes the document through the accessibility API and verify that the list is correctly structured. Expected Results #1 is true

---

## Resources

Resources Section 14.8.4.3.3 (List Elements) in PDF 1.7 (ISO 32000-1) (PDF) Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf21  
**Last Updated**: 2026-02-10
