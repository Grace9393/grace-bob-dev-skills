# PDF15 - Providing submit buttons with the submit-form action in PDF forms

**Technique ID**: PDF15  
**Technology**: pdf

---

## Description

Description The objective of this technique is to provide a mechanism that allows users to explicitly request a change of context using the submit-form action in a PDF form. The intended use of a submit button is to generate an HTTP request that submits data entered in a form, so it is an appropriate control to use for causing a change of context. In PDF documents, submit buttons are normally implemented using a tool for authoring PDF.

---

## Applicability

When to Use Tagged PDF documents with forms.

---

## Procedure

Procedure For each page that submits a form, visually verify that the form contains a submit button and check one of the following: Tab to the button and check that it submits the form in response to user action to select the button. Open the PDF document with a tool that is capable of showing the submit-form action and check that the button action is to submit the form.

---

## Examples

Examples Adding a submit button using Adobe Acrobat Pro This example is shown with Adobe Acrobat Pro. There are other software tools that perform similar functions. Select the Prepare Form tool. Using the Prepare Form toolbar, add a button to the form. Select the button and access the context menu and select the Properties... menu item. In the General tab, provide a Name. This will be used by any JavaScript scripting, so should be a value that can be assigned to a variable. In the General tab, provide a tooltip for the button. In the Options tab, choose an option in the Layout menu for the button label, icon image, or both. Then, type text in the Label box to identify the button as a submit button and/or click Choose Icon and locate the image file you want to use. In the Actions tab: For Select Trigger, choose Mouse Up. (The Mouse Up event is keyboard accessible and, in addition, ensures that the button will not change context unexpectedly, as it might with with a Mouse Enter event.) For Select Action, choose Submit A Form. Click Add. In the Add dialog, enter a URL to collect data on a server or collect form data as email attachments. Adding a script action to a submit button in a PDF document using JavaScript The following JavaScript code illustrates the use of a script to specify the submit-form action. To add this script to the form field: Open the Button Properties dialog, as shown in Example 1, and select the Actions tab Select Run a JavaScript from the drop-down list, and select the Add button Enter JavaScript code in the JavaScript Editor dialog. This example is shown in operation in the working example of adding a script action to a submit button.

---

## Tests

Tests Procedure For each page that submits a form, visually verify that the form contains a submit button and check one of the following: Tab to the button and check that it submits the form in response to user action to select the button. Open the PDF document with a tool that is capable of showing the submit-form action and check that the button action is to submit the form. Expected Results #1 is true for each page that contains a form.

---

## Resources

Resources Section 12.7.5.2 (Submit-Form Action) in PDF 1.7 (ISO 32000-1) (PDF) Create and verify PDF accessibility (Acrobat Pro)

---

**Keywords**: accessibility, wcag, technique, pdf, pdf15  
**Last Updated**: 2026-02-10
