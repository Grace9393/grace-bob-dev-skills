# SCR31 - Using script to change the background color or border of the element with focus

**Technique ID**: SCR31  
**Technology**: client-side-script

---

## Description

Description This purpose of this technique is to allow the author to use JavaScript to apply CSS, in order to make the focus indicator more visible than it would ordinarily be. When an element receives focus, the background color or border is changed to make it visually distinct. When the element loses focus, it returns to its normal styling. This technique can be used on any HTML user agent that supports Script and CSS, regardless of whether it supports the :focus pseudo class.

---

## Applicability

When to Use HTML CSS, script

---

## Procedure

Procedure Tab to each element in the page Check that the focus indicator is visible

---

## Examples

Examples In this example, when the link receives focus, its background turns yellow. When it loses focus, the yellow is removed. Note that if the link had a background color to begin with, you would use that color rather than "" in the script. <code class="language-html"><script>function toggleFocus(el) { el.style.backgroundColor = el.style.backgroundColor=="yellow" ? "inherit" : "yellow"; } </script> ... <a href="example.html" onfocus="toggleFocus(this)" onblur="toggleFocus(this)">focus me</a> ...</code>

---

## Tests

Tests Procedure Tab to each element in the page Check that the focus indicator is visible Expected Results Step #2 is true

---

## Resources

No additional resources.

---

**Keywords**: accessibility, wcag, technique, client-side-script, scr31  
**Last Updated**: 2026-02-10
