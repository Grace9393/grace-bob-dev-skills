# WCAG Knowledge Base

Wiki-style markdown documentation for WCAG 2.2 guidelines.

## Structure

```
wcag/
├── index.md                      # Main index (like wiki home)
├── principles/                   # 4 principle documents
├── guidelines/                   # 13 guideline documents
├── success-criteria/             # 87 success criteria documents
├── techniques/                   # 440 technique documents
└── examples/                     # 10 working example documents
```

## Usage

1. **Start with `index.md`** - Main overview with all principles
2. **Navigate to specific files** - Click links to drill down
3. **Follow cross-references** - Each document links to related content

## Statistics

- **Principles**: 4
- **Guidelines**: 13
- **Success Criteria**: 87
- **Techniques**: 440
- **Working Examples**: 10

## Benefits

✅ Human-readable markdown format  
✅ Easy navigation with hyperlinks  
✅ Small file sizes for quick loading  
✅ Git-friendly for version control  
✅ LLM-optimized structure

## Last Updated

2026-02-10
