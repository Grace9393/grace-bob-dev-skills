# Example of Simple Radio Button Group

**Example ID**: example1  
**Source File**: label-in-name-general/example1.html

---

## Content

Call me when balance exceeds $10,000? Yes No

---

**Keywords**: accessibility, wcag, working-example, example1  
**Last Updated**: 2026-02-10
