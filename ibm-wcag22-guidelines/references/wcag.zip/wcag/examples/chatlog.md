# Using role=log with chat conversation

**Example ID**: chatlog  
**Source File**: aria-role-log/chatlog.html

---

## Content

var counter = 0; var myVar; var onetime = 0; function makeChat () { var chatText = ["Hi!", "Pleased to meet you.", "We'll talk later, okay?", "Bye!"]; var chatContent = document.getElementById("converse"); var list = document.createElement("li") var item = document.createTextNode(chatText[counter]); list.appendChild(item); chatContent.appendChild(list); counter++; if (counter > 3) { clearInterval(myVar); } } function initiateChat () { if (onetime < 1) { document.getElementById("converse").innerHTML += "<li style\=\"text-indent: 100px;\">Hello</li>"; myVar = setInterval(makeChat, 2000); document.getElementById("btn"); btn.disabled = true; onetime++; } else { return false; } } Using role="log" with chat conversation This simple script demonstrates how the conversation region in a chat is updated and surfaced to ATs using the aria log role. Here the role is placed on the region containing the dynamically updating conversation. This is not intended to be a fully-functional chat client, but to demonstrate the use of log role. In this mock demo, the conversation is updated with a brief, one-sided conversation, which is initiated by pressing Send. Conversation Mock input Send

---

**Keywords**: accessibility, wcag, working-example, chatlog  
**Last Updated**: 2026-02-10
