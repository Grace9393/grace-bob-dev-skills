# Semantic Text Markup Example

**Example ID**: index  
**Source File**: semantic-text/index.html

---

## Content

Using Semantic markup to mark emphasized or special text Using the em and strong elements to emphasize text ... What she really meant to say was, "This isn't ok, it is excellent! ... Using the blockquote element to mark up long quotations from another source This example also demonstrates the use of the cite element to specify a reference. The following is an excerpt from the The Story Of My Life by Helen Keller: Even in the days before my teacher came, I used to feel along the square stiff boxwood hedges, and, guided by the sense of smell, would find the first violets and lilies. There, too, after a fit of temper, I went to find comfort and to hide my hot face in the cool leaves and grass. Using the q element to mark up a shorter quotation from another source Helen Keller said, Self-pity is our worst enemy and if we yield to it, we can never do anything good in the world. Using the sup and sub elements to mark up superscripts and subscripts Beth won 1st place in the 9th grade science competition. The chemical notation for water is H2O.

---

**Keywords**: accessibility, wcag, working-example, index  
**Last Updated**: 2026-02-10
