# Using role=log with server logs

**Example ID**: serverlog  
**Source File**: aria-role-log/serverlog.html

---

## Content



---

**Keywords**: accessibility, wcag, working-example, serverlog  
**Last Updated**: 2026-02-10
