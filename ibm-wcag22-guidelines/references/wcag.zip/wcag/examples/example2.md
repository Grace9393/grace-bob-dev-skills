# Example of Stacked Labels

**Example ID**: example2  
**Source File**: label-in-name-general/example2.html

---

## Content

Username New password Must be 10 or more characters, and contain at least one capital, numeric and non-alphanumeric.

---

**Keywords**: accessibility, wcag, working-example, example2  
**Last Updated**: 2026-02-10
