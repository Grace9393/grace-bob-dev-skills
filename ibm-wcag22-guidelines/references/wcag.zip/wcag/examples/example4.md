# Example of Range of Inputs

**Example ID**: example4  
**Source File**: label-in-name-general/example4.html

---

## Content

Rate your response Hated it Loved it

---

**Keywords**: accessibility, wcag, working-example, example4  
**Last Updated**: 2026-02-10
