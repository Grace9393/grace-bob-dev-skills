# Improper use of CSS to create a tabular layout

**Example ID**: styles-removed  
**Source File**: failure-css-positioning/styles-removed.html

---

## Content

Simulated removal of CSS to demonstrate improper use of CSS to create a tabular layout The tablular layout in this example was created via CSS. In this example the style information has been removed from the document. This demonstrates a Failure due to changing the meaning of content by positioning information with CSS since the reading order of the document can not be programmatically determined. Products Locations Telephones Computers Portable MP3 Players Wisconsin Idaho

---

**Keywords**: accessibility, wcag, working-example, styles-removed  
**Last Updated**: 2026-02-10
