# Example of inputs with simplified accessible names

**Example ID**: example3  
**Source File**: label-in-name-general/example3.html

---

## Content

Name * Birth date (YYYY-MM-DD)

---

**Keywords**: accessibility, wcag, working-example, example3  
**Last Updated**: 2026-02-10
